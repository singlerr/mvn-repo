package com.modularmods.mcgltf;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL40;
import org.lwjgl.opengl.GL43;
import org.lwjgl.opengl.GLCapabilities;

import com.modularmods.mcgltf.iris.RenderedGltfModelGL30Iris;
import com.modularmods.mcgltf.iris.RenderedGltfModelGL33Iris;
import com.modularmods.mcgltf.iris.RenderedGltfModelGL40Iris;
import com.modularmods.mcgltf.iris.RenderedGltfModelIris;

import de.javagl.jgltf.model.GltfModel;
import de.javagl.jgltf.model.io.Buffers;
import de.javagl.jgltf.model.io.GltfModelReader;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import simplelibs.SimpleConfig;

public class MCglTF implements ModInitializer {

	public static final String MODID = "mcgltf";
	public static final String RESOURCE_LOCATION = "resourceLocation";

	public static final Logger logger = LogManager.getLogger(MODID);

	private static MCglTF INSTANCE;

	private final EnumRenderedModelGLProfile renderedModelGLProfile;
	private final Map<class_2960, Supplier<ByteBuffer>> loadedBufferResources =
			new HashMap<class_2960, Supplier<ByteBuffer>>();
	private final Map<class_2960, Supplier<ByteBuffer>> loadedImageResources =
			new HashMap<class_2960, Supplier<ByteBuffer>>();
	private final List<IGltfModelReceiver> gltfModelReceivers = new ArrayList<IGltfModelReceiver>();
	private final List<Runnable> gltfRenderData = new ArrayList<Runnable>();
	private int glProgramSkinnig = -1;
	private int defaultColorMap;
	private int defaultNormalMap;
	private class_1044 lightTexture;
	private BooleanSupplier shaderModActive;

	private Function<GltfModel, RenderedGltfModel> gltfModelProcessor;

	public MCglTF() {
		INSTANCE = this;
		renderedModelGLProfile = EnumRenderedModelGLProfile.valueOf(
				SimpleConfig.of(MODID).provider(this::provider).request()
						.getOrDefault("RenderedModelGLProfile", "AUTO"));
	}

	public static MCglTF getInstance() {
		return INSTANCE;
	}

	@Override
	public void onInitialize() {
		Consumer<Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>>>
				processRenderedGltfModelSelector;
		if (FabricLoader.getInstance().isModLoaded("iris")) {
			shaderModActive = net.irisshaders.iris.api.v0.IrisApi.getInstance()::isShaderPackInUse;

			processRenderedGltfModelSelector = (lookup) -> {
				switch (renderedModelGLProfile) {
					case GL43:
						processRenderedGltfModelsGL43Iris(lookup);
						break;
					case GL40:
						processRenderedGltfModelsGL40Iris(lookup);
						break;
					case GL33:
						processRenderedGltfModelsGL33Iris(lookup);
						break;
					case GL30:
						processRenderedGltfModelsGL30Iris(lookup);
						break;
					default:
						GLCapabilities glCapabilities = GL.getCapabilities();
						if (glCapabilities.glTexBufferRange != 0) {
							processRenderedGltfModelsGL43Iris(lookup);
						} else if (glCapabilities.glGenTransformFeedbacks != 0) {
							processRenderedGltfModelsGL40Iris(lookup);
						} else {
							processRenderedGltfModelsGL33Iris(lookup);
						}
						break;
				}
			};

			gltfModelProcessor = (model) -> {
				switch (renderedModelGLProfile) {
					case GL43:
						return processRenderedGltfModelGL43Iris(model);
					case GL40:
						return processRenderedGltfModelGL40Iris(model);
					case GL33:
						return processRenderedGltfModelGL33Iris(model);
					case GL30:
						return processRenderedGltfModelGL30Iris(model);
					default:
						GLCapabilities glCapabilities = GL.getCapabilities();
						if (glCapabilities.glTexBufferRange != 0) {
							return processRenderedGltfModelGL43Iris(model);
						} else if (glCapabilities.glGenTransformFeedbacks != 0) {
							return processRenderedGltfModelGL40Iris(model);
						} else {
							return processRenderedGltfModelGL33Iris(model);
						}
				}
			};

		} else {
			shaderModActive = () -> false;

			processRenderedGltfModelSelector = (lookup) -> {
				switch (renderedModelGLProfile) {
					case GL43:
						processRenderedGltfModelsGL43(lookup);
						break;
					case GL40:
						processRenderedGltfModelsGL40(lookup);
						break;
					case GL33:
						processRenderedGltfModelsGL33(lookup);
						break;
					case GL30:
						processRenderedGltfModelsGL30(lookup);
						break;
					default:
						GLCapabilities glCapabilities = GL.getCapabilities();
						if (glCapabilities.glTexBufferRange != 0) {
							processRenderedGltfModelsGL43(lookup);
						} else if (glCapabilities.glGenTransformFeedbacks != 0) {
							processRenderedGltfModelsGL40(lookup);
						} else {
							processRenderedGltfModelsGL33(lookup);
						}
						break;
				}
			};

			gltfModelProcessor = (model) -> {
				switch (renderedModelGLProfile) {
					case GL43:
						return processRenderedGltfModelGL43(model);
					case GL40:
						return processRenderedGltfModelGL40(model);
					case GL33:
						return processRenderedGltfModelGL33(model);

					case GL30:
						return processRenderedGltfModelGL30(model);
					default:
						GLCapabilities glCapabilities = GL.getCapabilities();
						if (glCapabilities.glTexBufferRange != 0) {
							return processRenderedGltfModelGL43(model);
						} else if (glCapabilities.glGenTransformFeedbacks != 0) {
							return processRenderedGltfModelGL40(model);
						} else {
							return processRenderedGltfModelGL33(model);
						}
				}
			};
		}

		class_310.method_1551().execute(() -> {
			lightTexture = class_310.method_1551().method_1531()
					.method_4619(new class_2960("dynamic/light_map_1"));

			switch (renderedModelGLProfile) {
				case GL43:
					createSkinningProgramGL43();
					break;
				case GL40:
				case GL33:
					createSkinningProgramGL33();
					break;
				case GL30:
					break;
				default:
					//Since max OpenGL version on Windows from GLCapabilities will always return 3.2 as of Minecraft 1.17, this is a workaround to check if OpenGL 4.3 is available.
					if (GL.getCapabilities().glTexBufferRange != 0) {
						createSkinningProgramGL43();
					} else {
						createSkinningProgramGL33();
					}
					break;
			}

			GL11.glPixelStorei(GL11.GL_UNPACK_ROW_LENGTH, 0);
			GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_ROWS, 0);
			GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_PIXELS, 0);
			GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 4);

			int currentTexture = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);

			defaultColorMap = GL11.glGenTextures();
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, defaultColorMap);
			GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, 2, 2, 0, GL11.GL_RGBA,
					GL11.GL_UNSIGNED_BYTE, Buffers.create(
							new byte[] {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}));
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL12.GL_TEXTURE_BASE_LEVEL, 0);
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL12.GL_TEXTURE_MAX_LEVEL, 0);

			defaultNormalMap = GL11.glGenTextures();
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, defaultNormalMap);
			GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, 2, 2, 0, GL11.GL_RGBA,
					GL11.GL_UNSIGNED_BYTE, Buffers.create(
							new byte[] {-128, -128, -1, -1, -128, -128, -1, -1, -128, -128, -1, -1, -128, -128,
									-1, -1}));
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL12.GL_TEXTURE_BASE_LEVEL, 0);
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL12.GL_TEXTURE_MAX_LEVEL, 0);

			GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTexture);
		});

		ResourceManagerHelper.get(class_3264.field_14188)
				.registerReloadListener(new SimpleSynchronousResourceReloadListener() {

					@Override
					public class_2960 getFabricId() {
						return new class_2960(MODID, "gltf_reload_listener");
					}

					@Override
					public void method_14491(class_3300 resourceManager) {
						if(gltfModelReceivers.isEmpty())
							return;
						gltfRenderData.forEach(Runnable::run);
						gltfRenderData.clear();

						GL11.glPixelStorei(GL11.GL_UNPACK_ROW_LENGTH, 0);
						GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_ROWS, 0);
						GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_PIXELS, 0);
						GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 4);

						int currentTexture = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);

						Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup =
								new HashMap<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>>();
						gltfModelReceivers.forEach((receiver) -> {
							class_2960 modelLocation = receiver.getModelLocation();
							MutablePair<GltfModel, List<IGltfModelReceiver>> receivers =
									lookup.get(modelLocation);
							if (receivers == null) {
								receivers = MutablePair.of(null, new ArrayList<IGltfModelReceiver>());
								lookup.put(modelLocation, receivers);
							}
							receivers.getRight().add(receiver);
						});
						lookup.entrySet().parallelStream().forEach((entry) -> {
							try {
								entry.getValue().setLeft(new GltfModelReader().readWithoutReferences(
										new BufferedInputStream(
												class_310.method_1551().method_1478().method_14486(entry.getKey())
														.orElseThrow().method_14482())));
							} catch (IOException e) {
								e.printStackTrace();
							}
						});
						processRenderedGltfModelSelector.accept(lookup);
						GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
						GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, 0);
						GL30.glBindVertexArray(0);

						GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTexture);

						loadedBufferResources.clear();
						loadedImageResources.clear();
					}

				});
	}

	public RenderedGltfModel create(class_2960 location) throws IOException {
		gltfRenderData.forEach(Runnable::run);
		gltfRenderData.clear();

		GL11.glPixelStorei(GL11.GL_UNPACK_ROW_LENGTH, 0);
		GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_ROWS, 0);
		GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_PIXELS, 0);
		GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 4);

		int currentTexture = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);

		GltfModel model = new GltfModelReader().readWithoutReferences(new BufferedInputStream(
				class_310.method_1551().method_1478().method_14486(location).orElseThrow().method_14482()));
		RenderedGltfModel processedModel = gltfModelProcessor.apply(model);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
		GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, 0);
		GL30.glBindVertexArray(0);

		GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTexture);

		loadedBufferResources.clear();
		loadedImageResources.clear();

		return processedModel;
	}

	public int getGlProgramSkinnig() {
		return glProgramSkinnig;
	}

	public int getDefaultColorMap() {
		return defaultColorMap;
	}

	public int getDefaultNormalMap() {
		return defaultNormalMap;
	}

	public int getDefaultSpecularMap() {
		return 0;
	}

	public class_1044 getLightTexture() {
		return lightTexture;
	}

	public ByteBuffer getBufferResource(class_2960 location) {
		Supplier<ByteBuffer> supplier;
		synchronized (loadedBufferResources) {
			supplier = loadedBufferResources.get(location);
			if (supplier == null) {
				supplier = new Supplier<ByteBuffer>() {
					ByteBuffer bufferData;

					@Override
					public synchronized ByteBuffer get() {
						if (bufferData == null) {
							try {
								bufferData = Buffers.create(IOUtils.toByteArray(new BufferedInputStream(
										class_310.method_1551().method_1478().method_14486(location).orElseThrow()
												.method_14482())));
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						return bufferData;
					}

				};
				loadedBufferResources.put(location, supplier);
			}
		}
		return supplier.get();
	}

	public ByteBuffer getImageResource(class_2960 location) {
		Supplier<ByteBuffer> supplier;
		synchronized (loadedImageResources) {
			supplier = loadedImageResources.get(location);
			if (supplier == null) {
				supplier = new Supplier<ByteBuffer>() {
					ByteBuffer bufferData;

					@Override
					public synchronized ByteBuffer get() {
						if (bufferData == null) {
							try {
								bufferData = Buffers.create(IOUtils.toByteArray(new BufferedInputStream(
										class_310.method_1551().method_1478().method_14486(location).orElseThrow()
												.method_14482())));
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						return bufferData;
					}

				};
				loadedImageResources.put(location, supplier);
			}
		}
		return supplier.get();
	}

	public synchronized void addGltfModelReceiver(IGltfModelReceiver receiver) {
		gltfModelReceivers.add(receiver);
	}

	public synchronized boolean removeGltfModelReceiver(IGltfModelReceiver receiver) {
		return gltfModelReceivers.remove(receiver);
	}

	public boolean isShaderModActive() {
		return shaderModActive.getAsBoolean();
	}

	private void createSkinningProgramGL43() {
		int glShader = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
		GL20.glShaderSource(glShader,
				"#version 430\r\n"
						+ "layout(location = 0) in vec4 joint;"
						+ "layout(location = 1) in vec4 weight;"
						+ "layout(location = 2) in vec3 position;"
						+ "layout(location = 3) in vec3 normal;"
						+ "layout(location = 4) in vec4 tangent;"
						+
						"layout(std430, binding = 0) readonly buffer jointMatrixBuffer {mat4 jointMatrices[];};"
						+ "out vec3 outPosition;"
						+ "out vec3 outNormal;"
						+ "out vec4 outTangent;"
						+ "void main() {"
						+ "mat4 skinMatrix ="
						+ " weight.x * jointMatrices[int(joint.x)] +"
						+ " weight.y * jointMatrices[int(joint.y)] +"
						+ " weight.z * jointMatrices[int(joint.z)] +"
						+ " weight.w * jointMatrices[int(joint.w)];"
						+ "outPosition = (skinMatrix * vec4(position, 1.0)).xyz;"
						+ "mat3 upperLeft = mat3(skinMatrix);"
						+ "outNormal = upperLeft * normal;"
						+ "outTangent.xyz = upperLeft * tangent.xyz;"
						+ "outTangent.w = tangent.w;"
						+ "}");
		GL20.glCompileShader(glShader);

		glProgramSkinnig = GL20.glCreateProgram();
		GL20.glAttachShader(glProgramSkinnig, glShader);
		GL20.glDeleteShader(glShader);
		GL30.glTransformFeedbackVaryings(glProgramSkinnig,
				new CharSequence[] {"outPosition", "outNormal", "outTangent"}, GL30.GL_SEPARATE_ATTRIBS);
		GL20.glLinkProgram(glProgramSkinnig);
	}

	private void createSkinningProgramGL33() {
		int glShader = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
		GL20.glShaderSource(glShader,
				"#version 330\r\n"
						+ "layout(location = 0) in vec4 joint;"
						+ "layout(location = 1) in vec4 weight;"
						+ "layout(location = 2) in vec3 position;"
						+ "layout(location = 3) in vec3 normal;"
						+ "layout(location = 4) in vec4 tangent;"
						+ "uniform samplerBuffer jointMatrices;"
						+ "out vec3 outPosition;"
						+ "out vec3 outNormal;"
						+ "out vec4 outTangent;"
						+ "void main() {"
						+ "int jx = int(joint.x) * 4;"
						+ "int jy = int(joint.y) * 4;"
						+ "int jz = int(joint.z) * 4;"
						+ "int jw = int(joint.w) * 4;"
						+ "mat4 skinMatrix ="
						+
						" weight.x * mat4(texelFetch(jointMatrices, jx), texelFetch(jointMatrices, jx + 1), texelFetch(jointMatrices, jx + 2), texelFetch(jointMatrices, jx + 3)) +"
						+
						" weight.y * mat4(texelFetch(jointMatrices, jy), texelFetch(jointMatrices, jy + 1), texelFetch(jointMatrices, jy + 2), texelFetch(jointMatrices, jy + 3)) +"
						+
						" weight.z * mat4(texelFetch(jointMatrices, jz), texelFetch(jointMatrices, jz + 1), texelFetch(jointMatrices, jz + 2), texelFetch(jointMatrices, jz + 3)) +"
						+
						" weight.w * mat4(texelFetch(jointMatrices, jw), texelFetch(jointMatrices, jw + 1), texelFetch(jointMatrices, jw + 2), texelFetch(jointMatrices, jw + 3));"
						+ "outPosition = (skinMatrix * vec4(position, 1.0)).xyz;"
						+ "mat3 upperLeft = mat3(skinMatrix);"
						+ "outNormal = upperLeft * normal;"
						+ "outTangent.xyz = upperLeft * tangent.xyz;"
						+ "outTangent.w = tangent.w;"
						+ "}");
		GL20.glCompileShader(glShader);

		glProgramSkinnig = GL20.glCreateProgram();
		GL20.glAttachShader(glProgramSkinnig, glShader);
		GL20.glDeleteShader(glShader);
		GL30.glTransformFeedbackVaryings(glProgramSkinnig,
				new CharSequence[] {"outPosition", "outNormal", "outTangent"}, GL30.GL_SEPARATE_ATTRIBS);
		GL20.glLinkProgram(glProgramSkinnig);
	}

	private void processRenderedGltfModels(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup,
			BiFunction<List<Runnable>, GltfModel, RenderedGltfModel> renderedGltfModelBuilder) {
		lookup.forEach((modelLocation, receivers) -> {
			Iterator<IGltfModelReceiver> iterator = receivers.getRight().iterator();
			do {
				IGltfModelReceiver receiver = iterator.next();
				if (receiver.isReceiveSharedModel(receivers.getLeft(), gltfRenderData)) {
					RenderedGltfModel renderedModel =
							renderedGltfModelBuilder.apply(gltfRenderData, receivers.getLeft());
					receiver.onReceiveSharedModel(renderedModel);
					while (iterator.hasNext()) {
						receiver = iterator.next();
						if (receiver.isReceiveSharedModel(receivers.getLeft(), gltfRenderData)) {
							receiver.onReceiveSharedModel(renderedModel);
						}
					}
					return;
				}
			}
			while (iterator.hasNext());
		});
	}

	private RenderedGltfModel processRenderedGltfModel(GltfModel gltfModel,
													   BiFunction<List<Runnable>, GltfModel, RenderedGltfModel> renderedGltfModelBuilder) {
		return renderedGltfModelBuilder.apply(gltfRenderData, gltfModel);
	}

	private void processRenderedGltfModelsGL43(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModel::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
	}

	private RenderedGltfModel processRenderedGltfModelGL43(GltfModel model) {
		RenderedGltfModel processedModel = processRenderedGltfModel(model, RenderedGltfModel::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);

		return processedModel;
	}

	private void processRenderedGltfModelsGL40(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelGL40::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
	}

	private RenderedGltfModel processRenderedGltfModelGL40(GltfModel gltfModel) {
		RenderedGltfModel renderedGltfModel =
				processRenderedGltfModel(gltfModel, RenderedGltfModelGL40::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
		return renderedGltfModel;
	}

	private void processRenderedGltfModelsGL33(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelGL33::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
	}

	private RenderedGltfModel processRenderedGltfModelGL33(GltfModel gltfModel) {
		RenderedGltfModel renderedGltfModel =
				processRenderedGltfModel(gltfModel, RenderedGltfModelGL33::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
		return renderedGltfModel;
	}

	private void processRenderedGltfModelsGL30(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelGL30::new);
	}

	private RenderedGltfModel processRenderedGltfModelGL30(GltfModel gltfModel) {
		return processRenderedGltfModel(gltfModel, RenderedGltfModelGL30::new);
	}

	private void processRenderedGltfModelsGL43Iris(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelIris::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
	}

	private RenderedGltfModel processRenderedGltfModelGL43Iris(GltfModel gltfModel) {
		RenderedGltfModel renderedGltfModel =
				processRenderedGltfModel(gltfModel, RenderedGltfModelIris::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
		return renderedGltfModel;
	}


	private void processRenderedGltfModelsGL40Iris(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelGL40Iris::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
	}

	private RenderedGltfModel processRenderedGltfModelGL40Iris(GltfModel gltfModel) {
		RenderedGltfModel renderedGltfModel =
				processRenderedGltfModel(gltfModel, RenderedGltfModelGL40Iris::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
		GL40.glBindTransformFeedback(GL40.GL_TRANSFORM_FEEDBACK, 0);
		return renderedGltfModel;
	}


	private void processRenderedGltfModelsGL33Iris(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelGL33Iris::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
	}

	private RenderedGltfModel processRenderedGltfModelGL33Iris(GltfModel gltfModel) {
		RenderedGltfModel renderedGltfModel =
				processRenderedGltfModel(gltfModel, RenderedGltfModelGL33Iris::new);
		GL15.glBindBuffer(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0);
		GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
		return renderedGltfModel;
	}

	private void processRenderedGltfModelsGL30Iris(
			Map<class_2960, MutablePair<GltfModel, List<IGltfModelReceiver>>> lookup) {
		processRenderedGltfModels(lookup, RenderedGltfModelGL30Iris::new);
	}

	private RenderedGltfModel processRenderedGltfModelGL30Iris(GltfModel gltfModel) {
		return processRenderedGltfModel(gltfModel, RenderedGltfModelGL30Iris::new);
	}

	public EnumRenderedModelGLProfile getRenderedModelGLProfile() {
		return renderedModelGLProfile;
	}

	private String provider(String filename) {
		return "#Set maximum version of OpenGL to enable some optimizations for rendering glTF model.\n"
				+
				"#The AUTO means it will select maximum OpenGL version available based on your hardware. The GL43 is highest it may select.\n"
				+
				"#The lower OpenGL version you set, the more negative impact on performance you will probably get.\n"
				+
				"#The GL30 is a special profile which essentially the GL33 and above but replace hardware(GPU) skinning with software(CPU) skinning. This will trade a lots of CPU performance for a few GPU performance increase.\n"
				+ "#Allowed Values: AUTO, GL43, GL40, GL33, GL30\n"
				+ "RenderedModelGLProfile=AUTO";
	}

	public enum EnumRenderedModelGLProfile {
		AUTO,
		GL43,
		GL40,
		GL33,
		GL30
	}

}
