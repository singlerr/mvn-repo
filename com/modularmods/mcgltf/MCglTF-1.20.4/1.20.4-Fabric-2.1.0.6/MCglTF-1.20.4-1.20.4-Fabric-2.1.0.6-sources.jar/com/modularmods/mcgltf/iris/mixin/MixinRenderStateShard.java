package com.modularmods.mcgltf.iris.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.modularmods.mcgltf.iris.IrisRenderingHook;
import net.minecraft.class_4668;

@Mixin(class_4668.class)
public class MixinRenderStateShard {

	@Inject(method = "setupRenderState()V", at = @At("TAIL"))
	private void afterSetupRenderState(CallbackInfo ci) {
		IrisRenderingHook.irisHookAfterSetupRenderState((class_4668)(Object)this);
	}
}
