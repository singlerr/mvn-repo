package com.modularmods.mcgltf.iris;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import net.irisshaders.batchedentityrendering.impl.WrappableRenderType;
import net.irisshaders.iris.Iris;
import net.irisshaders.iris.pipeline.WorldRenderingPhase;
import net.irisshaders.iris.pipeline.WorldRenderingPipeline;
import net.minecraft.class_1041;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4668;
import net.minecraft.class_5944;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import com.modularmods.mcgltf.RenderedGltfModel;
import com.mojang.blaze3d.systems.RenderSystem;

public class IrisRenderingHook {

	private static final Map<WorldRenderingPhase, Map<class_4668, List<Runnable>>> phaseRenderStateShardToCommands = new EnumMap<WorldRenderingPhase, Map<class_4668, List<Runnable>>>(WorldRenderingPhase.class);
	private static class_4668 currentRenderStateShard;
	
	public static void submitCommandForIrisRenderingByPhaseName(String phase, class_1921 renderType, Runnable command) {
		submitCommandForIrisRendering(WorldRenderingPhase.valueOf(phase), renderType, command);
	}
	
	public static void submitCommandForIrisRendering(WorldRenderingPhase phase, class_1921 renderType, Runnable command) {
		Map<class_4668, List<Runnable>> renderStateShardToCommands = phaseRenderStateShardToCommands.get(phase);
		if(renderStateShardToCommands == null) {
			renderStateShardToCommands = new LinkedHashMap<class_4668, List<Runnable>>();
			phaseRenderStateShardToCommands.put(phase, renderStateShardToCommands);
			List<Runnable> commands = new LinkedList<Runnable>();
			renderStateShardToCommands.put(renderType, commands);
			commands.add(command);
		}
		else {
			List<Runnable> commands = renderStateShardToCommands.get(renderType);
			if(commands == null) {
				commands = new LinkedList<Runnable>();
				renderStateShardToCommands.put(renderType, commands);
			}
			commands.add(command);
		}
	}
	
	public static void irisHookAfterSetupRenderState(class_4668 renderStateShard) {
		currentRenderStateShard = ((renderStateShard instanceof WrappableRenderType) ? ((WrappableRenderType)renderStateShard).unwrap() : renderStateShard);
	}
	
	public static void irisHookBypassBufferUploaderVextexCountCheck(class_287.class_7433 renderedBuffer) {
		WorldRenderingPipeline pipeline = Iris.getPipelineManager().getPipelineNullable();
		if(pipeline != null) {
			WorldRenderingPhase phase = pipeline.getPhase();
			Map<class_4668, List<Runnable>> renderStateShardToCommands = phaseRenderStateShardToCommands.get(phase);
			if(renderStateShardToCommands != null) {
				List<Runnable> commands = renderStateShardToCommands.remove(currentRenderStateShard);
				if(commands != null) {
					class_5944 shaderInstance = RenderedGltfModel.CURRENT_SHADER_INSTANCE = RenderSystem.getShader();
					for (int i = 0; i < 12; ++i) {
						int j = RenderSystem.getShaderTexture(i);
						shaderInstance.method_34583("Sampler" + i, j);
					}
					if (shaderInstance.field_29470 != null) {
						shaderInstance.field_29470.method_1250(RenderSystem.getModelViewMatrix());
					}
					if (shaderInstance.field_29471 != null) {
						shaderInstance.field_29471.method_1250(RenderSystem.getProjectionMatrix());
					}
					if (shaderInstance.field_36323 != null) {
						shaderInstance.field_36323.method_39978(RenderSystem.getInverseViewRotationMatrix());
					}
					if (shaderInstance.field_29474 != null) {
						shaderInstance.field_29474.method_1253(RenderSystem.getShaderColor());
					}
					if (shaderInstance.field_29477 != null) {
						shaderInstance.field_29477.method_1251(RenderSystem.getShaderFogStart());
					}
					if (shaderInstance.field_29478 != null) {
						shaderInstance.field_29478.method_1251(RenderSystem.getShaderFogEnd());
					}
					if (shaderInstance.field_29479 != null) {
						shaderInstance.field_29479.method_1253(RenderSystem.getShaderFogColor());
					}
					if (shaderInstance.field_36373 != null) {
						shaderInstance.field_36373.method_35649(RenderSystem.getShaderFogShape().method_40036());
					}
					if (shaderInstance.field_29472 != null) {
						shaderInstance.field_29472.method_1250(RenderSystem.getTextureMatrix());
					}
					if (shaderInstance.field_29481 != null) {
						shaderInstance.field_29481.method_1251(RenderSystem.getShaderGameTime());
					}
					if (shaderInstance.field_29473 != null) {
						class_1041 window = class_310.method_1551().method_22683();
						shaderInstance.field_29473.method_1255((float)window.method_4489(), (float)window.method_4506());
					}
					if (shaderInstance.field_29480 != null) {
						class_293.class_5596 mode = renderedBuffer.method_43583().comp_752();
						if(mode == class_293.class_5596.field_27377 || mode == class_293.class_5596.field_27378) {
							shaderInstance.field_29480.method_1251(RenderSystem.getShaderLineWidth());
						}
					}
					RenderSystem.setupShaderLights(shaderInstance);
					shaderInstance.method_34586();
					
					setupAndRender(phase, shaderInstance, commands);
					
					shaderInstance.method_34585();
				}
			}
		}
	}
	
	public static void irisHookAfterVertexBufferDraw() {
		WorldRenderingPipeline pipeline = Iris.getPipelineManager().getPipelineNullable();
		if(pipeline != null) {
			WorldRenderingPhase phase = pipeline.getPhase();
			Map<class_4668, List<Runnable>> renderStateShardToCommands = phaseRenderStateShardToCommands.get(phase);
			if(renderStateShardToCommands != null) {
				List<Runnable> commands = renderStateShardToCommands.remove(currentRenderStateShard);
				if(commands != null) {
					setupAndRender(phase, RenderedGltfModel.CURRENT_SHADER_INSTANCE = RenderSystem.getShader(), commands);
				}
			}
		}
	}
	
	private static void setupAndRender(WorldRenderingPhase phase, class_5944 shaderInstance, List<Runnable> commands) {
		int currentVAO = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
		int currentArrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
		int currentElementArrayBuffer = GL11.glGetInteger(GL15.GL_ELEMENT_ARRAY_BUFFER_BINDING);
		
		boolean currentCullFace = GL11.glGetBoolean(GL11.GL_CULL_FACE);
		
		int currentTextureColor = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
		GL13.glActiveTexture(GL13.GL_TEXTURE0 + 2);
		int currentTextureNormal = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
		GL13.glActiveTexture(GL13.GL_TEXTURE0 + 1);
		int currentTextureSpecular = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);

		try {
			if(phase != WorldRenderingPhase.NONE) {
				int currentProgram = shaderInstance.method_1270();
				RenderedGltfModel.MODEL_VIEW_MATRIX = GL20.glGetUniformLocation(currentProgram, "iris_ModelViewMat");
				RenderedGltfModel.NORMAL_MATRIX = GL20.glGetUniformLocation(currentProgram, "iris_NormalMat");
			}
			else {
				RenderedGltfModel.LIGHT0_DIRECTION = new Vector3f(shaderInstance.field_29475.method_35664());
				RenderedGltfModel.LIGHT1_DIRECTION = new Vector3f(shaderInstance.field_29476.method_35664());
			}
			commands.forEach(Runnable::run);
		} finally {
			GL20.glDisableVertexAttribArray(RenderedGltfModel.at_tangent);
			GL13.glActiveTexture(GL13.GL_TEXTURE0);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTextureColor);
			GL13.glActiveTexture(GL13.GL_TEXTURE0 + 2);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTextureNormal);
			GL13.glActiveTexture(GL13.GL_TEXTURE0 + 1);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTextureSpecular);
		}
		
		if(currentCullFace) GL11.glEnable(GL11.GL_CULL_FACE);
		else GL11.glDisable(GL11.GL_CULL_FACE);
		
		GL30.glBindVertexArray(currentVAO);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, currentArrayBuffer);
		GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, currentElementArrayBuffer);
	}
}
