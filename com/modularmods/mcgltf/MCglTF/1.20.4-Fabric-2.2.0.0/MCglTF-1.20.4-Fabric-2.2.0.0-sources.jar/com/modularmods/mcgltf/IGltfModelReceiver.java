package com.modularmods.mcgltf;

import de.javagl.jgltf.model.GltfModel;
import java.util.List;
import net.minecraft.class_2960;

public interface IGltfModelReceiver {

    class_2960 getModelLocation();

    default void onReceiveSharedModel(RenderedGltfModel renderedModel) {
    }

    default boolean isReceiveSharedModel(GltfModel gltfModel, List<Runnable> gltfRenderDatas) {
        return true;
    }
}
