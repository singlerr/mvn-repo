package com.modularmods.mcgltf;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.*;

public class RenderedGltfSceneGL33 extends RenderedGltfScene {

    @Override
    public void renderForVanilla() {
        int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);

        if (!skinningCommands.isEmpty()) {
            GL20.glUseProgram(MCglTF.getInstance().getGlProgramSkinnig());
            GL11.glEnable(GL30.GL_RASTERIZER_DISCARD);
            skinningCommands.forEach(Runnable::run);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            GL11.glDisable(GL30.GL_RASTERIZER_DISCARD);
        }

        RenderedGltfModel.CURRENT_SHADER_INSTANCE = class_757.method_34502();
        int entitySolidProgram = RenderedGltfModel.CURRENT_SHADER_INSTANCE.method_1270();
        GL20.glUseProgram(entitySolidProgram);

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29471.method_1250(RenderSystem.getProjectionMatrix());
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29471.method_1300();

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_36323.method_39978(RenderSystem.getInverseViewRotationMatrix());
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_36323.method_1300();

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29477.method_1251(RenderSystem.getShaderFogStart());
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29477.method_1300();

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29478.method_1251(RenderSystem.getShaderFogEnd());
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29478.method_1300();

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29479.method_1253(RenderSystem.getShaderFogColor());
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29479.method_1300();

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_36373.method_35649(RenderSystem.getShaderFogShape().method_40036());
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_36373.method_1300();

        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29474.method_1254(1.0F, 1.0F, 1.0F, 1.0F);
        RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29474.method_1300();

        GL20.glUniform1i(GL20.glGetUniformLocation(entitySolidProgram, "Sampler0"), 0);
        GL20.glUniform1i(GL20.glGetUniformLocation(entitySolidProgram, "Sampler1"), 1);
        GL20.glUniform1i(GL20.glGetUniformLocation(entitySolidProgram, "Sampler2"), 2);

        RenderSystem.setupShaderLights(RenderedGltfModel.CURRENT_SHADER_INSTANCE);
        RenderedGltfModel.LIGHT0_DIRECTION = new Vector3f(RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29475.method_35664());
        RenderedGltfModel.LIGHT1_DIRECTION = new Vector3f(RenderedGltfModel.CURRENT_SHADER_INSTANCE.field_29476.method_35664());

        vanillaRenderCommands.forEach(Runnable::run);

        GL20.glUseProgram(currentProgram);

        RenderedGltfModel.NODE_GLOBAL_TRANSFORMATION_LOOKUP_CACHE.clear();
    }

    @Override
    public void renderForShaderMod() {
        int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);

        if (!skinningCommands.isEmpty()) {
            GL20.glUseProgram(MCglTF.getInstance().getGlProgramSkinnig());
            GL11.glEnable(GL30.GL_RASTERIZER_DISCARD);
            skinningCommands.forEach(Runnable::run);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            GL11.glDisable(GL30.GL_RASTERIZER_DISCARD);
            GL20.glUseProgram(currentProgram);
        }

        RenderedGltfModel.MODEL_VIEW_MATRIX = GL20.glGetUniformLocation(currentProgram, "modelViewMatrix");
        RenderedGltfModel.MODEL_VIEW_MATRIX_INVERSE = GL20.glGetUniformLocation(currentProgram, "modelViewMatrixInverse");
        RenderedGltfModel.NORMAL_MATRIX = GL20.glGetUniformLocation(currentProgram, "normalMatrix");

        Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
        projectionMatrix.get(RenderedGltfModel.BUF_FLOAT_16);
        GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(currentProgram, "projectionMatrix"), false, RenderedGltfModel.BUF_FLOAT_16);
        (new Matrix4f(projectionMatrix)).invert().get(RenderedGltfModel.BUF_FLOAT_16);
        GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(currentProgram, "projectionMatrixInverse"), false, RenderedGltfModel.BUF_FLOAT_16);

        GL13.glActiveTexture(GL13.GL_TEXTURE3);
        int currentTexture3 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        GL13.glActiveTexture(GL13.GL_TEXTURE1);
        int currentTexture1 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        int currentTexture0 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);

        shaderModRenderCommands.forEach(Runnable::run);

        GL13.glActiveTexture(GL13.GL_TEXTURE3);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTexture3);
        GL13.glActiveTexture(GL13.GL_TEXTURE1);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTexture1);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, currentTexture0);

        RenderedGltfModel.NODE_GLOBAL_TRANSFORMATION_LOOKUP_CACHE.clear();
    }

}
