package com.modularmods.mcgltf.iris.mixin;

import com.modularmods.mcgltf.iris.IrisRenderingHook;
import net.minecraft.class_286;
import net.minecraft.class_287;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_286.class)
public class MixinBufferUploader {

    @Inject(method = "_drawWithShader(Lcom/mojang/blaze3d/vertex/BufferBuilder$RenderedBuffer;)V", at = @At("HEAD"))
    private static void before_drawWithShader(class_287.class_7433 renderedBuffer, CallbackInfo ci) {
        if (renderedBuffer.method_43584()) IrisRenderingHook.irisHookBypassBufferUploaderVextexCountCheck(renderedBuffer);
    }
}
