package com.modularmods.mcgltf.iris.mixin;

import com.modularmods.mcgltf.iris.IrisRenderingHook;
import net.minecraft.class_291;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_291.class)
public class MixinVertexBuffer {

    @Inject(method = "draw()V", at = @At("TAIL"))
    private void afterDraw(CallbackInfo ci) {
        IrisRenderingHook.irisHookAfterVertexBufferDraw();
    }
}
