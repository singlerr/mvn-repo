package math.doubleV;


import math.floatV.Vec3f;


/**
 * Minimal implementation of basis transformations.
 * Supports only righthanded orthonormal bases (no scaling, now skewing, no reflections).
 *
 * @author Eron Gjoni
 *
 */
public abstract class AbstractBasis {
    public static final int LEFT = -1;
    public static final int RIGHT = 1;
    public static final int NONE = -1;
    public static final int X = 0;
    public static final int Y = 1;
    public static final int Z = 2;
    public int chirality = RIGHT;
    public Rot rotation = new Rot();
    public Rot inverseRotation = new Rot();
    /**
     * a vector respresnting the translation of this basis relative to its parent.
     */
    public Vec3d<?> translate;


    protected Vec3d<?> xBase; //= new SGVec_3d(1,0,0);
    protected Vec3d<?> yBase; //= new SGVec_3d(0,1,0);
    protected Vec3d<?> zBase;// = new SGVec_3d(0,0,1);

    protected sgRayd xRay;// = new sgRayd(new SGVec_3d(0,0,0), new SGVec_3d(1,0,0));
    protected sgRayd yRay;// = new sgRayd(new SGVec_3d(0,0,0), new SGVec_3d(0,1,0));
    protected sgRayd zRay;// = new sgRayd(new SGVec_3d(0,0,0), new SGVec_3d(0,0,1));


    /**
     * Initialize this basis at the origin. The basis will be righthanded by default.
     *
     * @param origin
     */
    public AbstractBasis(Vec3d<?> origin) {
        translate = origin.copy();
        xBase = origin.copy();
        yBase = origin.copy();
        zBase = origin.copy();
        xBase.set(1, 0, 0);
        yBase.set(0, 1, 0);
        zBase.set(0, 0, 1);
        Vec3d<?> zero = origin.copy();
        zero.set(0, 0, 0);
        xRay = new sgRayd(zero.copy(), xBase.copy());
        yRay = new sgRayd(zero.copy(), yBase.copy());
        zRay = new sgRayd(zero.copy(), zBase.copy());
        refreshPrecomputed();
    }

    public <T extends AbstractBasis> AbstractBasis(T input) {
        translate = input.translate.copy();
        xBase = translate.copy();
        yBase = translate.copy();
        zBase = translate.copy();
        xBase.set(1, 0, 0);
        yBase.set(0, 1, 0);
        zBase.set(0, 0, 1);
        Vec3d<?> zero = translate.copy();
        zero.set(0, 0, 0);
        xRay = new sgRayd(zero.copy(), xBase.copy());
        yRay = new sgRayd(zero.copy(), yBase.copy());
        zRay = new sgRayd(zero.copy(), zBase.copy());
        this.adoptValues(input);

    }


    /**
     * Initialize this basis at the origin.
     * The basis will be backed by a rotation object which presumes right handed chirality.
     * Therefore, the rotation object will align so its local XY plane aligns with this basis' XY plane
     * Afterwards, it will check chirality, and if the basis isn't righthanded, this class will assume the
     * z-axis is the one that's been flipped.
     * <p>
     * If you want to manually specify which axis has been flipped
     * (so that the rotation object aligns with respect to the plane formed
     * by the other two basis vectors) then use the constructor dedicated for that purpose
     *
     * @param origin
     * @param x      basis vector direction
     * @param y      basis vector direction
     * @param z      basis vector direction
     */
    public <V extends Vec3d<?>> AbstractBasis(V origin, V x, V y, V z) {
        this.translate = origin.copy();
        xRay = new sgRayd(origin.copy(), origin.copy());
        yRay = new sgRayd(origin.copy(), origin.copy());
        zRay = new sgRayd(origin.copy(), origin.copy());
        this.set(x.copy(), y.copy(), z.copy());
    }

    /**
     * Initialize this basis at the origin defined by the base of the @param x Ray.
     * <p>
     * The basis will be backed by a rotation object which presumes right handed chirality.
     * Therefore, the rotation object will align so its local XY plane aligns with this basis' XY plane
     * Afterwards, it will check chirality, and if the basis isn't righthanded, this class will assume the
     * z-axis is the one that's been flipped.
     * <p>
     * If you want to manually specify which axis has been flipped
     * (so that the rotation object aligns with respect to the plane formed
     * by the other two basis vectors) then use the constructor dedicated for that purpose
     *
     * @param x basis Ray
     * @param y basis Ray
     * @param z basis Ray
     */
    public <R extends sgRayd> AbstractBasis(R x, R y, R z) {
        this.translate = x.p1().copy();
        xRay = x.copy();
        yRay = y.copy();
        zRay = z.copy();
        Vec3d<?> xDirNew = x.heading().copy();
        Vec3d<?> yDirNew = y.heading().copy();
        Vec3d<?> zDirNew = z.heading().copy();
        xDirNew.normalize();
        yDirNew.normalize();
        zDirNew.normalize();
        set(xDirNew, yDirNew, zDirNew);

    }

    private <V extends Vec3d<?>> void set(V x, V y, V z) {
        xBase = translate.copy();
        yBase = translate.copy();
        zBase = translate.copy();
        xBase.set(1, 0, 0);
        yBase.set(0, 1, 0);
        zBase.set(0, 0, 1);
        Vec3d<?> zero = translate.copy();
        zero.set(0, 0, 0);
        xRay.setP1(zero.copy());
        xRay.setP2(xBase.copy());
        yRay.setP1(zero.copy());
        yRay.setP2(yBase.copy());
        zRay.setP1(zero.copy());
        zRay.setP2(zBase.copy());
        this.rotation = createPrioritzedRotation(x, y, z);
        this.refreshPrecomputed();
    }

    /**
     * takes on the same values (not references) as the input basis.
     *
     * @param in
     */
    public <T extends AbstractBasis> void adoptValues(T in) {
        this.translate.set(in.translate);
        this.rotation.set(in.rotation);
        xBase = translate.copy();
        yBase = translate.copy();
        zBase = translate.copy();
        xBase.set(1, 0, 0);
        yBase.set(0, 1, 0);
        zBase.set(0, 0, 1);
        xRay = in.xRay.copy();
        yRay = in.yRay.copy();
        zRay = in.zRay.copy();
        this.refreshPrecomputed();
    }

    public void setIdentity() {
        this.translate.set(0, 0, 0);
        xBase.set(1, 0, 0);
        yBase.set(0, 1, 0);
        zBase.set(0, 0, 1);
        this.xRay.p1.set(this.translate);
        this.xRay.p2.set(xBase);
        this.yRay.p1.set(this.translate);
        this.yRay.p2.set(yBase);
        this.zRay.p1.set(this.translate);
        this.zRay.p2.set(zBase);
        this.rotation = new Rot();
        refreshPrecomputed();
    }


    private Rot createPrioritzedRotation(Vec3d<?> xHeading, Vec3d<?> yHeading, Vec3d<?> zHeading) {

        Vec3d<?> tempV = zHeading.copy();
        tempV.set(0, 0, 0);
        Rot toYZ = new Rot(yBase, zBase, yHeading, zHeading);
        toYZ.applyTo(yBase, tempV);
        Rot toY = new Rot(tempV, yHeading);

        return toY.applyTo(toYZ);
		/*Vec3d<?> xidt = xBase.copy(); Vec3d<?> yidt = yBase.copy();  Vec3d<?> zidt = zBase.copy();
		Vec3d<?> origin = xBase.copy(); origin.set(0,0,0);  
		
		Vec3d<?>[] from = {origin, xidt, yidt, zidt};
		Vec3d<?>[] to = {origin.copy(), xHeading, yHeading, zHeading};
		QCP alignHeads = new QCP(MathUtils.DOUBLE_ROUNDING_ERROR, MathUtils.DOUBLE_ROUNDING_ERROR);
		alignHeads.setMaxIterations(50);
		Rot rotation = alignHeads.weightedSuperpose(from, to, null, false);
		return rotation;*/
    }


    public Rot getLocalOfRotation(Rot inRot) {
        Rot resultNew = inverseRotation.applyTo(inRot).applyTo(rotation);
        return resultNew;
    }

    public <B extends AbstractBasis> void setToLocalOf(B global_input, B local_output) {
        local_output.translate = this.getLocalOf(global_input.translate);
        inverseRotation.applyTo(global_input.rotation, local_output.rotation);

        local_output.refreshPrecomputed();
    }

    public void refreshPrecomputed() {
        this.rotation.setToReversion(inverseRotation);
        this.updateRays();
    }

    public <V extends Vec3d<?>> V getLocalOf(V v) {
        V result = (V) v.copy();
        setToLocalOf(v, result);
        return result;
    }


    public <V extends Vec3d<?>> void setToLocalOf(V input, V output) {
        output.set(input);
        output.sub(this.translate);
        inverseRotation.applyTo(output, output);
    }

    public void rotateTo(Rot newRotation) {
        this.rotation.set(newRotation);
        this.refreshPrecomputed();
    }

    public void rotateBy(Rot addRotation) {
        addRotation.applyTo(this.rotation, this.rotation);
        this.refreshPrecomputed();
    }


    /**
     * the default Basis implementation is orthonormal,
     * so by default this function will just set @param vec to (1,0,0),
     * but extending (affine) classes can override this to represent the direction and magnitude of the x axis prior to rotation.
     */
    public <V extends Vec3d<?>> void setToShearXBase(V vec) {
        vec.set(xBase);
    }

    /**
     * the default Basis implementation is orthonormal,
     * so by default this function will just set @param vec to (0,1,0),
     * but extending (affine) classes can override this to represent the direction and magnitude of the y axis prior to rotation.
     */
    public <V extends Vec3d<?>> void setToShearYBase(V vec) {
        vec.set(yBase);
    }

    /**
     * the default Basis implementation is orthonormal,
     * so by default this function will just set @param vec to (0,0,1),
     * but extending (affine) classes can override this to represent the direction and magnitude of the z axis prior to rotation.
     */
    public <V extends Vec3d<?>> void setToShearZBase(V vec) {
        vec.set(zBase);
    }


    /**
     * sets globalOutput such that the result of
     * this.getLocalOf(globalOutput) == localInput.
     *
     * @param localInput
     * @param globalOutput
     */
    public <T extends AbstractBasis> void setToGlobalOf(T localInput, T globalOutput) {
        this.rotation.applyTo(localInput.rotation, globalOutput.rotation);
        this.setToGlobalOf(localInput.translate, globalOutput.translate);
        globalOutput.refreshPrecomputed();
    }


    public <V extends Vec3d<?>> void setToGlobalOf(V input, V output) {
        try {
            rotation.applyTo(input, output);
            output.add(this.translate);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public <V extends Vec3d<?>> void translateBy(V transBy) {
        this.translate.x += transBy.x;
        this.translate.y += transBy.y;
        this.translate.z += transBy.z;
        updateRays();
    }

    public <V extends Vec3d<?>> void translateTo(V newOrigin) {
        this.translate.x = newOrigin.x;
        this.translate.y = newOrigin.y;
        this.translate.z = newOrigin.z;
        updateRays();
    }

    public sgRayd getXRay() {
        return xRay;
    }

    public sgRayd getYRay() {
        return yRay;
    }

    public sgRayd getZRay() {
        return zRay;
    }

    public Vec3d<?> getXHeading() {
        return this.xRay.heading();
    }

    public Vec3d<?> getYHeading() {
        return this.yRay.heading();
    }

    public Vec3d<?> getZHeading() {
        return this.zRay.heading();
    }

    public Vec3d<?> getOrigin() {
        return translate;
    }

    /**
     * true if the input axis should be multiplied by negative one after rotation.
     * By default, this always returns false. But can be overriden for more advanced implementations
     * allowing for reflection transformations.
     *
     * @param axis
     * @return true if axis should be flipped, false otherwise. Default is false.
     */
    public boolean isAxisFlipped(int axis) {
        return false;
    }

    /**
     * @return a precomputed inverse of the rotation represented by this basis object.
     */
    public Rot getInverseRotation() {
        return this.inverseRotation;
    }


    private void updateRays() {
        xRay.setP1(this.translate);
        xRay.p2.set(xBase);
        yRay.setP1(this.translate);
        yRay.p2.set(yBase);
        zRay.setP1(this.translate);
        zRay.p2.set(zBase);

        rotation.applyTo(xRay.p2, xRay.p2);
        rotation.applyTo(yRay.p2, yRay.p2);
        rotation.applyTo(zRay.p2, zRay.p2);

        xRay.p2.add(this.translate);
        yRay.p2.add(this.translate);
        zRay.p2.add(this.translate);
    }

    public abstract AbstractBasis copy();

    public String toString() {
        Vec3f xh = xRay.heading().toVec3f();

        Vec3f yh = yRay.heading().toVec3f();

        Vec3f zh = zRay.heading().toVec3f();

        float xMag = xh.mag();
        float yMag = yh.mag();
        float zMag = zh.mag();
        //this.chirality = this.composedMatrix. ? RIGHT : LEFT;
        String chirality = this.chirality == LEFT ? "LEFT" : "RIGHT";
        String result = "-----------\n"
                + chirality + " handed \n"
                + "origin: " + this.translate.toVec3f() + "\n"
                + "rot Axis: " + this.rotation.getAxis().toVec3f() + ", "
                + "Angle: " + (float) Math.toDegrees(this.rotation.getAngle()) + "\n"
                + "xHead: " + xh + ", mag: " + xMag + "\n"
                + "yHead: " + yh + ", mag: " + yMag + "\n"
                + "zHead: " + zh + ", mag: " + zMag + "\n";

        return result;
    }

}