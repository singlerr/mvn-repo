package data;

import IK.doubleIK.*;
import asj.SaveManager;
import asj.Saveable;
import asj.data.JSONArray;
import asj.data.JSONObject;
import asj.data.StringFuncs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.WeakHashMap;


public class EWBIKSaver extends SaveManager {


    public static String currentFilePath;
    public static String tempDir;
    WeakHashMap<Saveable, Boolean> saveables = new WeakHashMap<Saveable, Boolean>();

    public void saveArmature(AbstractArmature toSave, String path) {
        clearSaveState();
        toSave.notifyOfSaveIntent(this);
        saveAs(path);
        notifyCurrentSaveablesOfSaveCompletion();
    }

    public void saveArmature(IK.floatIK.AbstractArmature toSave, String path) {
        clearSaveState();
        toSave.notifyOfSaveIntent(this);
        saveAs(path);
        notifyCurrentSaveablesOfSaveCompletion();
    }

    public void addToSaveState(Saveable saveObj) {
        saveables.put(saveObj, true);
    }

    public void removeFromSaveState(Saveable saveObj) {
        saveables.remove(saveObj);
    }

    public void clearSaveState() {
        saveables.clear();
    }


    public void notifyCurrentSaveablesOfSaveCompletion() {
        ArrayList<Saveable> sarr = new ArrayList<>(saveables.keySet());
        for (Saveable s : sarr) {
            s.notifyOfSaveCompletion(this);
        }
        clearSaveState();
    }

    public JSONObject getSaveObject() {

        JSONArray axesJSON = new JSONArray();
        JSONArray armaturesJSON = new JSONArray();
        JSONArray bonesJSON = new JSONArray();
        JSONArray kusudamaJSON = new JSONArray();
        JSONArray limitConeJSON = new JSONArray();
        JSONArray IKPinsJSON = new JSONArray();

        Collection<Saveable> sk = saveables.keySet();

        JSONObject saveObject = new JSONObject();

        for (Saveable s : sk) {
            JSONObject jsonObj = s.getSaveJSON(this);
            if (jsonObj != null) {
                if (math.doubleV.AbstractAxes.class.isAssignableFrom(s.getClass()))
                    axesJSON.append(jsonObj);
                if (AbstractArmature.class.isAssignableFrom(s.getClass()))
                    armaturesJSON.append(jsonObj);
                if (AbstractBone.class.isAssignableFrom(s.getClass()))
                    bonesJSON.append(jsonObj);
                if (AbstractKusudama.class.isAssignableFrom(s.getClass()))
                    kusudamaJSON.append(jsonObj);
                if (AbstractLimitCone.class.isAssignableFrom(s.getClass()))
                    limitConeJSON.append(jsonObj);
                if (AbstractIKPin.class.isAssignableFrom(s.getClass()))
                    IKPinsJSON.append(jsonObj);
                if (math.floatV.AbstractAxes.class.isAssignableFrom(s.getClass()))
                    axesJSON.append(jsonObj);
                if (IK.floatIK.AbstractArmature.class.isAssignableFrom(s.getClass()))
                    armaturesJSON.append(jsonObj);
                if (IK.floatIK.AbstractBone.class.isAssignableFrom(s.getClass()))
                    bonesJSON.append(jsonObj);
                if (IK.floatIK.AbstractKusudama.class.isAssignableFrom(s.getClass()))
                    kusudamaJSON.append(jsonObj);
                if (IK.floatIK.AbstractLimitCone.class.isAssignableFrom(s.getClass()))
                    limitConeJSON.append(jsonObj);
                if (IK.floatIK.AbstractIKPin.class.isAssignableFrom(s.getClass()))
                    IKPinsJSON.append(jsonObj);
            }
        }

        saveObject.setJSONArray("axes", axesJSON);
        saveObject.setJSONArray("armatures", armaturesJSON);
        saveObject.setJSONArray("bones", bonesJSON);
        saveObject.setJSONArray("kusudamas", kusudamaJSON);
        saveObject.setJSONArray("limitCones", limitConeJSON);
        saveObject.setJSONArray("IKPins", IKPinsJSON);
        return saveObject;
    }

    public String getSaveString() {
        String resultString = getSaveObject().toString();
        return resultString;
    }

    private void saveAs(String savePath) {
        save(savePath);
    }

    public void save(String savePath) {
        JSONObject fileContent = getSaveObject();
        StringFuncs.saveJSONObject(fileContent, savePath);
    }


}