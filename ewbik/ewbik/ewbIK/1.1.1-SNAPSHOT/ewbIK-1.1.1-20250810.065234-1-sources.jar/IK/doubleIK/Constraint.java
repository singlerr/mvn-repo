package IK.doubleIK;

import asj.Saveable;
import math.doubleV.AbstractAxes;
import math.doubleV.Vec3d;

public interface Constraint extends Saveable {

    void snapToLimits();

    void disable();

    void enable();

    boolean isEnabled();

    //returns true if the ray from the constraint origin to the globalPoint is within the constraint's limits
    //false otherwise.
    <V extends Vec3d<?>> boolean isInLimits_(V globalPoint);

    <A extends AbstractAxes> A limitingAxes();

    /**
     * @return a measure of the rotational freedom afforded by this constraint.
     * with 0 meaning no rotational freedom (the bone is essentially stationary in relation to its parent)
     * and 1 meaning full rotational freedom (the bone is completely unconstrained).
     * <p>
     * This should be computed as ratio between orientations a bone can be in and orientations
     * a bone cannot be in as defined by its representation as a point on the surface of a hypersphere.
     */
    double getRotationalFreedom();


}
