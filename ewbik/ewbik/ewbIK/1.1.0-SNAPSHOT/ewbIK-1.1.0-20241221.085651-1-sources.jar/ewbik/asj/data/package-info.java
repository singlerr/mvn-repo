/**
 *
 */
/**
 * @author Eron Gjoni
 */

package ewbik.asj.data;