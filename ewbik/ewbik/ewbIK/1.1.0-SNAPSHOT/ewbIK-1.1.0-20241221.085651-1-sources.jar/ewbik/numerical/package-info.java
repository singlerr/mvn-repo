/**
 *
 */
/**
 * @author Eron Gjoni
 */

package ewbik.numerical;