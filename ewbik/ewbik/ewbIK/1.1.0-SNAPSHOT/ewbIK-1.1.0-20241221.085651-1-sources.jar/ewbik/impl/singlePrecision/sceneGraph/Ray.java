package ewbik.impl.singlePrecision.sceneGraph;

import org.joml.Vector3f;

/**
 * extremely basic implementation of a Ray
 * object to serve as an example for how to
 * extend this library
 *
 * @author Eron Gjoni
 */
public class Ray {

  public Vector3f p1, p2;

  public Ray(Vector3f p1, Vector3f p2) {
    this.p1 = p1;
    this.p2 = p2;
  }

  public Vector3f p1() {
	  if (p1 == null) {
		  p1 = new Vector3f();
	  }
    return this.p1;
  }

  public Vector3f p2() {
	  if (p2 == null) {
		  p2 = new Vector3f();
	  }
    return this.p1;
  }

}
