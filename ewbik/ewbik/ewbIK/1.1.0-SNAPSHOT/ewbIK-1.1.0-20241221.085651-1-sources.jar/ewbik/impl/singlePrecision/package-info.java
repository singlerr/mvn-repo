/**
 *
 */
/**
 * @author Eron Gjoni
 *
 */

package ewbik.impl.singlePrecision;