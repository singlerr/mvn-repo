package mod.chiselsandbits.render.chiseledblock;

import java.io.IOException;
import java.util.BitSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateInstance;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateReference;
import mod.chiselsandbits.client.model.baked.BaseSmartModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.render.ModelCombined;
import mod.chiselsandbits.render.cache.CacheMap;
import mod.chiselsandbits.utils.RenderTypeUtils;
import mod.chiselsandbits.utils.SimpleMaxSizedCache;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import net.minecraftforge.fml.config.ModConfig;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;

public class ChiseledBlockSmartModel extends BaseSmartModel implements ICacheClearable {
    public static final BitSet FLUID_RENDER_TYPES =
            new BitSet(class_1921.method_22720().size());
    private static final SimpleMaxSizedCache<ModelCacheKey, ChiseledBlockBakedModel> MODEL_CACHE =
            new SimpleMaxSizedCache<>(
                    ChiselsAndBits.getConfig().getClient().modelCacheSize.get());
    private static final CacheMap<class_1799, class_1087> ITEM_TO_MODEL_CACHE = new CacheMap<>();
    private static final CacheMap<VoxelBlobStateInstance, Integer> SIDE_CACHE = new CacheMap<>();
    private static final class_5819 RANDOM_SOURCE = class_5819.method_43047();

    public static int getSides(final TileEntityBlockChiseled te) {
        final VoxelBlobStateReference ref = te.getBlobStateReference();
        Integer out;

        if (ref == null) {
            return 0;
        }

        synchronized (SIDE_CACHE) {
            out = SIDE_CACHE.get(ref.getInstance());
            if (out == null) {
                final VoxelBlob blob = ref.getVoxelBlob();

                // ignore non-solid, and fluids.
                blob.filter(class_1921.method_23577());
                blob.filterFluids(false);

                out = blob.getSideFlags(0, VoxelBlob.dim_minus_one, VoxelBlob.dim2);
                SIDE_CACHE.put(ref.getInstance(), out);
            }
        }

        return out;
    }

    public static ChiseledBlockBakedModel getCachedModel(
            final TileEntityBlockChiseled te, final ChiselRenderType layer) {
        final VoxelBlobStateReference data = te.getBlobStateReference();
        Integer blockP = te.getPrimaryBlockStateId();
        VoxelBlob vBlob = (data != null) ? data.getVoxelBlob() : null;
        return getCachedModel(blockP, vBlob, layer, getModelFormat(), Objects.requireNonNull(te.method_10997()).field_9229);
    }

    public static ChiseledBlockBakedModel getCachedModel(final class_1799 stack, final ChiselRenderType layer) {
        Integer blockP = 0;
        return getCachedModel(
                blockP, ModUtil.getBlobFromStack(stack, null), layer, getModelFormat(), class_5819.method_43047());
    }

    private static class_293 getModelFormat() {
        return class_290.field_1590;
    }

    public static boolean ForgePipelineDisabled() {
        return ChiselsAndBits.getConfig().getClient().disableCustomVertexFormats.get();
    }

    public static ChiseledBlockBakedModel getCachedModel(
            final Integer blockP,
            final VoxelBlob data,
            final ChiselRenderType layer,
            final class_293 format,
            final class_5819 random) {
        if (data == null) {
            return new ChiseledBlockBakedModel(blockP, layer, null, format);
        }

        ChiseledBlockBakedModel out = null;

        if (format == getModelFormat()) {
            out = MODEL_CACHE.get(new ModelCacheKey(data, layer));
        }

        if (out == null) {
            out = new ChiseledBlockBakedModel(blockP, layer, data, format);

            if (out.isEmpty()) {
                out = ChiseledBlockBakedModel.breakingParticleModel(layer, blockP, random);
            }

            if (format == getModelFormat()) {
                MODEL_CACHE.put(new ModelCacheKey(data, layer), out);
            }
        } else {
            return out;
        }

        return out;
    }

    public static void onConfigurationReload(ModConfig modConfig) {
        MODEL_CACHE.changeMaxSize(
                ChiselsAndBits.getConfig().getClient().modelCacheSize.get());
    }

    @Override
    public class_1087 handleBlockState(
            class_2680 state, class_5819 random, IModelData modelData, ChiselRenderType renderType) {
        if (state == null) {
            return super.handleBlockState(state, random, modelData, renderType);
        }
        Map<ChiselRenderType, class_1087> pre;
        if (!modelData.getData(TileEntityBlockChiseled.MODEL_UPDATE)
                && (pre = modelData.getData(TileEntityBlockChiseled.MODEL_PROP)) != null) {
            return pre.get(renderType);
        }
        VoxelBlobStateReference data = modelData.getData(TileEntityBlockChiseled.MP_VBSR);
        int primaryStateId = modelData.getData(TileEntityBlockChiseled.MP_PBSI);
        final VoxelBlob blob = data == null ? null : data.getVoxelBlob();
        Map<ChiselRenderType, class_1087> typedModels = new ConcurrentHashMap<>();

        Set<Integer> states = ModUtil.getAllStates(blob);

        for (int s : states) {
            Optional<Pair<ChiselRenderType, class_1087>> opt = createModel(s, primaryStateId, blob, random);
            opt.ifPresent(model -> {
                typedModels.put(model.getKey(), model.getValue());
            });
        }

        modelData.setData(TileEntityBlockChiseled.MODEL_PROP, typedModels);

        return typedModels.get(renderType);
    }

    private Optional<ChiselRenderType> getRenderType(int stateId) {
        class_2680 state = ModUtil.getStateById(stateId);
        if (state.method_26215()) {
            return Optional.empty();
        }
        if (!state.method_26227().method_15769()) {
            return Optional.of(
                    ChiselRenderType.fromLayer(class_4696.method_23680(state.method_26227()), true));
        }
        return Optional.of(ChiselRenderType.fromLayer(class_4696.method_23679(state), false));
    }

    private Optional<Pair<ChiselRenderType, class_1087>> createModel(
            int stateId, int blockP, VoxelBlob blob, class_5819 randomSource) {
        class_2680 state = ModUtil.getStateById(stateId);
        if (state.method_26215()) {
            return Optional.empty();
        }

        if (ModUtil.isFluid(state)) {
            class_1921 renderType = class_4696.method_23680(state.method_26227());

            ChiselRenderType solidLayer, fluidLayer;
            ChiseledBlockBakedModel fluid = getCachedModel(
                    blockP,
                    blob,
                    fluidLayer = ChiselRenderType.fromLayer(renderType, true),
                    getModelFormat(),
                    randomSource);
            ChiseledBlockBakedModel solid = getCachedModel(
                    blockP,
                    blob,
                    solidLayer = ChiselRenderType.fromLayer(renderType, false),
                    getModelFormat(),
                    randomSource);
            class_1087 out;
            if (solid.isEmpty()) {
                out = fluid;
            } else if (fluid.isEmpty()) {
                out = solid;
            } else {
                out = new ModelCombined(Set.of(solidLayer, fluidLayer), solid, fluid);
            }

            return Optional.of(new ImmutablePair<>(fluidLayer, out));
        }

        ChiselRenderType renderType = ChiselRenderType.fromLayer(class_4696.method_23679(state), false);
        return Optional.of(new ImmutablePair<>(
                renderType, getCachedModel(blockP, blob, renderType, getModelFormat(), randomSource)));
    }

    @Override
    public class_1087 resolve(
            final class_1087 originalModel, final class_1799 stack, final class_1937 world, final class_1309 entity) {
        class_1087 mdl = ITEM_TO_MODEL_CACHE.get(stack);

        if (mdl != null) {
            return mdl;
        }

        class_2487 c = stack.method_7969();
        if (c == null) {
            return this;
        }

        c = c.method_10562(ModUtil.NBT_BLOCKENTITYTAG);

        final byte[] data = c.method_10547(NBTBlobConverter.NBT_LEGACY_VOXEL);
        byte[] vdata = c.method_10547(NBTBlobConverter.NBT_VERSIONED_VOXEL);
        final Integer blockP = c.method_10550(NBTBlobConverter.NBT_PRIMARY_STATE);

        if (vdata.length == 0 && data.length > 0) {
            final VoxelBlob xx = new VoxelBlob();

            try {
                xx.fromLegacyByteArray(data);
            } catch (final IOException e) {
                // :_(
            }

            vdata = xx.blobToBytes(VoxelBlob.VERSION_COMPACT_PALLETED);
        }
        byte[] finalVdata = vdata;
        final class_1087[] models =
                ModUtil.extractRenderTypes(new VoxelBlobStateReference(vdata, 0L).getVoxelBlob()).stream()
                        .flatMap(renderType -> {
                            class_1087 solidModel = getCachedModel(
                                    blockP,
                                    new VoxelBlobStateReference(finalVdata, 0L).getVoxelBlob(),
                                    ChiselRenderType.fromLayer(renderType, false),
                                    class_290.field_1590,
                                    RANDOM_SOURCE);
                            class_1087 fluidModel = getCachedModel(
                                    blockP,
                                    new VoxelBlobStateReference(finalVdata, 0L).getVoxelBlob(),
                                    ChiselRenderType.fromLayer(renderType, true),
                                    class_290.field_1590,
                                    RANDOM_SOURCE);
                            return Stream.of(solidModel, fluidModel);
                        })
                        .toArray(class_1087[]::new);
        mdl = new ModelCombined(models);

        ITEM_TO_MODEL_CACHE.put(stack, mdl);

        return mdl;
    }

    @Override
    public void clearCache() {
        SIDE_CACHE.clear();
        MODEL_CACHE.clear();
        ITEM_TO_MODEL_CACHE.clear();

        FLUID_RENDER_TYPES.clear();
        final List<class_1921> blockRenderTypes = class_1921.method_22720();
        for (int i = 0; i < blockRenderTypes.size(); i++) {
            final class_1921 renderType = blockRenderTypes.get(i);
            for (final class_3611 fluid : class_7923.field_41173) {
                if (RenderTypeUtils.canRenderInLayer(fluid.method_15785(), renderType)) {
                    FLUID_RENDER_TYPES.set(i);
                    break;
                }
            }
        }
    }

    @Override
    public boolean method_24304() {
        return true;
    }

    @Override
    public void updateModelData(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {

        VoxelBlobStateReference data = modelData.getData(TileEntityBlockChiseled.MP_VBSR);
        final VoxelBlob blob = data == null ? null : data.getVoxelBlob();
        Map<ChiselRenderType, class_1087> typedModels = new ConcurrentHashMap<>();
        int primaryStateId = modelData.getData(TileEntityBlockChiseled.MP_PBSI);

        Set<Integer> states = ModUtil.getAllStates(blob);

        for (int s : states) {
            Optional<Pair<ChiselRenderType, class_1087>> opt = createModel(s, primaryStateId, blob, RANDOM_SOURCE);
            opt.ifPresent(model -> {
                typedModels.put(model.getKey(), model.getValue());
            });
        }

        modelData.setData(TileEntityBlockChiseled.MODEL_PROP, typedModels);
        modelData.setData(TileEntityBlockChiseled.MODEL_UPDATE, false);
    }

    private Set<ChiselRenderType> getRenderTypes(VoxelBlob blob) {
        Set<ChiselRenderType> result = new HashSet<>();
        for (int state : ModUtil.getAllStates(blob)) {
            getRenderType(state).ifPresent(result::add);
        }
        return result;
    }

    @Override
    public Set<ChiselRenderType> getRenderTypes(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {
        if (!(world.method_8321(pos) instanceof TileEntityBlockChiseled te)) {
            return Set.of();
        }

        if (te.getBlob() == null) {
            return Set.of();
        }

        Map<ChiselRenderType, class_1087> data;
        if ((data = modelData.getData(TileEntityBlockChiseled.MODEL_PROP)) == null) {
            VoxelBlobStateReference blobRef = modelData.getData(TileEntityBlockChiseled.MP_VBSR);
            final VoxelBlob blob = blobRef == null ? null : blobRef.getVoxelBlob();
            return getRenderTypes(blob);
        }

        return data.keySet();
    }

    private static final class ModelCacheKey {
        private final VoxelBlob blob;
        private final ChiselRenderType type;

        private ModelCacheKey(final VoxelBlob blob, final ChiselRenderType type) {
            this.blob = blob;
            this.type = type;
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof ModelCacheKey that)) {
                return false;
            }
            return Objects.equals(blob, that.blob) && Objects.equals(type, that.type);
        }

        @Override
        public int hashCode() {
            return Objects.hash(blob, type);
        }
    }
}
