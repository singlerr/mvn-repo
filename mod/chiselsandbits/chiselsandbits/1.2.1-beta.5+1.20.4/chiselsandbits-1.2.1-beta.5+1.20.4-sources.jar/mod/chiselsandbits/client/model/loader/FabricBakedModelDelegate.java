package mod.chiselsandbits.client.model.loader;

import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.client.model.baked.DataAwareBakedModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FabricBakedModelDelegate implements class_1087, ICacheClearable {
    private static final Logger log = LoggerFactory.getLogger(FabricBakedModelDelegate.class);
    private final class_1087 delegate;

    private boolean cached = false;

    public FabricBakedModelDelegate(final class_1087 delegate) {
        this.delegate = delegate;
    }

    @Override
    public List<class_777> method_4707(
            @Nullable final class_2680 state, @Nullable final class_2350 direction, final @NotNull class_5819 random) {
        return delegate.method_4707(state, direction, random);
    }

    @Override
    public boolean method_4708() {
        return delegate.method_4708();
    }

    @Override
    public boolean method_4712() {
        return delegate.method_4712();
    }

    @Override
    public boolean method_24304() {
        return delegate.method_24304();
    }

    @Override
    public boolean method_4713() {
        return delegate.method_4713();
    }

    @Override
    public class_1058 method_4711() {
        return delegate.method_4711();
    }

    @Override
    public class_809 method_4709() {
        return delegate.method_4709();
    }

    @Override
    public class_806 method_4710() {
        return delegate.method_4710();
    }

    public class_1087 getDelegate() {
        return delegate;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(
            final class_1920 blockAndTintGetter,
            final class_2680 blockState,
            final class_2338 blockPos,
            final Supplier<class_5819> supplier,
            final RenderContext renderContext) {
        if (!(getDelegate() instanceof final DataAwareBakedModel dataAwareBakedModel)) {
            getDelegate().emitBlockQuads(blockAndTintGetter, blockState, blockPos, supplier, renderContext);
            return;
        }

        Object attachmentData = blockAndTintGetter.getBlockEntityRenderData(blockPos);

        if (attachmentData instanceof IModelData modelData) {
            dataAwareBakedModel.updateModelData(blockAndTintGetter, blockPos, blockState, modelData);
            emitBlockQuads(
                    dataAwareBakedModel, modelData, blockAndTintGetter, blockState, blockPos, supplier, renderContext);
        }
    }

    private void joinFluid(Set<ChiselRenderType> renderTypes) {
        ChiselRenderType nonFluid = null;
        ChiselRenderType fluid = null;
        for (ChiselRenderType renderType : renderTypes) {
            if (renderType == ChiselRenderType.TRANSLUCENT) {
                nonFluid = ChiselRenderType.TRANSLUCENT;
            } else if (renderType == ChiselRenderType.TRANSLUCENT_FLUID) {
                fluid = ChiselRenderType.TRANSLUCENT_FLUID;
            }
        }
        // if fluid and non-fluid coexist, keep the former and remove the latter
        if (fluid != null && nonFluid != null) {
            renderTypes.remove(nonFluid);
        }
    }

    public void emitBlockQuads(
            final DataAwareBakedModel dataAwareBakedModel,
            final IModelData blockModelData,
            final class_1920 world,
            final class_2680 blockState,
            final class_2338 blockPos,
            final Supplier<class_5819> supplier,
            final RenderContext renderContext) {
        if (!cached) {
            BlockBitInfo.recalculate();
            VoxelBlob.clearCache();
            cached = true;
        }

        Set<ChiselRenderType> renderTypes =
                dataAwareBakedModel.getRenderTypes(world, blockPos, blockState, blockModelData);

        joinFluid(renderTypes);

        log.info("{}", renderTypes);

        for (class_2350 direction : class_2350.values()) {
            renderTypes.forEach(renderType -> emitBlockQuads(
                    dataAwareBakedModel,
                    blockModelData,
                    blockState,
                    blockPos,
                    direction,
                    supplier,
                    renderContext,
                    renderType,
                    RendererAccess.INSTANCE
                            .getRenderer()
                            .materialFinder()
                            .blendMode(BlendMode.fromRenderLayer(renderType.layer))
                            .find()));
        }

        renderTypes.forEach(renderType -> emitBlockQuads(
                dataAwareBakedModel,
                blockModelData,
                blockState,
                blockPos,
                null,
                supplier,
                renderContext,
                renderType,
                RendererAccess.INSTANCE
                        .getRenderer()
                        .materialFinder()
                        .blendMode(BlendMode.fromRenderLayer(renderType.layer))
                        .find()));
    }

    public void emitBlockQuads(
            final DataAwareBakedModel dataAwareBakedModel,
            final IModelData blockModelData,
            final class_2680 blockState,
            final class_2338 blockPos,
            final class_2350 direction,
            final Supplier<class_5819> supplier,
            final RenderContext renderContext,
            ChiselRenderType renderType,
            RenderMaterial renderMaterial) {
        final List<class_777> quads =
                dataAwareBakedModel.getQuads(blockState, direction, supplier.get(), blockModelData, renderType);

        final RenderMaterial material = renderMaterial;

        quads.forEach(quad -> {
            final MeshBuilder meshBuilder =
                    RendererAccess.INSTANCE.getRenderer().meshBuilder();
            final QuadEmitter emitter = meshBuilder.getEmitter();
            emitter.fromVanilla(quad, material, direction);
            emitter.emit();
            renderContext.meshConsumer().accept(meshBuilder.build());
        });
    }

    @Override
    public void emitItemQuads(
            final class_1799 itemStack, final Supplier<class_5819> supplier, final RenderContext renderContext) {
        if (!cached) {
            BlockBitInfo.recalculate();
            VoxelBlob.clearCache();
            cached = true;
        }
        final class_1087 itemModel = getDelegate()
                .method_4710()
                .method_3495(
                        getDelegate(),
                        itemStack,
                        class_310.method_1551().field_1687,
                        class_310.method_1551().field_1724,
                        supplier.get().method_43054());

        renderContext.pushTransform(quad -> true);
        if (itemModel != null) {
            itemModel.emitItemQuads(itemStack, supplier, renderContext);
        }

        renderContext.popTransform();
    }

    @Override
    public void clearCache() {
        if (delegate instanceof ICacheClearable cache) {
            cache.clearCache();
        }
    }

    @FunctionalInterface
    private interface QuadGetter {

        List<class_777> getQuads(class_2680 blockState, class_2350 side, class_5819 rand);
    }

    private static final class QuadDelegatingBakedModel extends ForwardingBakedModel {
        private final QuadGetter quadGetter;

        private QuadDelegatingBakedModel(final class_1087 delegate, final QuadGetter quadGetter) {
            this.quadGetter = quadGetter;
            this.wrapped = delegate;
        }

        @Override
        public List<class_777> method_4707(
                @Nullable final class_2680 blockState, @Nullable final class_2350 direction, final class_5819 random) {
            return quadGetter.getQuads(blockState, direction, random);
        }
    }
}
