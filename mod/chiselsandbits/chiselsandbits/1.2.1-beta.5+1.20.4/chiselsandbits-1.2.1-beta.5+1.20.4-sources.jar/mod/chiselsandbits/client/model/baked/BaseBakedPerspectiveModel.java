package mod.chiselsandbits.client.model.baked;

import mod.chiselsandbits.utils.TransformationUtils;
import net.minecraft.class_1087;
import net.minecraft.class_4587;
import net.minecraft.class_4590;
import net.minecraft.class_5819;
import net.minecraft.class_804;
import net.minecraft.class_809;
import net.minecraft.class_811;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public abstract class BaseBakedPerspectiveModel implements class_1087, TransformTypeDependentItemBakedModel {

    protected static final class_5819 RANDOM = class_5819.method_43047();

    private static final class_4590 ground;
    private static final class_4590 gui;
    private static final class_4590 fixed;
    private static final class_4590 firstPerson_righthand;
    private static final class_4590 firstPerson_lefthand;
    private static final class_4590 thirdPerson_righthand;
    private static final class_4590 thirdPerson_lefthand;

    static {
        gui = getMatrix(0, 0, 0, 30, 225, 0, 0.625f);
        ground = getMatrix(0, 3 / 16.0f, 0, 0, 0, 0, 0.25f);
        fixed = getMatrix(0, 0, 0, 0, 0, 0, 0.5f);
        thirdPerson_lefthand = thirdPerson_righthand = getMatrix(0, 2.5f / 16.0f, 0, 75, 45, 0, 0.375f);
        firstPerson_righthand = firstPerson_lefthand = getMatrix(0, 0, 0, 0, 45, 0, 0.40f);
    }

    private static class_4590 getMatrix(
            final float transX,
            final float transY,
            final float transZ,
            final float rotX,
            final float rotY,
            final float rotZ,
            final float scaleXYZ) {
        final Vector3f translation = new Vector3f(transX, transY, transZ);
        final Vector3f scale = new Vector3f(scaleXYZ, scaleXYZ, scaleXYZ);
        final Quaternionf rotation = TransformationUtils.quatFromXYZ(rotX, rotY, rotZ, true);
        return new class_4590(translation, rotation, scale, null);
    }

    @Override
    public class_809 method_4709() {
        return new PerspectiveItemModelDelegate(this);
    }

    @Override
    public class_1087 applyTransform(class_811 context, class_4587 poseStack, boolean leftHand) {
        switch (context) {
            case field_4321:
                TransformationUtils.push(poseStack, firstPerson_lefthand, leftHand);
                return this;
            case field_4322:
                TransformationUtils.push(poseStack, firstPerson_righthand, leftHand);
                return this;
            case field_4323:
                TransformationUtils.push(poseStack, thirdPerson_lefthand, leftHand);
                return this;
            case field_4320:
                TransformationUtils.push(poseStack, thirdPerson_righthand, leftHand);
            case field_4319:
                TransformationUtils.push(poseStack, firstPerson_righthand, leftHand);
                return this;
            case field_4318:
                TransformationUtils.push(poseStack, ground, leftHand);
                return this;
            case field_4317:
                TransformationUtils.push(poseStack, gui, leftHand);
                return this;
            default:
        }

        TransformationUtils.push(poseStack, fixed, leftHand);
        return this;
    }

    private static final class PerspectiveItemModelDelegate extends class_809 {

        private final TransformTypeDependentItemBakedModel delegate;

        public PerspectiveItemModelDelegate(TransformTypeDependentItemBakedModel delegate) {
            super(
                    class_804.field_4284,
                    class_804.field_4284,
                    class_804.field_4284,
                    class_804.field_4284,
                    class_804.field_4284,
                    class_804.field_4284,
                    class_804.field_4284,
                    class_804.field_4284);
            this.delegate = delegate;
        }

        @Override
        public class_804 method_3503(class_811 itemDisplayContext) {
            return new class_804(new Vector3f(), new Vector3f(), new Vector3f()) {
                @Override
                public void method_23075(boolean bl, class_4587 poseStack) {
                    delegate.applyTransform(itemDisplayContext, poseStack, bl);
                }
            };
        }
    }
}
