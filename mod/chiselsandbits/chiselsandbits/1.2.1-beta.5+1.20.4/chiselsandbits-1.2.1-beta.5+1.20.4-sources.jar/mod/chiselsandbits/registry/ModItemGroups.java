package mod.chiselsandbits.registry;

import com.google.common.base.Suppliers;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;
import mod.chiselsandbits.api.BlockProvider;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.client.CreativeClipboardTab;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.api.ChiselAndBitsAPI;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2404;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_7923;

public final class ModItemGroups {

    public static final Supplier<class_1761> MAIN_TAB =
            Suppliers.memoize(() -> class_1761.method_47307(class_1761.class_7915.field_41049, 1)
                    .method_47320(() -> new class_1799(ModItems.ITEM_BIT_BAG_DYED.get()))
                    .method_47321(class_2561.method_43470("Chisels and bits"))
                    .method_47317((params, output) -> {
                        output.method_45420(new class_1799(ModItems.ITEM_CHISEL_STONE.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_CHISEL_IRON.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_CHISEL_GOLD.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_CHISEL_DIAMOND.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_CHISEL_NETHERITE.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_BIT_BAG_DEFAULT.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_BIT_BAG_DYED.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_POSITIVE_PRINT.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_MAGNIFYING_GLASS.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_TAPE_MEASURE.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_NEGATIVE_PRINT.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_MIRROR_PRINT.get()));
                        output.method_45420(new class_1799(ModItems.ITEM_MIRROR_PRINT_WRITTEN.get()));
                    })
                    .method_47324());
    public static final Supplier<class_1761> BLOCK_BITS = Suppliers.memoize(() -> class_1761.method_47307(
                    class_1761.class_7915.field_41049, 1)
            .method_47320(() -> new class_1799(ModItems.ITEM_BLOCK_BIT.get()))
            .method_47321(class_2561.method_43470("Block bits"))
            .method_47317((params, output) -> {
                for (class_2248 block : class_7923.field_41175) {
                    if (block instanceof BlockChiseled) {
                        continue;
                    }
                    Set<Integer> reservedStates = new HashSet<>();
                    for (BlockProvider stateProvider :
                            ((ChiselAndBitsAPI) ChiselsAndBits.getApi()).getStateProviders()) {
                        for (class_2248 b : stateProvider.getBlocks()) {
                            for (class_2680 state : b.method_9595().method_11662()) {
                                if (BlockBitInfo.canChisel(state)) {
                                    int stateId = ModUtil.getStateId(state);
                                    class_1799 itemStack = ItemChiseledBit.createStack(stateId, 1, true);
                                    try {
                                        output.method_45420(itemStack);
                                    } catch (Exception e) {
                                    }
                                    reservedStates.add(stateId);
                                }
                            }
                        }
                    }

                    class_2680 blockState = block.method_9564();

                    if (block instanceof class_2404 liquidBlock) {
                        class_3611 fluid = liquidBlock.method_9545(blockState).method_15772();
                        if (fluid instanceof class_3609 flowingFluid) {
                            blockState =
                                    flowingFluid.method_15751().method_15785().method_15759();
                        }
                    }

                    if (BlockBitInfo.canChisel(blockState)) {
                        int stateId = ModUtil.getStateId(blockState);
                        if (reservedStates.contains(stateId)) {
                            continue;
                        }
                        class_1799 itemStack = ItemChiseledBit.createStack(stateId, 1, true);
                        output.method_45420(itemStack);
                    }
                }
            })
            .method_47324());
    public static Supplier<class_1761> CLIPBOARD =
            Suppliers.memoize(() -> class_1761.method_47307(class_1761.class_7915.field_41049, 1)
                    .method_47320(() -> new class_1799(ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get()))
                    .method_47321(class_2561.method_43470("Clipboard"))
                    .method_47317((parameters, output) -> {
                        output.method_45423(CreativeClipboardTab.getInstance().getClipboard());
                    })
                    .method_47324());

    private ModItemGroups() {
        throw new IllegalStateException("Tried to initialize: ModItemGroups but this is a Utility class.");
    }

    public static void onModConstruction() {
        class_2378.method_10230(
                class_7923.field_44687,
                new class_2960(Constants.MOD_ID, "main_tab"),
                MAIN_TAB.get());
        class_2378.method_10230(
                class_7923.field_44687,
                new class_2960(Constants.MOD_ID, "block_bits"),
                BLOCK_BITS.get());
        class_2378.method_10230(
                class_7923.field_44687,
                new class_2960(Constants.MOD_ID, "clipboard"),
                CLIPBOARD.get());
    }
}
