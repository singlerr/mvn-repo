package mod.chiselsandbits.registry;

import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import mod.chiselsandbits.bitstorage.BlockBitStorage;
import mod.chiselsandbits.bitstorage.ItemBlockBitStorage;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.ReflectionHelperBlock;
import mod.chiselsandbits.printer.ChiselPrinterBlock;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {

    public static final Supplier<BlockBitStorage> BIT_STORAGE_BLOCK =
            Suppliers.memoize(() -> new BlockBitStorage(class_4970.class_2251.method_9637()
                    .method_9629(1.5F, 6.0F)
                    .method_29292()
                    .method_9624()
                    .method_22488()
                    .method_26235((p_test_1_, p_test_2_, p_test_3_, p_test_4_) -> false)
                    .method_26236((p_test_1_, p_test_2_, p_test_3_) -> false)
                    .method_26243((p_test_1_, p_test_2_, p_test_3_) -> false)
                    .method_26245((p_test_1_, p_test_2_, p_test_3_) -> false)));

    public static final Supplier<ItemBlockBitStorage> BIT_STORAGE_BLOCK_ITEM =
            Suppliers.memoize(() -> new ItemBlockBitStorage(BIT_STORAGE_BLOCK.get(), new class_1792.class_1793()));
    public static final Supplier<ChiselPrinterBlock> CHISEL_PRINTER_BLOCK =
            Suppliers.memoize(() -> new ChiselPrinterBlock(class_4970.class_2251.method_9637()
                    .method_9629(1.5f, 6f)
                    .method_22488()
                    .method_26236((p_test_1_, p_test_2_, p_test_3_) -> false)
                    .method_26245((p_test_1_, p_test_2_, p_test_3_) -> false)));

    public static final Supplier<BlockChiseled> CHISELED_BLOCK = Suppliers.memoize(() -> new BlockChiseled(
            "chiseled_block",
            class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15972)
                    .method_9629(3.5f, 3.5f)
                    .method_26245((p_test_1_, p_test_2_, p_test_3_) -> false)
                    .method_26236((p_test_1_, p_test_2_, p_test_3_) -> false)
                    .method_22488()));
    public static final Supplier<class_1747> CHISEL_PRINTER_ITEM =
            Suppliers.memoize(() -> new class_1747(CHISEL_PRINTER_BLOCK.get(), new class_1792.class_1793()));

    public static final Supplier<ReflectionHelperBlock> REFLECTION_HELPER_BLOCK =
            Suppliers.memoize(ReflectionHelperBlock::new);

    private ModBlocks() {
        throw new IllegalStateException("Tried to initialize: ModBlocks but this is a Utility class.");
    }

    public static void onModConstruction() {
        class_2378.method_10230(
                class_7923.field_41175,
                new class_2960(Constants.MOD_ID, "bit_storage"),
                BIT_STORAGE_BLOCK.get());
        class_2378.method_10230(
                class_7923.field_41175,
                new class_2960(Constants.MOD_ID, "chiseled_printer"),
                CHISEL_PRINTER_BLOCK.get());
        class_2378.method_10230(
                class_7923.field_41175,
                new class_2960(Constants.MOD_ID, "chiseled_block"),
                CHISELED_BLOCK.get());
        class_2378.method_10230(
                class_7923.field_41175,
                new class_2960(Constants.MOD_ID, "reflection_helper_block"),
                REFLECTION_HELPER_BLOCK.get());

        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "bit_storage"),
                BIT_STORAGE_BLOCK_ITEM.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "chiseled_printer"),
                CHISEL_PRINTER_ITEM.get());
    }

    public static class_2680 getChiseledDefaultState() {
        return CHISELED_BLOCK.get().method_9564();
    }

    public static BlockChiseled getChiseledBlock() {
        return CHISELED_BLOCK.get();
    }
}
