package mod.chiselsandbits.client;

import mod.chiselsandbits.helpers.ModUtil;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_322;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BlockColorChisled implements class_322 {

    public static final int TINT_MASK = 0xff;
    public static final int TINT_BITS = 8;

    @Override
    public int getColor(
            @NotNull final class_2680 state,
            @Nullable final class_1920 displayReader,
            @Nullable final class_2338 pos,
            final int color) {
        final class_2680 containedState = ModUtil.getStateById(color >> TINT_BITS);
        int tintValue = color & TINT_MASK;
        return class_310.method_1551().method_1505().method_1697(containedState, displayReader, pos, tintValue);
    }
}
