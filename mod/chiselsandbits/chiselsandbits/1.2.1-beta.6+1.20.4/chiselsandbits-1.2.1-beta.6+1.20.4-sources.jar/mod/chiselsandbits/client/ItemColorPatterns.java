package mod.chiselsandbits.client;

import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.render.helpers.ModelUtil;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_326;

public class ItemColorPatterns implements class_326 {

    @Override
    public int getColor(final class_1799 stack, final int tint) {
        if (ClientSide.instance.holdingShift()) {
            final class_2680 state = ModUtil.getStateById(tint >> BlockColorChisled.TINT_BITS);
            final class_2248 blk = state.method_26204();
            final class_1792 i = class_1792.method_7867(blk);
            int tintValue = tint & BlockColorChisled.TINT_MASK;

            if (i != null) {
                return ModelUtil.getItemStackColor(new class_1799(i, 1), tintValue);
            }

            return 0xffffff;
        }

        return 0xffffffff;
    }
}
