package mod.chiselsandbits.helpers;

import javax.annotation.Nonnull;
import mod.chiselsandbits.api.ChiselsAndBitsEvents;
import mod.chiselsandbits.api.EventBlockBitModification;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class ActingPlayer {
    private final class_1263 storage;

    // used to test permission and stuff...
    private final class_1657 innerPlayer;
    private final boolean realPlayer; // are we a real player?
    private final class_1268 hand;
    // permission check cache.
    class_2338 lastPos = null;
    Boolean lastPlacement = null;
    class_1799 lastPermissionBit = null;
    Boolean permissionResult = null;

    private ActingPlayer(final class_1657 player, final boolean realPlayer, final class_1268 hand) {
        innerPlayer = player;
        this.hand = hand;
        this.realPlayer = realPlayer;
        storage = realPlayer ? player.field_7514 : new PlayerCopiedInventory(player.field_7514);
    }

    @Nonnull
    public static ActingPlayer actingAs(final class_1657 player, final class_1268 hand) {
        return new ActingPlayer(player, true, hand);
    }

    @Nonnull
    public static ActingPlayer testingAs(final class_1657 player, final class_1268 hand) {
        return new ActingPlayer(player, false, hand);
    }

    public class_1263 getInventory() {
        return storage;
    }

    public int getCurrentItem() {
        return innerPlayer.field_7514.field_7545;
    }

    public boolean isCreative() {
        return innerPlayer.method_7337();
    }

    public class_1799 getCurrentEquippedItem() {
        return storage.method_5438(getCurrentItem());
    }

    public boolean canPlayerManipulate(
            final @Nonnull class_2338 pos,
            final @Nonnull class_2350 side,
            final @Nonnull class_1799 is,
            final boolean placement) {
        // only re-test if something changes.
        if (permissionResult == null || lastPermissionBit != is || lastPos != pos || placement != lastPlacement) {
            lastPos = pos;
            lastPlacement = placement;
            lastPermissionBit = is;

            if (innerPlayer.method_7343(pos, side, is)
                    && innerPlayer.method_5770().method_8505(innerPlayer, pos)) {
                final EventBlockBitModification event = new EventBlockBitModification(
                        innerPlayer.method_5770(), pos, innerPlayer, hand, is, placement);
                ChiselsAndBitsEvents.BLOCK_BIT_MODIFICATION.invoker().handle(event);
                permissionResult = !event.isCancelled();
            } else {
                permissionResult = false;
            }
        }

        return permissionResult;
    }

    public void damageItem(final class_1799 stack, final int amount) {
        if (realPlayer) {
            stack.method_7956(amount, innerPlayer, playerEntity -> {});
        } else {
            stack.method_7974(stack.method_7919() + amount);
        }
    }

    public void playerDestroyItem(final @Nonnull class_1799 stack, final class_1268 hand) {
        if (realPlayer) {
            //			net.minecraftforge.event.ForgeEventFactory.onPlayerDestroyItem( innerPlayer, stack, hand );
        }
    }

    public class_1937 getWorld() {
        return innerPlayer.method_5770();
    }

    /**
     * only call this is you require a player, and only as a last resort.
     */
    public class_1657 getPlayer() {
        return innerPlayer;
    }

    public boolean isReal() {
        return realPlayer;
    }

    /**
     * @return the hand
     */
    public class_1268 getHand() {
        return hand;
    }
}
