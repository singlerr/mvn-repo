package mod.chiselsandbits.core;

import com.google.common.base.Stopwatch;
import com.mojang.blaze3d.systems.RenderSystem;
import committee.nova.mkb.api.IKeyBinding;
import committee.nova.mkb.api.IKeyConflictContext;
import committee.nova.mkb.keybinding.KeyConflictContext;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.APIExceptions.CannotBeChiseled;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.IBitBrush;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.api.ModKeyBinding;
import mod.chiselsandbits.api.ReplacementStateHandler;
import mod.chiselsandbits.bitstorage.TileEntitySpecialRenderBitStorage;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.BitIterator;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.IntegerBox;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateReference;
import mod.chiselsandbits.chiseledblock.iterators.ChiselIterator;
import mod.chiselsandbits.chiseledblock.iterators.ChiselTypeIterator;
import mod.chiselsandbits.client.BlockColorChisled;
import mod.chiselsandbits.client.CreativeClipboardTab;
import mod.chiselsandbits.client.ItemColorBitBag;
import mod.chiselsandbits.client.ItemColorBits;
import mod.chiselsandbits.client.ItemColorChiseled;
import mod.chiselsandbits.client.ItemColorPatterns;
import mod.chiselsandbits.client.ModConflictContext;
import mod.chiselsandbits.client.RenderHelper;
import mod.chiselsandbits.client.TapeMeasures;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.client.gui.ChiselsAndBitsMenu;
import mod.chiselsandbits.client.gui.SpriteIconPositioning;
import mod.chiselsandbits.compat.client.DrawSelectionEvents;
import mod.chiselsandbits.compat.client.GameMouseEvents;
import mod.chiselsandbits.compat.client.OverlayRenderCallback;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.ChiselModeManager;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.helpers.ReadyState;
import mod.chiselsandbits.helpers.VoxelRegionSrc;
import mod.chiselsandbits.interfaces.IItemScrollWheel;
import mod.chiselsandbits.interfaces.IPatternItem;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.modes.IToolMode;
import mod.chiselsandbits.modes.PositivePatternMode;
import mod.chiselsandbits.modes.TapeMeasureModes;
import mod.chiselsandbits.network.packets.PacketChisel;
import mod.chiselsandbits.network.packets.PacketRotateVoxelBlob;
import mod.chiselsandbits.network.packets.PacketSetColor;
import mod.chiselsandbits.network.packets.PacketSuppressInteraction;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.registry.ModTileEntityTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1041;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1723;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5616;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_727;
import net.minecraft.class_761;
import org.lwjgl.opengl.GL11;

public class ClientSide {

    public static final ClientSide instance = new ClientSide();
    private static final Random RANDOM = new SecureRandom();
    public static class_1058 undoIcon;
    public static class_1058 redoIcon;
    public static class_1058 trashIcon;
    public static class_1058 sortIcon;
    public static class_1058 swapIcon;
    public static class_1058 placeIcon;
    public static class_1058 roll_x;
    public static class_1058 roll_z;
    public static class_1058 white;
    public final TapeMeasures tapeMeasures = new TapeMeasures();
    private final HashMap<IToolMode, SpriteIconPositioning> chiselModeIcons = new HashMap<>();
    ReadyState readyState = ReadyState.PENDING_PRE;
    boolean wasDrawing = false;
    int displayStatus = 0;

    @Nonnull
    ChiselToolType lastTool = ChiselToolType.CHISEL;

    @Nonnull
    class_1268 lastHand = class_1268.field_5808;

    private class_304 rotateCCW;
    private class_304 rotateCW;
    private class_304 undo;
    private class_304 redo;
    private class_304 modeMenu;
    private class_304 addToClipboard;
    private class_304 pickBit;
    private class_304 offgridPlacement;
    private Stopwatch rotateTimer;
    private class_1799 previousItem;
    private int previousRotations;
    private Object previousModel;
    private Object previousCacheRef;
    private IntegerBox modelBounds;
    private boolean isVisible = true;
    private boolean isUnplaceable = true;
    private class_2338 lastPartial;
    private class_2338 lastPos;
    private BitLocation drawStart;
    private int ticksSinceRelease = 0;
    private int lastRenderedFrame = Integer.MIN_VALUE;

    public static void placeSound(final class_1937 world, final class_2338 pos, final int stateID) {
        final class_2680 state = ModUtil.getStateById(stateID);
        final class_2248 block = state.method_26204();
        world.method_8486(
                pos.method_10263() + 0.5,
                pos.method_10264() + 0.5,
                pos.method_10260() + 0.5,
                DeprecationHelper.getSoundType(block).method_10598(),
                class_3419.field_15245,
                (DeprecationHelper.getSoundType(block).method_10597() + 1.0F) / 16.0F,
                DeprecationHelper.getSoundType(block).method_10599() * 0.9F,
                false);
    }

    public static void breakSound(final class_1937 world, final class_2338 pos, final int extractedState) {
        final class_2680 state = ModUtil.getStateById(extractedState);
        final class_2248 block = state.method_26204();
        world.method_8486(
                pos.method_10263() + 0.5,
                pos.method_10264() + 0.5,
                pos.method_10260() + 0.5,
                DeprecationHelper.getSoundType(block).method_10595(),
                class_3419.field_15245,
                (DeprecationHelper.getSoundType(block).method_10597() + 1.0F) / 16.0F,
                DeprecationHelper.getSoundType(block).method_10599() * 0.9F,
                false);
    }

    public static boolean offGridPlacement(class_1657 player) {
        if (player instanceof FakePlayer) {
            return false;
        }

        if (player.method_5770().field_9236) {
            return !getOffGridPlacementKey().method_1415()
                    && getOffGridPlacementKey().method_1434();
        }

        throw new RuntimeException("checking keybinds on server.");
    }

    public static class_304 getOffGridPlacementKey() {
        if (ClientSide.instance.offgridPlacement.method_1415() && ClientSide.instance.offgridPlacement.method_1427()) {
            return class_310.method_1551().field_1690.field_1832;
        }

        return ClientSide.instance.offgridPlacement;
    }

    public class_304 getKeyBinding(ModKeyBinding modKeyBinding) {
        return switch (modKeyBinding) {
            case ROTATE_CCW -> rotateCCW;
            case ROTATE_CW -> rotateCW;
            case UNDO -> undo;
            case REDO -> redo;
            case ADD_TO_CLIPBOARD -> addToClipboard;
            case PICK_BIT -> pickBit;
            case OFFGRID_PLACEMENT -> ClientSide.getOffGridPlacementKey();
            default -> modeMenu;
        };
    }

    public void preInit() {
        readyState = readyState.updateState(ReadyState.TRIGGER_PRE);
        OverlayRenderCallback.EVENT.register(this::onRenderGUI);
        UseBlockCallback.EVENT.register(this::drawingInteractionPrevention);
        ClientTickEvents.START_CLIENT_TICK.register(this::applyChiselDelay);
        ClientTickEvents.END_CLIENT_TICK.register(this::interaction);
        WorldRenderEvents.LAST.register(this::drawLast);
        WorldRenderEvents.LAST.register(this::drawHighlight);
        DrawSelectionEvents.BLOCK.register(this::drawHighlight);

        GameMouseEvents.BEFORE_SCROLL.register(this::wheelEvent);
    }

    public void init() {
        readyState = readyState.updateState(ReadyState.TRIGGER_INIT);
        class_5616.method_32144(
                ModTileEntityTypes.BIT_STORAGE.get(),
                context -> new TileEntitySpecialRenderBitStorage(context.method_32139()));

        for (final ChiselMode mode : ChiselMode.values()) {
            mode.binding = registerKeybind(
                    mode.string.toString(),
                    class_3675.field_16237,
                    "itemGroup.chiselsandbits",
                    ModConflictContext.HOLDING_CHISEL);
        }

        for (final PositivePatternMode mode : PositivePatternMode.values()) {
            mode.binding = registerKeybind(
                    mode.string.toString(),
                    class_3675.field_16237,
                    "itemGroup.chiselsandbits",
                    ModConflictContext.HOLDING_POSTIVEPATTERN);
        }

        for (final TapeMeasureModes mode : TapeMeasureModes.values()) {
            mode.binding = registerKeybind(
                    mode.string.toString(),
                    class_3675.field_16237,
                    "itemGroup.chiselsandbits",
                    ModConflictContext.HOLDING_TAPEMEASURE);
        }

        modeMenu = registerKeybind(
                "mod.chiselsandbits.other.mode",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                ModConflictContext.HOLDING_MENUITEM);
        rotateCCW = registerKeybind(
                "mod.chiselsandbits.other.rotate.ccw",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                ModConflictContext.HOLDING_ROTATEABLE);
        rotateCW = registerKeybind(
                "mod.chiselsandbits.other.rotate.cw",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                ModConflictContext.HOLDING_ROTATEABLE);
        pickBit = registerKeybind(
                "mod.chiselsandbits.other.pickbit",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                ModConflictContext.HOLDING_ROTATEABLE);
        offgridPlacement = registerKeybind(
                "mod.chiselsandbits.other.offgrid",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                ModConflictContext.HOLDING_OFFGRID);
        undo = registerKeybind(
                "mod.chiselsandbits.other.undo",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                KeyConflictContext.IN_GAME);
        redo = registerKeybind(
                "mod.chiselsandbits.other.redo",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                KeyConflictContext.IN_GAME);
        addToClipboard = registerKeybind(
                "mod.chiselsandbits.other.add_to_clipboard",
                class_3675.field_16237,
                "itemGroup.chiselsandbits",
                KeyConflictContext.IN_GAME);
    }

    private class_304 registerKeybind(
            final String bindingName,
            final class_3675.class_306 defaultKey,
            final String groupName,
            final IKeyConflictContext context) {
        final class_304 kb = new class_304(bindingName, defaultKey.method_1444(), groupName);
        if (kb instanceof IKeyBinding ext) {
            ext.setKeyConflictContext(context);
        }
        KeyBindingHelper.registerKeyBinding(kb);
        return kb;
    }

    public void postInit() {
        readyState = readyState.updateState(ReadyState.TRIGGER_POST);

        var itemColorRegistry = ColorProviderRegistry.ITEM;
        var blockColorRegistry = ColorProviderRegistry.BLOCK;

        itemColorRegistry.register(new ItemColorBitBag(), ModItems.ITEM_BIT_BAG_DEFAULT.get());
        itemColorRegistry.register(new ItemColorBitBag(), ModItems.ITEM_BIT_BAG_DYED.get());
        itemColorRegistry.register(new ItemColorBits(), ModItems.ITEM_BLOCK_BIT.get());
        itemColorRegistry.register(new ItemColorPatterns(), ModItems.ITEM_POSITIVE_PRINT.get());
        itemColorRegistry.register(new ItemColorPatterns(), ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get());
        itemColorRegistry.register(new ItemColorPatterns(), ModItems.ITEM_NEGATIVE_PRINT.get());
        itemColorRegistry.register(new ItemColorPatterns(), ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get());
        itemColorRegistry.register(new ItemColorPatterns(), ModItems.ITEM_MIRROR_PRINT.get());
        itemColorRegistry.register(new ItemColorPatterns(), ModItems.ITEM_MIRROR_PRINT_WRITTEN.get());

        blockColorRegistry.register(new BlockColorChisled(), ModBlocks.CHISELED_BLOCK.get());
        itemColorRegistry.register(new ItemColorChiseled(), ModItems.ITEM_CHISELED_BLOCK.get());
    }

    public SpriteIconPositioning getIconForMode(final IToolMode mode) {
        return chiselModeIcons.get(mode);
    }

    public void setIconForMode(final IToolMode mode, final SpriteIconPositioning positioning) {
        chiselModeIcons.put(mode, positioning);
    }

    public boolean onRenderGUI(
            class_332 guiGraphics, float partialTicks, class_1041 window, OverlayRenderCallback.Types type) {
        final ChiselToolType tool = getHeldToolType(lastHand);
        if (type == OverlayRenderCallback.Types.CROSSHAIRS && tool != null && tool.hasMenu()) {
            final boolean wasVisible = ChiselsAndBitsMenu.instance.isVisible();

            if (!modeMenu.method_1415() && modeMenu.method_1434()) {
                ChiselsAndBitsMenu.instance.actionUsed = false;
                if (ChiselsAndBitsMenu.instance.raiseVisibility()) {
                    class_310.method_1551().field_1729.method_1610();
                }
            } else {
                if (!ChiselsAndBitsMenu.instance.actionUsed) {
                    if (ChiselsAndBitsMenu.instance.switchTo != null) {
                        ClientSide.instance.playRadialMenu();
                        ChiselModeManager.changeChiselMode(
                                tool,
                                ChiselModeManager.getChiselMode(getPlayer(), tool, class_1268.field_5808),
                                ChiselsAndBitsMenu.instance.switchTo);
                    }

                    if (ChiselsAndBitsMenu.instance.doAction != null) {
                        ClientSide.instance.playRadialMenu();
                        switch (ChiselsAndBitsMenu.instance.doAction) {
                            case ROLL_X:
                                PacketRotateVoxelBlob pri = new PacketRotateVoxelBlob(class_2351.field_11048, class_2470.field_11463);
                                ChiselsAndBits.getNetworkChannel().sendToServer(pri);
                                break;

                            case ROLL_Z:
                                PacketRotateVoxelBlob pri2 = new PacketRotateVoxelBlob(class_2351.field_11051, class_2470.field_11463);
                                ChiselsAndBits.getNetworkChannel().sendToServer(pri2);
                                break;

                            case REPLACE_TOGGLE:
                                ReplacementStateHandler.getInstance()
                                        .setReplacing(!ReplacementStateHandler.getInstance()
                                                .isReplacing());
                                ReflectionWrapper.instance.clearHighlightedStack();
                                break;

                            case UNDO:
                                UndoTracker.getInstance().undo();
                                break;

                            case REDO:
                                UndoTracker.getInstance().redo();
                                break;

                            case BLACK:
                            case BLUE:
                            case BROWN:
                            case CYAN:
                            case GRAY:
                            case GREEN:
                            case LIGHT_BLUE:
                            case LIME:
                            case MAGENTA:
                            case ORANGE:
                            case PINK:
                            case PURPLE:
                            case RED:
                            case LIGHT_GRAY:
                            case WHITE:
                            case YELLOW:
                                final PacketSetColor setColor = new PacketSetColor(
                                        class_1767.valueOf(ChiselsAndBitsMenu.instance.doAction.name()),
                                        getHeldToolType(class_1268.field_5808),
                                        ChiselsAndBits.getConfig()
                                                .getClient()
                                                .chatModeNotification
                                                .get());
                                ChiselsAndBits.getNetworkChannel().sendToServer(setColor);
                                ReflectionWrapper.instance.clearHighlightedStack();

                                break;
                        }
                    }
                }

                ChiselsAndBitsMenu.instance.actionUsed = true;
                ChiselsAndBitsMenu.instance.decreaseVisibility();
            }

            if (ChiselsAndBitsMenu.instance.isVisible()) {
                ChiselsAndBitsMenu.instance.method_25423(
                        class_310.method_1551(), window.method_4486(), window.method_4502());
                ChiselsAndBitsMenu.instance.configure(window.method_4486(), window.method_4502());

                if (!wasVisible) {
                    class_310.method_1551().field_1755 = ChiselsAndBitsMenu.instance;
                    class_310.method_1551().field_1729.method_1610();
                }

                if (class_310.method_1551().field_1729.method_1613()) {
                    class_304.method_1437();
                }
                /*
                final int k1 = (int) (Minecraft.getInstance().mouseHelper.getMouseX() * window.getScaledWidth() / window.getWidth());
                final int l1 = (int) (window.getScaledHeight() - Minecraft.getInstance().mouseHelper.getMouseY() * window.getScaledHeight() / window.getHeight() - 1);

                net.minecraftforge.client.ForgeHooksClient.drawScreen(ChiselsAndBitsMenu.instance, event.getMatrixStack(), k1, l1, event.getPartialTicks());*/
            } else {
                if (wasVisible) {
                    class_310.method_1551().field_1729.method_1612();
                }
            }
        }

        if (!undo.method_1415() && undo.method_1436()) {
            UndoTracker.getInstance().undo();
        }

        if (!redo.method_1415() && redo.method_1436()) {
            UndoTracker.getInstance().redo();
        }

        if (!addToClipboard.method_1415() && addToClipboard.method_1436()) {
            final class_310 mc = class_310.method_1551();
            if (mc.field_1765 != null
                    && mc.field_1765.method_17783() == class_239.class_240.field_1332
                    && mc.field_1765 instanceof class_3965 rayTraceResult) {

                try {
                    final IBitAccess access =
                            ChiselsAndBits.getApi().getBitAccess(mc.field_1687, rayTraceResult.method_17777());
                    final class_1799 is = access.getBitsAsItem(null, ItemType.CHISELED_BLOCK, false);

                    CreativeClipboardTab.getInstance().addItem(is);
                } catch (final CannotBeChiseled e) {
                    // nope.
                }
            }
        }

        if (!pickBit.method_1415() && pickBit.method_1436()) {
            final class_310 mc = class_310.method_1551();
            if (mc.field_1765 != null
                    && mc.field_1765.method_17783() == class_239.class_240.field_1332
                    && mc.field_1765 instanceof class_3965 rayTraceResult) {

                try {
                    final BitLocation bl = new BitLocation(rayTraceResult, BitOperation.CHISEL);
                    final IBitAccess access = ChiselsAndBits.getApi().getBitAccess(mc.field_1687, bl.getBlockPos());
                    final IBitBrush brush = access.getBitAt(bl.getBitX(), bl.getBitY(), bl.getBitZ());
                    final class_1799 is = brush.getItemStack(1);
                    doPick(is);
                } catch (final CannotBeChiseled e) {
                    // nope.
                }
            }
        }

        if (
        /*type == OverlayRenderCallback.Types.PLAYER_HEALTH
        &&*/ ChiselsAndBits.getConfig().getClient().enableToolbarIcons.get()) {
            final class_310 mc = class_310.method_1551();

            if (!mc.field_1724.method_7325()) {
                final class_329 sc = mc.field_1705;

                for (int slot = 0; slot < 9; ++slot) {
                    final class_1799 stack = mc.field_1724.field_7514.field_7547.get(slot);
                    if (stack.method_7909() instanceof ItemChisel) {
                        final ChiselToolType toolType = getToolTypeForItem(stack);
                        IToolMode mode = toolType.getMode(stack);

                        if (!ChiselsAndBits.getConfig()
                                        .getClient()
                                        .perChiselMode
                                        .get()
                                && tool == ChiselToolType.CHISEL) {
                            mode = ChiselModeManager.getChiselMode(mc.field_1724, ChiselToolType.CHISEL, lastHand);
                        }

                        final int x = window.method_4486() / 2 - 90 + slot * 20 + 2;
                        final int y = window.method_4502() - 16 - 3;
                        guiGraphics.method_51422(1, 1, 1, 1);

                        //
                        // Minecraft.getInstance().getTextureManager().bind(InventoryMenu.BLOCK_ATLAS);
                        final class_1058 sprite =
                                chiselModeIcons.get(mode) == null ? getMissingIcon() : chiselModeIcons.get(mode).sprite;

                        RenderSystem.enableBlend();
                        guiGraphics.method_25298(x + 1, y + 1, 0, 8, 8, sprite);
                        RenderSystem.disableBlend();
                    }
                }
            }
        }
        return false;
    }

    public void playRadialMenu() {
        final double volume =
                ChiselsAndBits.getConfig().getClient().radialMenuVolume.get();
        if (volume >= 0.0001f) {
            final class_1113 psr = new class_1109(
                    class_3417.field_15015.comp_349(),
                    class_3419.field_15250,
                    (float) volume,
                    1.0f,
                    class_5819.method_43047(),
                    getPlayer().method_24515());
            class_310.method_1551().method_1483().method_4873(psr);
        }
    }

    private boolean doPick(final @Nonnull class_1799 result) {
        final class_1657 player = getPlayer();

        for (int x = 0; x < 9; x++) {
            final class_1799 stack = player.field_7514.method_5438(x);
            if (stack != null && class_1799.method_7984(stack, result) && class_1799.method_31577(stack, result)) {
                player.field_7514.field_7545 = x;
                return true;
            }
        }

        if (!player.method_7337()) {
            return false;
        }

        int slot = player.field_7514.method_7376();
        if (slot < 0 || slot >= 9) {
            slot = player.field_7514.field_7545;
        }

        // update inventory..
        player.field_7514.method_5447(slot, result);
        player.field_7514.field_7545 = slot;

        // update server...
        final int j = player.field_7498.field_7761.size() - 9 + player.field_7514.field_7545;
        class_310.method_1551()
                .field_1761
                .method_2909(player.field_7514.method_5438(player.field_7514.field_7545), j);
        return true;
    }

    public ChiselToolType getHeldToolType(final class_1268 Hand) {
        final class_1657 player = getPlayer();

        if (player == null) {
            return null;
        }

        final class_1799 is = player.method_5998(Hand);
        return getToolTypeForItem(is);
    }

    private ChiselToolType getToolTypeForItem(final class_1799 is) {
        if (is != null && is.method_7909() instanceof ItemChisel) {
            return ChiselToolType.CHISEL;
        }

        if (is != null && is.method_7909().equals(ModItems.ITEM_BLOCK_BIT.get())) {
            return ChiselToolType.BIT;
        }

        if (is != null && is.method_7909() instanceof ItemBlockChiseled) {
            return ChiselToolType.CHISELED_BLOCK;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_TAPE_MEASURE.get()) {
            return ChiselToolType.TAPEMEASURE;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_POSITIVE_PRINT.get()) {
            return ChiselToolType.POSITIVEPATTERN;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get()) {
            return ChiselToolType.POSITIVEPATTERN;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_NEGATIVE_PRINT.get()) {
            return ChiselToolType.NEGATIVEPATTERN;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get()) {
            return ChiselToolType.NEGATIVEPATTERN;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_MIRROR_PRINT.get()) {
            return ChiselToolType.MIRRORPATTERN;
        }

        if (is != null && is.method_7909() == ModItems.ITEM_MIRROR_PRINT_WRITTEN.get()) {
            return ChiselToolType.MIRRORPATTERN;
        }

        return null;
    }

    public class_1269 drawingInteractionPrevention(
            class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {

        if (world.field_9236) {
            final ChiselToolType tool = getHeldToolType(hand);
            final IToolMode chMode = ChiselModeManager.getChiselMode(getPlayer(), tool, hand);

            final BitLocation other = getStartPos();
            if ((chMode == ChiselMode.DRAWN_REGION || tool == ChiselToolType.TAPEMEASURE) && other != null) {
                // this handles the client side, but the server side will fire
                // separately.
                return class_1269.field_5814;
            }
        }
        return class_1269.field_5811;
    }

    public void applyChiselDelay(class_310 inst) {
        if (!class_310.method_1551().field_1690.field_1886.method_1415()
                && !class_310.method_1551().field_1690.field_1886.method_1434()) {
            ItemChisel.resetDelay();
        }
    }

    public void interaction(class_310 inst) {
        if (!readyState.isReady()) {
            return;
        }

        // used to prevent hyper chisels.. its actually far worse then you might
        // think...

        if (!getToolKey().method_1434() && lastTool == ChiselToolType.CHISEL) {
            if (ticksSinceRelease >= 4) {
                if (drawStart != null) {
                    drawStart = null;
                    lastHand = class_1268.field_5808;
                }

                lastTool = ChiselToolType.CHISEL;
                ticksSinceRelease = 0;
            } else {
                ticksSinceRelease++;
            }
        } else {
            ticksSinceRelease = 0;
        }

        if (!rotateCCW.method_1415() && rotateCCW.method_1434()) {
            if (rotateTimer == null || rotateTimer.elapsed(TimeUnit.MILLISECONDS) > 200) {
                rotateTimer = Stopwatch.createStarted();
                final PacketRotateVoxelBlob p = new PacketRotateVoxelBlob(class_2351.field_11052, class_2470.field_11465);
                ChiselsAndBits.getNetworkChannel().sendToServer(p);
            }
        }

        if (!rotateCW.method_1415() && rotateCW.method_1434()) {
            if (rotateTimer == null || rotateTimer.elapsed(TimeUnit.MILLISECONDS) > 200) {
                rotateTimer = Stopwatch.createStarted();
                final PacketRotateVoxelBlob p = new PacketRotateVoxelBlob(class_2351.field_11052, class_2470.field_11463);
                ChiselsAndBits.getNetworkChannel().sendToServer(p);
            }
        }

        for (final ChiselMode mode : ChiselMode.values()) {
            final class_304 kb = (class_304) mode.binding;
            if (!kb.method_1415() && kb.method_1434()) {
                final ChiselToolType tool = getHeldToolType(lastHand);
                if (tool.isBitOrChisel()) {
                    ChiselModeManager.changeChiselMode(
                            tool, ChiselModeManager.getChiselMode(getPlayer(), tool, lastHand), mode);
                }
            }
        }

        for (final PositivePatternMode mode : PositivePatternMode.values()) {
            final class_304 kb = (class_304) mode.binding;
            if (!kb.method_1415() && kb.method_1434()) {
                final ChiselToolType tool = getHeldToolType(lastHand);
                if (tool == ChiselToolType.POSITIVEPATTERN) {
                    ChiselModeManager.changeChiselMode(
                            tool, ChiselModeManager.getChiselMode(getPlayer(), tool, lastHand), mode);
                }
            }
        }

        for (final TapeMeasureModes mode : TapeMeasureModes.values()) {
            final class_304 kb = (class_304) mode.binding;
            if (!kb.method_1415() && kb.method_1434()) {
                final ChiselToolType tool = getHeldToolType(lastHand);
                if (tool == ChiselToolType.TAPEMEASURE) {
                    ChiselModeManager.changeChiselMode(
                            tool, ChiselModeManager.getChiselMode(getPlayer(), tool, lastHand), mode);
                }
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public void drawHighlight(WorldRenderContext context) {
        class_4587 stack = context.matrixStack();
        float partialTicks = context.tickDelta();
        stack.method_22903();
        class_243 renderView = class_310.method_1551().field_1773.method_19418().method_19326();
        stack.method_22904(-renderView.field_1352, -renderView.field_1351, -renderView.field_1350);
        ChiselToolType tool = getHeldToolType(lastHand);
        final IToolMode chMode = ChiselModeManager.getChiselMode(getPlayer(), tool, lastHand);
        if (chMode == ChiselMode.DRAWN_REGION) {
            tool = lastTool;
        }

        tapeMeasures.setPreviewMeasure(null, null, chMode, null);

        if (tool == ChiselToolType.TAPEMEASURE) {
            final class_1657 player = getPlayer();
            final class_239 mop = class_310.method_1551().field_1765;

            final class_1937 theWorld = player.field_6002;

            if (mop != null && mop.method_17783() == class_239.class_240.field_1332) {
                final class_3965 blockRayTraceResult = (class_3965) mop;
                final BitLocation location = new BitLocation(blockRayTraceResult, BitOperation.CHISEL);
                if (theWorld.method_8621().method_11952(location.blockPos)) {
                    final BitLocation other = getStartPos();
                    if (other != null) {
                        tapeMeasures.setPreviewMeasure(
                                other, location, chMode, getPlayer().method_5998(lastHand));

                        if (!getToolKey().method_1415() && !getToolKey().method_1434()) {
                            tapeMeasures.addMeasure(
                                    other, location, chMode, getPlayer().method_5998(lastHand));
                            drawStart = null;
                            lastHand = class_1268.field_5808;
                        }
                    }
                }
            }
        }

        tapeMeasures.render(stack, partialTicks);

        final boolean isDrawing =
                (chMode == ChiselMode.DRAWN_REGION || tool == ChiselToolType.TAPEMEASURE) && getStartPos() != null;
        if (isDrawing != wasDrawing) {
            wasDrawing = isDrawing;
            final PacketSuppressInteraction packet = new PacketSuppressInteraction(isDrawing);
            ChiselsAndBits.getNetworkChannel().sendToServer(packet);
        }

        stack.method_22909();
    }

    @Environment(EnvType.CLIENT)
    public boolean drawHighlight(
            class_761 context,
            class_4184 info,
            class_239 target,
            float partialTicks,
            class_4587 stack,
            class_4597 buffers) {
        try {
            stack.method_22903();
            class_243 renderView =
                    class_310.method_1551().field_1773.method_19418().method_19326();
            stack.method_22904(-renderView.field_1352, -renderView.field_1351, -renderView.field_1350);

            ChiselToolType tool = getHeldToolType(lastHand);

            final IToolMode chMode = ChiselModeManager.getChiselMode(getPlayer(), tool, lastHand);
            if (chMode == ChiselMode.DRAWN_REGION) {
                tool = lastTool;
            }

            if (tool != null && tool.isBitOrChisel() && chMode != null) {
                final class_1657 player = class_310.method_1551().field_1724;
                final class_239 mop = class_310.method_1551().field_1765;

                final class_1937 theWorld = player.field_6002;

                if (mop == null || mop.method_17783() != class_239.class_240.field_1332) {
                    return false;
                }

                boolean showBox = false;
                if (mop.method_17783() == class_239.class_240.field_1332) {
                    final class_3965 rayTraceResult = (class_3965) mop;
                    final BitLocation location = new BitLocation(
                            rayTraceResult,
                            getLastBitOperation(player, lastHand, getPlayer().method_5998(lastHand)));
                    if (theWorld.method_8621().method_11952(location.blockPos)) {
                        // this logic originated in the vanilla bounding box...
                        final class_2680 state = theWorld.method_8320(location.blockPos);

                        final boolean isChisel = getDrawnTool() == ChiselToolType.CHISEL;
                        final boolean isBit = getHeldToolType(class_1268.field_5808) == ChiselToolType.BIT;
                        final TileEntityBlockChiseled data =
                                ModUtil.getChiseledTileEntity(theWorld, location.blockPos, false);

                        final VoxelRegionSrc region = new VoxelRegionSrc(theWorld, location.blockPos, 1);
                        final VoxelBlob vb = data != null ? data.getBlob() : new VoxelBlob();

                        if ((isChisel) && data == null) {
                            showBox = true;
                            vb.fill(1);
                        }

                        final BitLocation other = getStartPos();

                        if (chMode == ChiselMode.DRAWN_REGION && other != null) {
                            final ChiselIterator oneEnd = ChiselTypeIterator.create(
                                    VoxelBlob.dim,
                                    location.bitX,
                                    location.bitY,
                                    location.bitZ,
                                    VoxelBlob.NULL_BLOB,
                                    ChiselMode.SINGLE,
                                    class_2350.field_11036,
                                    tool == ChiselToolType.BIT);
                            final ChiselIterator otherEnd = ChiselTypeIterator.create(
                                    VoxelBlob.dim,
                                    other.bitX,
                                    other.bitY,
                                    other.bitZ,
                                    VoxelBlob.NULL_BLOB,
                                    ChiselMode.SINGLE,
                                    class_2350.field_11036,
                                    tool == ChiselToolType.BIT);

                            final class_238 a = oneEnd.getBoundingBox(VoxelBlob.NULL_BLOB, false)
                                    .method_989(location.blockPos.method_10263(), location.blockPos.method_10264(), location.blockPos.method_10260());
                            final class_238 b = otherEnd.getBoundingBox(VoxelBlob.NULL_BLOB, false)
                                    .method_989(other.blockPos.method_10263(), other.blockPos.method_10264(), other.blockPos.method_10260());

                            final class_238 bb = a.method_991(b);

                            final double maxChiseSize = ChiselsAndBits.getConfig()
                                            .getClient()
                                            .maxDrawnRegionSize
                                            .get()
                                    + 0.001;

                            if (bb.field_1320 - bb.field_1323 <= maxChiseSize
                                    && bb.field_1325 - bb.field_1322 <= maxChiseSize
                                    && bb.field_1324 - bb.field_1321 <= maxChiseSize) {
                                RenderHelper.drawSelectionBoundingBoxIfExists(
                                        stack, bb, class_2338.field_10980, player, partialTicks, false);

                                if (!getToolKey().method_1434()) {
                                    final PacketChisel pc = new PacketChisel(
                                            getLastBitOperation(player, lastHand, player.method_5998(lastHand)),
                                            location,
                                            other,
                                            class_2350.field_11036,
                                            ChiselMode.DRAWN_REGION,
                                            lastHand);

                                    if (pc.doAction(getPlayer()) > 0) {
                                        ChiselsAndBits.getNetworkChannel().sendToServer(pc);
                                        ClientSide.placeSound(theWorld, location.blockPos, 0);
                                    }

                                    drawStart = null;
                                    lastHand = class_1268.field_5808;
                                    lastTool = ChiselToolType.CHISEL;
                                }
                            }
                        } else {
                            final class_2586 te = theWorld.method_8500(location.blockPos)
                                    .method_12201(location.blockPos, class_2818.class_2819.field_12859);

                            boolean isBitBlock = te instanceof TileEntityBlockChiseled;
                            final boolean isBlockSupported = BlockBitInfo.canChisel(state);

                            if (!(isBitBlock || isBlockSupported)) {
                                final TileEntityBlockChiseled tebc =
                                        ModUtil.getChiseledTileEntity(theWorld, location.blockPos, false);
                                if (tebc != null) {
                                    final VoxelBlob vx = tebc.getBlob();
                                    if (vx.get(location.bitX, location.bitY, location.bitZ) != 0) {
                                        isBitBlock = true;
                                    }
                                }
                            }

                            if (theWorld.method_22347(location.blockPos) || isBitBlock || isBlockSupported) {
                                final ChiselIterator i = ChiselTypeIterator.create(
                                        VoxelBlob.dim,
                                        location.bitX,
                                        location.bitY,
                                        location.bitZ,
                                        region,
                                        ChiselMode.castMode(chMode),
                                        rayTraceResult.method_17780(),
                                        !isChisel);
                                final class_238 bb = i.getBoundingBox(vb, isChisel);
                                RenderHelper.drawSelectionBoundingBoxIfExists(
                                        stack, bb, location.blockPos, player, partialTicks, false);
                                showBox = false;
                            } else if (isBit) {
                                final VoxelBlob j = new VoxelBlob();
                                j.fill(1);
                                final ChiselIterator i = ChiselTypeIterator.create(
                                        VoxelBlob.dim,
                                        location.bitX,
                                        location.bitY,
                                        location.bitZ,
                                        j,
                                        ChiselMode.castMode(chMode),
                                        rayTraceResult.method_17780(),
                                        !isChisel);
                                final class_238 bb =
                                        snapToSide(i.getBoundingBox(j, isChisel), rayTraceResult.method_17780());
                                RenderHelper.drawSelectionBoundingBoxIfExists(
                                        stack, bb, location.blockPos, player, partialTicks, false);
                            }
                        }
                    }

                    if (!showBox) {
                        return false;
                    }
                }
            }

        } finally {
            stack.method_22909();
        }

        return false;
    }

    private BitOperation getLastBitOperation(
            final class_1657 player, final class_1268 lastHand2, final class_1799 heldItem) {
        return lastTool == ChiselToolType.BIT
                ? ItemChiseledBit.getBitOperation(player, lastHand, player.method_5998(lastHand))
                : BitOperation.CHISEL;
    }

    private class_238 snapToSide(final class_238 boundingBox, final class_2350 sideHit) {
        if (boundingBox != null) {
            switch (sideHit) {
                case field_11033:
                    return new class_238(
                            boundingBox.field_1323,
                            boundingBox.field_1322,
                            boundingBox.field_1321,
                            boundingBox.field_1320,
                            boundingBox.field_1322,
                            boundingBox.field_1324);
                case field_11034:
                    return new class_238(
                            boundingBox.field_1320,
                            boundingBox.field_1322,
                            boundingBox.field_1321,
                            boundingBox.field_1320,
                            boundingBox.field_1325,
                            boundingBox.field_1324);
                case field_11043:
                    return new class_238(
                            boundingBox.field_1323,
                            boundingBox.field_1322,
                            boundingBox.field_1321,
                            boundingBox.field_1320,
                            boundingBox.field_1325,
                            boundingBox.field_1321);
                case field_11035:
                    return new class_238(
                            boundingBox.field_1323,
                            boundingBox.field_1322,
                            boundingBox.field_1324,
                            boundingBox.field_1320,
                            boundingBox.field_1325,
                            boundingBox.field_1324);
                case field_11036:
                    return new class_238(
                            boundingBox.field_1323,
                            boundingBox.field_1325,
                            boundingBox.field_1321,
                            boundingBox.field_1320,
                            boundingBox.field_1325,
                            boundingBox.field_1324);
                case field_11039:
                    return new class_238(
                            boundingBox.field_1323,
                            boundingBox.field_1322,
                            boundingBox.field_1321,
                            boundingBox.field_1323,
                            boundingBox.field_1325,
                            boundingBox.field_1324);
                default:
                    break;
            }
        }

        return boundingBox;
    }

    @Environment(EnvType.CLIENT)
    public void drawLast(WorldRenderContext context) {
        // important and used for tesr / block rendering.
        ++lastRenderedFrame;

        float partialTicks = context.tickDelta();
        class_4587 stack = context.matrixStack();

        if (class_310.method_1551().field_1690.field_1842) {
            return;
        }

        // now render the ghosts...
        final class_1657 player = class_310.method_1551().field_1724;
        final class_239 mop = class_310.method_1551().field_1765;
        final class_1937 theWorld = player.field_6002;
        final class_1799 currentItem = player.method_6047();

        final double x = player.field_6038 + (player.method_23317() - player.field_6038) * partialTicks;
        final double y = player.field_5971 + (player.method_23318() - player.field_5971) * partialTicks;
        final double z = player.field_5989 + (player.method_23321() - player.field_5989) * partialTicks;

        if (mop == null) {
            return;
        }
        AtomicBoolean isPositivePatten = new AtomicBoolean(false);
        if (ModUtil.isHoldingPattern(player, isPositivePatten)) {
            if (mop.method_17783() != class_239.class_240.field_1332) {
                return;
            }

            final class_3965 rayTraceResult = (class_3965) mop;
            final IToolMode mode =
                    ChiselModeManager.getChiselMode(player, ChiselToolType.POSITIVEPATTERN, class_1268.field_5808);

            final class_2338 pos = rayTraceResult.method_17777();
            final class_2338 partial = null;

            final class_2680 s = theWorld.method_8320(pos);
            if (!(s.method_26204() instanceof BlockChiseled) && !BlockBitInfo.canChisel(s)) {
                return;
            }

            if (!ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get().isWritten(currentItem)
                    && !ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get().isWritten(currentItem)) {
                return;
            }

            final class_1799 item = isPositivePatten.get()
                    ? ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get().getPatternedItem(currentItem, false)
                    : ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get().getPatternedItem(currentItem, false);
            if (item == null || !item.method_7985()) {
                return;
            }

            final int rotations = ModUtil.getRotations(player, ModUtil.getSide(currentItem));

            if (mode == PositivePatternMode.PLACEMENT) {
                doGhostForChiseledBlock(stack, x, y, z, theWorld, player, (class_3965) mop, item, item, rotations);
                return;
            }

            if (item != null && !item.method_7960()) {
                final TileEntityBlockChiseled tebc = ModUtil.getChiseledTileEntity(theWorld, pos, false);
                Object cacheRef = tebc != null ? tebc : s;
                if (cacheRef instanceof TileEntityBlockChiseled) {
                    cacheRef = ((TileEntityBlockChiseled) cacheRef).getBlobStateReference();
                }

                RenderSystem.depthFunc(GL11.GL_ALWAYS);
                showGhost(
                        stack,
                        currentItem,
                        item,
                        rayTraceResult.method_17777(),
                        player,
                        rotations,
                        x,
                        y,
                        z,
                        rayTraceResult.method_17780(),
                        partial,
                        cacheRef);
                RenderSystem.depthFunc(GL11.GL_LEQUAL);
            }
        } else if (ModUtil.isHoldingChiseledBlock(player)) {
            if (mop.method_17783() != class_239.class_240.field_1332) {
                return;
            }

            final class_1799 item = currentItem;
            if (!item.method_7985()) {
                return;
            }

            final int rotations = ModUtil.getRotations(player, ModUtil.getSide(item));
            doGhostForChiseledBlock(
                    stack, x, y, z, theWorld, player, (class_3965) mop, currentItem, item, rotations);
        }
    }

    private void doGhostForChiseledBlock(
            final class_4587 matrixStack,
            final double x,
            final double y,
            final double z,
            final class_1937 theWorld,
            final class_1657 player,
            final class_3965 mop,
            final class_1799 currentItem,
            final class_1799 item,
            final int rotations) {
        final class_2338 offset = mop.method_17777();

        if (ClientSide.offGridPlacement(player)) {
            final BitLocation bl = new BitLocation(mop, BitOperation.PLACE);
            showGhost(
                    matrixStack,
                    currentItem,
                    item,
                    bl.blockPos,
                    player,
                    rotations,
                    x,
                    y,
                    z,
                    mop.method_17780(),
                    new class_2338(bl.bitX, bl.bitY, bl.bitZ),
                    null);
        } else {
            boolean canMerge = false;
            if (currentItem.method_7985()) {
                final TileEntityBlockChiseled tebc = ModUtil.getChiseledTileEntity(theWorld, offset, true);

                if (tebc != null) {
                    final VoxelBlob blob = ModUtil.getBlobFromStack(currentItem, player);
                    canMerge = tebc.canMerge(blob);
                }
            }

            class_2338 newOffset = offset;
            final class_2248 block = theWorld.method_8320(newOffset).method_26204();
            final class_1268 hand =
                    player.method_6058() != null ? player.method_6058() : class_1268.field_5808;
            if (!canMerge
                    && !ClientSide.offGridPlacement(player)
                    && !block.method_9616(
                            theWorld.method_8320(newOffset),
                            new class_1750(player, hand, player.method_5998(hand), mop))) {
                newOffset = offset.method_10093(mop.method_17780());
            }

            final class_2586 newTarget = theWorld.method_8321(newOffset);

            if (theWorld.method_22347(newOffset)
                    || newTarget instanceof TileEntityBlockChiseled
                    || (theWorld.method_8321(newOffset) instanceof TileEntityBlockChiseled
                            && theWorld.method_8320(newOffset)
                                    .method_26204()
                                    .method_9616(
                                            theWorld.method_8320(newOffset),
                                            new class_1750(
                                                    player,
                                                    hand,
                                                    player.method_5998(hand),
                                                    new class_3965(
                                                            mop.method_17784()
                                                                    .method_1031(
                                                                            mop.method_17780()
                                                                                    .method_10148(),
                                                                            mop.method_17780()
                                                                                    .method_10164(),
                                                                            mop.method_17780()
                                                                                    .method_10165()),
                                                            mop.method_17780(),
                                                            mop.method_17777()
                                                                    .method_10081(mop.method_17780()
                                                                            .method_10163()),
                                                            mop.method_17781()))))
                    || (!(theWorld.method_8321(newOffset) instanceof TileEntityBlockChiseled)
                            && theWorld.method_8320(newOffset)
                                    .method_26204()
                                    .method_9616(
                                            theWorld.method_8320(newOffset),
                                            new class_1750(player, hand, player.method_5998(hand), mop)))) {

                final TileEntityBlockChiseled test = ModUtil.getChiseledTileEntity(theWorld, newOffset, false);
                showGhost(
                        matrixStack,
                        currentItem,
                        item,
                        newOffset,
                        player,
                        rotations,
                        x,
                        y,
                        z,
                        mop.method_17780(),
                        null,
                        test == null ? null : test.getBlobStateReference());
            }
        }
    }

    private void showGhost(
            final class_4587 matrixStack,
            final class_1799 refItem,
            final class_1799 item,
            final class_2338 blockPos,
            final class_1657 player,
            final int rotationCount,
            final double x,
            final double y,
            final double z,
            final class_2350 side,
            final class_2338 partial,
            final Object cacheRef) {
        class_1087 baked = null;

        if (previousCacheRef == cacheRef
                && samePos(lastPos, blockPos)
                && previousItem == refItem
                && previousRotations == rotationCount
                && previousModel != null
                && samePos(lastPartial, partial)) {
            baked = (class_1087) previousModel;
        } else {
            int rotations = rotationCount;

            previousItem = refItem;
            previousRotations = rotations;
            previousCacheRef = cacheRef;
            lastPos = blockPos;
            lastPartial = partial;

            final NBTBlobConverter c = new NBTBlobConverter();
            c.readChisleData(ModUtil.getSubCompound(item, ModUtil.NBT_BLOCKENTITYTAG, false), VoxelBlob.VERSION_ANY);
            VoxelBlob blob = c.getBlob();

            while (rotations-- > 0) {
                blob = blob.spin(class_2351.field_11052);
            }

            modelBounds = blob.getBounds();

            fail:
            if (refItem.method_7909() == ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get()) {
                final VoxelBlob pattern = blob;

                if (cacheRef instanceof VoxelBlobStateReference) {
                    blob = ((VoxelBlobStateReference) cacheRef).getVoxelBlob();
                } else if (cacheRef instanceof class_2680) {
                    blob = new VoxelBlob();
                    blob.fill(ModUtil.getStateId((class_2680) cacheRef));
                } else {
                    break fail;
                }

                final BitIterator it = new BitIterator();
                while (it.hasNext()) {
                    if (it.getNext(pattern) == 0) {
                        it.setNext(blob, 0);
                    }
                }
            }

            c.setBlob(blob);

            final class_2248 blk = class_2248.method_9503(item.method_7909());
            final class_1799 is = c.getItemStack(false);

            if (is == null || is.method_7960()) {
                isVisible = false;
            } else {
                baked = class_310.method_1551()
                        .method_1480()
                        .method_4012()
                        .method_3308(is);
                previousModel = baked = baked.method_4710()
                        .method_3495(baked, is, (class_638) player.method_5770(), player, 0);

                if (refItem.method_7909() instanceof IPatternItem) {
                    isVisible = true;
                } else {
                    isVisible = true;
                    // TODO: Figure out the hitvector here. Might need to pass that down stream.
                    isUnplaceable = !ItemBlockChiseled.tryPlaceBlockAt(
                            blk,
                            item,
                            player,
                            player.method_5770(),
                            blockPos,
                            side,
                            class_1268.field_5808,
                            0.5,
                            0.5,
                            0.5,
                            partial,
                            false);
                }
            }
        }

        if (!isVisible) {
            return;
        }

        matrixStack.method_22903();

        if (partial != null) {
            final class_2338 t = ModUtil.getPartialOffset(side, partial, modelBounds);
            final double fullScale = 1.0 / VoxelBlob.dim;
            matrixStack.method_22904(t.method_10263() * fullScale, t.method_10264() * fullScale, t.method_10260() * fullScale);
        }
        final class_243 camera = class_310.method_1551().field_1773.method_19418().method_19326();
        matrixStack.method_22904(
                blockPos.method_10263() - camera.field_1352 - 0.000125,
                blockPos.method_10264() - camera.field_1351 + 0.000125,
                blockPos.method_10260() - camera.field_1350 - 0.000125);
        matrixStack.method_22905(1.001F, 1.001F, 1.001F);
        RenderHelper.renderGhostModel(
                matrixStack,
                baked,
                player.method_5770(),
                blockPos,
                isUnplaceable,
                class_761.method_23794(player.method_5770(), blockPos),
                class_4608.field_21444);

        matrixStack.method_22909();
    }

    private boolean samePos(final class_2338 lastPartial2, final class_2338 partial) {
        if (lastPartial2 == partial) {
            return true;
        }

        if (lastPartial2 == null || partial == null) {
            return false;
        }

        return partial.equals(lastPartial2);
    }

    public class_1657 getPlayer() {
        return class_310.method_1551().field_1724;
    }

    public boolean addHitEffects(
            final class_1937 world,
            final class_3965 target,
            final class_2680 state,
            final class_702 effectRenderer) {
        final class_1799 hitWith = getPlayer().method_6047();
        if (hitWith != null
                && (hitWith.method_7909() instanceof ItemChisel || hitWith.method_7909() instanceof ItemChiseledBit)) {
            return true; // no
            // effects!
        }

        final class_2338 pos = target.method_17777();
        final float boxOffset = 0.1F;

        class_238 bb = world.method_8320(pos)
                .method_26204()
                .method_9530(state, world, pos, class_3726.method_16194())
                .method_1107();

        double x = RANDOM.nextDouble() * (bb.field_1320 - bb.field_1323 - boxOffset * 2.0F) + boxOffset + bb.field_1323;
        double y = RANDOM.nextDouble() * (bb.field_1325 - bb.field_1322 - boxOffset * 2.0F) + boxOffset + bb.field_1322;
        double z = RANDOM.nextDouble() * (bb.field_1324 - bb.field_1321 - boxOffset * 2.0F) + boxOffset + bb.field_1321;

        switch (target.method_17780()) {
            case field_11033:
                y = bb.field_1322 - boxOffset;
                break;
            case field_11034:
                x = bb.field_1320 + boxOffset;
                break;
            case field_11043:
                z = bb.field_1321 - boxOffset;
                break;
            case field_11035:
                z = bb.field_1324 + boxOffset;
                break;
            case field_11036:
                y = bb.field_1325 + boxOffset;
                break;
            case field_11039:
                x = bb.field_1323 - boxOffset;
                break;
            default:
                break;
        }

        effectRenderer.method_3058((new class_727((class_638) world, x, y, z, 0.0D, 0.0D, 0.0D, state, pos))
                .method_3075(0.2F)
                .method_3087(0.6F));

        return true;
    }

    public boolean wheelEvent(double deltaX, double deltaY) {
        final int dwheel = (int) deltaY;
        if (dwheel == 0) {
            return false;
        }

        final class_1657 player = ClientSide.instance.getPlayer();
        final class_1799 is = player.method_6047();

        if (dwheel != 0 && is != null && is.method_7909() instanceof IItemScrollWheel && player.method_5715()) {
            ((IItemScrollWheel) is.method_7909()).scroll(player, is, dwheel);
            return true;
        }
        return false;
    }

    public int getLastRenderedFrame() {
        return lastRenderedFrame;
    }

    public BitLocation getStartPos() {
        return drawStart;
    }

    public void pointAt(
            @Nonnull final ChiselToolType type, @Nonnull final BitLocation pos, @Nonnull final class_1268 hand) {
        if (drawStart == null) {
            drawStart = pos;
            lastTool = type;
            lastHand = hand;
        }
    }

    public void setLastTool(@Nonnull final ChiselToolType lastTool) {
        this.lastTool = lastTool;
    }

    class_304 getToolKey() {
        if (lastTool == ChiselToolType.CHISEL) {
            return class_310.method_1551().field_1690.field_1886;
        } else {
            return class_310.method_1551().field_1690.field_1904;
        }
    }

    public boolean addBlockDestroyEffects(@Nonnull final class_1937 world, @Nonnull final class_2338 pos, class_2680 state) {
        if (!state.method_26215()) {
            class_265 voxelshape = state.method_26218(world, pos);
            double d0 = 0.25D;
            voxelshape.method_1089((p_228348_3_, p_228348_5_, p_228348_7_, p_228348_9_, p_228348_11_, p_228348_13_) -> {
                double d1 = Math.min(1.0D, p_228348_9_ - p_228348_3_);
                double d2 = Math.min(1.0D, p_228348_11_ - p_228348_5_);
                double d3 = Math.min(1.0D, p_228348_13_ - p_228348_7_);
                int i = Math.max(2, class_3532.method_15384(d1 / 0.25D));
                int j = Math.max(2, class_3532.method_15384(d2 / 0.25D));
                int k = Math.max(2, class_3532.method_15384(d3 / 0.25D));

                for (int l = 0; l < i; ++l) {
                    for (int i1 = 0; i1 < j; ++i1) {
                        for (int j1 = 0; j1 < k; ++j1) {
                            double d4 = ((double) l + 0.5D) / (double) i;
                            double d5 = ((double) i1 + 0.5D) / (double) j;
                            double d6 = ((double) j1 + 0.5D) / (double) k;
                            double d7 = d4 * d1 + p_228348_3_;
                            double d8 = d5 * d2 + p_228348_5_;
                            double d9 = d6 * d3 + p_228348_7_;

                            class_310.method_1551()
                                    .field_1713
                                    .method_3058((new class_727(
                                            (class_638) world,
                                            (double) pos.method_10263() + d7,
                                            (double) pos.method_10264() + d8,
                                            (double) pos.method_10260() + d9,
                                            d4 - 0.5D,
                                            d5 - 0.5D,
                                            d6 - 0.5D,
                                            state,
                                            pos)));
                        }
                    }
                }
            });
        }

        return true;
    }

    public class_1058 getMissingIcon() {
        return class_310.method_1551()
                .method_1549(class_1723.field_21668)
                .apply(new class_2960("missingno"));
    }

    public String getModeKey() {
        return getKeyName(modeMenu);
    }

    public ChiselToolType getDrawnTool() {
        return lastTool;
    }

    public boolean holdingShift() {
        return (!class_310.method_1551().field_1690.field_1832.method_1415()
                        && class_310.method_1551().field_1690.field_1832.method_1434())
                || class_437.method_25442();
    }

    public String getKeyName(class_304 bind) {
        if (bind == null) {
            return LocalStrings.noBind.getLocal();
        }

        if (bind.field_1655.method_1444() == 0 && bind.method_1429().method_1444() != 0) {
            // TODO: This previously changed the resulting string to something easier to understand. Not sure that is
            // still needed.
            return DeprecationHelper.translateToLocal(bind.method_1428());
        }

        if (bind.field_1655.method_1444() == 0) {
            return '"' + DeprecationHelper.translateToLocal(bind.method_1431());
        }

        return makeMoreFrendly(bind.method_1428());
    }

    private String makeMoreFrendly(String displayName) {
        return DeprecationHelper.translateToLocal(displayName)
                .replace("LMENU", LocalStrings.leftAlt.getLocal())
                .replace("RMENU", LocalStrings.rightAlt.getLocal())
                .replace("LSHIFT", LocalStrings.leftShift.getLocal())
                .replace("RSHIFT", LocalStrings.rightShift.getLocal())
                .replace("key.keyboard.", "");
    }
}
