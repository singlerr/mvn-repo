package mod.chiselsandbits.items;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import mod.chiselsandbits.bitbag.BagInventory;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ActingPlayer;
import mod.chiselsandbits.helpers.BitInventoryFeeder;
import mod.chiselsandbits.helpers.ContinousChisels;
import mod.chiselsandbits.helpers.IContinuousInventory;
import mod.chiselsandbits.helpers.IItemInInventory;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IChiselModeItem;
import mod.chiselsandbits.modes.PositivePatternMode;
import mod.chiselsandbits.network.packets.PacketAccurateSneakPlace;
import mod.chiselsandbits.network.packets.PacketAccurateSneakPlace.IItemBlockAccurate;
import mod.chiselsandbits.registry.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class ItemPositivePrint extends ItemNegativePrint implements IChiselModeItem, IItemBlockAccurate {

    public ItemPositivePrint(final class_1793 properties) {
        super(properties);
    }

    @Override
    protected class_1792 getWrittenItem() {
        return ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get();
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        defaultAddInfo(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpPositivePrint,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getModeKey());

        if (stack.method_7985()) {
            if (ClientSide.instance.holdingShift()) {
                if (toolTipCache.needsUpdate(stack)) {
                    final VoxelBlob blob = ModUtil.getBlobFromStack(stack, null);
                    toolTipCache.updateCachedValue(blob.listContents(new ArrayList<class_2561>()));
                }

                tooltip.addAll(toolTipCache.getCached());
            } else {
                tooltip.add(class_2561.method_43470(LocalStrings.ShiftDetails.getLocal()));
            }
        }
    }

    @Override
    protected class_2487 getCompoundFromBlock(final class_1937 world, final class_2338 pos, final class_1657 player) {
        final class_2680 state = world.method_8320(pos);
        final class_2248 blkObj = state.method_26204();

        if (!(blkObj instanceof BlockChiseled) && BlockBitInfo.canChisel(state)) {
            final NBTBlobConverter tmp = new NBTBlobConverter();

            tmp.fillWith(state);
            final class_2487 comp = new class_2487();
            tmp.writeChisleData(comp, false);

            comp.method_10567(ModUtil.NBT_SIDE, (byte) ModUtil.getPlaceFace(player).ordinal());
            return comp;
        }

        return super.getCompoundFromBlock(world, pos, player);
    }

    @Override
    protected boolean convertToStone() {
        return false;
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        class_1657 player = context.method_8036();
        class_1937 world = context.method_8045();
        class_1268 hand = context.method_20287();
        class_2338 pos = context.method_8037();

        final class_1799 stack = player.method_5998(hand);
        final class_2680 blkstate = world.method_8320(pos);

        if (ItemChiseledBit.checkRequiredSpace(player, blkstate)) {
            return class_1269.field_5814;
        }

        boolean offgrid = false;

        if (PositivePatternMode.getMode(stack) == PositivePatternMode.PLACEMENT) {
            if (!world.field_9236) {
                // Say it "worked", Don't do anything we'll get a better
                // packet.
                return class_1269.field_5812;
            }

            // send accurate packet.
            final PacketAccurateSneakPlace pasp = new PacketAccurateSneakPlace(
                    context.method_8041(),
                    pos,
                    hand,
                    context.method_8038(),
                    context.method_17698().field_1352,
                    context.method_17698().field_1351,
                    context.method_17698().field_1350,
                    false);

            ChiselsAndBits.getNetworkChannel().sendToServer(pasp);
        }

        return placeItem(context, offgrid);
    }

    public final class_1269 placeItem(final class_1838 context, boolean offgrid) {
        class_1799 stack = context.method_8041();
        class_1657 player = context.method_8036();
        class_1268 hand = context.method_20287();
        class_2338 pos = context.method_8037();

        if (PositivePatternMode.getMode(stack) == PositivePatternMode.PLACEMENT) {
            final class_1799 output = getPatternedItem(stack, false);
            if (output != null) {
                final VoxelBlob pattern = ModUtil.getBlobFromStack(stack, player);
                final Map<Integer, Integer> stats = pattern.getBlockSums();

                if (consumeEntirePattern(pattern, stats, pos, ActingPlayer.testingAs(player, hand))
                        && output.method_7909() instanceof ItemBlockChiseled ibc) {
                    final class_1269 res = ibc.tryPlace(context, offgrid);

                    if (res == class_1269.field_5812) {
                        consumeEntirePattern(pattern, stats, pos, ActingPlayer.actingAs(player, hand));
                    }

                    return res;
                }

                return class_1269.field_5814;
            }
        }

        return super.method_7884(context);
    }

    private boolean consumeEntirePattern(
            final VoxelBlob pattern, final Map<Integer, Integer> stats, final class_2338 pos, final ActingPlayer player) {
        final List<BagInventory> bags = ModUtil.getBags(player);

        for (final Entry<Integer, Integer> type : stats.entrySet()) {
            final int inPattern = type.getKey();

            if (type.getKey() == 0) {
                continue;
            }

            IItemInInventory bit = ModUtil.findBit(player, pos, inPattern);
            int stillNeeded = type.getValue() - ModUtil.consumeBagBit(bags, inPattern, type.getValue());
            if (stillNeeded != 0) {
                for (int x = stillNeeded; x > 0 && bit.isValid(); --x) {
                    if (bit.consume()) {
                        stillNeeded--;
                        bit = ModUtil.findBit(player, pos, inPattern);
                    }
                }

                if (stillNeeded != 0) {
                    return false;
                }
            }
        }

        return true;
    }

    @Override
    protected void applyPrint(
            final class_1799 stack,
            final class_1937 world,
            final class_2338 pos,
            final class_2350 side,
            final VoxelBlob vb,
            final VoxelBlob pattern,
            final class_1657 who,
            final class_1268 hand) {
        // snag a tool...
        final ActingPlayer player = ActingPlayer.actingAs(who, hand);
        final IContinuousInventory selected = new ContinousChisels(player, pos, side);
        class_1799 spawnedItem = null;

        final VoxelBlob filled = new VoxelBlob();

        final List<BagInventory> bags = ModUtil.getBags(player);
        final List<class_1542> spawnlist = new ArrayList<>();

        final PositivePatternMode chiselMode = PositivePatternMode.getMode(stack);
        final boolean chisel_bits =
                chiselMode == PositivePatternMode.IMPOSE || chiselMode == PositivePatternMode.REPLACE;
        final boolean chisel_to_air = chiselMode == PositivePatternMode.REPLACE;

        for (int y = 0; y < vb.detail; y++) {
            for (int z = 0; z < vb.detail; z++) {
                for (int x = 0; x < vb.detail; x++) {
                    int inPlace = vb.get(x, y, z);
                    final int inPattern = pattern.get(x, y, z);
                    if (inPlace != inPattern) {
                        if (inPlace != 0 && chisel_bits && selected.isValid()) {
                            if (chisel_to_air || inPattern != 0) {
                                spawnedItem = ItemChisel.chiselBlock(
                                        selected, player, vb, world, pos, side, x, y, z, spawnedItem, spawnlist);

                                if (spawnedItem != null) {
                                    inPlace = 0;
                                }
                            }
                        }

                        if (inPlace == 0 && inPattern != 0 && filled.get(x, y, z) == 0) {
                            final IItemInInventory bit = ModUtil.findBit(player, pos, inPattern);
                            if (ModUtil.consumeBagBit(bags, inPattern, 1) == 1) {
                                vb.set(x, y, z, inPattern);
                            } else if (bit.isValid()) {
                                if (!player.isCreative()) {
                                    if (bit.consume()) {
                                        vb.set(x, y, z, inPattern);
                                    }
                                } else {
                                    vb.set(x, y, z, inPattern);
                                }
                            }
                        }
                    }
                }
            }
        }

        BitInventoryFeeder feeder = new BitInventoryFeeder(who, world);
        for (final class_1542 ei : spawnlist) {
            feeder.addItem(ei);
            ItemBitBag.cleanupInventory(who, ei.method_6983());
        }
    }

    //    @Override
    //    public Component getHighlightTip(final ItemStack item, final Component displayName)
    //    {
    //        if (EffectiveSide.get().isClient() && displayName instanceof MutableComponent &&
    // ChiselsAndBits.getConfig().getClient().itemNameModeDisplay.get() )
    //        {
    //            MutableComponent formattableTextComponent = (MutableComponent) displayName;
    //            return formattableTextComponent.append(" - ").append(PositivePatternMode.getMode( item
    // ).string.getLocal());
    //        }
    //
    //        return displayName;
    //    }

    @Override
    public class_1269 tryPlace(final class_1838 context, final boolean offGrid) {
        if (PositivePatternMode.getMode(context.method_8041()) == PositivePatternMode.PLACEMENT) {
            final class_1799 output = getPatternedItem(context.method_8041(), false);
            if (output != null) {
                final VoxelBlob pattern = ModUtil.getBlobFromStack(context.method_8041(), context.method_8036());
                final Map<Integer, Integer> stats = pattern.getBlockSums();

                if (consumeEntirePattern(
                                pattern,
                                stats,
                                context.method_8037(),
                                ActingPlayer.testingAs(context.method_8036(), context.method_20287()))
                        && output.method_7909() instanceof ItemBlockChiseled ibc) {
                    final class_1269 res = ibc.tryPlace(new class_1750(context), offGrid);

                    if (res == class_1269.field_5812) {
                        consumeEntirePattern(
                                pattern,
                                stats,
                                context.method_8037(),
                                ActingPlayer.actingAs(context.method_8036(), context.method_20287()));
                    }

                    return res;
                }

                return class_1269.field_5814;
            }
        }

        return super.method_7884(context);
    }
}
