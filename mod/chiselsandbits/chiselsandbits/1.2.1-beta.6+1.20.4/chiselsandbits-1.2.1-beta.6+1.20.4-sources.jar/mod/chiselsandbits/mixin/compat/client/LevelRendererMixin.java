package mod.chiselsandbits.mixin.compat.client;

import com.llamalad7.mixinextras.injector.WrapWithCondition;
import mod.chiselsandbits.compat.client.DrawSelectionEvents;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    @Final
    private class_4599 renderBuffers;

    @WrapWithCondition(
            method = "renderLevel",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/renderer/LevelRenderer;renderHitOutline(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/entity/Entity;DDDLnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"))
    private boolean port_lib$renderBlockOutline(
            class_761 self,
            class_4587 poseStack,
            class_4588 vertexConsumer,
            class_1297 entity,
            double d,
            double e,
            double f,
            class_2338 blockPos,
            class_2680 blockState,
            /* enclosing args */ class_4587 p,
            float partialTicks,
            long l,
            boolean bl,
            class_4184 camera,
            class_757 gameRenderer,
            class_765 lightTexture,
            Matrix4f matrix4f) {
        return !DrawSelectionEvents.BLOCK
                .invoker()
                .onHighlightBlock(
                        self, camera, minecraft.field_1765, partialTicks, poseStack, renderBuffers.method_23000());
    }

    @Inject(
            method = "renderLevel",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lcom/mojang/blaze3d/systems/RenderSystem;getModelViewStack()Lcom/mojang/blaze3d/vertex/PoseStack;",
                            shift = At.Shift.BEFORE))
    private void port_lib$renderEntityOutline(
            class_4587 poseStack,
            float partialTick,
            long finishNanoTime,
            boolean renderBlockOutline,
            class_4184 camera,
            class_757 gameRenderer,
            class_765 lightTexture,
            Matrix4f projectionMatrix,
            CallbackInfo ci) {
        class_239 hitresult = minecraft.field_1765;
        if (hitresult != null && hitresult.method_17783() == class_239.class_240.field_1331) {
            DrawSelectionEvents.ENTITY
                    .invoker()
                    .onHighlightEntity(
                            (class_761) (Object) this,
                            camera,
                            hitresult,
                            partialTick,
                            poseStack,
                            this.renderBuffers.method_23000());
        }
    }
}
