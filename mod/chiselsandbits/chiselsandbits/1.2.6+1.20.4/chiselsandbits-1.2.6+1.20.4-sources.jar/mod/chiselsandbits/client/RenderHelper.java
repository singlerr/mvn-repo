package mod.chiselsandbits.client;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_5819;
import net.minecraft.class_761;
import net.minecraft.class_777;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RenderHelper {

    private static final class_1921 CHISEL_PREVIEW = previewRender();
    private static final Logger log = LoggerFactory.getLogger(RenderHelper.class);
    public static class_5819 RENDER_RANDOM = class_5819.method_43047();

    private static class_1921 previewRender() {
        class_1921.class_4688 compositeState = class_1921.class_4688.method_23598()
                .method_34578(class_1921.field_29406)
                .method_34577(new class_4668.class_4683(class_1059.field_5275, false, false))
                .method_23615(class_1921.field_21370)
                .method_23608(class_1921.field_21383)
                .method_23607(class_1921.field_22241)
                .method_23616(class_1921.field_21350)
                .method_23603(class_1921.field_21345)
                .method_23604(class_4668.field_21348)
                .method_23611(class_1921.field_21386)
                .method_23617(true);
        return class_1921.method_24049(
                Constants.MOD_ID + ":chisels_preview",
                class_290.field_1580,
                class_293.class_5596.field_27382,
                1536,
                true,
                true,
                compositeState);
    }

    public static void drawSelectionBoundingBoxIfExists(
            final class_4587 matrixStack,
            final class_4597 buffers,
            final class_238 bb,
            final class_2338 blockPos,
            final class_1657 player,
            final float partialTicks,
            final boolean NormalBoundingBox) {
        drawSelectionBoundingBoxIfExistsWithColor(
                matrixStack, buffers, bb, blockPos, player, partialTicks, NormalBoundingBox, 0, 0, 0, 102, 32);
    }

    public static void drawSelectionBoundingBoxIfExistsWithColor(
            final class_4587 matrixStack,
            final class_4597 buffers,
            final class_238 bb,
            final class_2338 blockPos,
            final class_1657 player,
            final float partialTicks,
            final boolean NormalBoundingBox,
            final int red,
            final int green,
            final int blue,
            final int alpha,
            final int seeThruAlpha) {
        if (bb != null) {
            if (!NormalBoundingBox) {
                RenderHelper.renderBoundingBox(
                        matrixStack,
                        buffers,
                        bb.method_1012(0.002D, 0.002D, 0.002D)
                                .method_989(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()),
                        red,
                        green,
                        blue,
                        alpha);
            }

            RenderHelper.renderBoundingBox(
                    matrixStack,
                    buffers,
                    bb.method_1012(0.002D, 0.002D, 0.002D).method_989(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()),
                    red,
                    green,
                    blue,
                    seeThruAlpha);
        }
    }

    public static void drawLineWithColor(
            final class_4587 matrixStack,
            final class_4597 buffers,
            final class_243 a,
            final class_243 b,
            final class_2338 blockPos,
            final boolean NormalBoundingBox,
            final int red,
            final int green,
            final int blue,
            final int alpha,
            final int seeThruAlpha) {
        if (a != null && b != null) {
            final class_243 a2 = a.method_1031(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
            final class_243 b2 = b.method_1031(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
            if (!NormalBoundingBox) {
                RenderHelper.renderLine(matrixStack, buffers, a2, b2, red, green, blue, alpha);
            }

            RenderHelper.renderLine(matrixStack, buffers, a2, b2, red, green, blue, seeThruAlpha);
        }
    }

    public static void renderQuads(
            final class_4587 matrixStack,
            final int alpha,
            final class_287 renderer,
            final List<class_777> quads,
            final class_1937 worldObj,
            final class_2338 blockPos,
            int combinedLightIn,
            int combinedOverlayIn) {
        int i = 0;
        for (final int j = quads.size(); i < j; ++i) {
            final class_777 bakedquad = quads.get(i);
            int color = bakedquad.method_3359() == -1
                    ? alpha | 0xffffff
                    : getTint(alpha, bakedquad.method_3359(), worldObj, blockPos);

            float cb = (color & 0xFF) / 255f;
            float cg = ((color >>> 8) & 0xFF) / 255f;
            float cr = ((color >>> 16) & 0xFF) / 255f;
            float ca = ((alpha >>> 24) & 0xFF) / 255f;
            renderer.method_22920(
                    matrixStack.method_23760(),
                    bakedquad,
                    new float[] {ca, ca, ca, ca},
                    cr,
                    cg,
                    cb,
                    new int[] {combinedLightIn, combinedLightIn, combinedLightIn, combinedLightIn},
                    combinedOverlayIn,
                    false);
        }
    }

    public static void renderBoundingBox(
            final class_4587 matrixStack,
            final class_4597 buffers,
            final class_238 boundingBox,
            final int red,
            final int green,
            final int blue,
            final int alpha) {
        class_761.method_22983(
                matrixStack,
                buffers.getBuffer(class_1921.method_23594()),
                class_259.method_1078(boundingBox),
                0,
                0,
                0,
                red,
                green,
                blue,
                alpha,
                true);
    }

    public static void renderLine(
            final class_4587 matrixStack,
            final class_4597 buffers,
            final class_243 a,
            final class_243 b,
            final int red,
            final int green,
            final int blue,
            final int alpha) {
        final class_4588 bufferBuilder = buffers.getBuffer(class_1921.method_23594());
        bufferBuilder
                .method_22918(matrixStack.method_23760().method_23761(), (float) a.field_1352, (float) a.field_1351, (float) a.field_1350)
                .method_1336(red, green, blue, alpha)
                .method_23763(matrixStack.method_23760().method_23762(), 1f, 1f, 1f)
                .method_1344();
        bufferBuilder
                .method_22918(matrixStack.method_23760().method_23761(), (float) b.field_1352, (float) b.field_1351, (float) b.field_1350)
                .method_1336(red, green, blue, alpha)
                .method_23763(matrixStack.method_23760().method_23762(), 1f, 1f, 1f)
                .method_1344();
    }

    public static int getTint(final int alpha, final int tintIndex, final class_1937 worldObj, final class_2338 blockPos) {
        return alpha
                | class_310.method_1551()
                        .method_1505()
                        .method_1697(ModBlocks.getChiseledDefaultState(), worldObj, blockPos, tintIndex);
    }

    public static void renderModel(
            final class_4587 matrixStack,
            final class_1087 model,
            final class_1937 worldObj,
            final class_2338 blockPos,
            final int alpha,
            final int combinedLightmap,
            final int combinedOverlay) {
        final class_289 tessellator = class_289.method_1348();
        final class_287 buffer = tessellator.method_1349();

        class_1921 renderType = CHISEL_PREVIEW;

        buffer.method_1328(renderType.method_23033(), renderType.method_23031());

        for (final class_2350 enumfacing : class_2350.values()) {
            renderQuads(
                    matrixStack,
                    alpha,
                    buffer,
                    model.method_4707(null, enumfacing, RENDER_RANDOM),
                    worldObj,
                    blockPos,
                    combinedLightmap,
                    combinedOverlay);
        }

        renderQuads(
                matrixStack,
                alpha,
                buffer,
                model.method_4707(null, null, RENDER_RANDOM),
                worldObj,
                blockPos,
                combinedLightmap,
                combinedOverlay);

        renderType.method_23012(buffer, RenderSystem.getVertexSorting());
    }

    public static void renderGhostModel(
            final class_4587 matrixStack,
            final class_1087 baked,
            final class_1937 worldObj,
            final class_2338 blockPos,
            final boolean isUnplaceable,
            int combinedLightmap,
            final int combinedOverlay) {
        final int alpha = isUnplaceable ? 0x22000000 : 0xaa000000;
        RenderHelper.renderModel(matrixStack, baked, worldObj, blockPos, alpha, combinedLightmap, combinedOverlay);
    }
}
