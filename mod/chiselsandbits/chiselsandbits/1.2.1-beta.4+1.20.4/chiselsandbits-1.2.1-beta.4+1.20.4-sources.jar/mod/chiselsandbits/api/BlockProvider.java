package mod.chiselsandbits.api;

import java.util.Collection;
import net.minecraft.class_2680;

public interface BlockProvider {

    Collection<class_2680> getStates();
}
