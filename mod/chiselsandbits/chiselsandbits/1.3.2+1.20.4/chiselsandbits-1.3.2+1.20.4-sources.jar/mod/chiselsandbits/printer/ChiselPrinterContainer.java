package mod.chiselsandbits.printer;

import mod.chiselsandbits.interfaces.IPatternItem;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.registry.ModContainerTypes;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;
import org.jetbrains.annotations.NotNull;

public class ChiselPrinterContainer extends class_1703 {

    public static final int PLAYER_INVENTORY_ROWS = 3;
    public static final int PLAYER_INVENTORY_COLUMNS = 9;
    public static final int PLAYER_INVENTORY_X_OFFSET = 8;
    public static final int PLAYER_INVENTORY_Y_OFFSET = 84;
    public static final int SLOT_SIZE = 18;
    public static final int PLAYER_TOOLBAR_Y_OFFSET = 142;

    private final class_3913 stationData;

    private final IItemHandlerModifiable toolHandler;

    public ChiselPrinterContainer(final int id, final class_1661 playerInventory) {
        this(
                id,
                playerInventory,
                new ItemStackHandler(1),
                new ItemStackHandler(1),
                new ItemStackHandler(1),
                new class_3919(1));
    }

    public ChiselPrinterContainer(
            final int id,
            final class_1661 playerInventory,
            final IItemHandlerModifiable patternHandler,
            final IItemHandlerModifiable toolHandler,
            final IItemHandlerModifiable resultHandler,
            final class_3913 stationData) {
        super(ModContainerTypes.CHISEL_STATION_CONTAINER.get(), id);
        this.stationData = stationData;
        this.toolHandler = toolHandler;

        this.method_7621(new SlotItemHandler(patternHandler, 0, 50, 47) {
            @Override
            public boolean method_7680(@NotNull final class_1799 stack) {
                return stack.method_7960() || stack.method_7909() instanceof IPatternItem;
            }
        });

        this.method_7621(new SlotItemHandler(toolHandler, 0, 81, 21) {
            @Override
            public boolean method_7680(@NotNull final class_1799 stack) {
                return stack.method_7909() instanceof ItemChisel;
            }
        });

        this.method_7621(new SlotItemHandler(resultHandler, 0, 116, 47) {
            @Override
            public boolean method_7680(@NotNull final class_1799 stack) {
                return false;
            }
        });

        for (int rowIndex = 0; rowIndex < PLAYER_INVENTORY_ROWS; ++rowIndex) {
            for (int columnIndex = 0; columnIndex < PLAYER_INVENTORY_COLUMNS; ++columnIndex) {
                this.method_7621(new class_1735(
                        playerInventory,
                        columnIndex + rowIndex * PLAYER_INVENTORY_COLUMNS + PLAYER_INVENTORY_COLUMNS,
                        PLAYER_INVENTORY_X_OFFSET + columnIndex * SLOT_SIZE,
                        PLAYER_INVENTORY_Y_OFFSET + rowIndex * SLOT_SIZE));
            }
        }

        for (int toolbarIndex = 0; toolbarIndex < PLAYER_INVENTORY_COLUMNS; ++toolbarIndex) {
            this.method_7621(new class_1735(
                    playerInventory,
                    toolbarIndex,
                    PLAYER_INVENTORY_X_OFFSET + toolbarIndex * SLOT_SIZE,
                    PLAYER_TOOLBAR_Y_OFFSET));
        }

        this.method_17360(this.stationData);
    }

    @Override
    public boolean method_7597(final class_1657 playerIn) {
        return true;
    }

    public int getChiselProgressionScaled() {
        int progress = this.stationData.method_17390(0);
        return progress != 0 ? progress * 16 / 100 : 0;
    }

    public class_1799 getToolStack() {
        return toolHandler.getStackInSlot(0);
    }

    @NotNull
    @Override
    public class_1799 method_7601(final class_1657 playerIn, final int index) {
        class_1799 itemstack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);
        if (slot != null && slot.method_7681()) {
            class_1799 itemstack1 = slot.method_7677();
            itemstack = itemstack1.method_7972();
            if (index == 2) {
                if (!this.method_7616(itemstack1, 3, 39, true)) {
                    return class_1799.field_8037;
                }

                slot.method_7670(itemstack1, itemstack);
            } else if (index != 1 && index != 0) {
                if (itemstack1.method_7909() instanceof IPatternItem) {
                    if (!this.method_7616(itemstack1, 0, 1, false)) {
                        return class_1799.field_8037;
                    }
                } else if (itemstack1.method_7909() instanceof ItemChisel) {
                    if (!this.method_7616(itemstack1, 1, 2, false)) {
                        return class_1799.field_8037;
                    }
                } else if (index < 30) {
                    if (!this.method_7616(itemstack1, 30, 39, false)) {
                        return class_1799.field_8037;
                    }
                } else if (index < 39 && !this.method_7616(itemstack1, 3, 30, false)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(itemstack1, 3, 39, false)) {
                return class_1799.field_8037;
            }

            if (itemstack1.method_7960()) {
                slot.method_7673(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (itemstack1.method_7947() == itemstack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(playerIn, itemstack1);
        }

        return itemstack;
    }
}
