package mod.chiselsandbits.printer;

import java.util.Objects;
import mod.chiselsandbits.bitstorage.TileEntityBitStorage;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IPatternItem;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.registry.ModTileEntityTypes;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3913;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.NonNullLazy;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.wrapper.EmptyHandler;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ChiselPrinterTileEntity extends class_2586 implements class_3908 {
    public final LazyOptional<ItemStackHandler> result_handler =
            LazyOptional.of(NonNullLazy.of(() -> new ItemStackHandler(1) {
                @Override
                public boolean isItemValid(final int slot, @NotNull final class_1799 stack) {
                    return true;
                }
            }));
    final MutableObject<class_1799> currentRealisedWorkingStack = new MutableObject<>(class_1799.field_8037);
    private final LazyOptional<EmptyHandler> empty_handler = LazyOptional.of(NonNullLazy.of(EmptyHandler::new));
    private final LazyOptional<ItemStackHandler> tool_handler =
            LazyOptional.of(NonNullLazy.of(() -> new ItemStackHandler(1) {
                @Override
                public boolean isItemValid(final int slot, @NotNull final class_1799 stack) {
                    return stack.method_7909() instanceof ItemChisel;
                }

                @Override
                public int getSlotLimit(final int slot) {
                    return 1;
                }
            }));
    private final LazyOptional<ItemStackHandler> pattern_handler =
            LazyOptional.of(NonNullLazy.of(() -> new ItemStackHandler(1) {
                @Override
                public boolean isItemValid(final int slot, @NotNull final class_1799 stack) {
                    return stack.method_7909() instanceof IPatternItem;
                }

                @Override
                public int getSlotLimit(final int slot) {
                    return 1;
                }

                @Override
                protected void onContentsChanged(final int slot) {
                    currentRealisedWorkingStack.setValue(class_1799.field_8037);
                }
            }));
    int progress = 0;
    protected final class_3913 stationData = new class_3913() {
        public int method_17390(int index) {
            if (index == 0) {
                return ChiselPrinterTileEntity.this.progress;
            }
            return 0;
        }

        public void method_17391(int index, int value) {
            if (index == 0) {
                ChiselPrinterTileEntity.this.progress = value;
            }
        }

        public int method_17389() {
            return 1;
        }
    };
    long lastTickTime = 0L;

    public ChiselPrinterTileEntity(class_2338 pos, class_2680 state) {
        super(ModTileEntityTypes.CHISEL_PRINTER.get(), pos, state);
    }

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull final Capability<T> cap, @Nullable final class_2350 side) {
        if (cap != CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return super.getCapability(cap, side);
        }

        if (side != null) {
            switch (side) {
                case field_11033:
                    return result_handler.cast();
                case field_11036:
                case field_11043:
                case field_11035:
                case field_11039:
                case field_11034:
                    return tool_handler.cast();
            }
        }

        return empty_handler.cast();
    }

    @Override
    public void method_11014(class_2487 compoundTag) {
        super.method_11014(compoundTag);
        tool_handler.ifPresent(h -> h.deserializeNBT(compoundTag.method_10562("tool")));
        pattern_handler.ifPresent(h -> h.deserializeNBT(compoundTag.method_10562("pattern")));
        result_handler.ifPresent(h -> h.deserializeNBT(compoundTag.method_10562("result")));

        progress = compoundTag.method_10550("progress");
    }

    @Override
    protected void method_11007(class_2487 compoundTag) {
        super.method_11007(compoundTag);
        tool_handler.ifPresent(h -> compoundTag.method_10566("tool", h.serializeNBT()));
        pattern_handler.ifPresent(h -> compoundTag.method_10566("pattern", h.serializeNBT()));
        result_handler.ifPresent(h -> compoundTag.method_10566("result", h.serializeNBT()));

        compoundTag.method_10569("progress", progress);
    }

    @Override
    public class_2487 method_16887() {
        return method_38242();
    }

    public IItemHandlerModifiable getPatternHandler() {
        return pattern_handler.orElseThrow(() -> new IllegalStateException("Missing empty handler."));
    }

    public IItemHandlerModifiable getToolHandler() {
        return tool_handler.orElseThrow(() -> new IllegalStateException("Missing tool handler."));
    }

    public IItemHandlerModifiable getResultHandler() {
        return result_handler.orElseThrow(() -> new IllegalStateException("Missing result handler."));
    }

    public boolean hasPatternStack() {
        return !getPatternStack().method_7960();
    }

    public boolean hasToolStack() {
        return !getToolStack().method_7960();
    }

    public boolean hasRealisedStack() {
        return !getRealisedStack().method_7960();
    }

    public boolean hasOutputStack() {
        return !getOutputStack().method_7960();
    }

    public boolean canMergeOutputs() {
        if (!hasOutputStack()) {
            return true;
        }

        if (!hasRealisedStack()) {
            return false;
        }

        return ItemHandlerHelper.canItemStacksStack(getOutputStack(), getRealisedStack());
    }

    public boolean canWork() {
        return hasPatternStack() && hasToolStack() && canMergeOutputs();
    }

    public boolean couldWork() {
        return hasPatternStack() && hasToolStack();
    }

    public boolean hasMergeableInput() {
        if (!hasOutputStack()) {
            return true;
        }

        return ItemHandlerHelper.canItemStacksStack(getOutputStack(), realisePattern(false));
    }

    public class_1799 getPatternStack() {
        return pattern_handler.map(h -> h.getStackInSlot(0)).orElse(class_1799.field_8037);
    }

    public class_1799 getToolStack() {
        return tool_handler.map(h -> h.getStackInSlot(0)).orElse(class_1799.field_8037);
    }

    public class_1799 getRealisedStack() {
        class_1799 realisedStack = currentRealisedWorkingStack.getValue();
        if (realisedStack.method_7960()) {
            realisedStack = realisePattern(false);
            currentRealisedWorkingStack.setValue(realisedStack);
        }

        return realisedStack;
    }

    public class_1799 getOutputStack() {
        return result_handler.map(h -> h.getStackInSlot(0)).orElse(class_1799.field_8037);
    }

    public class_1799 realisePattern(final boolean consumeResources) {
        if (!hasPatternStack()) {
            return class_1799.field_8037;
        }

        final class_1799 stack = getPatternStack();
        if (!(stack.method_7909() instanceof IPatternItem patternItem)) {
            return class_1799.field_8037;
        }

        final class_1799 realisedPattern = patternItem.getPatternedItem(stack.method_7972(), true);
        if (realisedPattern == null || realisedPattern.method_7960()) {
            return class_1799.field_8037;
        }

        class_2680 firstState = getPrimaryBlockState();
        class_2680 secondState = getSecondaryBlockState();
        class_2680 thirdState = getTertiaryBlockState();

        if (firstState == null) {
            firstState = class_2246.field_10124.method_9564();
        }

        if (secondState == null) {
            secondState = class_2246.field_10124.method_9564();
        }

        if (thirdState == null) {
            thirdState = class_2246.field_10124.method_9564();
        }

        if ((!BlockBitInfo.isSupported(firstState) && !firstState.method_26215())
                || (!BlockBitInfo.isSupported(secondState) && !secondState.method_26215())
                || (!BlockBitInfo.isSupported(thirdState) && !thirdState.method_26215())) {
            return class_1799.field_8037;
        }

        final NBTBlobConverter c = new NBTBlobConverter();
        final class_2487 tag = ModUtil.getSubCompound(realisedPattern, ModUtil.NBT_BLOCKENTITYTAG, false)
                .method_10553();
        c.readChisleData(tag, VoxelBlob.VERSION_ANY);
        VoxelBlob blob = c.getBlob();

        final VoxelBlob.PartialFillResult fillResult = blob.clearAllBut(
                ModUtil.getStateId(firstState), ModUtil.getStateId(secondState), ModUtil.getStateId(thirdState));

        if (fillResult.getFirstStateUsedCount() == 0
                && fillResult.getSecondStateUsedCount() == 0
                && fillResult.getThirdStateUsedCount() == 0) {
            return class_1799.field_8037;
        }

        if (fillResult.getFirstStateUsedCount() > getAvailablePrimaryBlockState()
                || fillResult.getSecondStateUsedCount() > getAvailableSecondaryBlockState()
                || fillResult.getThirdStateUsedCount() > getAvailableTertiaryBlockState()) {
            return class_1799.field_8037;
        }

        if (consumeResources) {
            drainPrimaryStorage(fillResult.getFirstStateUsedCount());
            drainSecondaryStorage(fillResult.getSecondStateUsedCount());
            drainTertiaryStorage(fillResult.getThirdStateUsedCount());
        }

        c.setBlob(blob);

        final class_2680 state = c.getPrimaryBlockState();
        final class_1799 itemstack = new class_1799(ModBlocks.getChiseledBlock(), 1);
        c.writeChisleData(tag, false);

        itemstack.method_7959(ModUtil.NBT_BLOCKENTITYTAG, tag);
        return itemstack;
    }

    void damageChisel() {
        if (method_10997() != null && !method_10997().method_8608()) {
            getToolStack().method_7970(1, method_10997().method_8409(), null);
        }
    }

    @Nullable
    @Override
    public class_1703 createMenu(
            final int containerId, @NotNull final class_1661 playerInventory, @NotNull final class_1657 playerEntity) {
        return new ChiselPrinterContainer(
                containerId, playerInventory, getPatternHandler(), getToolHandler(), getResultHandler(), stationData);
    }

    @Override
    public class_2561 method_5476() {
        return LocalStrings.ChiselStationName.getLocalText();
    }

    public int getAvailablePrimaryBlockState() {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10170();

        return getStorageContents(targetedFacing);
    }

    public int getAvailableSecondaryBlockState() {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10170().method_10170();

        return getStorageContents(targetedFacing);
    }

    public int getAvailableTertiaryBlockState() {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10160();

        return getStorageContents(targetedFacing);
    }

    private int getStorageContents(final class_2350 targetedFacing) {
        final class_2586 targetedTileEntity =
                this.method_10997().method_8321(this.method_11016().method_10093(targetedFacing));
        if (targetedTileEntity instanceof TileEntityBitStorage storage) {
            return storage.getBits();
        }

        return 0;
    }

    public class_2680 getPrimaryBlockState() {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10170();

        return getStorage(targetedFacing);
    }

    public class_2680 getSecondaryBlockState() {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10170().method_10170();

        return getStorage(targetedFacing);
    }

    public class_2680 getTertiaryBlockState() {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10160();

        return getStorage(targetedFacing);
    }

    private class_2680 getStorage(final class_2350 targetedFacing) {
        final class_2586 targetedTileEntity =
                this.method_10997().method_8321(this.method_11016().method_10093(targetedFacing));
        if (targetedTileEntity instanceof TileEntityBitStorage storage) {
            return storage.getState();
        }

        return class_2246.field_10124.method_9564();
    }

    public void drainPrimaryStorage(final int amount) {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10170();

        drainStorage(amount, targetedFacing);
    }

    public void drainSecondaryStorage(final int amount) {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10170().method_10170();

        drainStorage(amount, targetedFacing);
    }

    public void drainTertiaryStorage(final int amount) {
        final class_2350 facing = Objects.requireNonNull(this.method_10997())
                .method_8320(this.method_11016())
                .method_11654(ChiselPrinterBlock.FACING);
        final class_2350 targetedFacing = facing.method_10160();

        drainStorage(amount, targetedFacing);
    }

    private void drainStorage(final int amount, final class_2350 targetedFacing) {
        final class_2586 targetedTileEntity =
                this.method_10997().method_8321(this.method_11016().method_10093(targetedFacing));
        if (targetedTileEntity instanceof TileEntityBitStorage storage) {
            storage.extractBits(0, amount, false);
        }
    }
}
