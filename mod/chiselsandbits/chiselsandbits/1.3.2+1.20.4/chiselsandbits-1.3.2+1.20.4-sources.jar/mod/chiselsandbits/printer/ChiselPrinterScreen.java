package mod.chiselsandbits.printer;

import java.util.Objects;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class ChiselPrinterScreen extends class_465<ChiselPrinterContainer> {

    private static final class_2960 GUI_TEXTURES =
            new class_2960(Constants.MOD_ID, "textures/gui/container/chisel_printer.png");

    public ChiselPrinterScreen(
            final ChiselPrinterContainer screenContainer, final class_1661 inv, final class_2561 titleIn) {
        super(screenContainer, inv, titleIn);
    }

    @Override
    protected void method_25426() {
        this.field_2792 = 176;
        this.field_2779 = 166;

        super.method_25426();

        this.field_25267 = (this.field_2792 - this.field_22793.method_27525(this.field_22785)) / 2;
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float f, int i, int j) {
        method_25420(guiGraphics, i, j, f);
        guiGraphics.method_51422(1, 1, 1, 1);
        guiGraphics.method_25302(GUI_TEXTURES, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779);

        if (this.field_2797.getToolStack().method_7960()) {
            return;
        }

        guiGraphics.method_51423(
                Objects.requireNonNull(this.field_22787.field_1724),
                this.field_2797.getToolStack(),
                this.field_2776 + 81,
                this.field_2800 + 47,
                0);

        int scaledProgress = this.field_2797.getChiselProgressionScaled();
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 400);
        guiGraphics.method_25302(
                GUI_TEXTURES,
                this.field_2776 + 73 + 10 + scaledProgress,
                this.field_2800 + 49,
                this.field_2792 + scaledProgress,
                0,
                16 - scaledProgress,
                16);
        guiGraphics.method_51448().method_22909();
    }
}
