package mod.chiselsandbits.printer;

import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.LocalStrings;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class ChiselPrinterBlock extends class_2248 implements class_2343 {

    public static final class_2753 FACING = class_2383.field_11177;

    private static final Map<class_2350, class_265> BUTTON_VS_MAP = ImmutableMap.<class_2350, class_265>builder()
            .put(class_2350.field_11043, class_2248.method_9541(7, 1, -0.5, 12, 4, 0))
            .put(class_2350.field_11034, class_2248.method_9541(16, 1, 7, 16.5, 4, 12))
            .put(class_2350.field_11035, class_2248.method_9541(4, 1, 16, 9, 4, 16.5))
            .put(class_2350.field_11039, class_2248.method_9541(-0.5, 1, 4, 0, 4, 9))
            .build();

    private static final class_265 VS_NORTH = createForDirection(class_2350.field_11043);
    private static final class_265 VS_EAST = createForDirection(class_2350.field_11034);
    private static final class_265 VS_SOUTH = createForDirection(class_2350.field_11035);
    private static final class_265 VS_WEST = createForDirection(class_2350.field_11039);

    private static final Map<class_2350, class_265> VS_MAP = ImmutableMap.<class_2350, class_265>builder()
            .put(class_2350.field_11043, VS_NORTH)
            .put(class_2350.field_11034, VS_EAST)
            .put(class_2350.field_11035, VS_SOUTH)
            .put(class_2350.field_11039, VS_WEST)
            .build();

    public ChiselPrinterBlock(final class_2251 builder) {
        super(builder);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    private static class_265 createForDirection(final class_2350 direction) {
        return class_259.method_1072(
                class_259.method_1072(
                        Stream.of(
                                        class_2248.method_9541(0, 5, 0, 2, 16, 2),
                                        class_2248.method_9541(14, 5, 0, 16, 16, 2),
                                        class_2248.method_9541(0, 5, 14, 2, 16, 16),
                                        class_2248.method_9541(14, 5, 14, 16, 16, 16))
                                .reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366))
                                .orElse(class_259.method_1073()),
                        Stream.of(
                                        class_2248.method_9541(2, 14, 0, 14, 16, 2),
                                        class_2248.method_9541(2, 14, 14, 14, 16, 16),
                                        class_2248.method_9541(0, 14, 2, 2, 16, 14),
                                        class_2248.method_9541(14, 14, 2, 16, 16, 14),
                                        Stream.of(
                                                        class_2248.method_9541(2, 14, 7, 14, 16, 9),
                                                        class_2248.method_9541(7, 13.99, 2, 9, 15.98, 14),
                                                        class_2248.method_9541(7, 11, 7, 9, 14, 9),
                                                        class_2248.method_9541(7.5, 10, 7.5, 8.5, 11, 8.5))
                                                .reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366))
                                                .orElse(class_259.method_1073()))
                                .reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366))
                                .orElse(class_259.method_1073()),
                        class_247.field_1366),
                class_259.method_1072(
                        class_2248.method_9541(0, 0, 0, 16, 5, 16),
                        BUTTON_VS_MAP.getOrDefault(direction, class_259.method_1073()),
                        class_247.field_1366),
                class_247.field_1366);
    }

    public class_2680 method_9605(class_1750 context) {
        return this.method_9564()
                .method_11657(FACING, context.method_8042().method_10153());
    }

    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    public class_2680 method_9598(class_2680 state, class_2470 rot) {
        return state.method_11657(FACING, rot.method_10503(state.method_11654(FACING)));
    }

    public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
        return state.method_26186(mirrorIn.method_10345(state.method_11654(FACING)));
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_265 method_9530(
            final class_2680 state, final class_1922 worldIn, final class_2338 pos, final class_3726 context) {
        return VS_MAP.getOrDefault(state.method_11654(FACING), class_259.method_1073());
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new ChiselPrinterTileEntity(blockPos, blockState);
    }

    public class_1269 method_9534(
            class_2680 state, class_1937 worldIn, class_2338 pos, class_1657 player, class_1268 handIn, class_3965 hit) {
        if (worldIn.field_9236) {
            return class_1269.field_5812;
        } else {
            player.method_17355((class_3908) worldIn.method_8321(pos));
            return class_1269.field_21466;
        }
    }

    @Override
    public void method_9568(
            final class_1799 stack,
            @Nullable final class_1922 worldIn,
            final List<class_2561> tooltip,
            final class_1836 flagIn) {
        super.method_9568(stack, worldIn, tooltip, flagIn);
        ChiselsAndBits.getConfig().getCommon().helpText(LocalStrings.ChiselStationHelp, tooltip);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 level, class_2680 blockState, class_2591<T> blockEntityType) {
        return (level1, blockPos, blockState1, e) -> {
            ChiselPrinterTileEntity blockEntity = (ChiselPrinterTileEntity) e;
            if (blockEntity.method_10997() == null
                    || blockEntity.lastTickTime == level1.method_8510()
                    || level1.method_8608()) {
                return;
            }

            blockEntity.lastTickTime = level1.method_8510();

            if (blockEntity.couldWork()) {
                if (blockEntity.canWork()) {
                    blockEntity.progress++;
                    if (blockEntity.progress >= 100) {
                        blockEntity.result_handler.ifPresent(
                                h -> h.insertItem(0, blockEntity.realisePattern(true), false));
                        blockEntity.currentRealisedWorkingStack.setValue(class_1799.field_8037);
                        blockEntity.progress = 0;
                        blockEntity.damageChisel();
                    }
                    blockEntity.method_5431();
                }
            } else if (blockEntity.progress != 0) {
                blockEntity.progress = 0;
                blockEntity.method_5431();
            }
        };
    }
}
