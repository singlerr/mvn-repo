package mod.chiselsandbits.debug;

import java.util.HashMap;
import java.util.Map.Entry;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.APIExceptions.CannotBeChiseled;
import mod.chiselsandbits.api.APIExceptions.InvalidBitItem;
import mod.chiselsandbits.api.APIExceptions.SpaceOccupied;
import mod.chiselsandbits.api.BitQueryResults;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.IBitBrush;
import mod.chiselsandbits.api.IBitLocation;
import mod.chiselsandbits.api.IBitVisitor;
import mod.chiselsandbits.api.IChiselAndBitsAPI;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModItems;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public abstract class DebugAction {

    public static IChiselAndBitsAPI api;

    protected static void Msg(final class_1657 player, final String msg) {
        final String side = FabricLoader.getInstance().getEnvironmentType().name() + ": ";
        player.method_43496(class_2561.method_43470(side + msg));
    }

    private static void apiAssert(final String name, final class_1657 player, final boolean must_be_true) {
        if (!must_be_true) {
            Msg(player, name + " = false");
        }
    }

    public abstract void run(
            final @Nonnull class_1937 w,
            final @Nonnull class_2338 pos,
            final @Nonnull class_2350 side,
            final double hitX,
            final double hitY,
            final double hitZ,
            @Nonnull class_1657 player);

    enum Tests {
        canBeChiseled(new DebugAction.canBeChiseled()),
        createBitItem(new DebugAction.createBitItem()),
        getBit(new DebugAction.getBit()),
        listContents(new DebugAction.listContents()),
        getBitAccess(new DebugAction.getBitAccess()),
        setBitAccess(new DebugAction.setBitAccess()),
        isBlockChiseled(new DebugAction.isBlockChiseled()),
        ItemTests(new DebugAction.ItemTests()),
        Randomize(new DebugAction.Randomize()),
        Spin(new DebugAction.Spin()),
        Mirror(new DebugAction.Mirror()),
        getTileClass(new DebugAction.getTileClass()),
        occusionTest(new DebugAction.occlusionTest()),
        queryTest(new DebugAction.queryTest());

        final DebugAction which;

        Tests(final DebugAction action) {
            which = action;
        }
    }

    static class ItemTests extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitAccess access = api.createBitItem(ModUtil.getEmptyStack());
            assert access != null;

            apiAssert(
                    "BIT_BAG",
                    player,
                    api.getItemType(new class_1799(ModItems.ITEM_BIT_BAG_DEFAULT.get())) == ItemType.BIT_BAG);
            apiAssert(
                    "CHISEL",
                    player,
                    api.getItemType(new class_1799(ModItems.ITEM_CHISEL_DIAMOND.get())) == ItemType.CHISEL);
            apiAssert(
                    "MIRROR_DESIGN 1",
                    player,
                    api.getItemType(new class_1799(ModItems.ITEM_MIRROR_PRINT.get())) == ItemType.MIRROR_DESIGN);
            apiAssert(
                    "NEGATIVE_DESIGN 1",
                    player,
                    api.getItemType(new class_1799(ModItems.ITEM_NEGATIVE_PRINT.get())) == ItemType.NEGATIVE_DESIGN);
            apiAssert(
                    "POSITIVE_DESIGN 1",
                    player,
                    api.getItemType(new class_1799(ModItems.ITEM_POSITIVE_PRINT.get())) == ItemType.POSITIVE_DESIGN);
            apiAssert("WRENCH", player, api.getItemType(new class_1799(ModItems.ITEM_WRENCH.get())) == ItemType.WRENCH);
            apiAssert(
                    "CHISLED_BIT-cobblestone",
                    player,
                    api.getItemType(ItemChiseledBit.createStack(
                                    ModUtil.getStateId(class_2246.field_10445.method_9564()), 1, true))
                            == ItemType.CHISELED_BIT);
            apiAssert(
                    "CHISLED_BLOCK",
                    player,
                    api.getItemType(access.getBitsAsItem(class_2350.field_11036, ItemType.CHISELED_BLOCK, false)) == null);
            apiAssert(
                    "MIRROR_DESIGN 2",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.MIRROR_DESIGN, false)) == null);
            apiAssert(
                    "NEGATIVE_DESIGN 2",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.NEGATIVE_DESIGN, false)) == null);
            apiAssert(
                    "POSITIVE_DESIGN 2",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.POSITIVE_DESIGN, false)) == null);

            try {
                final class_1799 bitItem = api.getBitItem(class_2246.field_10445.method_9564());
                final IBitBrush brush = api.createBrush(bitItem);
                access.setBitAt(0, 0, 0, brush);
            } catch (final InvalidBitItem e) {
                apiAssert("createBrush/getBitItem", player, false);
            } catch (final SpaceOccupied e) {
                apiAssert("setBitAt", player, false);
            }

            apiAssert(
                    "CHISLED_BLOCK 2",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.CHISELED_BLOCK, false))
                            == ItemType.CHISELED_BLOCK);
            apiAssert(
                    "MIRROR_DESIGN 3",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.MIRROR_DESIGN, false))
                            == ItemType.MIRROR_DESIGN);
            apiAssert(
                    "NEGATIVE_DESIGN 3",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.NEGATIVE_DESIGN, false))
                            == ItemType.NEGATIVE_DESIGN);
            apiAssert(
                    "POSITIVE_DESIGN 3",
                    player,
                    api.getItemType(access.getBitsAsItem(null, ItemType.POSITIVE_DESIGN, false))
                            == ItemType.POSITIVE_DESIGN);
            apiAssert("WRENCH", player, api.getItemType(access.getBitsAsItem(null, ItemType.WRENCH, false)) == null);
        }
    }

    static class getTileClass extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final class_2586 te = w.method_8321(pos);
            if (te != null) {
                Msg(player, te.getClass().getName());
            }
        }
    }

    static class canBeChiseled extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            Msg(player, "canBeChiseled = " + (api.canBeChiseled(w, pos) ? "true" : "false"));
        }
    }

    static class isBlockChiseled extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            Msg(player, "isBlockChiseled = " + (api.isBlockChiseled(w, pos) ? "true" : "false"));
        }
    }

    static class getBitAccess extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, true);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());
                final IBitBrush brush = api.createBrush(api.getBitItem(class_2246.field_10445.method_9564()));

                access.setBitAt(loc.getBitX(), loc.getBitY(), loc.getBitZ(), brush);
                access.commitChanges(true);
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            } catch (final SpaceOccupied e) {
                Log.logError("FAIL", e);
            } catch (final InvalidBitItem e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class queryTest extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());

                output(player, access.queryBitRange(new class_2338(-1, -1, -1), new class_2338(16, 16, 16)));
                output(player, access.queryBitRange(new class_2338(1, 1, 1), new class_2338(14, 14, 14)));
                output(player, access.queryBitRange(new class_2338(0, 15, 0), new class_2338(15, 15, 15)));
                output(player, access.queryBitRange(new class_2338(0, 15, 15), new class_2338(15, 15, 15)));
                output(player, access.queryBitRange(new class_2338(0, 0, 0), new class_2338(15, 15, 0)));
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }

        private void output(final class_1657 player, final BitQueryResults queryBitRange) {
            Msg(
                    player,
                    queryBitRange.total + " = e" + queryBitRange.empty + " + s" + queryBitRange.solid + " + f"
                            + queryBitRange.fluid);
        }
    }

    static class setBitAccess extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());
                final IBitBrush brush = api.createBrush(ModUtil.getEmptyStack());

                access.setBitAt(loc.getBitX(), loc.getBitY(), loc.getBitZ(), brush);
                access.commitChanges(true);
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            } catch (final SpaceOccupied e) {
                Log.logError("FAIL", e);
            } catch (final InvalidBitItem e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class Randomize extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());

                access.visitBits(new IBitVisitor() {

                    @Override
                    public IBitBrush visitBit(final int x, final int y, final int z, final IBitBrush currentValue) {
                        IBitBrush bit = currentValue;
                        final class_2680 state = class_2246.field_10146.method_9564();

                        try {
                            bit = api.createBrush(api.getBitItem(state));
                        } catch (final InvalidBitItem e) {
                        }

                        return y % 2 == 0 ? currentValue : bit;
                    }
                });

                access.commitChanges(true);
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class Mirror extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());

                access.mirror(side.method_10166());

                access.commitChanges(true);
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class Spin extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());

                access.rotate(side.method_10166(), class_2470.field_11463);

                access.commitChanges(true);
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class listContents extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final HashMap<Integer, class_1799> bucket = new HashMap<Integer, class_1799>();
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());

                access.visitBits(new IBitVisitor() {

                    @Override
                    public IBitBrush visitBit(final int x, final int y, final int z, final IBitBrush currentValue) {
                        if (bucket.containsKey(currentValue.getStateID())) {
                            ModUtil.adjustStackSize(bucket.get(currentValue.getStateID()), 1);
                        } else {
                            bucket.put(currentValue.getStateID(), currentValue.getItemStack(1));
                        }

                        return currentValue;
                    }
                });

                for (Entry<Integer, class_1799> is : bucket.entrySet()) {
                    player.field_7514.method_7394(is.getValue());
                }
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class getBit extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());
                final IBitBrush brush = access.getBitAt(loc.getBitX(), loc.getBitY(), loc.getBitZ());

                if (brush == null) {
                    Msg(player, "AIR!");
                } else {
                    final class_2680 state = brush.getState();
                    if (state != null) {
                        final class_2248 blk = state.method_26204();

                        final class_1799 it = brush.getItemStack(1);

                        if (it != null && it.method_7909() != null) {
                            player.field_7514.method_7394(it);
                        }

                        player.field_7514.method_7394(new class_1799(blk, 1));
                    }
                }
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }
    }

    static class occlusionTest extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            final VoxelBlob out = new VoxelBlob();

            player.method_43496(class_2561.method_43470(out.filled() + " blocked"));
            player.method_43496(class_2561.method_43470(out.air() + " not-blocked"));
        }
    }

    static class createBitItem extends DebugAction {

        @Override
        public void run(
                final class_1937 w,
                final class_2338 pos,
                final class_2350 side,
                final double hitX,
                final double hitY,
                final double hitZ,
                final class_1657 player) {
            final IBitLocation loc = api.getBitPos(hitX, hitY, hitZ, side, pos, false);

            try {
                final IBitAccess access = api.getBitAccess(w, loc.getBlockPos());

                player.field_7514.method_7394(access.getBitsAsItem(side, ItemType.CHISELED_BLOCK, false));
                player.field_7514.method_7394(access.getBitsAsItem(side, ItemType.MIRROR_DESIGN, false));
                player.field_7514.method_7394(access.getBitsAsItem(side, ItemType.NEGATIVE_DESIGN, false));
                player.field_7514.method_7394(access.getBitsAsItem(side, ItemType.POSITIVE_DESIGN, false));
            } catch (final CannotBeChiseled e) {
                Log.logError("FAIL", e);
            }
        }
    }
}
