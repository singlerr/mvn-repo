package mod.chiselsandbits.debug;

import mod.chiselsandbits.debug.DebugAction.Tests;
import mod.chiselsandbits.helpers.ModUtil;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class ItemApiDebug extends class_1792 {

    public ItemApiDebug(class_1792.class_1793 properties) {
        super(properties.method_7895(1).method_7889(1));
    }

    @Override
    public class_2561 method_7864(final class_1799 stack) {
        final class_2561 parent = super.method_7864(stack);
        if (!(parent instanceof class_5250 name)) {
            return parent;
        }

        return name.method_27693(" - " + getAction(stack).name());
    }

    private Tests getAction(final class_1799 stack) {
        return Tests.values()[getActionID(stack)];
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1799 stack = context.method_8036().method_5998(context.method_20287());

        if (context.method_8036().method_5715()) {
            final int newDamage = getActionID(stack) + 1;
            setActionID(stack, newDamage % Tests.values().length);
            DebugAction.Msg(context.method_8036(), getAction(stack).name());
            return class_1269.field_5812;
        }

        getAction(stack)
                .which
                .run(
                        context.method_8045(),
                        context.method_8037(),
                        context.method_8038(),
                        context.method_17698().field_1352,
                        context.method_17698().field_1351,
                        context.method_17698().field_1350,
                        context.method_8036());
        return class_1269.field_5812;
    }

    private void setActionID(final class_1799 stack, final int i) {
        final class_2487 o = new class_2487();
        o.method_10569("id", i);
        stack.method_7980(o);
    }

    private int getActionID(final class_1799 stack) {
        if (stack.method_7985()) {
            return ModUtil.getTagCompound(stack).method_10550("id");
        }

        return 0;
    }
}
