package mod.chiselsandbits.helpers;

import javax.annotation.Nonnull;
import net.minecraft.class_1263;
import net.minecraft.class_1799;

public class ItemStackSlot implements IItemInInventory {
    private final class_1263 inv;
    private final int slot;
    private final @Nonnull class_1799 originalStack;
    private final boolean isCreative;
    private final boolean isEditable;
    private final int toolSlot;
    private @Nonnull class_1799 stack;

    ItemStackSlot(
            final class_1263 i,
            final int s,
            final @Nonnull class_1799 st,
            final ActingPlayer player,
            final boolean canEdit) {
        inv = i;
        slot = s;
        stack = st;
        originalStack = ModUtil.copy(st);
        toolSlot = player.getCurrentItem();
        isCreative = player.isCreative();
        isEditable = canEdit;
    }

    @Override
    public boolean isValid() {
        return isEditable && (isCreative || !ModUtil.isEmpty(stack) && ModUtil.getStackSize(stack) > 0);
    }

    @Override
    public void damage(final ActingPlayer who) {
        if (isCreative) {
            return;
        }

        who.damageItem(stack, 1);
        if (ModUtil.getStackSize(stack) <= 0) {
            who.playerDestroyItem(stack, who.getHand());
            inv.method_5447(slot, ModUtil.getEmptyStack());
        }
    }

    @Override
    public boolean consume() {
        if (isCreative) {
            return true;
        }

        if (ModUtil.getStackSize(stack) > 0) {
            ModUtil.adjustStackSize(stack, -1);
            if (ModUtil.getStackSize(stack) <= 0) {
                inv.method_5447(slot, ModUtil.getEmptyStack());
            }

            return true;
        }

        return false;
    }

    @Override
    public class_1799 getStack() {
        return stack;
    }

    @Override
    public void swapWithWeapon() {
        final class_1799 it = inv.method_5438(toolSlot);
        inv.method_5447(toolSlot, inv.method_5438(slot));
        inv.method_5447(slot, it);
    }

    @Override
    public class_1799 getStackType() {
        return originalStack;
    }

    public void replaceStack(final @Nonnull class_1799 restockItem) {
        stack = restockItem;
        inv.method_5447(slot, restockItem);
    }
}
