package mod.chiselsandbits.helpers;

import java.util.ArrayList;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

public class StateLookup {

    public int getStateId(final class_2680 state) {
        return class_2248.method_9507(state);
    }

    public class_2680 getStateById(final int blockStateID) {
        return class_2248.method_9531(blockStateID);
    }

    public static class CachedStateLookup extends StateLookup {

        private final class_2680[] states;

        public CachedStateLookup() {
            final ArrayList<class_2680> list = new ArrayList<>();

            for (final class_2248 blk : class_7923.field_41175) {
                for (final class_2680 state : blk.method_9595().method_11662()) {
                    final int id = ModUtil.getStateId(state);

                    list.ensureCapacity(id);
                    while (list.size() <= id) {
                        list.add(null);
                    }

                    list.set(id, state);
                }
            }

            states = list.toArray(new class_2680[list.size()]);
        }

        @Override
        public class_2680 getStateById(final int blockStateID) {
            return blockStateID >= 0 && blockStateID < states.length
                    ? states[blockStateID] == null ? class_2246.field_10124.method_9564() : states[blockStateID]
                    : class_2246.field_10124.method_9564();
        }
    }
}
