package mod.chiselsandbits.helpers;

import net.minecraft.class_1799;

public interface IItemInInventory {

    boolean isValid();

    void damage(ActingPlayer who);

    boolean consume();

    class_1799 getStack();

    void swapWithWeapon();

    class_1799 getStackType();
}
