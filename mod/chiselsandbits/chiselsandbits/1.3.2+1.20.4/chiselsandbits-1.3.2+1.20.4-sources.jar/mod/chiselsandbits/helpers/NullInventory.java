package mod.chiselsandbits.helpers;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class NullInventory implements class_1263 {

    final int size;

    public NullInventory(final int size) {
        this.size = size;
    }

    @Override
    public int method_5439() {
        return size;
    }

    @Override
    public class_1799 method_5438(final int index) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_1799 method_5434(final int index, final int count) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_1799 method_5441(final int index) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {}

    @Override
    public int method_5444() {
        return 64;
    }

    @Override
    public void method_5431() {}

    @Override
    public boolean method_5443(final class_1657 player) {
        return false;
    }

    @Override
    public void method_5435(final class_1657 player) {}

    @Override
    public void method_5432(final class_1657 player) {}

    @Override
    public boolean method_5437(final int index, final class_1799 stack) {
        return false;
    }

    @Override
    public void method_5448() {}

    @Override
    public boolean method_5442() {
        return true;
    }
}
