package mod.chiselsandbits.helpers;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Nonnull;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.registry.ModItems;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class ContinousChisels implements IContinuousInventory {

    private final ActingPlayer who;
    private final List<ItemStackSlot> options = new ArrayList<ItemStackSlot>();
    private final HashMap<Integer, List<ItemStackSlot>> actionCache = new HashMap<Integer, List<ItemStackSlot>>();
    private final boolean canEdit;

    public ContinousChisels(
            final @Nonnull ActingPlayer who, final @Nonnull class_2338 pos, final @Nonnull class_2350 side) {
        this.who = who;
        final class_1799 inHand = who.getCurrentEquippedItem();
        final class_1263 inv = who.getInventory();

        // test can edit...
        canEdit = who.canPlayerManipulate(pos, side, new class_1799(ModItems.ITEM_CHISEL_DIAMOND.get(), 1), false);

        if (ModUtil.notEmpty(inHand) && inHand.method_7909() instanceof ItemChisel) {
            if (who.canPlayerManipulate(pos, side, inHand, false)) {
                options.add(new ItemStackSlot(inv, who.getCurrentItem(), inHand, who, canEdit));
            }
        } else {
            final ArrayListMultimap<Integer, ItemStackSlot> discovered = ArrayListMultimap.create();

            for (int x = 0; x < inv.method_5439(); x++) {
                final class_1799 is = inv.method_5438(x);

                if (is == inHand) {
                    continue;
                }

                if (!who.canPlayerManipulate(pos, side, is, false)) {
                    continue;
                }

                if (ModUtil.notEmpty(is) && is.method_7909() instanceof ItemChisel) {
                    final class_1832 newMat = ((ItemChisel) is.method_7909()).method_8022();
                    discovered.put(newMat.method_8024(), new ItemStackSlot(inv, x, is, who, canEdit));
                }
            }

            final List<ItemStackSlot> allValues = Lists.newArrayList(discovered.values());
            for (final ItemStackSlot f : Lists.reverse(allValues)) {
                options.add(f);
            }
        }
    }

    @Override
    public IItemInInventory getItem(final int BlockID) {
        if (!actionCache.containsKey(BlockID)) {
            actionCache.put(BlockID, new ArrayList<ItemStackSlot>(options));
        }

        final List<ItemStackSlot> choices = actionCache.get(BlockID);

        if (choices.isEmpty()) {
            return new ItemStackSlot(who.getInventory(), -1, ModUtil.getEmptyStack(), who, canEdit);
        }

        final IItemInInventory slot = choices.get(choices.size() - 1);

        if (slot.isValid()) {
            return slot;
        } else {
            fail(BlockID);
        }

        return getItem(BlockID);
    }

    @Override
    public void fail(final int BlockID) {
        final List<ItemStackSlot> choices = actionCache.get(BlockID);

        if (!choices.isEmpty()) {
            choices.remove(choices.size() - 1);
        }
    }

    @Override
    public boolean isValid() {
        return !options.isEmpty() || who.isCreative();
    }

    @Override
    public boolean useItem(final int blk) {
        getItem(blk).damage(who);
        return true;
    }
}
