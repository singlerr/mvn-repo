package mod.chiselsandbits.helpers;

import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import net.minecraftforge.items.IItemHandler;

public class IItemHandlerSlot implements IItemInInventory {

    private final @Nonnull class_1799 originalStack;
    private final IItemHandler internal;
    private final int zz;
    private final @Nonnull class_1799 stack; // copy of itemstack
    private final ActingPlayer src;
    private final boolean isEditable;

    public IItemHandlerSlot(IItemHandler internal, int zz, class_1799 which, ActingPlayer src, boolean canEdit) {
        this.internal = internal;
        this.zz = zz;
        this.stack = ModUtil.copy(which);
        this.originalStack = ModUtil.copy(which);
        this.src = src;
        this.isEditable = canEdit;
    }

    @Override
    public boolean isValid() {
        return isEditable && (src.isCreative() || !ModUtil.isEmpty(stack) && ModUtil.getStackSize(stack) > 0);
    }

    @Override
    public void damage(ActingPlayer who) {
        throw new RuntimeException("Cannot damage an item in an inventory?");
    }

    @Override
    public boolean consume() {
        class_1799 is = internal.extractItem(zz, 1, true);
        if (is != null && class_1799.method_31577(is, stack) && class_1799.method_7984(is, stack)) {
            internal.extractItem(zz, 1, false);
            ModUtil.adjustStackSize(stack, -1);
            return true;
        }

        return false;
    }

    @Override
    public class_1799 getStack() {
        return stack;
    }

    @Override
    public void swapWithWeapon() {
        throw new RuntimeException("Cannot swap an item in an inventory?");
    }

    @Override
    public class_1799 getStackType() {
        return originalStack;
    }
}
