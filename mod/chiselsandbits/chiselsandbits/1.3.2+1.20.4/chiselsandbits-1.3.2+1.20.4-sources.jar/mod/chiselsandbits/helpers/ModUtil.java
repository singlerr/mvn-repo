package mod.chiselsandbits.helpers;

import com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import mod.chiselsandbits.bitbag.BagInventory;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.IntegerBox;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.StateLookup.CachedStateLookup;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import mod.chiselsandbits.render.helpers.SimpleInstanceCache;
import mod.chiselsandbits.utils.RenderTypeUtils;
import mod.chiselsandbits.utils.SingleBlockBlockReader;
import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2350;
import net.minecraft.class_2358;
import net.minecraft.class_2362;
import net.minecraft.class_2369;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.IFluidBlock;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;

public class ModUtil {

    @Nonnull
    public static final String NBT_SIDE = "side";

    @Nonnull
    public static final String NBT_BLOCKENTITYTAG = "BlockEntityTag";

    private static final Random RAND = new Random();
    private static final float DEG_TO_RAD = 0.017453292f;

    private static final SimpleInstanceCache<class_2487, VoxelBlob> STACK_VOXEL_BLOB_SIMPLE_INSTANCE_CACHE =
            new SimpleInstanceCache<>(new class_2487(), null);
    private static StateLookup IDRelay = new StateLookup();

    public static class_2350 getPlaceFace(final class_1309 placer) {
        class_2350[] orderedDirections = class_2350.method_10159(placer);
        return orderedDirections[0].method_10166() == class_2350.class_2351.field_11052
                ? orderedDirections[1].method_10153()
                : orderedDirections[0].method_10153();
    }

    public static Pair<class_243, class_243> getPlayerRay(final class_1657 playerIn) {
        double reachDistance = 5.0d;

        final double x = playerIn.field_6014 + (playerIn.method_23317() - playerIn.field_6014);
        final double y = playerIn.field_6036 + (playerIn.method_23318() - playerIn.field_6036) + playerIn.method_5751();
        final double z = playerIn.field_5969 + (playerIn.method_23321() - playerIn.field_5969);

        final float playerPitch = playerIn.field_6004 + (playerIn.field_5965 - playerIn.field_6004);
        final float playerYaw = playerIn.field_5982 + (playerIn.field_6031 - playerIn.field_5982);

        final float yawRayX = class_3532.method_15374(-playerYaw * DEG_TO_RAD - (float) Math.PI);
        final float yawRayZ = class_3532.method_15362(-playerYaw * DEG_TO_RAD - (float) Math.PI);

        final float pitchMultiplier = -class_3532.method_15362(-playerPitch * DEG_TO_RAD);
        final float eyeRayY = class_3532.method_15374(-playerPitch * DEG_TO_RAD);
        final float eyeRayX = yawRayX * pitchMultiplier;
        final float eyeRayZ = yawRayZ * pitchMultiplier;

        if (playerIn instanceof class_3222) {

            reachDistance = ReachEntityAttributes.getReachDistance(
                    playerIn, ReachEntityAttributes.ATTACK_RANGE.method_6169());
        }

        final class_243 from = new class_243(x, y, z);
        final class_243 to = from.method_1031(eyeRayX * reachDistance, eyeRayY * reachDistance, eyeRayZ * reachDistance);

        return Pair.of(from, to);
    }

    public static IItemInInventory findBit(final ActingPlayer who, final class_2338 pos, final int StateID) {
        final class_1799 inHand = who.getCurrentEquippedItem();
        final class_1263 inv = who.getInventory();
        final boolean canEdit = who.canPlayerManipulate(pos, class_2350.field_11036, inHand, true);

        if (getStackSize(inHand) > 0
                && inHand.method_7909() instanceof ItemChiseledBit
                && ItemChiseledBit.getStackState(inHand) == StateID) {
            return new ItemStackSlot(inv, who.getCurrentItem(), inHand, who, canEdit);
        }

        for (int x = 0; x < inv.method_5439(); x++) {
            final class_1799 is = inv.method_5438(x);
            if (getStackSize(is) > 0
                    && is.method_7909() instanceof ItemChiseledBit
                    && ItemChiseledBit.sameBit(is, StateID)) {
                return new ItemStackSlot(inv, x, is, who, canEdit);
            }
        }

        return new ItemStackSlot(inv, -1, ModUtil.getEmptyStack(), who, canEdit);
    }

    public static Set<Integer> getAllStates(VoxelBlob blob) {
        if (blob == null || blob.getBlockSums() == null) {
            return Set.of();
        }
        return blob.getBlockSums().keySet();
    }

    public static ChiselRenderType[] getRenderType(class_2680 state) {
        class_1921 renderType = class_4696.method_23679(state);

        if (state.method_26227().method_15769()) {
            return new ChiselRenderType[] {ChiselRenderType.fromLayer(renderType, false)};
        }

        renderType = class_4696.method_23680(state.method_26227());

        return new ChiselRenderType[] {
            ChiselRenderType.fromLayer(renderType, false), ChiselRenderType.fromLayer(renderType, true)
        };
    }

    public static class_1921 get(class_2680 state) {
        if (!state.method_26227().method_15769()) {
            return class_4696.method_23680(state.method_26227());
        }
        return class_4696.method_23679(state);
    }

    public static Set<class_1921> extractRenderTypes(VoxelBlob blob) {
        return getAllStates(blob).stream()
                .map(ModUtil::getStateById)
                .filter(state -> !state.method_26215())
                .map(ModUtil::get)
                .collect(Collectors.toSet());
    }

    public static Set<ChiselRenderType> getAllRenderTypes(VoxelBlob blob) {
        return getAllStates(blob).stream()
                .flatMap(id -> Stream.of(getRenderType(ModUtil.getStateById(id))))
                .collect(Collectors.toSet());
    }

    public static @Nonnull class_1799 copy(final class_1799 st) {
        if (st == null) {
            return ModUtil.getEmptyStack();
        }

        return nonNull(st.method_7972());
    }

    public static @Nonnull class_1799 nonNull(final class_1799 st) {
        if (st == null) {
            return ModUtil.getEmptyStack();
        }

        return st;
    }

    public static boolean isHoldingPattern(final class_1657 player, AtomicBoolean positivePattern) {
        final class_1799 inHand = player.method_6047();

        if (inHand != null && inHand.method_7909().equals(ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get())) {
            positivePattern.set(true);
            return true;
        }

        if (inHand != null && inHand.method_7909().equals(ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get())) {
            positivePattern.set(false);
            return true;
        }

        return false;
    }

    public static boolean isHoldingChiseledBlock(final class_1657 player) {
        final class_1799 inHand = player.method_6047();

        return inHand != null && inHand.method_7909() instanceof ItemBlockChiseled;
    }

    public static int getRotationIndex(final class_2350 face) {
        return face.method_10161();
    }

    public static int getRotations(final class_1309 placer, final class_2350 oldYaw) {
        final class_2350 newFace = ModUtil.getPlaceFace(placer);
        int rotations = getRotationIndex(newFace) - getRotationIndex(oldYaw);

        // work out the rotation math...
        while (rotations < 0) {
            rotations = 4 + rotations;
        }
        while (rotations > 4) {
            rotations = rotations - 4;
        }

        return 4 - rotations;
    }

    public static class_2338 getPartialOffset(
            final class_2350 side, final class_2338 partial, final IntegerBox modelBounds) {
        int offset_x = modelBounds.minX;
        int offset_y = modelBounds.minY;
        int offset_z = modelBounds.minZ;

        final int partial_x = partial.method_10263();
        final int partial_y = partial.method_10264();
        final int partial_z = partial.method_10260();

        int middle_x = (modelBounds.maxX - modelBounds.minX) / -2;
        int middle_y = (modelBounds.maxY - modelBounds.minY) / -2;
        int middle_z = (modelBounds.maxZ - modelBounds.minZ) / -2;

        switch (side) {
            case field_11033:
                offset_y = modelBounds.maxY;
                middle_y = 0;
                break;
            case field_11034:
                offset_x = modelBounds.minX;
                middle_x = 0;
                break;
            case field_11043:
                offset_z = modelBounds.maxZ;
                middle_z = 0;
                break;
            case field_11035:
                offset_z = modelBounds.minZ;
                middle_z = 0;
                break;
            case field_11036:
                offset_y = modelBounds.minY;
                middle_y = 0;
                break;
            case field_11039:
                offset_x = modelBounds.maxX;
                middle_x = 0;
                break;
            default:
                throw new NullPointerException();
        }

        final int t_x = -offset_x + middle_x + partial_x;
        int t_y = -offset_y + middle_y + partial_y;
        final int t_z = -offset_z + middle_z + partial_z;

        return new class_2338(t_x, t_y, t_z);
    }

    @SafeVarargs
    public static <T> T firstNonNull(final T... options) {
        for (final T i : options) {
            if (i != null) {
                return i;
            }
        }

        throw new NullPointerException("Unable to find a non null item.");
    }

    public static class_2586 getTileEntitySafely(final @Nonnull class_1922 world, final @Nonnull class_2338 pos) {

        // stupid...
        if (world instanceof class_1937) {
            return ((class_1937) world).method_8500(pos).method_12201(pos, class_2818.class_2819.field_12859);
        }

        // yep... stupid.
        else {
            return world.method_8321(pos);
        }
    }

    public static boolean isFluid(class_2680 state) {
        return !state.method_26227().method_15769();
    }

    public static TileEntityBlockChiseled getChiseledTileEntity(
            @Nonnull final class_1922 world, @Nonnull final class_2338 pos) {
        final class_2586 te = getTileEntitySafely(world, pos);
        if (te instanceof TileEntityBlockChiseled) {
            return (TileEntityBlockChiseled) te;
        }

        return null;
    }

    public static TileEntityBlockChiseled getChiseledTileEntity(
            @Nonnull final class_1937 world, @Nonnull final class_2338 pos, final boolean create) {
        if (world.method_22340(pos)) {
            final class_2586 te = world.method_8500(pos).method_12201(pos, class_2818.class_2819.field_12859);
            if (te instanceof TileEntityBlockChiseled) {
                return (TileEntityBlockChiseled) te;
            }

            return null;
        }
        return null;
    }

    public static void removeChiseledBlock(@Nonnull final class_1937 world, @Nonnull final class_2338 pos) {
        final class_2586 te = world.method_8321(pos);
        final class_2680 oldState = world.method_8320(pos);

        if (te instanceof TileEntityBlockChiseled) {
            world.method_8501(pos, class_2246.field_10124.method_9564()); // no physical matter left...
            return;
        }

        world.method_16109(pos, oldState, class_2246.field_10124.method_9564());
    }

    public static boolean containsAtLeastOneOf(final class_1263 inv, final class_1799 is) {
        boolean seen = false;
        for (int x = 0; x < inv.method_5439(); x++) {
            final class_1799 which = inv.method_5438(x);

            if (which != null
                    && which.method_7909() == is.method_7909()
                    && ItemChiseledBit.sameBit(which, ItemChiseledBit.getStackState(is))) {
                if (!seen) {
                    seen = true;
                }
            }
        }
        return seen;
    }

    public static List<BagInventory> getBags(final ActingPlayer player) {
        if (player.isCreative()) {
            return java.util.Collections.emptyList();
        }

        final List<BagInventory> bags = new ArrayList<BagInventory>();
        final class_1263 inv = player.getInventory();

        for (int zz = 0; zz < inv.method_5439(); zz++) {
            final class_1799 which = inv.method_5438(zz);
            if (which != null && which.method_7909() instanceof ItemBitBag) {
                bags.add(new BagInventory(which));
            }
        }

        return bags;
    }

    public static int consumeBagBit(final List<BagInventory> bags, final int inPattern, final int howMany) {
        int remaining = howMany;
        for (final BagInventory inv : bags) {
            remaining -= inv.extractBit(inPattern, remaining);
            if (remaining == 0) {
                return howMany;
            }
        }

        return howMany - remaining;
    }

    public static VoxelBlob getBlobFromStack(final class_1799 stack, final class_1309 rotationPlayer) {
        if (stack.method_7985()) {
            VoxelBlob blob;
            class_2487 cData = getSubCompound(stack, NBT_BLOCKENTITYTAG, false);

            if (STACK_VOXEL_BLOB_SIMPLE_INSTANCE_CACHE.needsUpdate(cData)) {
                final NBTBlobConverter tmp = new NBTBlobConverter();

                if (cData.method_10546() == 0) {
                    cData = stack.method_7969();
                }

                tmp.readChisleData(cData, VoxelBlob.VERSION_ANY);
                blob = tmp.getBlob();
                STACK_VOXEL_BLOB_SIMPLE_INSTANCE_CACHE.updateCachedValue(new VoxelBlob(blob));
            } else {
                blob = new VoxelBlob(STACK_VOXEL_BLOB_SIMPLE_INSTANCE_CACHE.getCached());
            }

            if (rotationPlayer != null) {
                int xrotations = ModUtil.getRotations(rotationPlayer, ModUtil.getSide(stack));
                while (xrotations-- > 0) {
                    blob = blob.spin(class_2350.class_2351.field_11052);
                }
            }

            return blob;
        }

        return new VoxelBlob();
    }

    public static void sendUpdate(@Nullable final class_1937 worldObj, @Nonnull final class_2338 pos) {
        if (worldObj == null) {
            return;
        }

        final class_2680 state = worldObj.method_8320(pos);
        worldObj.method_8413(pos, state, state, 0);
    }

    private static class_1792 getItem(@NotNull final class_2680 blockState) {
        final class_2248 block = blockState.method_26204();
        if (block.equals(class_2246.field_10164)) {
            return class_1802.field_8187;
        } else if (block instanceof class_2302) {
            final class_1799 stack = block.method_9574(null, null, blockState);
            if (stack != null) {
                return stack.method_7909();
            }

            return class_1802.field_8317;
        }
        // oh no...
        else if (block instanceof class_2344 || block instanceof class_2369) {
            return getItemFromBlock(class_2246.field_10566);
        } else if (block instanceof class_2358) {
            return class_1802.field_8884;
        } else if (block instanceof class_2362) {
            return class_1802.field_8074;
        } else if (block == class_2246.field_10108) {
            return class_1802.field_8648;
        } else {
            return getItemFromBlock(block);
        }
    }

    private static class_1792 getItemFromBlock(final class_2248 block) {
        return class_1792.method_7867(block);
    }

    /**
     * Mimics pick block.
     *
     * @param blockState the block and state we are creating an ItemStack for.
     * @return ItemStack fromt the BlockState.
     */
    public static class_1799 getItemStackFromBlockState(@NotNull final class_2680 blockState) {
        if (blockState.method_26204() instanceof IFluidBlock) {
            return FluidUtil.getFilledBucket(new FluidStack(((IFluidBlock) blockState.method_26204()).getFluid(), 1000));
        }
        final class_1792 item = getItem(blockState);
        if (item != class_1802.field_8162 && item != null) {
            if (item instanceof class_1747 blockItem) {
                class_2248 block = blockItem.method_7711();
                try {
                    return block.method_9574(null, null, blockState);
                } catch (Exception e) {
                }
            }
            return new class_1799(item, 1);
        }

        return new class_1799(blockState.method_26204(), 1);
    }

    public static boolean support(int primaryStateId, class_1921 renderType) {
        class_2680 blockState = ModUtil.getStateById(primaryStateId);
        return RenderTypeUtils.canRenderInLayer(blockState, renderType);
    }

    @Nullable
    public static VoxelBlob rotate(final VoxelBlob blob, final class_2350.class_2351 axis, final class_2470 rotation) {
        switch (rotation) {
            case field_11463:
                return blob.spin(axis).spin(axis).spin(axis);
            case field_11464:
                return blob.spin(axis).spin(axis);
            case field_11465:
                return blob.spin(axis);
            case field_11467:
            default:
                break;
        }
        return null;
    }

    public static boolean isNormalCube(final class_2680 blockType, final class_1922 reader, final class_2338 pos) {
        return blockType.method_26212(reader, pos);
    }

    public static boolean isNormalCube(final class_2680 blockState) {
        return isNormalCube(blockState, new SingleBlockBlockReader(blockState, blockState.method_26204()), class_2338.field_10980);
    }

    public static class_2350 getSide(final class_1799 stack) {
        if (stack != null) {
            final class_2487 blueprintTag = stack.method_7969();

            int byteValue = class_2350.field_11043.ordinal();

            if (blueprintTag == null) {
                return class_2350.field_11043;
            }

            if (blueprintTag.method_10545(NBT_SIDE)) {
                byteValue = blueprintTag.method_10571(NBT_SIDE);
            }

            if (blueprintTag.method_10545(NBT_BLOCKENTITYTAG)) {
                final class_2487 c = blueprintTag.method_10562(NBT_BLOCKENTITYTAG);
                if (c.method_10545(NBT_SIDE)) {
                    byteValue = c.method_10571(NBT_SIDE);
                }
            }

            class_2350 side = class_2350.field_11043;

            if (byteValue >= 0 && byteValue < class_2350.values().length) {
                side = class_2350.values()[byteValue];
            }

            if (side == class_2350.field_11033 || side == class_2350.field_11036) {
                side = class_2350.field_11043;
            }

            return side;
        }

        return class_2350.field_11043;
    }

    public static void setSide(final class_1799 stack, final class_2350 side) {
        if (stack != null) {
            class_2487 blueprintTag = stack.method_7969();

            if (blueprintTag == null) {
                blueprintTag = new class_2487();
            }
            if (blueprintTag.method_10545(NBT_BLOCKENTITYTAG)) {
                blueprintTag.method_10562(NBT_BLOCKENTITYTAG).method_10567(NBT_SIDE, (byte) +side.ordinal());
            }

            blueprintTag.method_10569(NBT_SIDE, +side.ordinal());

            stack.method_7980(blueprintTag);
        }
    }

    public static class_2680 getStateById(final int blockStateID) {
        return IDRelay.getStateById(blockStateID);
    }

    public static int getStateId(final class_2680 state) {
        return Math.max(0, IDRelay.getStateId(state));
    }

    public static void cacheFastStates() {
        if (!ChiselsAndBits.getConfig().getServer().lowMemoryMode.get()) {
            // cache id -> state table as an array for faster rendering lookups.
            IDRelay = new CachedStateLookup();
        }
    }

    public static int getStackSize(final class_1799 stack) {
        return stack == null ? 0 : stack.method_7947();
    }

    public static void setStackSize(final @Nonnull class_1799 stack, final int stackSize) {
        stack.method_7939(stackSize);
    }

    public static void adjustStackSize(final @Nonnull class_1799 is, final int sizeDelta) {
        setStackSize(is, getStackSize(is) + sizeDelta);
    }

    public static class_2487 getSubCompound(final class_1799 stack, final String tag, final boolean create) {
        if (create) {
            if (!stack.method_7948().method_10545(tag)) {
                Objects.requireNonNull(stack.method_7969()).method_10566(tag, new class_2487());
            }
        }

        return stack.method_7948().method_10562(tag);
    }

    public static @Nonnull class_1799 getEmptyStack() {
        return class_1799.field_8037;
    }

    public static boolean notEmpty(final class_1799 itemStack) {
        return itemStack != null && !itemStack.method_7960();
    }

    public static boolean isEmpty(final class_1799 itemStack) {
        return itemStack == null || itemStack.method_7960();
    }

    public static @Nonnull class_2487 getTagCompound(final class_1799 ei) {
        return ei.method_7948();
    }

    @SuppressWarnings("deprecation")
    public static class_2680 getStateFromItem(final class_1799 is) {
        try {
            if (!ModUtil.isEmpty(is) && is.method_7909() instanceof class_1747 iblk) {
                final class_2680 state = iblk.method_7711().method_9564();

                return state;
            }
        } catch (final Throwable t) {
            // : (
        }

        return class_2246.field_10124.method_9564();
    }

    public static void damageItem(@Nonnull final class_1799 is, @Nonnull final class_5819 r) {
        if (is.method_7963()) {
            if (is.method_7970(1, r, null)) {
                is.method_7934(1);
                is.method_7974(0);
            }
        }
    }

    @Nonnull
    public static class_1799 makeStack(final class_1792 item) {
        return makeStack(item, 1);
    }

    @Nonnull
    public static class_1799 makeStack(final class_1792 item, final int stackSize) {
        return new class_1799(item, stackSize);
    }

    public static boolean isEmpty(final class_1792 item) {
        return item == class_1802.field_8162;
    }
}
