package mod.chiselsandbits.helpers;

import mod.chiselsandbits.api.APIExceptions.CannotBeChiseled;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.api.BitAccess;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class VoxelRegionSrc implements IVoxelSrc {

    final class_2338 min;
    final class_2338 max;
    final class_2338 actingCenter;

    final int wrapZ;
    final int wrapY;
    final int wrapX;

    final VoxelBlob[] blobs;

    private VoxelRegionSrc(final class_1937 src, final class_2338 min, final class_2338 max, final class_2338 actingCenter) {
        this.min = min;
        this.max = max;
        this.actingCenter = actingCenter.method_10059(min);

        wrapX = max.method_10263() - min.method_10263() + 1;
        wrapY = max.method_10264() - min.method_10264() + 1;
        wrapZ = max.method_10260() - min.method_10260() + 1;

        blobs = new VoxelBlob[wrapX * wrapY * wrapZ];

        for (int x = min.method_10263(); x <= max.method_10263(); ++x) {
            for (int y = min.method_10264(); y <= max.method_10264(); ++y) {
                for (int z = min.method_10260(); z <= max.method_10260(); ++z) {
                    final int idx = x - min.method_10263() + (y - min.method_10264()) * wrapX + (z - min.method_10260()) * wrapX * wrapY;

                    try {
                        final BitAccess access =
                                (BitAccess) ChiselsAndBits.getApi().getBitAccess(src, new class_2338(x, y, z));
                        blobs[idx] = access.getNativeBlob();
                    } catch (final CannotBeChiseled e) {
                        blobs[idx] = new VoxelBlob();
                    }
                }
            }
        }
    }

    public VoxelRegionSrc(final class_1937 theWorld, final class_2338 blockPos, final int range) {
        this(theWorld, blockPos.method_10069(-range, -range, -range), blockPos.method_10069(range, range, range), blockPos);
    }

    @Override
    public int getSafe(int x, int y, int z) {
        x += actingCenter.method_10263() * VoxelBlob.dim;
        y += actingCenter.method_10264() * VoxelBlob.dim;
        z += actingCenter.method_10260() * VoxelBlob.dim;

        final int bitPosX = x & 0xf;
        final int bitPosY = y & 0xf;
        final int bitPosZ = z & 0xf;

        final int blkPosX = x >> 4;
        final int blkPosY = y >> 4;
        final int blkPosZ = z >> 4;

        final int idx = blkPosX + blkPosY * wrapX + blkPosZ * wrapX * wrapY;

        if (blkPosX < 0 || blkPosY < 0 || blkPosZ < 0 || blkPosX >= wrapX || blkPosY >= wrapY || blkPosZ >= wrapZ) {
            return 0;
        }

        return blobs[idx].get(bitPosX, bitPosY, bitPosZ);
    }

    public VoxelBlob getBlobAt(final class_2338 blockPos) {
        final int blkPosX = blockPos.method_10263() - min.method_10263();
        final int blkPosY = blockPos.method_10264() - min.method_10264();
        final int blkPosZ = blockPos.method_10260() - min.method_10260();

        final int idx = blkPosX + blkPosY * wrapX + blkPosZ * wrapX * wrapY;

        if (blkPosX < 0 || blkPosY < 0 || blkPosZ < 0 || blkPosX >= wrapX || blkPosY >= wrapY || blkPosZ >= wrapZ) {
            return new VoxelBlob();
        }

        return blobs[idx];
    }
}
