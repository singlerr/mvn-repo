package mod.chiselsandbits.helpers;

import net.minecraft.class_1263;
import net.minecraft.class_1799;

public class InventoryBackup {

    class_1263 original;
    class_1799[] slots;

    public InventoryBackup(final class_1263 inventory) {
        original = inventory;
        slots = new class_1799[original.method_5439()];

        for (int x = 0; x < slots.length; ++x) {
            slots[x] = original.method_5438(x);

            if (slots[x] != null) {
                slots[x] = slots[x].method_7972();
            }
        }
    }

    public void rollback() {
        for (int x = 0; x < slots.length; ++x) {
            original.method_5447(x, slots[x]);
        }
    }
}
