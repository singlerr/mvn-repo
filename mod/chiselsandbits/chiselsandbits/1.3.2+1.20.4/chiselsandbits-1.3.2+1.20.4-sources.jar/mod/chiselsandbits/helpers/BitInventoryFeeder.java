package mod.chiselsandbits.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.events.extra.EntityItemPickupEvent;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemBitBag.BagPos;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class BitInventoryFeeder {
    private static final Random itemRand = new Random();
    final class_1657 player;
    final class_1937 world;
    ArrayList<Integer> seenBits = new ArrayList<>();
    boolean hasSentMessage = false;

    public BitInventoryFeeder(final class_1657 p, final class_1937 w) {
        player = p;
        world = w;
    }

    private static void spawnItem(class_1937 world, class_1542 ei) {
        if (world.field_9236) // no spawning items on the client.
        {
            return;
        }

        world.method_8649(ei);
    }

    public void addItem(final class_1542 ei) {
        class_1799 is = ModUtil.nonNull(ei.method_6983());

        final List<BagPos> bags = ItemBitBag.getBags(player.field_7514);

        if (!ModUtil.containsAtLeastOneOf(player.field_7514, is)) {
            final class_1799 minSize = is.method_7972();

            if (ModUtil.getStackSize(minSize) > minSize.method_7914()) {
                ModUtil.setStackSize(minSize, minSize.method_7914());
            }

            ModUtil.adjustStackSize(is, -ModUtil.getStackSize(minSize));
            player.field_7514.method_7394(minSize);
            ModUtil.adjustStackSize(is, ModUtil.getStackSize(minSize));
        }

        for (final BagPos bp : bags) {
            is = bp.inv.insertItem(is);
        }

        if (ModUtil.isEmpty(is)) {
            return;
        }

        ei.method_6979(is);
        boolean result = EntityItemPickupEvent.EVENT.invoker().handle(ei, player);
        if (result) {
            // cancelled...
            spawnItem(world, ei);
        } else {

            is = ei.method_6983();

            if (is != null && !player.field_7514.method_7394(is)) {
                ei.method_6979(is);
                // Never spawn the items for dropped excess items if setting is enabled.
                if (!ChiselsAndBits.getConfig().getServer().voidExcessBits.get()) {
                    spawnItem(world, ei);
                }
            } else {
                if (!ei.method_5701()) {
                    ei.field_6002.method_43128(
                            null,
                            ei.method_23317(),
                            ei.method_23318(),
                            ei.method_23321(),
                            class_3417.field_15197,
                            class_3419.field_15248,
                            0.2F,
                            ((itemRand.nextFloat() - itemRand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                }
            }

            player.field_7514.method_5431();

            if (player.field_7498 != null) {
                player.field_7498.method_7623();
            }
        }

        final int blk = ItemChiseledBit.getStackState(is);
        if (ChiselsAndBits.getConfig().getServer().voidExcessBits.get() && !seenBits.contains(blk) && !hasSentMessage) {
            if (!ItemChiseledBit.hasBitSpace(player, blk)) {
                player.method_43496(class_2561.method_43471("mod.chiselsandbits.result.void_excess"));
                hasSentMessage = true;
            }
            if (!seenBits.contains(blk)) {
                seenBits.add(blk);
            }
        }
    }
}
