package mod.chiselsandbits.helpers;

import java.util.Arrays;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;

public class PlayerCopiedInventory implements class_1263 {

    private class_1661 logicBase;
    private class_1799[] slots;

    public PlayerCopiedInventory(class_1661 original) {
        logicBase = original;
        slots = new class_1799[original.method_5439()];

        for (int x = 0; x < slots.length; ++x) {
            slots[x] = original.method_5438(x);

            if (slots[x] != null) {
                slots[x] = slots[x].method_7972();
            }
        }
    }

    @Override
    public boolean method_5442() {
        return Arrays.stream(slots).allMatch(class_1799::method_7960);
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return true;
    }

    @Override
    public int method_5439() {
        return slots.length;
    }

    @Override
    public class_1799 method_5438(final int index) {
        return slots[index];
    }

    @Override
    public class_1799 method_5434(final int index, final int count) {
        if (slots[index] != null) {
            if (ModUtil.getStackSize(slots[index]) <= count) {
                return method_5441(index);
            } else {
                return slots[index].method_7971(count);
            }
        }

        return ModUtil.getEmptyStack();
    }

    @Override
    public class_1799 method_5441(final int index) {
        final class_1799 r = slots[index];
        slots[index] = ModUtil.getEmptyStack();
        return r;
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {
        slots[index] = stack;
    }

    @Override
    public void method_5431() {}

    @Override
    public boolean method_5437(final int index, final class_1799 stack) {
        return logicBase.method_5437(index, stack);
    }

    @Override
    public void method_5448() {
        for (int x = 0; x < slots.length; ++x) {
            slots[x] = ModUtil.getEmptyStack();
        }
    }
}
