package mod.chiselsandbits.helpers;

import com.communi.suggestu.saecularia.caudices.core.block.IBlockWithWorldlyProperties;
import mod.chiselsandbits.utils.EnvExecutor;
import mod.chiselsandbits.utils.LanguageHandler;
import mod.chiselsandbits.utils.SingleBlockBlockReader;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2477;
import net.minecraft.class_2498;
import net.minecraft.class_2680;

@SuppressWarnings("deprecation")
public class DeprecationHelper {

    public static int getLightValue(final class_2680 state) {
        if (state.method_26204() instanceof IBlockWithWorldlyProperties prop) {
            return prop.getLightEmission(state, new SingleBlockBlockReader(state, state.method_26204()), class_2338.field_10980);
        }
        return state.method_26213();
    }

    public static class_2680 getStateFromItem(final class_1799 bitItemStack) {
        if (bitItemStack != null && bitItemStack.method_7909() instanceof class_1747 blkItem) {
            return blkItem.method_7711().method_9564();
        }

        return null;
    }

    public static String translateToLocal(final String string) {
        return EnvExecutor.unsafeRunForDist(
                () -> () -> {
                    final String translated = class_2477.method_10517().method_48307(string);
                    if (translated.equals(string)) {
                        return LanguageHandler.translateKey(string);
                    }

                    return translated;
                },
                () -> () -> LanguageHandler.translateKey(string));
    }

    public static String translateToLocal(final String string, final Object... args) {
        return String.format(translateToLocal(string), args);
    }

    public static class_2498 getSoundType(class_2680 block) {
        return block.method_26204().field_23162;
    }

    public static class_2498 getSoundType(class_2248 block) {
        return block.field_23162;
    }
}
