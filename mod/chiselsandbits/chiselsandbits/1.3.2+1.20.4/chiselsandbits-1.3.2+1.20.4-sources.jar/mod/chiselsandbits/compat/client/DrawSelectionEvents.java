package mod.chiselsandbits.compat.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_239;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;

/**
 * Events called when rendering outlines. For both, return true to cancel further processing.
 */
public interface DrawSelectionEvents {
    Event<Block> BLOCK = EventFactory.createArrayBacked(
            Block.class, callbacks -> (context, info, target, partialTicks, matrix, buffers) -> {
                for (Block e : callbacks) {
                    if (e.onHighlightBlock(context, info, target, partialTicks, matrix, buffers)) {
                        return true;
                    }
                }
                return false;
            });

    Event<Entity> ENTITY = EventFactory.createArrayBacked(
            Entity.class, callbacks -> (context, info, target, partialTicks, matrix, buffers) -> {
                for (Entity e : callbacks) {
                    if (e.onHighlightEntity(context, info, target, partialTicks, matrix, buffers)) {
                        return true;
                    }
                }
                return false;
            });

    @FunctionalInterface
    interface Block {
        boolean onHighlightBlock(
                class_761 context,
                class_4184 info,
                class_239 target,
                float partialTicks,
                class_4587 matrix,
                class_4597 buffers);
    }

    @FunctionalInterface
    interface Entity {
        boolean onHighlightEntity(
                class_761 context,
                class_4184 info,
                class_239 target,
                float partialTicks,
                class_4587 matrix,
                class_4597 buffers);
    }
}
