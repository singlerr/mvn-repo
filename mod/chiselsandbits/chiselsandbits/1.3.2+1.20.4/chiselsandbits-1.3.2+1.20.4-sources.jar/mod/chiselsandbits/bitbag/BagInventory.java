package mod.chiselsandbits.bitbag;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import javax.annotation.Nonnull;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraftforge.items.CapabilityItemHandler;

public class BagInventory implements class_1263 {

    // internal storage, the capability.
    BagStorage inv;

    // tmp storage, the IInventory
    class_1799[] stackSlots;

    public BagInventory(final class_1799 is) {
        inv = CapabilityItemHandler.ITEM_HANDLER_CAPABILITY != null
                ? (BagStorage) is.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null)
                        .orElseThrow(() -> new IllegalStateException("Failed to get IItemHandler from Bag!"))
                : null;
        stackSlots = new class_1799[BagStorage.BAG_STORAGE_SLOTS];

        // the cap is missing? then just make and load it ourselves.
        if (inv == null) {
            inv = new BagStorage();
            inv.stack = is;
            inv.setStorage(BagCapabilityProvider.getStorageArray(
                    is, BagStorage.BAG_STORAGE_SLOTS * ItemBitBag.INTS_PER_BIT_TYPE));
        }

        for (int x = 0; x < stackSlots.length; ++x) {
            stackSlots[x] = ModUtil.getEmptyStack();
        }
    }

    public class_1799 getItemStack() {
        return inv.stack;
    }

    @Override
    public int method_5439() {
        return stackSlots.length;
    }

    private int getStateInSlot(int index) {
        final int qty = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY];
        final int id = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_STATE_ID];

        if (qty > 0) {
            return id;
        }

        return 0;
    }

    @Override
    public @Nonnull class_1799 method_5438(final int index) {
        final int qty = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY];
        final int id = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_STATE_ID];

        if (ModUtil.notEmpty(stackSlots[index])) {
            final class_1799 which = ModUtil.nonNull(stackSlots[index]);
            ModUtil.setStackSize(which, qty);
            return which;
        }

        if (qty == 0 || id == 0) {
            return ModUtil.getEmptyStack();
        }

        return stackSlots[index] = ItemChiseledBit.createStack(id, qty, false);
    }

    @Override
    public class_1799 method_5434(final int index, int count) {
        final int qty = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY];
        final int id = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_STATE_ID];

        if (qty == 0 || id == 0) {
            return ModUtil.getEmptyStack();
        }

        if (count > qty) {
            count = qty;
        }

        inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY] -= count;
        inv.onChange();

        if (ModUtil.notEmpty(stackSlots[index])) {
            ModUtil.adjustStackSize(ModUtil.nonNull(stackSlots[index]), -count);
        }

        return ItemChiseledBit.createStack(id, count, false);
    }

    @Override
    public class_1799 method_5441(final int index) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {
        stackSlots[index] = ModUtil.getEmptyStack();

        if (stack != null && stack.method_7909() instanceof ItemChiseledBit) {
            inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY] =
                    ModUtil.getStackSize(stack);
            inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_STATE_ID] =
                    ItemChiseledBit.getStackState(stack);
        } else {
            inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY] = 0;
            inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_STATE_ID] = 0;
        }

        inv.onChange();
    }

    @Override
    public int method_5444() {
        return ChiselsAndBits.getConfig().getServer().bagStackSize.get();
    }

    @Override
    public void method_5431() {
        for (int x = 0; x < method_5439(); x++) {
            if (ModUtil.notEmpty(stackSlots[x])) {
                inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * x + ItemBitBag.OFFSET_QUANTITY] =
                        ModUtil.getStackSize(stackSlots[x]);
                stackSlots[x] = ModUtil.getEmptyStack();
                inv.onChange();
            }
        }
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return true;
    }

    @Override
    public void method_5435(final class_1657 player) {}

    @Override
    public void method_5432(final class_1657 player) {}

    @Override
    public boolean method_5437(final int index, final class_1799 stack) {
        return stack != null && stack.method_7909() instanceof ItemChiseledBit;
    }

    public void sort() {
        List<StateQtyPair> stacks = new ArrayList<StateQtyPair>();

        for (int x = 0; x < stackSlots.length; ++x) {
            int state = inv.contents[x * ItemBitBag.INTS_PER_BIT_TYPE + ItemBitBag.OFFSET_STATE_ID];
            int qty = inv.contents[x * ItemBitBag.INTS_PER_BIT_TYPE + ItemBitBag.OFFSET_QUANTITY];

            if (state > 0 && qty > 0) {
                stacks.add(new StateQtyPair(state, qty));
            }
        }

        stacks.sort(new Comparator<StateQtyPair>() {

            @Override
            public int compare(StateQtyPair o1, StateQtyPair o2) {
                if (o1.state < o2.state) {
                    return 1;
                }

                if (o1.state > o2.state) {
                    return -1;
                }

                if (o1.qty < o2.qty) {
                    return 1;
                }

                if (o1.qty > o2.qty) {
                    return -1;
                }

                return 0;
            }
        });

        for (int x = 0; x < stacks.size() - 1; x++) {
            StateQtyPair a = stacks.get(x);
            StateQtyPair b = stacks.get(x + 1);

            if (a.state == b.state) {
                if (a.qty < method_5444()) {
                    int shiftSize = method_5444() - a.qty;
                    shiftSize = Math.min(shiftSize, b.qty);

                    a.qty += shiftSize;
                    b.qty -= shiftSize;

                    if (b.qty <= 0) {
                        stacks.remove(x + 1);
                    }

                    --x;
                }
            }
        }

        for (int x = 0; x < stackSlots.length; ++x) {
            int state = 0;
            int qty = 0;

            if (stacks.size() > x) {
                state = stacks.get(x).state;
                qty = stacks.get(x).qty;
            }

            inv.contents[x * ItemBitBag.INTS_PER_BIT_TYPE + ItemBitBag.OFFSET_STATE_ID] = state;
            inv.contents[x * ItemBitBag.INTS_PER_BIT_TYPE + ItemBitBag.OFFSET_QUANTITY] = qty;

            stackSlots[x] = ModUtil.getEmptyStack();
        }

        inv.onChange();
    }

    public void clear(final class_1799 stack) {
        for (int x = 0; x < stackSlots.length; ++x) {
            if (matches(stack, stackSlots[x])) {
                stackSlots[x] = ModUtil.getEmptyStack();
                inv.contents[x * ItemBitBag.INTS_PER_BIT_TYPE + ItemBitBag.OFFSET_STATE_ID] = 0;
                inv.contents[x * ItemBitBag.INTS_PER_BIT_TYPE + ItemBitBag.OFFSET_QUANTITY] = 0;
            }
        }

        inv.onChange();
    }

    public boolean matches(final class_1799 cmpStack, final class_1799 invStack) {
        if (ModUtil.isEmpty(cmpStack) || invStack == null) {
            return true;
        }

        return cmpStack.method_7909() == invStack.method_7909() && class_1799.method_31577(cmpStack, invStack);
    }

    public class_1799 restockItem(final class_1799 target, final class_1799 targetType) {
        int outSize = ModUtil.getStackSize(target);

        for (int x = method_5439() - 1; x >= 0; x--) {
            if (ItemChiseledBit.sameBit(targetType, getStateInSlot(x))) {
                final class_1799 is = method_5438(x);

                outSize += ModUtil.getStackSize(is);
                final int total = outSize;
                outSize = Math.min(is.method_7914(), outSize);
                final int overage = total - outSize;

                if (overage > 0) {
                    ModUtil.setStackSize(is, overage);
                } else {
                    method_5447(x, ModUtil.getEmptyStack());
                }

                method_5431();

                if (outSize == is.method_7914()) {
                    // done!
                    break;
                }
            }
        }

        final class_1799 out = ModUtil.copy(targetType);
        ModUtil.setStackSize(out, outSize);
        return out;
    }

    public @Nonnull class_1799 insertItem(final @Nonnull class_1799 which) {
        for (int x = 0; x < method_5439(); x++) {
            final class_1799 is = method_5438(x);
            if (!ModUtil.isEmpty(is) && ItemChiseledBit.getStackState(which) == ItemChiseledBit.getStackState(is)) {
                ModUtil.adjustStackSize(is, ModUtil.getStackSize(which));
                final int total = ModUtil.getStackSize(is);
                ModUtil.setStackSize(is, Math.min(method_5444(), ModUtil.getStackSize(is)));
                final int overage = total - ModUtil.getStackSize(is);
                if (overage > 0) {
                    ModUtil.setStackSize(which, overage);
                    method_5431();
                } else {
                    method_5431();
                    return ModUtil.getEmptyStack();
                }
            } else if (ModUtil.isEmpty(is)) {
                method_5447(x, which);
                method_5431();
                return ModUtil.getEmptyStack();
            }
        }

        return which;
    }

    public int extractBit(final int bitMeta, int total) {
        int used = 0;

        for (int index = stackSlots.length - 1; index >= 0; index--) {
            final int qty_idx = ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_QUANTITY;

            final int qty = inv.contents[qty_idx];
            final int id = inv.contents[ItemBitBag.INTS_PER_BIT_TYPE * index + ItemBitBag.OFFSET_STATE_ID];

            if (id == bitMeta && qty > 0) {
                inv.contents[qty_idx] -= total;

                if (inv.contents[qty_idx] < 0) {
                    inv.contents[qty_idx] = 0;
                }

                inv.onChange();

                final int diff = qty - inv.contents[qty_idx];
                used += diff;
                total -= diff;

                if (0 == total) {
                    return used;
                }
            }
        }

        return used;
    }

    @Environment(EnvType.CLIENT)
    public List<class_2561> listContents(final List<class_2561> details) {
        final TreeMap<String, Integer> contents = new TreeMap<>();

        for (int x = 0; x < method_5439(); x++) {
            final class_1799 is = method_5438(x);
            if (!ModUtil.isEmpty(is)) {
                final class_2680 state = ModUtil.getStateById(ItemChiseledBit.getStackState(is));
                if (state == null) {
                    continue;
                }

                final class_2561 name = ItemChiseledBit.getBitStateName(state);

                if (name != null) {
                    Integer count = contents.get(name.getString());
                    if (count == null) {
                        count = ModUtil.getStackSize(is);
                    } else {
                        count += ModUtil.getStackSize(is);
                    }

                    contents.put(name.getString(), count);
                }
            }
        }

        if (contents.isEmpty()) {
            details.add(class_2561.method_43470(LocalStrings.Empty.getLocal()));
        }

        final List<Entry<String, Integer>> list = new ArrayList<>();
        list.addAll(contents.entrySet());

        Collections.sort(list, (o1, o2) -> {
            final int y = o1.getValue();
            final int x = o2.getValue();

            return Integer.compare(x, y);
        });

        for (final Entry<String, Integer> e : list) {
            details.add(class_2561.method_43470(e.getValue().toString()).method_27693(" ").method_27693(e.getKey()));
        }

        return details;
    }

    @Override
    public void method_5448() {
        clear(null);
    }

    @Override
    public boolean method_5442() {
        for (final class_1799 itemstack : stackSlots) {
            if (!itemstack.method_7960()) {
                return false;
            }
        }

        return true;
    }

    private static class StateQtyPair {
        int qty;
        int state;

        public StateQtyPair(int state, int qty) {
            this.qty = qty;
            this.state = state;
        }
    }
}
