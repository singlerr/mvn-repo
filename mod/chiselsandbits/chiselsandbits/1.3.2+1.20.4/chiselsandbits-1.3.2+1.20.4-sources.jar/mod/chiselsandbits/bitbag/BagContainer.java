package mod.chiselsandbits.bitbag;

import java.util.ArrayList;
import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.helpers.NullInventory;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.network.packets.PacketBagGuiStack;
import mod.chiselsandbits.registry.ModContainerTypes;
import mod.chiselsandbits.registry.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public class BagContainer extends class_1703 {
    static final int OUTER_SLOT_SIZE = 18;
    public final List<class_1735> customSlots = new ArrayList<class_1735>();
    public final List<class_1799> customSlotsItems = new ArrayList<class_1799>();
    final class_1657 thePlayer;
    final TargetedInventory visibleInventory = new TargetedInventory();
    BagInventory bagInv;
    SlotReadonly bagSlot;

    public BagContainer(final int id, final class_1661 playerInventory) {
        super(ModContainerTypes.BAG_CONTAINER.get(), id);
        thePlayer = playerInventory.field_7546;

        final int playerInventoryOffset = (7 - 4) * OUTER_SLOT_SIZE;

        final class_1799 is = thePlayer.method_6047();
        setBag(is);

        for (int yOffset = 0; yOffset < 7; ++yOffset) {
            for (int xOffset = 0; xOffset < 9; ++xOffset) {
                addCustomSlot(new SlotBit(
                        visibleInventory,
                        xOffset + yOffset * 9,
                        8 + xOffset * OUTER_SLOT_SIZE,
                        18 + yOffset * OUTER_SLOT_SIZE));
            }
        }

        for (int xPlayerInventory = 0; xPlayerInventory < 3; ++xPlayerInventory) {
            for (int yPlayerInventory = 0; yPlayerInventory < 9; ++yPlayerInventory) {
                method_7621(new class_1735(
                        thePlayer.field_7514,
                        yPlayerInventory + xPlayerInventory * 9 + 9,
                        8 + yPlayerInventory * OUTER_SLOT_SIZE,
                        104 + xPlayerInventory * OUTER_SLOT_SIZE + playerInventoryOffset));
            }
        }

        for (int xToolbar = 0; xToolbar < 9; ++xToolbar) {
            if (thePlayer.field_7514.field_7545 == xToolbar) {
                method_7621(
                        bagSlot = new SlotReadonly(
                                thePlayer.field_7514,
                                xToolbar,
                                8 + xToolbar * OUTER_SLOT_SIZE,
                                162 + playerInventoryOffset));
            } else {
                method_7621(new class_1735(
                        thePlayer.field_7514, xToolbar, 8 + xToolbar * OUTER_SLOT_SIZE, 162 + playerInventoryOffset));
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public static Object getGuiClass() {
        return BagGui.class;
    }

    private void addCustomSlot(final SlotBit newSlot) {
        newSlot.field_7874 = customSlots.size();
        customSlots.add(newSlot);
        customSlotsItems.add(ModUtil.getEmptyStack());
    }

    private void setBag(final class_1799 bagItem) {
        final class_1263 inv;

        if (ModUtil.notEmpty(bagItem) && bagItem.method_7909() instanceof ItemBitBag) {
            inv = bagInv = new BagInventory(bagItem);
        } else {
            bagInv = null;
            inv = new NullInventory(BagStorage.BAG_STORAGE_SLOTS);
        }

        visibleInventory.setInventory(inv);
    }

    @Override
    public boolean method_7597(final class_1657 playerIn) {
        return bagInv != null && playerIn == thePlayer && hasBagInHand(thePlayer);
    }

    private boolean hasBagInHand(final class_1657 player) {
        if (bagInv.getItemStack() != player.method_6047()) {
            setBag(player.method_6047());
        }

        return bagInv != null && bagInv.getItemStack().method_7909() instanceof ItemBitBag;
    }

    @Override
    public class_1799 method_7601(final class_1657 playerIn, final int index) {
        return transferStack(index, true);
    }

    private class_1799 transferStack(final int index, final boolean normalToBag) {
        class_1799 someReturnValue = ModUtil.getEmptyStack();
        boolean reverse = true;

        final TargetedTransferContainer helper = new TargetedTransferContainer();

        if (!normalToBag) {
            helper.field_7761.clear();
            helper.field_7761.addAll(customSlots);
        } else {
            helper.field_7761.clear();
            helper.field_7761.addAll(field_7761);
            reverse = false;
        }

        final class_1735 slot = helper.field_7761.get(index);

        if (slot != null && slot.method_7681()) {
            final class_1799 transferStack = slot.method_7677();
            someReturnValue = transferStack.method_7972();

            int extraItems = 0;
            if (ModUtil.getStackSize(transferStack) > transferStack.method_7914()) {
                extraItems = ModUtil.getStackSize(transferStack) - transferStack.method_7914();
                ModUtil.setStackSize(transferStack, transferStack.method_7914());
            }

            if (normalToBag) {
                helper.field_7761.clear();
                helper.field_7761.addAll(customSlots);
                ItemChiseledBit.bitBagStackLimitHack = true;
            } else {
                helper.field_7761.clear();
                helper.field_7761.addAll(field_7761);
            }

            try {
                if (!helper.doMergeItemStack(transferStack, 0, helper.field_7761.size(), reverse)) {
                    return ModUtil.getEmptyStack();
                }
            } finally {
                // add the extra items back on...
                ModUtil.adjustStackSize(transferStack, extraItems);
                ItemChiseledBit.bitBagStackLimitHack = false;
            }

            if (ModUtil.getStackSize(transferStack) == 0) {
                slot.method_7673(ModUtil.getEmptyStack());
            } else {
                slot.method_7668();
            }
        }

        return someReturnValue;
    }

    public void handleCustomSlotAction(
            final int slotNumber, final int mouseButton, final boolean duplicateButton, final boolean holdingShift) {
        final class_1735 slot = customSlots.get(slotNumber);
        final class_1799 held = method_34255();
        final class_1799 slotStack = slot.method_7677();

        if (duplicateButton && thePlayer.method_7337()) {
            if (slot.method_7681() && ModUtil.isEmpty(held)) {
                final class_1799 is = slot.method_7677().method_7972();
                ModUtil.setStackSize(is, is.method_7914());
                method_34254(is);
            }
        } else if (holdingShift) {
            if (slotStack != null) {
                transferStack(slotNumber, false);
            }
        } else if (mouseButton == 0 && !duplicateButton) {
            if (ModUtil.isEmpty(held) && slot.method_7681()) {
                final class_1799 pulled = ModUtil.copy(slotStack);
                ModUtil.setStackSize(pulled, Math.min(pulled.method_7914(), ModUtil.getStackSize(pulled)));

                final class_1799 newStackSlot = ModUtil.copy(slotStack);
                ModUtil.setStackSize(
                        newStackSlot,
                        ModUtil.getStackSize(pulled) >= ModUtil.getStackSize(slotStack)
                                ? 0
                                : ModUtil.getStackSize(slotStack) - ModUtil.getStackSize(pulled));

                slot.method_7673(ModUtil.getStackSize(newStackSlot) <= 0 ? ModUtil.getEmptyStack() : newStackSlot);
                method_34254(pulled);
            } else if (ModUtil.notEmpty(held) && slot.method_7681() && slot.method_7680(held)) {
                if (held.method_7909() == slotStack.method_7909()
                        && held.method_7919() == slotStack.method_7919()
                        && class_1799.method_31577(held, slotStack)) {
                    final class_1799 newStackSlot = ModUtil.copy(slotStack);
                    ModUtil.adjustStackSize(newStackSlot, ModUtil.getStackSize(held));
                    int held_stackSize = 0;

                    if (ModUtil.getStackSize(newStackSlot) > slot.method_7675()) {
                        held_stackSize = ModUtil.getStackSize(newStackSlot) - slot.method_7675();
                        ModUtil.adjustStackSize(newStackSlot, -held_stackSize);
                    }

                    slot.method_7673(newStackSlot);
                    ModUtil.setStackSize(held, held_stackSize);
                    method_34254(held);
                } else {
                    if (ModUtil.notEmpty(held)
                            && slot.method_7681()
                            && ModUtil.getStackSize(slotStack) <= slotStack.method_7914()) {
                        slot.method_7673(held);
                        method_34254(slotStack);
                    }
                }
            } else if (ModUtil.notEmpty(held) && !slot.method_7681() && slot.method_7680(held)) {
                slot.method_7673(held);
                method_34254(ModUtil.getEmptyStack());
            }
        } else if (mouseButton == 1 && !duplicateButton) {
            if (ModUtil.isEmpty(held) && slot.method_7681()) {
                final class_1799 pulled = ModUtil.copy(slotStack);
                ModUtil.setStackSize(
                        pulled,
                        Math.max(1, (Math.min(pulled.method_7914(), ModUtil.getStackSize(pulled)) + 1) / 2));

                final class_1799 newStackSlot = ModUtil.copy(slotStack);
                ModUtil.setStackSize(
                        newStackSlot,
                        ModUtil.getStackSize(pulled) >= ModUtil.getStackSize(slotStack)
                                ? 0
                                : ModUtil.getStackSize(slotStack) - ModUtil.getStackSize(pulled));

                slot.method_7673(ModUtil.getStackSize(newStackSlot) <= 0 ? ModUtil.getEmptyStack() : newStackSlot);
                method_34254(pulled);
            } else if (ModUtil.notEmpty(held) && slot.method_7681() && slot.method_7680(held)) {
                if (held.method_7909() == slotStack.method_7909()
                        && held.method_7919() == slotStack.method_7919()
                        && class_1799.method_7973(held, slotStack)) {
                    final class_1799 newStackSlot = ModUtil.copy(slotStack);
                    ModUtil.adjustStackSize(newStackSlot, 1);
                    int held_quantity = ModUtil.getStackSize(held) - 1;

                    if (ModUtil.getStackSize(newStackSlot) > slot.method_7675()) {
                        final int diff = ModUtil.getStackSize(newStackSlot) - slot.method_7675();
                        held_quantity += diff;
                        ModUtil.adjustStackSize(newStackSlot, -diff);
                    }

                    slot.method_7673(newStackSlot);
                    ModUtil.setStackSize(held, held_quantity);
                    method_34254(ModUtil.notEmpty(held) ? held : ModUtil.getEmptyStack());
                }
            } else if (ModUtil.notEmpty(held) && !slot.method_7681() && slot.method_7680(held)) {
                final class_1799 newStackSlot = ModUtil.copy(held);
                ModUtil.setStackSize(newStackSlot, 1);
                ModUtil.adjustStackSize(ModUtil.nonNull(held), -1);

                slot.method_7673(newStackSlot);
                method_34254(ModUtil.notEmpty(held) ? held : ModUtil.getEmptyStack());
            }
        }
    }

    @Override
    public void method_7623() {
        super.method_7623();

        for (int slotIdx = 0; slotIdx < customSlots.size(); ++slotIdx) {
            final class_1799 realStack = customSlots.get(slotIdx).method_7677();
            class_1799 clientstack = customSlotsItems.get(slotIdx);

            if (!class_1799.method_7973(clientstack, realStack)) {
                clientstack = ModUtil.isEmpty(realStack) ? ModUtil.getEmptyStack() : realStack.method_7972();
                customSlotsItems.set(slotIdx, clientstack);

                for (int crafterIndex = 0; crafterIndex < field_7765.size(); ++crafterIndex) {
                    final class_1712 cl = field_7765.get(crafterIndex);

                    if (cl instanceof class_3222) {
                        final PacketBagGuiStack pbgs = new PacketBagGuiStack(slotIdx, clientstack);
                        ChiselsAndBits.getNetworkChannel().sendToPlayer(pbgs, (class_3222) cl);
                    }
                }
            }
        }
    }

    public void clear(final class_1799 stack) {
        if (ModUtil.notEmpty(stack) && stack.method_7909() == ModItems.ITEM_BLOCK_BIT.get()) {
            if (bagInv.matches(stack, method_34255())) {
                method_34254(ModUtil.getEmptyStack());
            }
        }

        bagInv.clear(stack);
        method_34247(this);
    }

    public void sort() {
        bagInv.sort();
        method_34247(this);
    }
}
