package mod.chiselsandbits.bitbag;

import mod.chiselsandbits.items.ItemBitBag;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BagCapabilityProvider extends BagStorage implements ICapabilityProvider {

    private final LazyOptional<IItemHandler> capResult = LazyOptional.of(() -> this);

    public BagCapabilityProvider(final class_1799 stack, final class_2487 nbt) {
        this.stack = stack;
    }

    /**
     * Read NBT int array in and ensure its the proper size.
     *
     * @param stack
     * @param size
     * @return a usable int[] for the bag storage.
     */
    static int[] getStorageArray(final class_1799 stack, final int size) {
        int[] out = null;
        class_2487 compound = stack.method_7969();

        if (compound == null) {
            compound = new class_2487();
        }

        if (compound.method_10545("contents")) {
            out = compound.method_10561("contents");
        }

        if (out == null) {
            stack.method_7980(compound);
            out = new int[size];
            compound.method_10539("contents", out);
        }

        if (out.length != size && compound != null) {
            final int[] tmp = out;
            out = new int[size];
            System.arraycopy(out, 0, tmp, 0, Math.min(size, tmp.length));
            compound.method_10539("contents", out);
        }

        return out;
    }

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull final Capability<T> cap, @Nullable final class_2350 side) {
        if (cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            setStorage(getStorageArray(stack, BAG_STORAGE_SLOTS * ItemBitBag.INTS_PER_BIT_TYPE));
            return capResult.cast();
        }

        return LazyOptional.empty();
    }
}
