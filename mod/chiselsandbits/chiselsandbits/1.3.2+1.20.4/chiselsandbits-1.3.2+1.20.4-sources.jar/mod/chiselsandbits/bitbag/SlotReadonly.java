package mod.chiselsandbits.bitbag;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class SlotReadonly extends class_1735 {

    public SlotReadonly(final class_1263 inventoryIn, final int index, final int xPosition, final int yPosition) {
        super(inventoryIn, index, xPosition, yPosition);
    }

    @Override
    public boolean method_7680(final class_1799 stack) {
        return false;
    }

    @Override
    public boolean method_7674(final class_1657 playerIn) {
        return false;
    }
}
