package mod.chiselsandbits.bitbag;

import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class SlotBit extends class_1735 {

    public SlotBit(final class_1263 inventoryIn, final int index, final int xPosition, final int yPosition) {
        super(inventoryIn, index, xPosition, yPosition);
    }

    @Override
    public boolean method_7680(final class_1799 stack) {
        return ModUtil.notEmpty(stack) && stack.method_7909() instanceof ItemChiseledBit;
    }
}
