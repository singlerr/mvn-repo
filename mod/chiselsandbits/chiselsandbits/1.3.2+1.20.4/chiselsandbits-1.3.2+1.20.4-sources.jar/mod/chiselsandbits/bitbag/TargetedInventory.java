package mod.chiselsandbits.bitbag;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class TargetedInventory implements class_1263 {

    private class_1263 src;

    public TargetedInventory() {
        src = null;
    }

    public void setInventory(final class_1263 a) {
        src = a;
    }

    @Override
    public int method_5439() {
        return src.method_5439();
    }

    @Override
    public class_1799 method_5438(final int index) {
        return src.method_5438(index);
    }

    @Override
    public class_1799 method_5434(final int index, final int count) {
        return src.method_5434(index, count);
    }

    @Override
    public class_1799 method_5441(final int index) {
        return src.method_5441(index);
    }

    @Override
    public void method_5447(final int index, final class_1799 stack) {
        src.method_5447(index, stack);
    }

    @Override
    public int method_5444() {
        return src.method_5444();
    }

    @Override
    public void method_5431() {
        src.method_5431();
    }

    @Override
    public boolean method_5443(final class_1657 player) {
        return src.method_5443(player);
    }

    @Override
    public void method_5435(final class_1657 player) {
        src.method_5435(player);
    }

    @Override
    public void method_5432(final class_1657 player) {
        src.method_5432(player);
    }

    @Override
    public boolean method_5437(final int index, final class_1799 stack) {
        return src.method_5437(index, stack);
    }

    @Override
    public void method_5448() {
        src.method_5448();
    }

    @Override
    public boolean method_5442() {
        return src.method_5442();
    }

    public class_1263 getSrc() {
        return src;
    }
}
