package mod.chiselsandbits.bitbag;

import com.mojang.blaze3d.systems.RenderSystem;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.network.packets.PacketBagGui;
import mod.chiselsandbits.network.packets.PacketClearBagGui;
import mod.chiselsandbits.network.packets.PacketSortBagGui;
import mod.chiselsandbits.registry.ModItems;
import net.minecraft.class_1074;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import net.minecraft.class_7919;

public class BagGui extends class_465<BagContainer> {

    private static final class_2960 BAG_GUI_TEXTURE =
            new class_2960(ChiselsAndBits.MODID, "textures/gui/container/bitbag.png");

    private static GuiBagFontRenderer specialFontRenderer = null;
    boolean requireConfirm = true;
    boolean dontThrow = false;
    private GuiIconButton trashBtn;
    private GuiIconButton sortBtn;
    private class_1735 hoveredBitSlot = null;

    public BagGui(final BagContainer container, final class_1661 playerInventory, final class_2561 title) {
        super(container, playerInventory, title);
        field_2779 = 239;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        trashBtn = method_25429(new GuiIconButton(field_2776 - 18, field_2800, ClientSide.trashIcon, p_onPress_1_ -> {
            if (requireConfirm) {
                dontThrow = true;
                if (isValidBitItem()) {
                    requireConfirm = false;
                }
            } else {
                requireConfirm = true;
                // server side!
                ChiselsAndBits.getNetworkChannel().sendToServer(new PacketClearBagGui(getInHandItem()));
                dontThrow = false;
            }
        }));

        sortBtn = method_25429(new GuiIconButton(field_2776 - 18, field_2800 + 18, ClientSide.sortIcon, new class_4185.class_4241() {
            @Override
            public void onPress(final class_4185 p_onPress_1_) {
                ChiselsAndBits.getNetworkChannel().sendToServer(new PacketSortBagGui());
            }
        }));
    }

    BagContainer getBagContainer() {
        return field_2797;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float ticks) {
        method_25420(guiGraphics, mouseX, mouseY, ticks);
        if (trashBtn.method_25405(mouseX, mouseY)) {
            if (isValidBitItem()) {
                final String msgNotConfirm = ModUtil.notEmpty(getInHandItem())
                        ? LocalStrings.TrashItem.getLocal(
                                getInHandItem().method_7964().getString())
                        : LocalStrings.Trash.getLocal();
                final String msgConfirm = ModUtil.notEmpty(getInHandItem())
                        ? LocalStrings.ReallyTrashItem.getLocal(
                                getInHandItem().method_7964().getString())
                        : LocalStrings.ReallyTrash.getLocal();
                trashBtn.method_47400(class_7919.method_47407(class_2561.method_43470(requireConfirm ? msgNotConfirm : msgConfirm)));
            } else {
                trashBtn.method_47400(class_7919.method_47407(class_2561.method_43470(LocalStrings.TrashInvalidItem.getLocal(
                        getInHandItem().method_7964().getString()))));
            }
        }

        if (sortBtn.method_25405(mouseX, mouseY)) {
            sortBtn.method_47400(class_7919.method_47407(class_2561.method_43470(LocalStrings.Sort.getLocal())));
        }
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float f, int mouseX, int mouseY) {
        final int xOffset = (field_22789 - field_2792) / 2;
        final int yOffset = (field_22790 - field_2779) / 2;
        guiGraphics.method_51422(1f, 1f, 1f, 1f);

        guiGraphics.method_25302(BAG_GUI_TEXTURE, xOffset, yOffset, 0, 0, field_2792, field_2779);

        if (specialFontRenderer == null) {
            specialFontRenderer = new GuiBagFontRenderer(
                    field_22793, ChiselsAndBits.getConfig().getServer().bagStackSize.get());
        }
        class_4587 posestack = RenderSystem.getModelViewStack();
        posestack.method_22903();
        posestack.method_22904(this.field_2776, this.field_2800, 0.0D);
        hoveredBitSlot = null;
        guiGraphics.method_51448().method_22903();
        for (int slotIdx = 0; slotIdx < getBagContainer().customSlots.size(); ++slotIdx) {
            final class_1735 slot = getBagContainer().customSlots.get(slotIdx);

            final class_327 defaultFontRenderer = field_22793;

            try {
                field_22793 = specialFontRenderer;
                method_2385(guiGraphics, slot);
            } finally {
                field_22793 = defaultFontRenderer;
            }

            if (method_2387(slot, mouseX, mouseY) && slot.method_7682()) {
                final int xDisplayPos = this.field_2776 + slot.field_7873;
                final int yDisplayPos = this.field_2800 + slot.field_7872;
                hoveredBitSlot = slot;

                RenderSystem.disableDepthTest();
                RenderSystem.colorMask(true, true, true, false);
                final int INNER_SLOT_SIZE = 16;

                guiGraphics.method_25296(
                        xDisplayPos,
                        yDisplayPos,
                        xDisplayPos + INNER_SLOT_SIZE,
                        yDisplayPos + INNER_SLOT_SIZE,
                        -2130706433,
                        -2130706433);
                RenderSystem.colorMask(true, true, true, true);
                RenderSystem.enableDepthTest();
            }
        }
        posestack.method_22909();
        RenderSystem.applyModelViewMatrix();
        guiGraphics.method_51448().method_22909();
        if (!trashBtn.method_25405(mouseX, mouseY)) {
            requireConfirm = true;
        }
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        // This is what vanilla does...
        final boolean duplicateButton =
                button == class_310.method_1551().field_1690.field_1871.field_1655.method_1444() + 100;

        class_1735 slot = field_2787;
        if (slot == null) {
            slot = hoveredBitSlot;
        }
        if (slot != null && slot.field_7871 instanceof TargetedInventory) {
            final PacketBagGui bagGuiPacket =
                    new PacketBagGui(slot.field_7874, button, duplicateButton, ClientSide.instance.holdingShift());
            bagGuiPacket.doAction(ClientSide.instance.getPlayer());

            ChiselsAndBits.getNetworkChannel().sendToServer(bagGuiPacket);

            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    private class_1799 getInHandItem() {
        return getBagContainer().method_34255();
    }

    private boolean isValidBitItem() {
        return ModUtil.isEmpty(getInHandItem()) || getInHandItem().method_7909() == ModItems.ITEM_BLOCK_BIT.get();
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int x, int y) {

        guiGraphics.method_35720(
                field_22793,
                class_2477.method_10517()
                        .method_30934(ModItems.ITEM_BIT_BAG_DEFAULT.get().method_7864(ModUtil.getEmptyStack())),
                8,
                6,
                0x404040);
        guiGraphics.method_25303(field_22793, class_1074.method_4662("container.inventory"), 8, field_2779 - 93, 0x404040);
    }
}
