package mod.chiselsandbits.bitbag;

import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;

public class TargetedTransferContainer extends class_1703 {

    protected TargetedTransferContainer() {
        super(null, 0);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int i) {
        return null;
    }

    @Override
    public boolean method_7597(final class_1657 playerIn) {
        return true;
    }

    public boolean doMergeItemStack(
            final class_1799 stack, final int startIndex, final int endIndex, final boolean reverseDirection) {
        return method_7616(stack, startIndex, endIndex, reverseDirection);
    }
}
