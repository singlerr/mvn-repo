package mod.chiselsandbits.bitbag;

import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

public class GuiBagFontRenderer extends class_327 {
    class_327 talkto;

    int offsetX, offsetY;
    float scale;

    public GuiBagFontRenderer(final class_327 src, final int bagStackSize) {
        super(src.field_1997, false);
        talkto = src;

        if (bagStackSize < 100) {
            scale = 1f;
        } else if (bagStackSize >= 100) {
            scale = 0.75f;
            offsetX = 3;
            offsetY = 2;
        }
    }

    @Override
    public int method_1727(String text) {
        text = convertText(text);
        return talkto.method_1727(text);
    }

    @Override
    protected int method_27529(
            String text,
            float x,
            float y,
            int color,
            boolean dropShadow,
            Matrix4f matrix,
            class_4597 multiBufferSource,
            class_6415 displayMode,
            int j,
            int k,
            boolean bl2) {
        final class_4587 stack = new class_4587();
        final Matrix4f original = new Matrix4f(matrix);

        try {
            stack.method_23760().method_23761().mul(matrix);
            stack.method_22905(scale, scale, scale);

            x /= scale;
            y /= scale;
            x += offsetX;
            y += offsetY;

            return super.method_27529(text, x, y, color, dropShadow, matrix, multiBufferSource, displayMode, j, k, bl2);
        } finally {
            matrix.set(original);
        }
    }

    @Override
    public int method_27522(
            String text,
            float x,
            float y,
            int color,
            boolean dropShadow,
            Matrix4f matrix,
            class_4597 buffer,
            class_6415 displayMode,
            int colorBackgroundIn,
            int packedLight,
            boolean transparentIn) {
        final class_4587 stack = new class_4587();
        final Matrix4f original = new Matrix4f(matrix);

        try {
            stack.method_23760().method_23761().mul(matrix);
            stack.method_22905(scale, scale, scale);

            x /= scale;
            y /= scale;
            x += offsetX;
            y += offsetY;

            return super.method_27522(
                    text,
                    x,
                    y,
                    color,
                    dropShadow,
                    matrix,
                    buffer,
                    displayMode,
                    colorBackgroundIn,
                    packedLight,
                    transparentIn);
        } finally {
            matrix.set(original);
        }
    }

    //    @Override
    //    public int draw(PoseStack matrixStack, String text, float x, float y, int color)
    //    {
    //        try
    //        {
    //            text = convertText( text );
    //            matrixStack.pushPose();
    //            matrixStack.scale( scale, scale, scale );
    //
    //            x /= scale;
    //            y /= scale;
    //            x += offsetX;
    //            y += offsetY;
    //
    //            return talkto.draw(matrixStack, text, x, y, color );
    //        }
    //        finally
    //        {
    //            matrixStack.popPose();
    //        }
    //    }
    //
    //    @Override
    //    public int drawShadow(PoseStack matrixStack, String text, float x, float y, int color)
    //    {
    //        try
    //        {
    //            text = convertText( text );
    //            matrixStack.pushPose();
    //            matrixStack.scale( scale, scale, scale );
    //
    //            x /= scale;
    //            y /= scale;
    //            x += offsetX;
    //            y += offsetY;
    //
    //            return talkto.drawShadow(matrixStack, text, x, y, color );
    //        }
    //        finally
    //        {
    //            matrixStack.popPose();
    //        }
    //    }

    private String convertText(final String text) {
        try {
            final int value = Integer.parseInt(text);

            if (value >= 1000) {
                return value / 1000 + "k";
            }

            return text;
        } catch (final NumberFormatException e) {
            return text;
        }
    }
}
