package mod.chiselsandbits.bitbag;

import net.minecraft.class_1058;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class GuiIconButton extends class_4185 {
    class_1058 icon;

    public GuiIconButton(final int x, final int y, final class_1058 icon, class_4185.class_4241 pressedAction) {
        super(x, y, 18, 18, class_2561.method_43470(""), pressedAction, class_4185.field_40754);
        this.icon = icon;
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int i, int j, float f) {
        super.method_48579(guiGraphics, i, j, f);
        guiGraphics.method_51422(1f, 1f, 1f, 1f);
        guiGraphics.method_25298(field_22760 + 1, field_22761 + 1, 0, 16, 16, icon);
    }

    public interface OnToolTip {

        void onToolTip(double mouseX, double mouseY);
    }
}
