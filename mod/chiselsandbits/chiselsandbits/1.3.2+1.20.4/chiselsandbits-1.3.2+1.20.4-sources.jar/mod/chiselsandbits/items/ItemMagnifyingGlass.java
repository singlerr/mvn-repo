package mod.chiselsandbits.items;

import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.LocalStrings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class ItemMagnifyingGlass extends class_1792 {

    public ItemMagnifyingGlass(class_1793 properties) {
        super(properties.method_7889(1));
    }

    //	@Environment(EnvType.CLIENT)
    //    @Override
    //    public Component getHighlightTip(final ItemStack item, final Component displayName)
    //    {
    //        if (Minecraft.getInstance().hitResult == null)
    //            return displayName;
    //
    //        if (Minecraft.getInstance().hitResult.getType() != HitResult.Type.BLOCK)
    //            return displayName;
    //
    //        final BlockHitResult rayTraceResult = (BlockHitResult) Minecraft.getInstance().hitResult;
    //        final BlockState state = Minecraft.getInstance().level.getBlockState(rayTraceResult.getBlockPos());
    //        final BlockBitInfo.SupportsAnalysisResult result = BlockBitInfo.doSupportAnalysis(state);
    //        return new TextComponent(
    //          result.isSupported() ?
    //            ChatFormatting.GREEN + result.getSupportedReason().getLocal() + ChatFormatting.RESET :
    //            ChatFormatting.RED + result.getUnsupportedReason().getLocal() + ChatFormatting.RESET
    //        );
    //    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig().getCommon().helpText(LocalStrings.HelpMagnifyingGlass, tooltip);
    }
}
