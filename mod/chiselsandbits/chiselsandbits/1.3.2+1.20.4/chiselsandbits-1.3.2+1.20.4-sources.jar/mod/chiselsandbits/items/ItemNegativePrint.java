package mod.chiselsandbits.items;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.VoxelStats;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ActingPlayer;
import mod.chiselsandbits.helpers.BitInventoryFeeder;
import mod.chiselsandbits.helpers.ContinousChisels;
import mod.chiselsandbits.helpers.IContinuousInventory;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IItemScrollWheel;
import mod.chiselsandbits.interfaces.IPatternItem;
import mod.chiselsandbits.interfaces.IVoxelBlobItem;
import mod.chiselsandbits.network.packets.PacketRotateVoxelBlob;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.render.helpers.SimpleInstanceCache;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class ItemNegativePrint extends class_1792 implements IVoxelBlobItem, IItemScrollWheel, IPatternItem {

    // add info cached info
    SimpleInstanceCache<class_1799, List<class_2561>> toolTipCache = new SimpleInstanceCache<>(null, new ArrayList<>());

    public ItemNegativePrint(class_1792.class_1793 properties) {
        super(properties);
    }

    @Environment(EnvType.CLIENT)
    protected void defaultAddInfo(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        defaultAddInfo(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpNegativePrint,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904));

        if (isWritten(stack)) {
            if (ClientSide.instance.holdingShift()) {
                final List<class_2561> details = toolTipCache.getCached();

                if (toolTipCache.needsUpdate(stack)) {
                    details.clear();

                    final VoxelBlob blob = ModUtil.getBlobFromStack(stack, null);

                    final int solid = blob.filled();
                    final int air = blob.air();

                    if (solid > 0) {
                        details.add(class_2561.method_43470(Integer.valueOf(solid).toString())
                                .method_27693(" ")
                                .method_10852(class_2561.method_43470(LocalStrings.Filled.getLocal())));
                    }

                    if (air > 0) {
                        details.add(class_2561.method_43470(Integer.valueOf(air).toString())
                                .method_27693(" ")
                                .method_10852(class_2561.method_43470(LocalStrings.Empty.getLocal())));
                    }
                }

                tooltip.addAll(details);
            } else {
                tooltip.add(class_2561.method_43470(LocalStrings.ShiftDetails.getLocal()));
            }
        }
    }

    @Override
    public boolean isWritten(final class_1799 stack) {
        if (stack.method_7909() != getWrittenItem()) {
            return false;
        }

        if (stack.method_7985()) {
            final boolean a = ModUtil.getSubCompound(stack, ModUtil.NBT_BLOCKENTITYTAG, false)
                            .method_10546()
                    != 0;
            final boolean b = ModUtil.getTagCompound(stack).method_10545(NBTBlobConverter.NBT_LEGACY_VOXEL);
            final boolean c = ModUtil.getTagCompound(stack).method_10545(NBTBlobConverter.NBT_VERSIONED_VOXEL);
            return a || b || c;
        }
        return false;
    }

    protected class_1792 getWrittenItem() {
        return ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get();
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1657 player = context.method_8036();
        final class_1268 hand = context.method_20287();
        final class_1937 world = context.method_8045();
        final class_2338 pos = context.method_8037();
        final class_2350 side = context.method_8038();

        final class_1799 stack = player.method_5998(hand);
        final class_2680 blkstate = world.method_8320(pos);

        if (ItemChiseledBit.checkRequiredSpace(player, blkstate)) {
            return class_1269.field_5814;
        }

        if (!player.method_7343(pos, side, stack) || !world.method_8505(player, pos)) {
            return class_1269.field_5814;
        }

        if (!isWritten(stack)) {
            final class_2487 comp = getCompoundFromBlock(world, pos, player);
            if (comp != null) {
                final int count = stack.method_7947();
                stack.method_7934(count);

                final class_1799 newStack = new class_1799(this::getWrittenItem, count);
                newStack.method_7980(comp);

                class_1542 itementity = player.method_7328(newStack, false);
                if (itementity != null) {
                    itementity.method_6975();
                    itementity.method_6981(player);
                }
                return class_1269.field_5812;
            }

            return class_1269.field_5814;
        }

        final TileEntityBlockChiseled te = ModUtil.getChiseledTileEntity(world, pos, false);
        if (te != null) {
            // we can do this!
        } else if (!BlockChiseled.replaceWithChiseled(world, pos, blkstate, true)) {
            return class_1269.field_5814;
        }

        final TileEntityBlockChiseled tec = ModUtil.getChiseledTileEntity(world, pos, true);
        if (tec != null) {
            final VoxelBlob vb = tec.getBlob();

            final VoxelBlob pattern = ModUtil.getBlobFromStack(stack, player);

            applyPrint(stack, world, pos, side, vb, pattern, player, hand);

            tec.completeEditOperation(vb);
            return class_1269.field_5812;
        }

        return class_1269.field_5814;
    }

    protected boolean convertToStone() {
        return true;
    }

    protected class_2487 getCompoundFromBlock(final class_1937 world, final class_2338 pos, final class_1657 player) {

        final TileEntityBlockChiseled te = ModUtil.getChiseledTileEntity(world, pos, false);
        if (te != null) {
            final class_2487 comp = new class_2487();
            te.writeChiselData(comp);

            if (convertToStone()) {
                final TileEntityBlockChiseled tmp = new TileEntityBlockChiseled(pos, world.method_8320(pos));
                tmp.readChiselData(comp);

                final VoxelBlob bestBlob = tmp.getBlob();
                bestBlob.binaryReplacement(0, ModUtil.getStateId(class_2246.field_10340.method_9564()));

                tmp.setBlob(bestBlob);
                tmp.writeChiselData(comp);
            }

            comp.method_10567(ModUtil.NBT_SIDE, (byte) ModUtil.getPlaceFace(player).ordinal());
            return comp;
        }

        return null;
    }

    @Override
    public class_1799 getPatternedItem(final class_1799 stack, final boolean craftingBlocks) {
        if (!isWritten(stack)) {
            return null;
        }

        final class_2487 tag = ModUtil.getTagCompound(stack);

        // Detect and provide full blocks if pattern solid full and solid.
        final NBTBlobConverter conv = new NBTBlobConverter();
        conv.readChisleData(tag, VoxelBlob.VERSION_ANY);

        if (craftingBlocks
                && ChiselsAndBits.getConfig().getServer().fullBlockCrafting.get()) {
            final VoxelStats stats = conv.getBlob().getVoxelStats();
            if (stats.isFullBlock) {
                final class_2680 state = ModUtil.getStateById(stats.mostCommonState);
                final class_1799 is = ModUtil.getItemStackFromBlockState(state);

                if (!ModUtil.isEmpty(is)) {
                    return is;
                }
            }
        }

        final class_2680 state = conv.getPrimaryBlockState();
        final class_1799 itemstack = new class_1799(ModBlocks.getChiseledBlock(), 1);

        itemstack.method_7959(ModUtil.NBT_BLOCKENTITYTAG, tag);
        return itemstack;
    }

    protected void applyPrint(
            @Nonnull final class_1799 stack,
            @Nonnull final class_1937 world,
            @Nonnull final class_2338 pos,
            @Nonnull final class_2350 side,
            @Nonnull final VoxelBlob vb,
            @Nonnull final VoxelBlob pattern,
            @Nonnull final class_1657 who,
            @Nonnull final class_1268 hand) {
        // snag a tool...
        final ActingPlayer player = ActingPlayer.actingAs(who, hand);
        final IContinuousInventory selected = new ContinousChisels(player, pos, side);
        class_1799 spawnedItem = null;

        final List<class_1542> spawnlist = new ArrayList<class_1542>();

        for (int z = 0; z < vb.detail && selected.isValid(); z++) {
            for (int y = 0; y < vb.detail && selected.isValid(); y++) {
                for (int x = 0; x < vb.detail && selected.isValid(); x++) {
                    final int blkID = vb.get(x, y, z);
                    if (blkID != 0 && pattern.get(x, y, z) == 0) {
                        spawnedItem = ItemChisel.chiselBlock(
                                selected, player, vb, world, pos, side, x, y, z, spawnedItem, spawnlist);
                    }
                }
            }
        }

        BitInventoryFeeder feeder = new BitInventoryFeeder(who, world);
        for (final class_1542 ei : spawnlist) {
            feeder.addItem(ei);
        }
    }

    @Override
    public void scroll(final class_1657 player, final class_1799 stack, final int dwheel) {
        final PacketRotateVoxelBlob p =
                new PacketRotateVoxelBlob(class_2351.field_11052, dwheel > 0 ? class_2470.field_11463 : class_2470.field_11465);
        ChiselsAndBits.getNetworkChannel().sendToServer(p);
    }

    @Override
    public void rotate(final class_1799 stack, final class_2350.class_2351 axis, final class_2470 rotation) {
        class_2350 side = ModUtil.getSide(stack);

        if (axis == class_2351.field_11052) {
            if (side.method_10166() == class_2351.field_11052) {
                side = class_2350.field_11043;
            }

            switch (rotation) {
                case field_11464:
                    side = side.method_10170();
                case field_11463:
                    side = side.method_10170();
                    break;
                case field_11465:
                    side = side.method_10160();
                    break;
                default:
                case field_11467:
                    break;
            }
        } else {
            IBitAccess ba = ChiselsAndBits.getApi().createBitItem(stack);
            ba.rotate(axis, rotation);
            stack.method_7980(ba.getBitsAsItem(side, ChiselsAndBits.getApi().getItemType(stack), false)
                    .method_7969());
        }

        ModUtil.setSide(stack, side);
    }
}
