package mod.chiselsandbits.items;

import com.google.common.base.Stopwatch;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.ReplacementStateHandler;
import mod.chiselsandbits.bitstorage.BlockBitStorage;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.BlockChiseled.ReplaceWithChiseledValue;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.events.TickHandler;
import mod.chiselsandbits.helpers.ActingPlayer;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.ChiselModeManager;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.IContinuousInventory;
import mod.chiselsandbits.helpers.IItemInInventory;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.interfaces.IChiselModeItem;
import mod.chiselsandbits.interfaces.IItemScrollWheel;
import mod.chiselsandbits.items.ItemBitBag.BagPos;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.modes.IToolMode;
import mod.chiselsandbits.network.packets.PacketChisel;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.utils.FluidUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_239;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2497;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_310;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import org.apache.commons.lang3.tuple.Pair;

public class ItemChiseledBit extends class_1792 implements IItemScrollWheel, IChiselModeItem, ICacheClearable {

    private static final class_2371<class_1799> alternativeStacks = class_2371.method_10211();
    public static boolean bitBagStackLimitHack;
    private static Stopwatch timer;
    private ArrayList<class_1799> bits;

    //	public Component getHighlightTip(final ItemStack item, final Component displayName)
    //    {
    //        return EnvExecutor.unsafeRunForDist(() -> () -> {
    //            if ( ChiselsAndBits.getConfig().getClient().itemNameModeDisplay.get() && displayName instanceof
    // MutableComponent)
    //            {
    //                String extra = "";
    //                if ( getBitOperation( ClientSide.instance.getPlayer(), InteractionHand.MAIN_HAND, item ) ==
    // BitOperation.REPLACE )
    //                {
    //                    extra = " - " + LocalStrings.BitOptionReplace.getLocal();
    //                }
    //
    //                final MutableComponent comp = (MutableComponent) displayName;
    //
    //                return comp.append(" - ").append(Component.literal(ChiselModeManager.getChiselMode(
    // ClientSide.instance.getPlayer(), ChiselToolType.BIT, InteractionHand.MAIN_HAND
    // ).getName().getLocal())).append(new TextComponent(extra));
    //            }
    //
    //            return displayName;
    //        },
    //          () -> () -> displayName);
    //    }

    public ItemChiseledBit(class_1792.class_1793 properties) {
        super(properties);
        ChiselsAndBits.getInstance().addClearable(this);
    }

    public static class_2561 getBitStateName(final class_2680 state) {
        class_1799 target = null;
        class_2248 blk = null;

        if (state == null) {
            return class_2561.method_43470("Null");
        }

        try {
            // for an unknown reason its possible to generate mod blocks without
            // proper state here...
            blk = state.method_26204();

            final class_1792 item = class_1792.method_7867(blk);
            if (ModUtil.isEmpty(item)) {
                final class_3611 f = BlockBitInfo.getFluidFromBlock(blk);
                if (f != null) {
                    return class_2561.method_43471(FluidUtil.getTranslationKey(f));
                }
            } else {
                try {
                    target = state.method_26204().method_9574(null, null, state);
                } catch (Exception ex) {
                    target = new class_1799(() -> class_1792.method_7867(state.method_26204()), 1);
                }
            }
        } catch (final IllegalArgumentException e) {
            Log.logError("Unable to get Item Details for Bit.", e);
        }

        if (target == null || target.method_7909() == null) {
            return null;
        }

        try {
            final class_2561 myName = target.method_7964();
            if (!(myName instanceof class_5250 formattableName)) {
                return myName;
            }

            final Set<String> extra = new HashSet<String>();
            if (blk != null && state != null) {
                for (final class_2769<?> p : state.method_28501()) {
                    if (p.method_11899().equals("axis") || p.method_11899().equals("facing")) {
                        extra.add(DeprecationHelper.translateToLocal(
                                "mod.chiselsandbits.pretty." + p.method_11899() + "-" + state.method_11654(p)));
                    }
                }
            }

            if (extra.isEmpty()) {
                return myName;
            }

            for (final String x : extra) {
                formattableName.method_27693(" ").method_27693(x);
            }

            return formattableName;
        } catch (final Exception e) {
            return class_2561.method_43470("Error");
        }
    }

    public static class_2561 getBitTypeName(final class_1799 stack) {
        int stateID = ItemChiseledBit.getStackState(stack);
        if (stateID == 0) {
            // We are running an empty bit, for display purposes.
            // Lets loop:
            if (alternativeStacks.isEmpty()) {
                ModItems.ITEM_BLOCK_BIT.get().fillItemCategory(alternativeStacks);
            }

            stateID = ItemChiseledBit.getStackState(alternativeStacks.get(
                    (int) (TickHandler.getClientTicks() % ((alternativeStacks.size() * 20L)) / 20L)));

            if (stateID == 0) {
                alternativeStacks.clear();
            }
        }

        return getBitStateName(ModUtil.getStateById(stateID));
    }

    public static BitOperation getBitOperation(final class_1657 player, final class_1268 hand, final class_1799 stack) {
        return ReplacementStateHandler.getInstance().isReplacing() ? BitOperation.REPLACE : BitOperation.PLACE;
    }

    public static boolean sameBit(final class_1799 output, final int blk) {
        return output.method_7985() && getStackState(output) == blk;
    }

    public static @Nonnull class_1799 createStack(final int id, final int count, final boolean RequireStack) {
        final class_1799 out = new class_1799(ModItems.ITEM_BLOCK_BIT.get(), count);
        out.method_7959("id", class_2497.method_23247(id));
        return out;
    }

    public static int getStackState(final class_1799 inHand) {
        return inHand != null && inHand.method_7985()
                ? ModUtil.getTagCompound(inHand).method_10550("id")
                : 0;
    }

    public static boolean placeBit(
            final IContinuousInventory bits,
            final ActingPlayer player,
            final VoxelBlob vb,
            final int x,
            final int y,
            final int z) {
        if (vb.get(x, y, z) == 0) {
            final IItemInInventory slot = bits.getItem(0);
            final int stateID = ItemChiseledBit.getStackState(slot.getStack());

            if (slot.isValid()) {
                if (!player.isCreative()) {
                    if (bits.useItem(stateID)) {
                        vb.set(x, y, z, stateID);
                    }
                } else {
                    vb.set(x, y, z, stateID);
                }
            }

            return true;
        }

        return false;
    }

    public static boolean hasBitSpace(final class_1657 player, final int blk) {
        final List<BagPos> bags = ItemBitBag.getBags(player.field_7514);
        for (final BagPos bp : bags) {
            for (int x = 0; x < bp.inv.method_5439(); x++) {
                final class_1799 is = bp.inv.method_5438(x);
                if ((ItemChiseledBit.sameBit(is, blk) && ModUtil.getStackSize(is) < bp.inv.method_5444())
                        || ModUtil.isEmpty(is)) {
                    return true;
                }
            }
        }
        for (int x = 0; x < 36; x++) {
            final class_1799 is = player.field_7514.method_5438(x);
            if ((ItemChiseledBit.sameBit(is, blk) && ModUtil.getStackSize(is) < is.method_7914())
                    || ModUtil.isEmpty(is)) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkRequiredSpace(final class_1657 player, final class_2680 blkstate) {
        if (ChiselsAndBits.getConfig().getServer().requireBagSpace.get() && !player.method_7337()) {
            // Cycle every item in any bag, if the player can't store the clicked block then
            // send them a message.
            final int stateId = ModUtil.getStateId(blkstate);
            if (!ItemChiseledBit.hasBitSpace(player, stateId)) {
                if (player.method_5770().field_9236
                        && (timer == null || timer.elapsed(TimeUnit.MILLISECONDS) > 1000)) {
                    // Timer is client-sided so it doesn't have to be made player-specific
                    timer = Stopwatch.createStarted();
                    // Only client should handle messaging.
                    player.method_43496(class_2561.method_43471("mod.chiselsandbits.result.require_bag"));
                }
                return true;
            }
        }
        return false;
    }

    //    @Override
    //    public void fillItemCategory(final CreativeModeTab tab, final NonNullList<ItemStack> items)
    //    {
    //        if ( !this.allowdedIn( tab ) ) // is this my creative tab?
    //        {
    //            return;
    //        }
    //
    //        if ( bits == null )
    //        {
    //            bits = new ArrayList<ItemStack>();
    //
    //            final NonNullList<ItemStack> List = NonNullList.create();
    //            final BitSet used = new BitSet( 4096 );
    //
    //            for ( final Object obj : ForgeRegistries.ITEMS)
    //            {
    //                if ( !( obj instanceof BlockItem ) )
    //                {
    //                    continue;
    //                }
    //
    //                try
    //                {
    //                    Item it = (Item) obj;
    //                    final CreativeModeTab ctab = it.getItemCategory();
    //
    //                    if ( ctab != null )
    //                    {
    //                        it.fillItemCategory( ctab, List );
    //                    }
    //
    //                    for ( final ItemStack out : List )
    //                    {
    //                        it = out.getItem();
    //
    //                        if ( !( it instanceof BlockItem ) )
    //                        {
    //                            continue;
    //                        }
    //
    //                        final BlockState state = DeprecationHelper.getStateFromItem( out );
    //                        if ( state != null && BlockBitInfo.canChisel( state ) )
    //                        {
    //                            used.set( ModUtil.getStateId( state ) );
    //                            bits.add( ItemChiseledBit.createStack( ModUtil.getStateId( state ), 1, false ) );
    //                        }
    //                    }
    //
    //                }
    //                catch ( final Throwable t )
    //                {
    //                    // a mod did something that isn't acceptable, let them crash
    //                    // in their own code...
    //                }
    //
    //                List.clear();
    //            }
    //
    //            for ( final Fluid o : ForgeRegistries.FLUIDS )
    //            {
    //                if ( !o.defaultFluidState().isSource() )
    //                {
    //                    continue;
    //                }
    //
    //                bits.add( ItemChiseledBit.createStack( Block.getId( o.defaultFluidState().createLegacyBlock() ),
    // 1, false ) );
    //            }
    //        }
    //
    //        items.addAll( bits );
    //    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpBit,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1886),
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getModeKey());

        final int stateId = ItemChiseledBit.getStackState(stack);
        if (stateId == 0) {
            tooltip.add(class_2561.method_43470(class_124.field_1061.toString()
                    + class_124.field_1056
                    + LocalStrings.AnyHelpBit.getLocal()
                    + class_124.field_1070));
        }
    }

    @Override
    public class_2561 method_7864(final class_1799 stack) {
        final class_2561 typeName = getBitTypeName(stack);

        if (typeName == null) {
            return super.method_7864(stack);
        }

        final class_5250 strComponent = class_2561.method_43470("");
        return strComponent.method_10852(super.method_7864(stack)).method_27693(" - ").method_10852(typeName);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        if (!context.method_8045().field_9236) {
            return class_1269.field_5811;
        }

        final Pair<class_243, class_243> PlayerRay = ModUtil.getPlayerRay(context.method_8036());
        final class_243 ray_from = PlayerRay.getLeft();
        final class_243 ray_to = PlayerRay.getRight();
        final class_3959 rtc = new class_3959(
                ray_from, ray_to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, context.method_8036());

        final class_239 mop = context.method_8045().method_17742(rtc);
        if (mop != null) {
            final class_3965 rayTraceResult = (class_3965) mop;
            return onItemUseInternal(
                    context.method_8036(),
                    context.method_8045(),
                    context.method_8037(),
                    context.method_20287(),
                    rayTraceResult);
        }

        return class_1269.field_5814;
    }

    public class_1269 onItemUseInternal(
            final @Nonnull class_1657 player,
            final @Nonnull class_1937 world,
            final @Nonnull class_2338 usedBlock,
            final @Nonnull class_1268 hand,
            final @Nonnull class_3965 rayTraceResult) {
        final class_1799 stack = player.method_5998(hand);

        if (!player.method_7343(usedBlock, rayTraceResult.method_17780(), stack)) {
            return class_1269.field_5814;
        }

        // forward interactions to tank...
        final class_2680 usedState = world.method_8320(usedBlock);
        final class_2248 blk = usedState.method_26204();
        if (blk instanceof BlockBitStorage) {
            if (blk.method_9534(usedState, world, usedBlock, player, hand, rayTraceResult) == class_1269.field_5812) {
                return class_1269.field_5812;
            }
            return class_1269.field_5814;
        }

        if (world.field_9236) {
            final IToolMode mode =
                    ChiselModeManager.getChiselMode(player, ClientSide.instance.getHeldToolType(hand), hand);
            final BitLocation bitLocation = new BitLocation(rayTraceResult, getBitOperation(player, hand, stack));

            class_2680 blkstate = world.method_8320(bitLocation.blockPos);
            TileEntityBlockChiseled tebc = ModUtil.getChiseledTileEntity(world, bitLocation.blockPos, true);
            ReplaceWithChiseledValue rv = null;
            if (tebc == null
                    && (rv = BlockChiseled.replaceWithChiseled(
                                    world, bitLocation.blockPos, blkstate, ItemChiseledBit.getStackState(stack), true))
                            .success) {
                blkstate = world.method_8320(bitLocation.blockPos);
                tebc = rv.te;
            }

            if (tebc != null) {
                PacketChisel pc = null;
                if (mode == ChiselMode.DRAWN_REGION) {
                    if (world.field_9236) {
                        ClientSide.instance.pointAt(
                                getBitOperation(player, hand, stack).getToolType(), bitLocation, hand);
                    }
                    return class_1269.field_5814;
                } else {

                    pc = new PacketChisel(
                            getBitOperation(player, hand, stack),
                            bitLocation,
                            rayTraceResult.method_17780(),
                            ChiselMode.castMode(mode),
                            hand);
                }

                final int result = pc.doAction(player);

                if (result > 0) {
                    ClientSide.instance.setLastTool(ChiselToolType.BIT);
                    ChiselsAndBits.getNetworkChannel().sendToServer(pc);
                }
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public boolean method_7885(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player) {
        class_1799 itemStack = player.method_5998(player.method_6058());
        return ItemChisel.fromBreakToChisel(
                ChiselMode.castMode(
                        ChiselModeManager.getChiselMode(player, ChiselToolType.BIT, class_1268.field_5808)),
                itemStack,
                blockPos,
                player,
                class_1268.field_5808);
    }

    @Override
    public boolean method_7856(final class_2680 blk) {
        return blk.method_26204() instanceof BlockChiseled || super.method_7856(blk);
    }

    @Override
    public void clearCache() {
        bits = null;
    }

    public void fillItemCategory(class_2371<class_1799> output) {
        for (class_2248 block : class_7923.field_41175) {
            if (block instanceof BlockChiseled) {
                continue;
            }

            for (class_2680 possibleState : block.method_9595().method_11662()) {
                if (BlockBitInfo.canChisel(possibleState)) {
                    class_1799 itemStack = ItemChiseledBit.createStack(ModUtil.getStateId(possibleState), 1, true);
                    output.add(itemStack);
                }
            }

            class_2680 blockState = block.method_9564();

            if (block instanceof class_2404 liquidBlock) {
                class_3611 fluid = liquidBlock.method_9545(blockState).method_15772();
                if (fluid instanceof class_3609 flowingFluid) {
                    blockState = flowingFluid.method_15751().method_15785().method_15759();
                }
            }

            if (BlockBitInfo.canChisel(blockState)) {
                class_1799 itemStack = ItemChiseledBit.createStack(ModUtil.getStateId(blockState), 1, true);
                output.add(itemStack);
            }
        }
    }

    @Override
    public void scroll(final class_1657 player, final class_1799 stack, final int dwheel) {
        final IToolMode mode = ChiselModeManager.getChiselMode(player, ChiselToolType.BIT, class_1268.field_5808);
        ChiselModeManager.scrollOption(ChiselToolType.BIT, mode, mode, dwheel);
    }
}
