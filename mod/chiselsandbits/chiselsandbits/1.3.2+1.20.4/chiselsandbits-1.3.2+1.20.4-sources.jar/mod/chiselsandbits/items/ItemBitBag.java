package mod.chiselsandbits.items;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import mod.chiselsandbits.bitbag.BagCapabilityProvider;
import mod.chiselsandbits.bitbag.BagInventory;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.network.packets.PacketOpenBagGui;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.render.helpers.SimpleInstanceCache;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import org.jetbrains.annotations.Nullable;

public class ItemBitBag extends class_1792 {

    public static final int INTS_PER_BIT_TYPE = 2;
    public static final int OFFSET_STATE_ID = 0;
    public static final int OFFSET_QUANTITY = 1;

    SimpleInstanceCache<class_1799, List<class_2561>> tooltipCache = new SimpleInstanceCache<>(null, new ArrayList<>());

    public ItemBitBag(class_1792.class_1793 properties) {
        super(properties.method_7889(1));
    }

    public static void cleanupInventory(final class_1657 player, final class_1799 is) {
        if (is != null && is.method_7909() instanceof ItemChiseledBit) {
            // time to clean up your inventory...
            final class_1263 inv = player.field_7514;
            final List<ItemBitBag.BagPos> bags = ItemBitBag.getBags(inv);

            int firstSeen = -1;
            for (int slot = 0; slot < inv.method_5439(); slot++) {
                int actingSlot = slot;
                @Nonnull class_1799 which = ModUtil.nonNull(inv.method_5438(actingSlot));

                if (which != null
                        && which.method_7909() == is.method_7909()
                        && (ItemChiseledBit.sameBit(which, ItemChiseledBit.getStackState(is)))) {
                    if (actingSlot == player.field_7514.field_7545) {
                        if (firstSeen != -1) {
                            actingSlot = firstSeen;
                        } else {
                            continue;
                        }
                    }

                    which = ModUtil.nonNull(inv.method_5438(actingSlot));

                    if (firstSeen == -1) {
                        firstSeen = actingSlot;
                    } else {
                        for (final ItemBitBag.BagPos i : bags) {
                            which = i.inv.insertItem(which);
                            if (ModUtil.isEmpty(which)) {
                                inv.method_5447(actingSlot, which);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    public static List<BagPos> getBags(final class_1263 inv) {
        final ArrayList<BagPos> bags = new ArrayList<BagPos>();
        for (int x = 0; x < inv.method_5439(); x++) {
            final class_1799 which = inv.method_5438(x);
            if (which != null && which.method_7909() instanceof ItemBitBag) {
                bags.add(new BagPos(new BagInventory(which)));
            }
        }
        return bags;
    }

    public static class_1799 dyeBag(class_1799 bag, class_1767 color) {
        class_1799 copy = bag.method_7972();

        if (!copy.method_7985()) {
            copy.method_7980(new class_2487());
        }

        if (color == null && bag.method_7909() == ModItems.ITEM_BIT_BAG_DYED.get()) {
            final class_1799 unColoredStack = new class_1799(ModItems.ITEM_BIT_BAG_DEFAULT.get());
            unColoredStack.method_7980(copy.method_7969());
            unColoredStack.method_7969().method_10551("color");
            return unColoredStack;
        } else if (color != null) {
            class_1799 coloredStack = copy;
            if (coloredStack.method_7909() == ModItems.ITEM_BIT_BAG_DEFAULT.get()) {
                coloredStack = new class_1799(ModItems.ITEM_BIT_BAG_DYED.get());
                coloredStack.method_7980(copy.method_7969());
            }

            coloredStack.method_7969().method_10582("color", color.method_7792());
            return coloredStack;
        }

        return copy;
    }

    public static class_1767 getDyedColor(class_1799 stack) {
        if (stack.method_7909() != ModItems.ITEM_BIT_BAG_DYED.get()) {
            return null;
        }

        if (stack.method_7948().method_10545("color")) {
            String name = stack.method_7969().method_10558("color");
            for (class_1767 color : class_1767.values()) {
                if (name.equals(color.method_15434())) {
                    return color;
                }
            }
        }

        return null;
    }

    @Override
    public ICapabilityProvider initCapabilities(final class_1799 stack, final class_2487 nbt) {
        return new BagCapabilityProvider(stack, nbt);
    }

    @Override
    public class_2561 method_7864(final class_1799 stack) {
        class_1767 color = getDyedColor(stack);
        final class_2561 parent = super.method_7864(stack);
        if (parent instanceof class_5250 && color != null) {
            return ((class_5250) parent)
                    .method_27693(" - ")
                    .method_10852(class_2561.method_43471("chiselsandbits.color." + color.method_7792()));
        } else {
            return super.method_7864(stack);
        }
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(
            final class_1799 stack,
            @Nullable final class_1937 worldIn,
            final List<class_2561> tooltip,
            final class_1836 flagIn) {
        super.method_7851(stack, worldIn, tooltip, flagIn);
        ChiselsAndBits.getConfig().getCommon().helpText(LocalStrings.HelpBitBag, tooltip);

        if (tooltipCache.needsUpdate(stack)) {
            final BagInventory bi = new BagInventory(stack);
            tooltipCache.updateCachedValue(bi.listContents(new ArrayList<>()));
        }

        final List<class_2561> details = tooltipCache.getCached();
        if (details.size() <= 2 || ClientSide.instance.holdingShift()) {
            tooltip.addAll(details);
        } else {
            tooltip.add(class_2561.method_43470(LocalStrings.ShiftDetails.getLocal()));
        }
    }

    //    @Override
    //    public boolean showDurabilityBar(
    //      final ItemStack stack)
    //    {
    //        final Object o = stack.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
    //
    //        if (o instanceof BagStorage)
    //        {
    //            final int qty = ((BagStorage) o).getSlotsUsed();
    //            return qty != 0;
    //        }
    //
    //        return false;
    //    }
    //
    //    @Override
    //    public double getDurabilityForDisplay(
    //      final ItemStack stack)
    //    {
    //        final Object o = stack.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
    //
    //        if (o instanceof BagStorage)
    //        {
    //            final int qty = ((BagStorage) o).getSlotsUsed();
    //
    //            final double value = qty / (float) BagStorage.BAG_STORAGE_SLOTS;
    //            return Math.min(1.0d, Math.max(0.0d, ChiselsAndBits.getConfig().getClient().invertBitBagFullness.get()
    // ? value : 1.0 - value));
    //        }
    //
    //        return 0;
    //    }

    @Override
    public class_1271<class_1799> method_7836(
            final class_1937 worldIn, final class_1657 playerIn, final class_1268 hand) {
        final class_1799 itemStackIn = playerIn.method_5998(hand);

        if (worldIn.field_9236) {
            ChiselsAndBits.getNetworkChannel().sendToServer(new PacketOpenBagGui());
        }

        return new class_1271<class_1799>(class_1269.field_5812, itemStackIn);
    }

    public static class BagPos {
        public final BagInventory inv;

        public BagPos(final BagInventory bagInventory) {
            inv = bagInventory;
        }
    }
}
