package mod.chiselsandbits.items;

import java.util.List;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.core.ReflectionWrapper;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IChiselModeItem;
import mod.chiselsandbits.interfaces.IItemScrollWheel;
import mod.chiselsandbits.network.packets.PacketSetColor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.apache.commons.lang3.tuple.Pair;

public class ItemTapeMeasure extends class_1792 implements IChiselModeItem, IItemScrollWheel {
    public ItemTapeMeasure(class_1792.class_1793 properties) {
        super(properties.method_7889(1));
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpTapeMeasure,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1832),
                        ClientSide.instance.getModeKey());
    }

    @Override
    public class_1271<class_1799> method_7836(
            final class_1937 worldIn, final class_1657 playerIn, final class_1268 hand) {
        if (playerIn.method_5715() && playerIn.method_5770().field_9236) {
            ClientSide.instance.tapeMeasures.clear();
        }

        final class_1799 itemstack = playerIn.method_5998(hand);
        return new class_1271<>(class_1269.field_5812, itemstack);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        if (context.method_8045().field_9236) {
            if (context.method_8036().method_5715()) {
                ClientSide.instance.tapeMeasures.clear();
                return class_1269.field_5812;
            }

            final Pair<class_243, class_243> PlayerRay = ModUtil.getPlayerRay(context.method_8036());
            final class_243 ray_from = PlayerRay.getLeft();
            final class_243 ray_to = PlayerRay.getRight();

            final class_3959 rayTraceContext = new class_3959(
                    ray_from, ray_to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, context.method_8036());

            final class_3965 mop =
                    context.method_8036().method_5770().method_17742(rayTraceContext);
            if (mop.method_17783() == class_239.class_240.field_1332) {
                final BitLocation loc = new BitLocation(mop, BitOperation.CHISEL);
                ClientSide.instance.pointAt(ChiselToolType.TAPEMEASURE, loc, context.method_20287());
            } else {
                return class_1269.field_5814;
            }
        }

        return class_1269.field_5812;
    }

    //    @Override
    //    public Component getHighlightTip(final ItemStack item, final Component displayName)
    //    {
    //        if (EffectiveSide.get().isClient() && displayName instanceof MutableComponent &&
    // ChiselsAndBits.getConfig().getClient().itemNameModeDisplay.get() )
    //        {
    //            final MutableComponent formattableTextComponent = (MutableComponent) displayName;
    //            return formattableTextComponent.append(" - ").append(TapeMeasureModes.getMode( item
    // ).string.getLocal()).append(" - ").append(DeprecationHelper.translateToLocal( "chiselsandbits.color." +
    // getTapeColor( item ).getName()) );
    //        }
    //
    //        return displayName;
    //    }

    public class_1767 getTapeColor(final class_1799 item) {
        final class_2487 compound = item.method_7969();
        if (compound != null && compound.method_10545("color")) {
            try {
                return class_1767.valueOf(compound.method_10558("color"));
            } catch (final IllegalArgumentException iae) {
                // nope!
            }
        }

        return class_1767.field_7952;
    }

    @Override
    public void scroll(final class_1657 player, final class_1799 stack, final int dwheel) {
        final class_1767 color = getTapeColor(stack);
        int next = color.ordinal() + (dwheel < 0 ? -1 : 1);

        if (next < 0) {
            next = class_1767.values().length - 1;
        }

        if (next >= class_1767.values().length) {
            next = 0;
        }

        final class_1767 col = class_1767.values()[next];
        setTapeColor(stack, col);

        final PacketSetColor setColor = new PacketSetColor(
                col,
                ChiselToolType.TAPEMEASURE,
                ChiselsAndBits.getConfig().getClient().chatModeNotification.get());

        ChiselsAndBits.getNetworkChannel().sendToServer(setColor);
        ReflectionWrapper.instance.clearHighlightedStack();
    }

    public void setTapeColor(final class_1799 stack, final class_1767 color) {
        stack.method_7959("color", class_2519.method_23256(color.method_15434()));
    }
}
