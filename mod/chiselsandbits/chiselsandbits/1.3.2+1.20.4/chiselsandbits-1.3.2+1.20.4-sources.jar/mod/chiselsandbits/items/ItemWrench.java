package mod.chiselsandbits.items;

import com.communi.suggestu.saecularia.caudices.core.block.IBlockWithWorldlyProperties;
import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.LocalStrings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class ItemWrench extends class_1792 {

    public ItemWrench(class_1792.class_1793 properties) {
        super(properties.method_7889(1).method_7895(1));
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpWrench,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904));
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1657 player = context.method_8036();
        final class_2338 pos = context.method_8037();
        final class_2350 side = context.method_8038();
        final class_1937 world = context.method_8045();
        final class_1799 stack = context.method_8041();
        final class_1268 hand = context.method_20287();

        if (!player.method_7343(pos, side, stack) || !world.method_8505(player, pos)) {
            return class_1269.field_5814;
        }

        final class_2680 b = world.method_8320(pos);
        if (b != null && !player.method_5715()) {
            class_2680 nb;

            if (b.method_26204() instanceof IBlockWithWorldlyProperties prop) {
                nb = prop.rotate(b, world, pos, class_2470.field_11463);
            } else {
                nb = b.method_26186(class_2470.field_11463);
            }

            if (nb != b) {
                world.method_8501(pos, nb);
                stack.method_7956(1, player, playerEntity -> {
                    playerEntity.method_20236(hand);
                });
                world.method_8452(pos, b.method_26204());
                player.method_6104(hand);
                return class_1269.field_5812;
            }
        }
        return class_1269.field_5814;
    }
}
