package mod.chiselsandbits.items;

import static net.minecraft.class_1834.field_8930;
import static net.minecraft.class_1834.field_8929;
import static net.minecraft.class_1834.field_8923;
import static net.minecraft.class_1834.field_22033;
import static net.minecraft.class_1834.field_8927;

import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.LocalStrings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class ItemBitSaw extends class_1792 {

    public ItemBitSaw(class_1832 tier, class_1792.class_1793 properties) {
        super(properties);
    }

    private static class_1792.class_1793 setupDamageStack(class_1832 material, class_1792.class_1793 properties) {
        long uses = 1;
        if (field_8930.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().diamondSawUses.get();
        } else if (field_8929.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().goldSawUses.get();
        } else if (field_8923.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().ironSawUses.get();
        } else if (field_8927.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().stoneSawUses.get();
        } else if (field_22033.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().netheriteSawUses.get();
        }

        return properties.method_7895(
                ChiselsAndBits.getConfig().getServer().damageTools.get() ? (int) Math.max(0, uses) : 0);
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig().getCommon().helpText(LocalStrings.HelpBitSaw, tooltip);
    }

    public class_1799 getContainerItem(final class_1799 itemStack) {
        if (ChiselsAndBits.getConfig().getServer().damageTools.get()) {
            itemStack.method_7974(itemStack.method_7919() + 1);
            if (itemStack.method_7919() == itemStack.method_7936()) {
                return class_1799.field_8037;
            }
        }

        return itemStack.method_7972();
    }
}
