package mod.chiselsandbits.items;

import static net.minecraft.class_1834.field_8930;
import static net.minecraft.class_1834.field_8929;
import static net.minecraft.class_1834.field_8923;
import static net.minecraft.class_1834.field_22033;
import static net.minecraft.class_1834.field_8927;
import static net.minecraft.class_1834.field_8922;

import com.communi.suggestu.saecularia.caudices.core.block.IBlockWithWorldlyProperties;
import com.google.common.base.Stopwatch;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ActingPlayer;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.ChiselModeManager;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.IContinuousInventory;
import mod.chiselsandbits.helpers.IItemInInventory;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IChiselModeItem;
import mod.chiselsandbits.interfaces.IItemScrollWheel;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.modes.IToolMode;
import mod.chiselsandbits.network.packets.PacketChisel;
import mod.chiselsandbits.registry.ModTags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1766;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5250;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

public class ItemChisel extends class_1766 implements IItemScrollWheel, IChiselModeItem {
    private static final float one_16th = 1.0f / 16.0f;
    private static Stopwatch timer;
    private static boolean testingChisel = false;

    public ItemChisel(final class_1832 material, final class_1792.class_1793 properties) {
        super(0.1F, -2.8F, material, ModTags.Blocks.CHISELED_BLOCK, properties);
    }

    private static class_1792.class_1793 setupDamageStack(class_1832 material, class_1792.class_1793 properties) {
        long uses = 1;
        if (field_8930.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().diamondChiselUses.get();
        } else if (field_8929.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().goldChiselUses.get();
        } else if (field_8923.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().ironChiselUses.get();
        } else if (field_8927.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().stoneChiselUses.get();
        } else if (field_22033.equals(material)) {
            uses = ChiselsAndBits.getConfig().getServer().netheriteChiselUses.get();
        }

        return properties.method_7895(
                ChiselsAndBits.getConfig().getServer().damageTools.get() ? (int) Math.max(0, uses) : 0);
    }

    public static void resetDelay() {
        timer = null;
    }

    public static boolean fromBreakToChisel(
            final ChiselMode mode,
            final class_1799 itemstack,
            final @Nonnull class_2338 pos,
            final class_1657 player,
            final class_1268 hand) {
        final class_2680 state = player.method_5770().method_8320(pos);
        if (ItemChiseledBit.checkRequiredSpace(player, state)) {
            return false;
        }
        if (BlockBitInfo.canChisel(state)) {
            if (itemstack != null && (timer == null || timer.elapsed(TimeUnit.MILLISECONDS) > 150)) {
                timer = Stopwatch.createStarted();
                if (mode == ChiselMode.DRAWN_REGION) {
                    final Pair<class_243, class_243> PlayerRay = ModUtil.getPlayerRay(player);
                    final class_243 ray_from = PlayerRay.getLeft();
                    final class_243 ray_to = PlayerRay.getRight();

                    final class_3959 context =
                            new class_3959(ray_from, ray_to, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, player);

                    final class_239 mop = player.field_6002.method_17742(context);
                    if (mop != null && mop instanceof class_3965 rayTraceResult) {
                        final BitLocation loc = new BitLocation(rayTraceResult, BitOperation.CHISEL);
                        ClientSide.instance.pointAt(ChiselToolType.CHISEL, loc, hand);
                        return true;
                    }

                    return true;
                }

                if (!player.field_6002.field_9236) {
                    return true;
                }

                final Pair<class_243, class_243> PlayerRay = ModUtil.getPlayerRay(player);
                final class_243 ray_from = PlayerRay.getLeft();
                final class_243 ray_to = PlayerRay.getRight();
                final class_3959 context =
                        new class_3959(ray_from, ray_to, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, player);

                class_3965 mop = player.field_6002.method_17742(context);
                if (mop.method_17783() != class_239.class_240.field_1333) {
                    if ((class_310.method_1551().field_1765 != null
                                    ? class_310.method_1551().field_1765.method_17783()
                                    : class_239.class_240.field_1333)
                            == class_239.class_240.field_1332) {
                        class_3965 minecraftResult = (class_3965) class_310.method_1551().field_1765;
                        if (!minecraftResult
                                .method_17777()
                                .method_10062()
                                .equals(mop.method_17777().method_10062())) {
                            mop = minecraftResult;
                        }
                    }

                    useChisel(mode, player, player.field_6002, mop, hand);
                }
            }

            return true;
        }

        if (player.method_5770().field_9236) {
            return ClientSide.instance.getStartPos() != null;
        }

        return false;
    }

    static void useChisel(
            final ChiselMode mode,
            final class_1657 player,
            final class_1937 world,
            final class_3965 rayTraceResult,
            final class_1268 hand) {
        final BitLocation location = new BitLocation(rayTraceResult, BitOperation.CHISEL);

        final PacketChisel pc =
                new PacketChisel(BitOperation.CHISEL, location, rayTraceResult.method_17780(), mode, hand);

        final int extractedState = pc.doAction(player);
        if (extractedState != 0) {
            ClientSide.breakSound(world, rayTraceResult.method_17777(), extractedState);

            ChiselsAndBits.getNetworkChannel().sendToServer(pc);
        }
    }

    /**
     * Modifies VoxelData of TileEntityChiseled
     *
     * @param selected
     * @param player
     * @param vb
     * @param world
     * @param pos
     * @param side
     * @param x
     * @param y
     * @param z
     * @param output
     * @return
     */
    public static class_1799 chiselBlock(
            final IContinuousInventory selected,
            final ActingPlayer player,
            final VoxelBlob vb,
            final class_1937 world,
            final class_2338 pos,
            final class_2350 side,
            final int x,
            final int y,
            final int z,
            class_1799 output,
            final List<class_1542> spawnlist) {
        final boolean isCreative = player.isCreative();

        final int blk = vb.get(x, y, z);
        if (blk == 0) {
            return output;
        }

        if (!canMine(selected, ModUtil.getStateById(blk), player.getPlayer(), world, pos)) {
            return output;
        }

        if (!selected.useItem(blk)) {
            return output;
        }

        if (!world.field_9236 && !isCreative) {
            double hitX = x * one_16th;
            double hitY = y * one_16th;
            double hitZ = z * one_16th;

            final double offset = 0.5;
            hitX += side.method_10148() * offset;
            hitY += side.method_10164() * offset;
            hitZ += side.method_10165() * offset;

            if (output == null || !ItemChiseledBit.sameBit(output, blk) || ModUtil.getStackSize(output) == 64) {
                output = ItemChiseledBit.createStack(blk, 1, true);

                spawnlist.add(new class_1542(world, pos.method_10263() + hitX, pos.method_10264() + hitY, pos.method_10260() + hitZ, output));
            } else {
                ModUtil.adjustStackSize(output, 1);
            }
        } else {
            // return value...
            output = ItemChiseledBit.createStack(blk, 1, true);
        }

        vb.clear(x, y, z);
        return output;
    }

    public static boolean canMine(
            final IContinuousInventory chiselInv,
            final class_2680 state,
            final class_1657 player,
            final class_1937 world,
            final @Nonnull class_2338 pos) {
        final int targetState = ModUtil.getStateId(state);
        IItemInInventory chiselSlot = chiselInv.getItem(targetState);
        class_1799 chisel = chiselSlot.getStack();

        if (player.method_7337()) {
            return world.method_8505(player, pos);
        }

        if (ModUtil.isEmpty(chisel)) {
            return false;
        }

        if (ChiselsAndBits.getConfig().getServer().enableChiselToolHarvestCheck.get()) {
            // this is the earily check.
            if (state.method_26204() instanceof BlockChiseled) {
                return ((BlockChiseled) state.method_26204()).basicHarvestBlockTest(world, pos, player);
            }

            do {
                final class_2248 blk = world.method_8320(pos).method_26204();
                BlockChiseled.setActingAs(state);
                testingChisel = true;
                chiselSlot.swapWithWeapon();
                boolean canHarvest = false;
                if (blk instanceof IBlockWithWorldlyProperties prop) {
                    canHarvest = prop.canHarvestBlock(world.method_8320(pos), world, pos, player);
                }
                chiselSlot.swapWithWeapon();
                testingChisel = false;
                BlockChiseled.setActingAs(null);

                if (canHarvest) {
                    return true;
                }

                chiselInv.fail(targetState);

                chiselSlot = chiselInv.getItem(targetState);
                chisel = chiselSlot.getStack();
            } while (!ModUtil.isEmpty(chisel));

            return false;
        }

        return true;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(
            final class_1799 stack,
            @Nullable final class_1937 worldIn,
            final List<class_2561> tooltip,
            final class_1836 flagIn) {
        super.method_7851(stack, worldIn, tooltip, flagIn);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpChisel,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1886),
                        ClientSide.instance.getModeKey());
    }

    @Override
    public boolean method_7885(class_2680 blockState, class_1937 level, class_2338 pos, class_1657 player) {
        class_1799 itemStack = player.method_5998(player.method_6058());
        return ItemChisel.fromBreakToChisel(
                ChiselMode.castMode(
                        ChiselModeManager.getChiselMode(player, ChiselToolType.CHISEL, class_1268.field_5808)),
                itemStack,
                pos,
                player,
                class_1268.field_5808);
    }

    @Override
    public class_2561 method_7864(class_1799 itemStack) {
        class_2561 displayName = super.method_7864(itemStack);
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT
                && ChiselsAndBits.getConfig().getClient().itemNameModeDisplay.get()
                && displayName instanceof class_5250 formattableTextComponent) {
            if (ChiselsAndBits.getConfig().getClient().perChiselMode.get()
                    || FabricLoader.getInstance().getEnvironmentType() == EnvType.SERVER) {
                return formattableTextComponent
                        .method_27693(" - ")
                        .method_27693(ChiselMode.getMode(itemStack).string.getLocal());
            } else {
                return formattableTextComponent
                        .method_27693(" - ")
                        .method_27693(ChiselModeManager.getChiselMode(
                                        ClientSide.instance.getPlayer(),
                                        ChiselToolType.CHISEL,
                                        class_1268.field_5808)
                                .getName()
                                .getLocal());
            }
        }
        return displayName;
    }

    @Override
    public class_1271<class_1799> method_7836(
            final class_1937 worldIn, final class_1657 playerIn, final class_1268 hand) {
        final class_1799 itemStackIn = playerIn.method_5998(hand);

        if (worldIn.field_9236
                && ChiselsAndBits.getConfig()
                        .getClient()
                        .enableRightClickModeChange
                        .get()) {
            final IToolMode mode = ChiselModeManager.getChiselMode(playerIn, ChiselToolType.CHISEL, hand);
            ChiselModeManager.scrollOption(ChiselToolType.CHISEL, mode, mode, playerIn.method_5715() ? -1 : 1);
            return new class_1271<>(class_1269.field_5812, itemStackIn);
        }

        return super.method_7836(worldIn, playerIn, hand);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        if (context.method_8045().field_9236
                && ChiselsAndBits.getConfig()
                        .getClient()
                        .enableRightClickModeChange
                        .get()) {
            method_7836(context.method_8045(), context.method_8036(), context.method_20287());
            return class_1269.field_5812;
        }

        return class_1269.field_5814;
    }

    @Override
    public boolean method_7856(final class_2680 blk) {
        class_1792 it;

        final class_1832 tier = method_8022();
        if (field_8930.equals(tier)) {
            it = class_1802.field_8377;
        } else if (field_8929.equals(tier)) {
            it = class_1802.field_8335;
        } else if (field_8923.equals(tier)) {
            it = class_1802.field_8403;
        } else if (field_8922.equals(tier)) {
            it = class_1802.field_8647;
        } else {
            it = class_1802.field_8387;
        }

        return blk.method_26204() instanceof BlockChiseled || it.method_7856(blk);
    }

    //    @Override
    //    public int getHarvestLevel(final ItemStack stack, final ToolType tool, @Nullable final Player player,
    // @Nullable final BlockState blockState)
    //    {
    //        if ( testingChisel && stack.getItem() instanceof ItemChisel )
    //        {
    //            final String pattern = "(^|,)" + Pattern.quote( tool.getName() ) + "(,|$)";
    //
    //            final Pattern p = Pattern.compile( pattern );
    //            final Matcher m = p.matcher(
    // ChiselsAndBits.getConfig().getServer().enableChiselToolHarvestCheckTools.get() );
    //
    //            if ( m.find() )
    //            {
    //                final ItemChisel ic = (ItemChisel) stack.getItem();
    //                return ic.getTier().getLevel();
    //            }
    //        }
    //
    //        return super.getHarvestLevel( stack, tool, player, blockState );
    //    }

    @Override
    public void scroll(final class_1657 player, final class_1799 stack, final int dwheel) {
        final IToolMode mode =
                ChiselModeManager.getChiselMode(player, ChiselToolType.CHISEL, class_1268.field_5808);
        ChiselModeManager.scrollOption(ChiselToolType.CHISEL, mode, mode, dwheel);
    }
}
