package mod.chiselsandbits.items;

import java.util.ArrayList;
import java.util.List;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IPatternItem;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.render.helpers.SimpleInstanceCache;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class ItemMirrorPrint extends class_1792 implements IPatternItem {

    SimpleInstanceCache<class_1799, List<class_2561>> toolTipCache = new SimpleInstanceCache<>(null, new ArrayList<>());

    public ItemMirrorPrint(class_1792.class_1793 properties) {
        super(properties);
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(
            final class_1799 stack, final class_1937 worldIn, final List<class_2561> tooltip, final class_1836 advanced) {
        super.method_7851(stack, worldIn, tooltip, advanced);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpMirrorPrint,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904));

        if (isWritten(stack)) {
            if (ClientSide.instance.holdingShift()) {
                if (toolTipCache.needsUpdate(stack)) {
                    final VoxelBlob blob = ModUtil.getBlobFromStack(stack, null);
                    toolTipCache.updateCachedValue(blob.listContents(new ArrayList<>()));
                }

                tooltip.addAll(toolTipCache.getCached());
            } else {
                tooltip.add(class_2561.method_43470(LocalStrings.ShiftDetails.getLocal()));
            }
        }
    }

    @Override
    public String method_7866(final class_1799 stack) {
        return super.method_7866(stack);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1799 stack = context.method_8036().method_5998(context.method_20287());

        if (!context.method_8036().method_7343(context.method_8037(), context.method_8038(), stack)) {
            return class_1269.field_5812;
        }

        if (!isWritten(stack)) {
            final class_2487 comp = getCompoundFromBlock(
                    context.method_8045(), context.method_8037(), context.method_8036(), context.method_8038());
            if (comp != null) {
                stack.method_7934(1);

                final class_1799 newStack = new class_1799(ModItems.ITEM_MIRROR_PRINT_WRITTEN.get(), 1);
                newStack.method_7980(comp);

                final class_1542 entity = context.method_8036().method_7328(newStack, true);
                entity.method_6982(0);
                entity.method_6981(context.method_8036());

                return class_1269.field_5812;
            }

            return class_1269.field_5814;
        }

        return class_1269.field_5814;
    }

    protected class_2487 getCompoundFromBlock(
            final class_1937 world, final class_2338 pos, final class_1657 player, final class_2350 face) {
        final TileEntityBlockChiseled te = ModUtil.getChiseledTileEntity(world, pos, false);

        if (te != null) {
            final class_2487 comp = new class_2487();
            te.writeChiselData(comp);

            final TileEntityBlockChiseled tmp = new TileEntityBlockChiseled(pos, world.method_8320(pos));
            tmp.readChiselData(comp);

            final VoxelBlob bestBlob = tmp.getBlob();
            tmp.setBlob(bestBlob.mirror(face.method_10166()));
            tmp.writeChiselData(comp);

            comp.method_10567(ModUtil.NBT_SIDE, (byte) ModUtil.getPlaceFace(player).ordinal());
            return comp;
        }

        return null;
    }

    @Override
    public class_1799 getPatternedItem(final class_1799 stack, final boolean wantRealItems) {
        if (!isWritten(stack)) {
            return null;
        }

        final class_2487 tag = ModUtil.getTagCompound(stack);

        // Detect and provide full blocks if pattern solid full and solid.
        final NBTBlobConverter conv = new NBTBlobConverter();
        conv.readChisleData(tag, VoxelBlob.VERSION_ANY);

        final class_2680 blk = conv.getPrimaryBlockState();
        final class_1799 itemstack = new class_1799(ModBlocks.getChiseledBlock(), 1);

        itemstack.method_7959(ModUtil.NBT_BLOCKENTITYTAG, tag);
        return itemstack;
    }

    @Override
    public boolean isWritten(final class_1799 stack) {
        return stack.method_7909() == ModItems.ITEM_MIRROR_PRINT_WRITTEN.get() && stack.method_7985();
    }
}
