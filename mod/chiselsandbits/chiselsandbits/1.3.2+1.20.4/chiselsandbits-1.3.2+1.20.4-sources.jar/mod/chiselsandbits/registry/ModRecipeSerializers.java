package mod.chiselsandbits.registry;

import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import mod.chiselsandbits.crafting.BagDyeing;
import mod.chiselsandbits.crafting.BitSawCrafting;
import mod.chiselsandbits.crafting.ChiselBlockCrafting;
import mod.chiselsandbits.crafting.ChiselCrafting;
import mod.chiselsandbits.crafting.MirrorTransferCrafting;
import mod.chiselsandbits.crafting.NegativeInversionCrafting;
import mod.chiselsandbits.crafting.StackableCrafting;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1866;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModRecipeSerializers {

    public static final Supplier<class_1866<BagDyeing>> BAG_DYEING =
            Suppliers.memoize(() -> new class_1866<>(BagDyeing::new));
    public static final Supplier<class_1866<ChiselCrafting>> CHISEL_CRAFTING =
            Suppliers.memoize(() -> new class_1866<>(ChiselCrafting::new));
    public static final Supplier<class_1866<ChiselBlockCrafting>> CHISEL_BLOCK_CRAFTING =
            Suppliers.memoize(() -> new class_1866<>(ChiselBlockCrafting::new));
    public static final Supplier<class_1866<StackableCrafting>> STACKABLE_CRAFTING =
            Suppliers.memoize(() -> new class_1866<>(StackableCrafting::new));
    public static final Supplier<class_1866<NegativeInversionCrafting>>
            NEGATIVE_INVERSION_CRAFTING =
                    Suppliers.memoize(() -> new class_1866<>(NegativeInversionCrafting::new));
    public static final Supplier<class_1866<MirrorTransferCrafting>> MIRROR_TRANSFER_CRAFTING =
            Suppliers.memoize(() -> new class_1866<>(MirrorTransferCrafting::new));
    public static final Supplier<class_1866<BitSawCrafting>> BIT_SAW_CRAFTING =
            Suppliers.memoize(() -> new class_1866<>(BitSawCrafting::new));

    private ModRecipeSerializers() {
        throw new IllegalStateException("Tried to initialize: ModRecipeSerializers but this is a Utility class.");
    }

    public static void onModConstruction() {
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "bag_dyeing"),
                BAG_DYEING.get());
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "chisel_crafting"),
                CHISEL_CRAFTING.get());
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "chisel_block_crafting"),
                CHISEL_BLOCK_CRAFTING.get());
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "stackable_crafting"),
                STACKABLE_CRAFTING.get());
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "negative_inversion_crafting"),
                NEGATIVE_INVERSION_CRAFTING.get());
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "mirror_transfer_crafting"),
                MIRROR_TRANSFER_CRAFTING.get());
        class_2378.method_10230(
                class_7923.field_41189,
                new class_2960(Constants.MOD_ID, "bit_saw_crafting"),
                BIT_SAW_CRAFTING.get());
    }
}
