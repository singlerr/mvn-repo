package mod.chiselsandbits.registry;

import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {

    public static void init() {
        Items.init();
        Blocks.init();
    }

    public static final class Items {
        public static class_6862<class_1792> CHISEL = tag("chisel");
        public static class_6862<class_1792> BIT_BAG = tag("bit_bag");

        private static void init() {}

        private static class_6862<class_1792> tag(String name) {
            return class_3489.method_15102(Constants.MOD_ID + ":" + name);
        }
    }

    public static final class Blocks {
        public static class_6862<class_2248> FORCED_CHISELABLE = tag("chiselable/forced");
        public static class_6862<class_2248> BLOCKED_CHISELABLE = tag("chiselable/blocked");
        public static class_6862<class_2248> CHISELED_BLOCK = tag("chiseled/block");

        private static void init() {}

        private static class_6862<class_2248> tag(String name) {
            return class_6862.method_40092(class_7924.field_41254, new class_2960(Constants.MOD_ID + ":" + name));
        }
    }
}
