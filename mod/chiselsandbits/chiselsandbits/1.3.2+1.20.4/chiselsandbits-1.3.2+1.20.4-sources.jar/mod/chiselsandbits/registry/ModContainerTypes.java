package mod.chiselsandbits.registry;

import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import mod.chiselsandbits.bitbag.BagContainer;
import mod.chiselsandbits.printer.ChiselPrinterContainer;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7699;
import net.minecraft.class_7923;

public final class ModContainerTypes {

    private ModContainerTypes() {
        throw new IllegalStateException("Tried to initialize: ModContainerTypes but this is a Utility class.");
    }

    public static void onModConstruction() {
        class_2378.method_10230(class_7923.field_41187, new class_2960(Constants.MOD_ID, "bag"), BAG_CONTAINER.get());
        class_2378.method_10230(
                class_7923.field_41187,
                new class_2960(Constants.MOD_ID, "chisel_station"),
                CHISEL_STATION_CONTAINER.get());
    }

    public static final Supplier<class_3917<BagContainer>> BAG_CONTAINER =
            Suppliers.memoize(() -> new class_3917<>(BagContainer::new, class_7699.method_45397()));
    public static final Supplier<class_3917<ChiselPrinterContainer>> CHISEL_STATION_CONTAINER =
            Suppliers.memoize(() -> new class_3917<>(ChiselPrinterContainer::new, class_7699.method_45397()));
}
