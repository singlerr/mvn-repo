package mod.chiselsandbits.registry;

import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemBitSaw;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.items.ItemMagnifyingGlass;
import mod.chiselsandbits.items.ItemMirrorPrint;
import mod.chiselsandbits.items.ItemNegativePrint;
import mod.chiselsandbits.items.ItemPositivePrint;
import mod.chiselsandbits.items.ItemTapeMeasure;
import mod.chiselsandbits.items.ItemWrench;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1792;
import net.minecraft.class_1834;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {

    public static final Supplier<ItemBlockChiseled> ITEM_CHISELED_BLOCK =
            Suppliers.memoize(() -> new ItemBlockChiseled(ModBlocks.CHISELED_BLOCK.get(), new class_1792.class_1793()));
    public static final Supplier<ItemChisel> ITEM_CHISEL_STONE =
            Suppliers.memoize(() -> new ItemChisel(class_1834.field_8927, new class_1792.class_1793()));
    public static final Supplier<ItemChisel> ITEM_CHISEL_IRON =
            Suppliers.memoize(() -> new ItemChisel(class_1834.field_8923, new class_1792.class_1793()));
    public static final Supplier<ItemChisel> ITEM_CHISEL_GOLD =
            Suppliers.memoize(() -> new ItemChisel(class_1834.field_8929, new class_1792.class_1793()));
    public static final Supplier<ItemChisel> ITEM_CHISEL_DIAMOND =
            Suppliers.memoize(() -> new ItemChisel(class_1834.field_8930, new class_1792.class_1793()));
    public static final Supplier<ItemChisel> ITEM_CHISEL_NETHERITE =
            Suppliers.memoize(() -> new ItemChisel(class_1834.field_22033, new class_1792.class_1793().method_24359()));
    public static final Supplier<ItemChiseledBit> ITEM_BLOCK_BIT =
            Suppliers.memoize(() -> new ItemChiseledBit(new class_1792.class_1793()));
    public static final Supplier<ItemMirrorPrint> ITEM_MIRROR_PRINT =
            Suppliers.memoize(() -> new ItemMirrorPrint(new class_1792.class_1793()));
    public static final Supplier<ItemMirrorPrint> ITEM_MIRROR_PRINT_WRITTEN =
            Suppliers.memoize(() -> new ItemMirrorPrint(new class_1792.class_1793()));
    public static final Supplier<ItemPositivePrint> ITEM_POSITIVE_PRINT =
            Suppliers.memoize(() -> new ItemPositivePrint(new class_1792.class_1793()));
    public static final Supplier<ItemPositivePrint> ITEM_POSITIVE_PRINT_WRITTEN =
            Suppliers.memoize(() -> new ItemPositivePrint(new class_1792.class_1793()));
    public static final Supplier<ItemNegativePrint> ITEM_NEGATIVE_PRINT =
            Suppliers.memoize(() -> new ItemNegativePrint(new class_1792.class_1793()));
    public static final Supplier<ItemNegativePrint> ITEM_NEGATIVE_PRINT_WRITTEN =
            Suppliers.memoize(() -> new ItemNegativePrint(new class_1792.class_1793()));
    public static final Supplier<ItemBitBag> ITEM_BIT_BAG_DEFAULT =
            Suppliers.memoize(() -> new ItemBitBag(new class_1792.class_1793()));
    public static final Supplier<ItemBitBag> ITEM_BIT_BAG_DYED =
            Suppliers.memoize(() -> new ItemBitBag(new class_1792.class_1793()));
    public static final Supplier<ItemWrench> ITEM_WRENCH =
            Suppliers.memoize(() -> new ItemWrench(new class_1792.class_1793()));
    public static final Supplier<ItemBitSaw> ITEM_BIT_SAW_STONE =
            Suppliers.memoize(() -> new ItemBitSaw(class_1834.field_8927, new class_1792.class_1793()));
    public static final Supplier<ItemBitSaw> ITEM_BIT_SAW_GOLD =
            Suppliers.memoize(() -> new ItemBitSaw(class_1834.field_8929, new class_1792.class_1793()));
    public static final Supplier<ItemBitSaw> ITEM_BIT_SAW_IRON =
            Suppliers.memoize(() -> new ItemBitSaw(class_1834.field_8923, new class_1792.class_1793()));
    public static final Supplier<ItemBitSaw> ITEM_BIT_SAW_DIAMOND =
            Suppliers.memoize(() -> new ItemBitSaw(class_1834.field_8930, new class_1792.class_1793()));
    public static final Supplier<ItemBitSaw> ITEM_BIT_SAW_NETHERITE =
            Suppliers.memoize(() -> new ItemBitSaw(class_1834.field_22033, new class_1792.class_1793().method_24359()));
    public static final Supplier<ItemTapeMeasure> ITEM_TAPE_MEASURE =
            Suppliers.memoize(() -> new ItemTapeMeasure(new class_1792.class_1793()));
    public static final Supplier<ItemMagnifyingGlass> ITEM_MAGNIFYING_GLASS =
            Suppliers.memoize(() -> new ItemMagnifyingGlass(new class_1792.class_1793()));

    private ModItems() {
        throw new IllegalStateException("Tried to initialize: ModItems but this is a Utility class.");
    }

    public static void onModConstruction() {
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "chiseled_block"),
                ITEM_CHISELED_BLOCK.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "chisel_stone"),
                ITEM_CHISEL_STONE.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "chisel_iron"), ITEM_CHISEL_IRON.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "chisel_gold"), ITEM_CHISEL_GOLD.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "chisel_diamond"),
                ITEM_CHISEL_DIAMOND.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "chisel_netherite"),
                ITEM_CHISEL_NETHERITE.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "block_bit"), ITEM_BLOCK_BIT.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "mirrorprint"), ITEM_MIRROR_PRINT.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "mirrorprint_written"),
                ITEM_MIRROR_PRINT_WRITTEN.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "positiveprint"),
                ITEM_POSITIVE_PRINT.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "positiveprint_written"),
                ITEM_POSITIVE_PRINT_WRITTEN.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "negativeprint"),
                ITEM_NEGATIVE_PRINT.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "negativeprint_written"),
                ITEM_NEGATIVE_PRINT_WRITTEN.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "bit_bag"), ITEM_BIT_BAG_DEFAULT.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "bit_bag_dyed"),
                ITEM_BIT_BAG_DYED.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "wrench_wood"), ITEM_WRENCH.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "bitsaw_stone"),
                ITEM_BIT_SAW_STONE.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "bitsaw_gold"), ITEM_BIT_SAW_GOLD.get());
        class_2378.method_10230(
                class_7923.field_41178, new class_2960(Constants.MOD_ID, "bitsaw_iron"), ITEM_BIT_SAW_IRON.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "bitsaw_diamond"),
                ITEM_BIT_SAW_DIAMOND.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "bitsaw_netherite"),
                ITEM_BIT_SAW_NETHERITE.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "tape_measure"),
                ITEM_TAPE_MEASURE.get());
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(Constants.MOD_ID, "magnifying_glass"),
                ITEM_MAGNIFYING_GLASS.get());
    }
}
