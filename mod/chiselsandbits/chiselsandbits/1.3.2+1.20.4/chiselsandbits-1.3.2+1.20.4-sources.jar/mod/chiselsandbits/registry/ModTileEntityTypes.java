package mod.chiselsandbits.registry;

import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import mod.chiselsandbits.bitstorage.TileEntityBitStorage;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.printer.ChiselPrinterTileEntity;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModTileEntityTypes {

    private ModTileEntityTypes() {
        throw new IllegalStateException("Tried to initialize: ModTileEntityTypes but this is a Utility class.");
    }

    public static void onModConstruction() {
        class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Constants.MOD_ID, "chiseled"),
                CHISELED.get());
        class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Constants.MOD_ID, "bit_storage"),
                BIT_STORAGE.get());
        class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Constants.MOD_ID, "chisel_printer"),
                CHISEL_PRINTER.get());
    }

    public static final Supplier<class_2591<TileEntityBlockChiseled>> CHISELED = Suppliers.memoize(
            () -> class_2591.class_2592.method_20528(TileEntityBlockChiseled::new, ModBlocks.CHISELED_BLOCK.get())
                    .method_11034(null));

    public static final Supplier<class_2591<TileEntityBitStorage>> BIT_STORAGE = Suppliers.memoize(
            () -> class_2591.class_2592.method_20528(TileEntityBitStorage::new, ModBlocks.BIT_STORAGE_BLOCK.get())
                    .method_11034(null));

    public static final Supplier<class_2591<ChiselPrinterTileEntity>> CHISEL_PRINTER = Suppliers.memoize(
            () -> class_2591.class_2592.method_20528(ChiselPrinterTileEntity::new, ModBlocks.CHISEL_PRINTER_BLOCK.get())
                    .method_11034(null));
}
