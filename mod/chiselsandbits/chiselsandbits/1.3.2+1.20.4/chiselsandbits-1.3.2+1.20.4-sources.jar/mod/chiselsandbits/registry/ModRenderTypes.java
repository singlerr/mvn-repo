package mod.chiselsandbits.registry;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.OptionalDouble;
import java.util.function.Supplier;
import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1059;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4668;
import net.minecraft.class_4722;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.opengl.GL11;

/***
 * from chisels-and-bits 1.20.4 by ldtteam
 */
public enum ModRenderTypes {
    MEASUREMENT_LINES(() -> InternalType.MEASUREMENT_LINES),
    CHISEL_PREVIEW_INSIDE_BLOCKS(() -> InternalType.CHISEL_PREVIEW_INSIDE_BLOCKS),
    CHISEL_PREVIEW_OUTSIDE_BLOCKS(() -> InternalType.CHISEL_PREVIEW_OUTSIDE_BLOCKS),
    WIREFRAME_LINES(() -> InternalType.WIREFRAME_LINES),
    WIREFRAME_LINES_ALWAYS(() -> InternalType.WIREFRAME_LINES_ALWAYS),
    WIREFRAME_BODY(() -> InternalType.WIREFRAME_BODY),
    GHOST_BLOCK_PREVIEW(() -> InternalType.GHOST_BLOCK_PREVIEW),
    GHOST_BLOCK_PREVIEW_GREATER(() -> InternalType.GHOST_BLOCK_PREVIEW_GREATER),
    GHOST_BLOCK_COLORED_PREVIEW(() -> InternalType.GHOST_BLOCK_COLORED_PREVIEW),
    GHOST_BLOCK_COLORED_PREVIEW_ALWAYS(() -> InternalType.GHOST_BLOCK_COLORED_PREVIEW_ALWAYS);

    private final Supplier<class_1921> typeSupplier;

    ModRenderTypes(final Supplier<class_1921> typeSupplier) {
        this.typeSupplier = typeSupplier;
    }

    public class_1921 get() {
        return typeSupplier.get();
    }

    private static class PreviewState extends class_4668 {

        public PreviewState() {
            super("preview_state", PreviewState::setupState, PreviewState::clearState);
        }

        private static void setupState() {
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            RenderSystem.colorMask(false, false, false, false);
        }

        private static void clearState() {
            RenderSystem.defaultBlendFunc();
            RenderSystem.colorMask(true, true, true, true);
            RenderSystem.disableBlend();
        }

        private static class PreviewDepthTest extends class_4672 {

            public PreviewDepthTest() {
                super("preview_depth_test", 0);
            }

            @Override
            public void method_23516() {}

            @Override
            public void method_23518() {}
        }
    }

    private static class InternalState extends class_4668 {
        private static final class_4672 DISABLED_DEPTH_TEST = new DepthTestDisabled();
        private static final DepthTestLessOrEqual LESS_OR_EQUAL_DEPTH_TEST = new DepthTestLessOrEqual();
        private static final DepthTestGreaterOrEqual GREATER_OR_EQUAL_DEPTH_TEST = new DepthTestGreaterOrEqual();

        public InternalState(String name, Runnable setupState, Runnable clearState) {
            super(name, setupState, clearState);
            throw new IllegalStateException("This class must not be instantiated");
        }

        private static class DepthTestDisabled extends class_4672 {
            public DepthTestDisabled() {
                super("depth_test_disabled", 0);
            }

            @Override
            public void method_23516() {
                RenderSystem.disableDepthTest();
            }

            @Override
            public void method_23518() {
                RenderSystem.enableDepthTest();
            }

            @Override
            public @NotNull String toString() {
                return field_21363 + "[" + Constants.MOD_ID + ":depth_test_disabled]";
            }
        }

        private static class DepthTestLessOrEqual extends class_4672 {
            public DepthTestLessOrEqual() {
                super("depth_test_less_or_equal", 0);
            }

            @Override
            public void method_23516() {
                RenderSystem.enableDepthTest();
                RenderSystem.depthFunc(GL11.GL_LEQUAL);
            }

            @Override
            public void method_23518() {
                RenderSystem.enableDepthTest();
                RenderSystem.depthFunc(GL11.GL_LEQUAL);
            }

            @Override
            public @NotNull String toString() {
                return field_21363 + "[" + Constants.MOD_ID + ":depth_test_less_or_equal]";
            }
        }

        private static class DepthTestGreaterOrEqual extends class_4672 {
            public DepthTestGreaterOrEqual() {
                super("depth_test_greater_or_equal", 0);
            }

            @Override
            public void method_23516() {
                RenderSystem.enableDepthTest();
                RenderSystem.depthFunc(GL11.GL_GEQUAL);
            }

            @Override
            public void method_23518() {
                RenderSystem.enableDepthTest();
                RenderSystem.depthFunc(GL11.GL_LEQUAL);
            }

            @Override
            public @NotNull String toString() {
                return field_21363 + "[" + Constants.MOD_ID + ":depth_test_greater_or_equal]";
            }
        }
    }

    private static class InternalType extends class_1921 {
        private static final class_1921 MEASUREMENT_LINES = class_1921.method_24049(
                Constants.MOD_ID + ":measurement_lines",
                class_290.field_29337,
                class_293.class_5596.field_27377,
                256,
                false,
                false,
                class_1921.class_4688.method_23598()
                        .method_34578(field_29433)
                        .method_23609(new class_4677(OptionalDouble.of(2.5d)))
                        .method_23607(field_22241)
                        .method_23615(field_21370)
                        .method_23610(field_25280)
                        .method_23616(field_21350)
                        .method_23603(field_21345)
                        .method_23604(InternalState.DISABLED_DEPTH_TEST)
                        .method_23617(false));

        private static final class_1921 CHISEL_PREVIEW_INSIDE_BLOCKS = class_1921.method_24049(
                Constants.MOD_ID + ":chisel_preview_inside_blocks",
                class_290.field_29337,
                class_293.class_5596.field_27377,
                256,
                false,
                false,
                class_1921.class_4688.method_23598()
                        .method_34578(field_29433)
                        .method_23609(new class_4677(OptionalDouble.of(2.5d)))
                        .method_23607(field_22241)
                        .method_23615(field_21370)
                        .method_23610(field_25280)
                        .method_23616(field_21350)
                        .method_23603(field_21345)
                        .method_23604(InternalState.GREATER_OR_EQUAL_DEPTH_TEST)
                        .method_23617(false));

        private static final class_1921 CHISEL_PREVIEW_OUTSIDE_BLOCKS = class_1921.method_24049(
                Constants.MOD_ID + ":chisel_preview_outside_blocks",
                class_290.field_29337,
                class_293.class_5596.field_27377,
                256,
                false,
                false,
                class_1921.class_4688.method_23598()
                        .method_34578(field_29433)
                        .method_23609(new class_4677(OptionalDouble.of(2.5d)))
                        .method_23607(field_22241)
                        .method_23615(field_21370)
                        .method_23610(field_25280)
                        .method_23616(field_21350)
                        .method_23603(field_21345)
                        .method_23604(InternalState.LESS_OR_EQUAL_DEPTH_TEST)
                        .method_23617(false));

        private static final class_1921 WIREFRAME_LINES = buildWireframeType(false);
        private static final class_1921 WIREFRAME_LINES_ALWAYS = buildWireframeType(true);
        private static final class_1921 WIREFRAME_BODY = class_1921.method_24049(
                Constants.MOD_ID + ":wireframe_body",
                class_290.field_1590,
                class_293.class_5596.field_27382,
                2097152,
                false,
                true,
                class_4688.method_23598()
                        .method_34578(class_1921.field_29443)
                        .method_23607(field_22241)
                        .method_23615(field_21364)
                        .method_23610(field_25280)
                        .method_23616(field_21350)
                        .method_23603(field_21345)
                        .method_23604(field_21346)
                        .method_23617(false));
        private static final class_4683 BLOCK_TEXTURE =
                new class_4683(class_1059.field_5275, false, false);
        private static final class_4672 field_44814 = new class_4672(">", GL11.GL_GREATER);
        private static final class_1921 GHOST_BLOCK_PREVIEW = buildGhostType(false);
        private static final class_1921 GHOST_BLOCK_PREVIEW_GREATER = buildGhostType(true);
        private static final class_1921 GHOST_BLOCK_COLORED_PREVIEW = buildColoredGhostType(false);
        private static final class_1921 GHOST_BLOCK_COLORED_PREVIEW_ALWAYS = buildColoredGhostType(true);

        private InternalType(
                String name,
                class_293 fmt,
                class_293.class_5596 glMode,
                int size,
                boolean doCrumbling,
                boolean depthSorting,
                Runnable onEnable,
                Runnable onDisable) {
            super(name, fmt, glMode, size, doCrumbling, depthSorting, onEnable, onDisable);
            throw new IllegalStateException("This class must not be instantiated");
        }

        private static class_1921 buildWireframeType(final boolean always) {
            return class_1921.method_24049(
                    Constants.MOD_ID + ":wireframe_lines" + (always ? "_always" : ""),
                    class_290.field_1576,
                    class_293.class_5596.field_27377,
                    256,
                    false,
                    true,
                    class_4688.method_23598()
                            .method_34578(field_29433)
                            .method_23609(new class_4677(OptionalDouble.of(3d)))
                            .method_23607(field_22241)
                            .method_23615(field_21370)
                            .method_23610(field_25280)
                            .method_23616(field_21350)
                            .method_23603(field_21345)
                            .method_23604(always ? InternalState.DISABLED_DEPTH_TEST : field_21348)
                            .method_23617(false));
        }

        private static class_1921 buildGhostType(final boolean greater) {
            if (!greater) {
                return class_4722.method_24076();
            }
            // DEPTH TEST TAKES BIG ROLE
            return class_1921.method_24049(
                    Constants.MOD_ID + ":ghost_block_preview_greater",
                    class_290.field_1580,
                    class_293.class_5596.field_27382,
                    256,
                    true,
                    true,
                    class_4688.method_23598()
                            .method_34578(class_1921.field_29406)
                            .method_34577(BLOCK_TEXTURE)
                            .method_23615(field_21370)
                            .method_23608(field_21383)
                            .method_23611(field_21385)
                            .method_23604(InternalState.field_21348) // Only difference from
                            // RenderType#ENTITY_TRANSLUCENT_CULL
                            .method_23617(false));
        }

        private static class_1921 buildColoredGhostType(final boolean always) {
            return class_1921.method_24049(
                    Constants.MOD_ID + ":ghost_block_colored_preview" + (always ? "_always" : ""),
                    class_290.field_29337,
                    class_293.class_5596.field_27382,
                    256,
                    false,
                    false,
                    class_4688.method_23598()
                            .method_34578(field_29442)
                            .method_23615(field_21370)
                            .method_23604(always ? InternalState.DISABLED_DEPTH_TEST : field_21348)
                            .method_23617(false));
        }
    }
}
