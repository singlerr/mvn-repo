package mod.chiselsandbits.crafting;

import java.util.ArrayList;
import java.util.List;
import mod.chiselsandbits.api.StateCount;
import mod.chiselsandbits.bitbag.BagInventory;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.minecraft.class_1263;
import net.minecraft.class_1799;

class ChiselCraftingRequirements {
    final class_1799 pattern;
    final class_1799[] pile;
    private final VoxelBlob voxelBlob;
    private final ArrayList<class_1799> stacks = new ArrayList<class_1799>();
    private final ArrayList<BagInventory> bags = new ArrayList<BagInventory>();
    private Boolean isValid = null;

    public ChiselCraftingRequirements(final class_1263 inv, final class_1799 inPattern, final boolean copy) {
        pile = new class_1799[inv.method_5439()];
        pattern = inPattern;

        for (int x = 0; x < inv.method_5439(); x++) {
            final class_1799 is = inv.method_5438(x);
            pile[x] = is;

            if (!copy) {
                // if we are not copying.. then we remove it...
                inv.method_5447(x, ModUtil.getEmptyStack());
            }

            if (is == null) {
                continue;
            }

            if (is.method_7909() instanceof ItemBitBag) {
                bags.add(new BagInventory(copy ? is.method_7972() : is));
            }

            if (is.method_7909() instanceof ItemChiseledBit) {
                stacks.add(copy ? is.method_7972() : is);
            }
        }

        voxelBlob = ModUtil.getBlobFromStack(inPattern, null);
    }

    public boolean isValid() {
        if (isValid != null) {
            return isValid;
        }

        final List<StateCount> count = voxelBlob.getStateCounts();

        isValid = true;
        for (final StateCount ref : count) {
            if (ref.stateId != 0) {

                for (final class_1799 is : stacks) {
                    if (ItemChiseledBit.getStackState(is) == ref.stateId && ModUtil.notEmpty(is)) {
                        final int original = ModUtil.getStackSize(is);
                        ModUtil.setStackSize(is, Math.max(0, ModUtil.getStackSize(is) - ref.quantity));
                        ref.quantity -= original - ModUtil.getStackSize(is);
                    }
                }

                for (final BagInventory bag : bags) {
                    ref.quantity -= bag.extractBit(ref.stateId, ref.quantity);
                }

                if (ref.quantity > 0) {
                    isValid = false;
                    break;
                }
            }
        }
        return isValid;
    }
}
