package mod.chiselsandbits.crafting;

import javax.annotation.Nonnull;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.registry.ModRecipeSerializers;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2371;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class StackableCrafting extends class_1852 {

    public StackableCrafting(class_7710 name) {
        super(name);
    }

    @Override
    public boolean matches(final class_8566 craftingInv, final class_1937 worldIn) {
        class_1799 target = null;

        for (int x = 0; x < craftingInv.method_5439(); x++) {
            final class_1799 f = craftingInv.method_5438(x);
            if (ModUtil.isEmpty(f)) {
                continue;
            }

            if (target == null) {
                target = f;
            } else {
                return false;
            }
        }

        return target != null && target.method_7985() && target.method_7909() instanceof ItemBlockChiseled;
    }

    @Override
    public class_1799 assemble(class_8566 craftingInv, class_5455 registryAccess) {
        class_1799 target = null;

        for (int x = 0; x < craftingInv.method_5439(); x++) {
            final class_1799 f = craftingInv.method_5438(x);
            if (ModUtil.isEmpty(f)) {
                continue;
            }

            if (target == null) {
                target = f;
            } else {
                return ModUtil.getEmptyStack();
            }
        }

        if (target == null || !target.method_7985() || !(target.method_7909() instanceof ItemBlockChiseled)) {
            return ModUtil.getEmptyStack();
        }

        return getSortedVersion(target);
    }

    private class_1799 getSortedVersion(final @Nonnull class_1799 stack) {
        final NBTBlobConverter tmp = new NBTBlobConverter();
        tmp.readChisleData(ModUtil.getSubCompound(stack, ModUtil.NBT_BLOCKENTITYTAG, false), VoxelBlob.VERSION_ANY);

        VoxelBlob bestBlob = tmp.getBlob();
        byte[] bestValue = bestBlob.toLegacyByteArray();

        VoxelBlob lastBlob = bestBlob;
        for (int x = 0; x < 34; x++) {
            lastBlob = lastBlob.spin(class_2351.field_11052);
            final byte[] aValue = lastBlob.toLegacyByteArray();

            if (arrayCompare(bestValue, aValue)) {
                bestBlob = lastBlob;
                bestValue = aValue;
            }
        }

        tmp.setBlob(bestBlob);
        return tmp.getItemStack(false);
    }

    private boolean arrayCompare(final byte[] bestValue, final byte[] aValue) {
        if (aValue.length < bestValue.length) {
            return true;
        }

        if (aValue.length > bestValue.length) {
            return false;
        }

        for (int x = 0; x < aValue.length; x++) {
            if (aValue[x] < bestValue[x]) {
                return true;
            }

            if (aValue[x] > bestValue[x]) {
                return false;
            }
        }

        return false;
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return true;
    }

    @Override
    public class_1799 method_8110(class_5455 registryAccess) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_8566 inv) {
        final class_2371<class_1799> aitemstack = class_2371.method_10213(inv.method_5439(), class_1799.field_8037);

        for (int i = 0; i < aitemstack.size(); ++i) {
            final class_1799 itemstack = ModUtil.nonNull(inv.method_5438(i));
            if (itemstack.method_7909().method_7857()) {
                aitemstack.set(i, new class_1799(itemstack.method_7909().method_7858()));
            }
        }

        return aitemstack;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.STACKABLE_CRAFTING.get();
    }
}
