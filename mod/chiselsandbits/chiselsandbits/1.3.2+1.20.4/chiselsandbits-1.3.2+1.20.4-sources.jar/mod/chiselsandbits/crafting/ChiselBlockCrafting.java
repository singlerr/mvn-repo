package mod.chiselsandbits.crafting;

import mod.chiselsandbits.api.APIExceptions.InvalidBitItem;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.IBitBag;
import mod.chiselsandbits.api.IBitBrush;
import mod.chiselsandbits.api.IBitVisitor;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.registry.ModRecipeSerializers;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2680;
import net.minecraft.class_5455;
import net.minecraft.class_5819;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class ChiselBlockCrafting extends class_1852 {

    public ChiselBlockCrafting(class_7710 name) {
        super(name);
    }

    private ChiselBlockInfo getInfo(final class_8566 inv) {
        final ChiselBlockInfo i = new ChiselBlockInfo();
        boolean noDuplicates = true;
        boolean noStrangeitems = true;

        for (int x = 0; x < inv.method_5439(); ++x) {
            final class_1799 is = inv.method_5438(x);

            if (ModUtil.isEmpty(is)) {
                continue;
            }

            if (is.method_7909() instanceof ItemBitBag) {
                if (i.bag_slot != -1) {
                    noDuplicates = false;
                }

                i.bag = is;
                i.bag_slot = x;
                continue;
            }

            if (is.method_7909() instanceof ItemChisel) {
                if (i.chisel_slot != -1) {
                    noDuplicates = false;
                }

                i.chisel = is;
                i.chisel_slot = x;
                continue;
            }

            if (is.method_7909() instanceof class_1747) {
                if (i.block_slot != -1) {
                    noDuplicates = false;
                }

                final class_2680 actingState = ModUtil.getStateFromItem(is);
                if (actingState.method_26204() != class_2246.field_10124) {
                    try {
                        final IBitBrush state = ChiselsAndBits.getApi().createBrushFromState(actingState);
                        final IBitAccess item = ChiselsAndBits.getApi().createBitItem(ModUtil.getEmptyStack());
                        assert item != null;

                        item.visitBits(new IBitVisitor() {

                            @Override
                            public IBitBrush visitBit(
                                    final int x, final int y, final int z, final IBitBrush currentValue) {
                                return state;
                            }
                        });

                        i.block = item.getBitsAsItem(class_2350.field_11034, ItemType.CHISELED_BLOCK, false);
                        if (i.block != null) {
                            ModUtil.setStackSize(i.block, ModUtil.getStackSize(is));
                            i.block_slot = x;
                            continue;
                        }
                    } catch (final InvalidBitItem err) {
                        // not supported.
                    }
                }
            }

            if (is.method_7909() instanceof ItemBlockChiseled) {
                if (i.block_slot != -1) {
                    noDuplicates = false;
                }

                i.block = is;
                i.block_slot = x;
                continue;
            }

            noStrangeitems = false;
        }

        i.isValid = i.chisel_slot != -1 && i.bag_slot != -1 && i.block_slot != -1 && noDuplicates && noStrangeitems;

        return i;
    }

    @Override
    public boolean matches(final class_8566 inv, final class_1937 worldIn) {
        return getInfo(inv).isValid;
    }

    @Override
    public class_1799 assemble(class_8566 inv, class_5455 registryAccess) {
        final ChiselBlockInfo cbc = getInfo(inv);
        cbc.doLogic();

        if (cbc.isValid && cbc.modified) {
            return cbc.bag;
        }

        return ModUtil.getEmptyStack();
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return width * height > 3;
    }

    @Override
    public class_1799 method_8110(class_5455 registryAccess) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_8566 inv) {
        final class_2371<class_1799> list = class_2371.method_10211();

        final ChiselBlockInfo cbc = getInfo(inv);
        cbc.doLogic();

        boolean damageTools = ChiselsAndBits.getConfig().getServer().damageTools.get();
        for (int x = 0; x < inv.method_5439(); ++x) {
            if (cbc.isValid
                    && x == cbc.chisel_slot
                    && !ModUtil.isEmpty(cbc.chisel)
                    && (!damageTools || cbc.chisel.method_7919() < cbc.chisel.method_7936())) {
                list.add(cbc.chisel);
            } else if (cbc.isValid && x == cbc.block_slot && !ModUtil.isEmpty(cbc.block)) {
                class_1799 block = ModUtil.copy(cbc.block);
                ModUtil.setStackSize(block, 1);
                list.add(block);
            } else {
                list.add(ModUtil.getEmptyStack());
            }
        }

        return list;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.CHISEL_BLOCK_CRAFTING.get();
    }

    private static class ChiselBlockInfo {
        public class_1799 chisel = ModUtil.getEmptyStack();
        public int chisel_slot = -1;

        public class_1799 bag = ModUtil.getEmptyStack();
        public int bag_slot = -1;

        public class_1799 block = ModUtil.getEmptyStack();
        public int block_slot = -1;

        public boolean isValid;
        public boolean modified = false;

        public void doLogic() {
            bag = ModUtil.copy(bag);
            block = ModUtil.copy(block);
            chisel = ModUtil.copy(chisel);

            try {
                final IBitAccess ba = ChiselsAndBits.getApi().createBitItem(block);
                final Chiseler c = new Chiseler(chisel, ChiselsAndBits.getApi().getBitbag(bag));

                if (ba == null) {
                    return;
                }

                ba.visitBits(c);

                modified = c.modified;

                if (!c.isAir) {
                    block = ba.getBitsAsItem(class_2350.field_11043, ItemType.CHISELED_BLOCK, false);
                } else {
                    block = ModUtil.getEmptyStack();
                }
            } catch (final InvalidBitItem e) {

            }
        }

        private static class Chiseler implements IBitVisitor {
            final IBitBrush airBrush;
            private final class_1799 chisel;
            private final IBitBag bbag;
            private final class_5819 r = class_5819.method_43047();
            public boolean isAir = true;
            public boolean modified = false;

            public Chiseler(final class_1799 chisel, final IBitBag bag) throws InvalidBitItem {
                airBrush = ChiselsAndBits.getApi().createBrushFromState(null);
                this.chisel = chisel;
                bbag = bag;
                r.method_43052(0); // ensure that the results are always the same,
                // crafting needs to be 'regular'
            }

            @Override
            public IBitBrush visitBit(final int x, final int y, final int z, final IBitBrush currentValue) {
                if (currentValue.isAir()) {
                    return currentValue;
                }

                boolean damageTools =
                        ChiselsAndBits.getConfig().getServer().damageTools.get();

                if (chisel.method_7919() < chisel.method_7936() || !damageTools) {
                    if (damageTools) {
                        ModUtil.damageItem(chisel, r);
                    }

                    final class_1799 is = currentValue.getItemStack(1);
                    if (is != null) {
                        for (int idx = 0; idx < bbag.getSlots(); ++idx) {
                            if (ModUtil.isEmpty(bbag.insertItem(idx, is, false))) {
                                modified = true;
                                return airBrush;
                            }
                        }
                    }
                }

                isAir = false;
                return currentValue;
            }
        }
    }
}
