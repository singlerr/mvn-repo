package mod.chiselsandbits.crafting;

import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.registry.ModRecipeSerializers;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class BagDyeing extends class_1852 {

    public BagDyeing(class_7710 name) {

        super(name);
    }

    @Override
    public class_1799 assemble(class_8566 inv, class_5455 registryAccess) {
        dyed_output output = getOutput(inv);

        if (output != null) {
            ModItems.ITEM_BIT_BAG_DEFAULT.get();
            return ItemBitBag.dyeBag(output.bag, output.color);
        }

        return ModUtil.getEmptyStack();
    }

    private dyed_output getOutput(class_8566 inv) {
        class_1799 bag = null;
        class_1799 dye = null;

        for (int x = 0; x < inv.method_5439(); ++x) {
            class_1799 is = inv.method_5438(x);
            if (is != null && !ModUtil.isEmpty(is)) {
                if (is.method_7909() == class_1802.field_8705 || getDye(is) != null) {
                    if (dye == null) {
                        dye = is;
                    } else {
                        return null;
                    }
                } else if (is.method_7909() instanceof ItemBitBag) {
                    if (bag == null) {
                        bag = is;
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            }
        }

        if (bag != null && dye != null) {
            return new dyed_output(bag, getDye(dye));
        }

        return null;
    }

    private class_1767 getDye(class_1799 is) {
        if (is.method_7909() instanceof class_1769 item) {
            return item.method_7802();
        }

        return null;
    }

    @Override
    public boolean matches(final class_8566 inv, final class_1937 worldIn) {
        return getOutput(inv) != null;
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return width * height >= 2;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.BAG_DYEING.get();
    }

    private static class dyed_output {
        class_1799 bag;
        class_1767 color;

        public dyed_output(class_1799 bag, class_1767 dye) {
            this.bag = bag;
            this.color = dye;
        }
    }
}
