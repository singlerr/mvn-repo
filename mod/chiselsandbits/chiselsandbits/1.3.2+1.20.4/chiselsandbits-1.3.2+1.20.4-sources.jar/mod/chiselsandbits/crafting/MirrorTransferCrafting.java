package mod.chiselsandbits.crafting;

import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.registry.ModRecipeSerializers;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class MirrorTransferCrafting extends class_1852 {

    public MirrorTransferCrafting(class_7710 name) {
        super(name);
    }

    @Override
    public boolean matches(final class_8566 craftingInv, final class_1937 worldIn) {
        return analzyeCraftingInventory(craftingInv, true) != null;
    }

    public class_1799 analzyeCraftingInventory(final class_8566 craftingInv, final boolean generatePattern) {
        class_1799 targetA = null;
        class_1799 targetB = null;

        boolean isNegative = false;

        for (int x = 0; x < craftingInv.method_5439(); x++) {
            final class_1799 f = craftingInv.method_5438(x);
            if (f == null) {
                continue;
            }

            if (f.method_7909().equals(ModItems.ITEM_MIRROR_PRINT_WRITTEN.get())) {
                if (ModItems.ITEM_MIRROR_PRINT.get().isWritten(f)) {
                    if (targetA != null) {
                        return null;
                    }

                    targetA = f;
                } else {
                    return null;
                }
            } else if (f.method_7909().equals(ModItems.ITEM_NEGATIVE_PRINT.get())) {
                if (!ModItems.ITEM_NEGATIVE_PRINT.get().isWritten(f)) {
                    if (targetB != null) {
                        return null;
                    }

                    isNegative = true;
                    targetB = f;
                } else {
                    return null;
                }
            } else if (f.method_7909().equals(ModItems.ITEM_POSITIVE_PRINT.get())) {
                if (!ModItems.ITEM_POSITIVE_PRINT.get().isWritten(f)) {
                    if (targetB != null) {
                        return null;
                    }

                    isNegative = false;
                    targetB = f;
                } else {
                    return null;
                }
            } else if (!ModUtil.isEmpty(f)) {
                return null;
            }
        }

        if (targetA != null && targetB != null) {
            if (generatePattern) {
                return targetA;
            }

            final NBTBlobConverter tmp = new NBTBlobConverter();
            tmp.readChisleData(targetA.method_7969(), VoxelBlob.VERSION_ANY);

            final VoxelBlob bestBlob = tmp.getBlob();

            if (isNegative) {
                bestBlob.binaryReplacement(0, ModUtil.getStateId(class_2246.field_10340.method_9564()));
            }

            tmp.setBlob(bestBlob);

            final class_2487 comp = ModUtil.getTagCompound(targetA).method_10553();
            tmp.writeChisleData(comp, false);

            class_1792 resultItem;

            if (targetB.method_7909().equals(ModItems.ITEM_NEGATIVE_PRINT.get())) {
                resultItem = ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get();
            } else {
                resultItem = ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get();
            }

            final class_1799 outputPattern = new class_1799(resultItem);
            outputPattern.method_7980(comp);

            return outputPattern;
        }

        return null;
    }

    @Override
    public class_1799 assemble(class_8566 craftingInv, class_5455 registryAccess) {
        return analzyeCraftingInventory(craftingInv, false);
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return width > 1 || height > 1;
    }

    @Override
    public class_1799 method_8110(class_5455 registryAccess) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_8566 craftingInv) {
        final class_2371<class_1799> aitemstack = class_2371.method_10213(craftingInv.method_5439(), class_1799.field_8037);

        for (int i = 0; i < aitemstack.size(); ++i) {
            final class_1799 itemstack = craftingInv.method_5438(i);
            if (itemstack.method_7909() == ModItems.ITEM_MIRROR_PRINT_WRITTEN.get() && itemstack.method_7985()) {
                ModUtil.adjustStackSize(itemstack, 1);
            }
        }

        return aitemstack;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.MIRROR_TRANSFER_CRAFTING.get();
    }
}
