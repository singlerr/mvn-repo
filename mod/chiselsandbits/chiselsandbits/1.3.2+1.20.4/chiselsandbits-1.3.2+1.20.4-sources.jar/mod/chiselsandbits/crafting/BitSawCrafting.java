package mod.chiselsandbits.crafting;

import java.util.List;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.api.StateCount;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.BitIterator;
import mod.chiselsandbits.chiseledblock.data.IntegerBox;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.api.BitAccess;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitSaw;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModRecipeSerializers;
import mod.chiselsandbits.utils.ItemStackUtils;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2371;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class BitSawCrafting extends class_1852 {

    public BitSawCrafting(class_7710 name) {
        super(name);
    }

    private SawCraft getSawCraft(final class_8566 inv) {
        final SawCraft r = new SawCraft();

        for (int x = 0; x < inv.method_17398(); ++x) {
            for (int y = 0; y < inv.method_17397(); ++y) {
                final class_1799 is = inv.method_5438(x + y * inv.method_17398());

                if (!ModUtil.isEmpty(is)) {
                    if (is.method_7909() instanceof ItemBitSaw) {
                        if (r.sawPosX != -1) {
                            return null;
                        }

                        r.sawPosX = x;
                        r.sawPosY = y;
                        continue;
                    }

                    if (is.method_7909() instanceof ItemBlockChiseled) {
                        if (r.blockPosX != -1) {
                            return null;
                        }

                        r.chisledBlock = is;
                        r.blockPosX = x;
                        r.blockPosY = y;
                        continue;
                    }

                    if (is != null && is.method_7909() instanceof class_1747 blkItem) {
                        final class_2680 state = blkItem.method_7711().method_9564();

                        if (!BlockBitInfo.isSupported(state)) {
                            return null;
                        }

                        if (r.blockPosX != -1) {
                            return null;
                        }

                        r.chisledBlock = is;
                        r.blockPosX = x;
                        r.blockPosY = y;
                        continue;
                    }

                    return null;
                }
            }
        }

        if (r.sawPosX == -1 || r.blockPosX == -1) {
            return null;
        }

        return r;
    }

    @Override
    public boolean matches(final class_8566 inv, final class_1937 worldIn) {
        return getSawCraft(inv) != null;
    }

    @Override
    public class_1799 assemble(class_8566 inv, class_5455 registryAccess) {
        final SawCraft sc = getSawCraft(inv);

        if (sc == null) {
            return ModUtil.getEmptyStack();
        }

        final IBitAccess contents = ChiselsAndBits.getApi().createBitItem(sc.chisledBlock);
        if (contents == null) {
            return ModUtil.getEmptyStack();
        }

        final VoxelBlob blob = ((BitAccess) contents).getNativeBlob();

        final VoxelBlob a = new VoxelBlob();
        final VoxelBlob b = new VoxelBlob();

        final int sawOffsetX = sc.sawPosX - sc.blockPosX;
        final int sawOffsetY = sc.sawPosY - sc.blockPosY;

        class_2351 direction = null;
        if (sawOffsetY == 0) {
            direction = class_2351.field_11048;
        } else if (sawOffsetX == 0) {
            direction = class_2351.field_11052;
        } else {
            direction = class_2351.field_11051;
        }

        int split_pos = 7;
        final IntegerBox box = blob.getBounds();
        int scale = 0;

        switch (direction) {
            case field_11048:
                split_pos = class_3532.method_15340((box.maxX + box.minX) / 2, 0, 15);
                scale = (box.maxX - box.minX) / 2;
                break;
            case field_11052:
                split_pos = class_3532.method_15340((box.maxY + box.minY) / 2, 0, 15);
                scale = (box.maxY - box.minY) / 2;
                break;
            case field_11051:
                split_pos = class_3532.method_15340((box.maxZ + box.minZ) / 2, 0, 15);
                scale = (box.maxZ - box.minZ) / 2;
                break;
        }

        final int split_pos_plus_one = class_3532.method_15340(split_pos + 1, 0, 15);

        final BitIterator bi = new BitIterator();
        while (bi.hasNext()) {
            final int state = bi.getNext(blob);
            if (state == 0) {
                continue;
            }

            switch (direction) {
                case field_11048:
                    if (bi.x > split_pos) {
                        a.set(scale - (bi.x - split_pos_plus_one), bi.y - box.minY, bi.z - box.minZ, state);
                    } else {
                        b.set(bi.x - box.minX, bi.y - box.minY, bi.z - box.minZ, state);
                    }

                    break;
                case field_11052:
                    if (bi.y > split_pos) {
                        a.set(bi.x - box.minX, scale - (bi.y - split_pos_plus_one), bi.z - box.minZ, state);
                    } else {
                        b.set(bi.x - box.minX, bi.y - box.minY, bi.z - box.minZ, state);
                    }

                    break;
                case field_11051:
                    if (bi.z > split_pos) {
                        a.set(bi.x - box.minX, bi.y - box.minY, scale - (bi.z - split_pos_plus_one), state);
                    } else {
                        b.set(bi.x - box.minX, bi.y - box.minY, bi.z - box.minZ, state);
                    }

                    break;
            }
        }

        if (a.equals(b)) {
            final List<StateCount> refs = a.getStateCounts();

            if (refs.size() == 2) {
                boolean good = false;
                int outState = -1;
                for (final StateCount tr : refs) {
                    if (tr.stateId != 0 && tr.quantity == 1) {
                        outState = tr.stateId;
                    } else if (tr.stateId == 0 && tr.quantity == VoxelBlob.full_size - 1) {
                        good = true;
                    }
                }

                if (good && outState != -1) {
                    final class_1799 stack = ItemChiseledBit.createStack(outState, 2, false);

                    if (stack != null) {
                        return stack;
                    }
                }
            }

            blob.fill(a);
            final class_1799 out = contents.getBitsAsItem(null, ItemType.CHISELED_BLOCK, false);

            if (out != null) {
                ModUtil.setStackSize(out, 2);
                return out;
            }
        }

        return ModUtil.getEmptyStack();
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return false;
    }

    @Override
    public class_1799 method_8110(class_5455 registryAccess) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_8566 inv) {

        final class_2371<class_1799> aitemstack = class_2371.method_10213(inv.method_5439(), class_1799.field_8037);

        for (int i = 0; i < aitemstack.size(); ++i) {
            final class_1799 itemstack = inv.method_5438(i);

            aitemstack.set(i, ItemStackUtils.getContainerItem(itemstack));
        }

        return aitemstack;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.BIT_SAW_CRAFTING.get();
    }

    private static class SawCraft {
        int sawPosX = -1;
        int blockPosX = -1;
        int sawPosY = -1;
        int blockPosY = -1;
        class_1799 chisledBlock = null;
    }
}
