package mod.chiselsandbits.crafting;

import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.registry.ModRecipeSerializers;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class ChiselCrafting extends class_1852 {

    public ChiselCrafting(class_7710 name) {
        super(name);
    }

    /**
     * Find the bag and pattern...
     *
     * @param inv
     * @return
     */
    private ChiselCraftingRequirements getCraftingReqs(final class_8566 inv, final boolean copy) {
        class_1799 pattern = null;

        for (int x = 0; x < inv.method_5439(); x++) {
            final class_1799 is = inv.method_5438(x);

            if (is == null) {
                continue;
            }

            if (is.method_7909() == ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get() && pattern == null) {
                pattern = is;
            } else if (is.method_7909() instanceof ItemBitBag) {
                continue;
            } else if (is.method_7909() instanceof ItemChiseledBit) {
                continue;
            } else if (!ModUtil.isEmpty(is)) {
                return null;
            }
        }

        if (pattern == null || !pattern.method_7985()) {
            return null;
        }

        final ChiselCraftingRequirements r = new ChiselCraftingRequirements(inv, pattern, copy);
        if (r.isValid()) {
            return r;
        }

        return null;
    }

    @Override
    public boolean matches(final class_8566 inv, final class_1937 worldIn) {
        return getCraftingReqs(inv, true) != null;
    }

    @Override
    public class_1799 assemble(class_8566 inv, class_5455 registryAccess) {
        final ChiselCraftingRequirements req = getCraftingReqs(inv, true);

        if (req != null) {
            return ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get().getPatternedItem(req.pattern, true);
        }

        return ModUtil.getEmptyStack();
    }

    @Override
    public boolean method_8113(final int width, final int height) {
        return width * height > 3;
    }

    @Override
    public class_1799 method_8110(class_5455 registryAccess) {
        return ModUtil.getEmptyStack();
    }

    @Override
    public class_2371<class_1799> getRemainingItems(final class_8566 inv) {
        final class_2371<class_1799> out = class_2371.method_10213(inv.method_5439(), class_1799.field_8037);

        // just getting this will alter the stacks..
        final ChiselCraftingRequirements r = getCraftingReqs(inv, false);

        if (inv.method_5439() != r.pile.length) {
            throw new RuntimeException("Inventory Changed Size!");
        }

        for (int x = 0; x < r.pile.length; x++) {

            if (r.pile[x] != null && ModUtil.getStackSize(r.pile[x]) > 0) {
                out.set(x, r.pile[x]);
            }
        }

        return out;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.CHISEL_CRAFTING.get();
    }
}
