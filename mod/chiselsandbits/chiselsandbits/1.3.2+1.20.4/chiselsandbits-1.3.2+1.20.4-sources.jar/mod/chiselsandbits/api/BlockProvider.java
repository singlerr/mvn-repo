package mod.chiselsandbits.api;

import java.util.Collection;
import net.minecraft.class_2248;

public interface BlockProvider {

    Collection<class_2248> getBlocks();
}
