package mod.chiselsandbits.api;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class EventFullBlockRestoration {

    private final class_1937 w;
    private final class_2338 pos;
    private final class_2680 restoredState;
    private boolean cancelled;

    public EventFullBlockRestoration(final class_1937 w, final class_2338 pos, final class_2680 restoredState) {

        this.w = w;
        this.pos = pos;
        this.restoredState = restoredState;
    }

    public class_1937 getWorld() {
        return w;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getState() {
        return restoredState;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}
