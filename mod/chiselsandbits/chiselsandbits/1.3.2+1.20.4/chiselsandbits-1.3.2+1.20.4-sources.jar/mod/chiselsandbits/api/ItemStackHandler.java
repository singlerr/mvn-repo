package mod.chiselsandbits.api;

import net.minecraft.class_1799;
import net.minecraft.class_2680;

public interface ItemStackHandler {

    void apply(class_2680 state, class_1799 stack);
}
