package mod.chiselsandbits.api;

import net.minecraft.class_2338;
import net.minecraft.class_2350;

/**
 * Do not implement, acquire from {@link IChiselAndBitsAPI}
 */
public interface IBitLocation {

    /**
     * Get block position that the bit is inside.
     *
     * @return Block Pos
     */
    class_2338 getBlockPos();

    /**
     * get Bit X coordinate.
     *
     * @return X coordinate
     */
    int getBitX();

    /**
     * get Bit Y coordinate.
     *
     * @return Y coordinate
     */
    int getBitY();

    /**
     * get Bit Z coordinate.
     *
     * @return Z coordinate
     */
    int getBitZ();

    /**
     * Offsets the bit location into the given direction by one.
     * Possibly moving it to a new block if need be.
     *
     * @param direction The direction.
     */
    IBitLocation offSet(final class_2350 direction);
}
