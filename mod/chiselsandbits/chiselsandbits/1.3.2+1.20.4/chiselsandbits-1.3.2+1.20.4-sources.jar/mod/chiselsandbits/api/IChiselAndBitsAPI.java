package mod.chiselsandbits.api;

import javax.annotation.Nullable;
import mod.chiselsandbits.api.APIExceptions.CannotBeChiseled;
import mod.chiselsandbits.api.APIExceptions.InvalidBitItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_4587;
import org.jetbrains.annotations.NotNull;

/**
 * Do not implement, is passed to your {@link IChiselsAndBitsAddon}
 */
public interface IChiselAndBitsAPI {

    void registerBlockProvider(BlockProvider provider);

    void registerItemStackHandler(class_2248 block, @NotNull ItemStackHandler provider);

    /**
     * Determine the Item Type of the item in an ItemStack and return it.
     *
     * @param stack
     * @return ItemType of the item, or null if it is not any of them.
     */
    @Nullable
    ItemType getItemType(class_1799 stack);

    /**
     * Check if a block can support {@link IBitAccess}
     *
     * @param world
     * @param pos
     * @return true if the block can be chiseled, this is true for air,
     * multi-parts, and blocks which can be chiseled, false otherwise.
     */
    boolean canBeChiseled(class_1937 world, class_2338 pos);

    /**
     * is this block already chiseled?
     *
     * @param world
     * @param pos
     * @return true if the block contains chiseled bits, false otherwise.
     */
    boolean isBlockChiseled(class_1937 world, class_2338 pos);

    /**
     * Get Access to the bits for a given block.
     *
     * @param world
     * @param pos
     * @return A {@link IBitAccess} for the specified location.
     * @throws CannotBeChiseled when the location cannot support bits, or if the parameters
     *                          are invalid.
     */
    IBitAccess getBitAccess(class_1937 world, class_2338 pos) throws CannotBeChiseled;

    /**
     * Create a bit access from an ItemStack, passing an empty ItemStack creates
     * an empty bit access, passing an invalid item returns null.
     *
     * @return a {@link IBitAccess} for an ItemStack.
     */
    @Nullable
    IBitAccess createBitItem(class_1799 stack);

    /**
     * Create a brush from an ItemStack, once created you can use it many times.
     *
     * @param stack the stack.
     * @return A brush for the specified ItemStack, if passed an empty ItemStack
     * an air brush is created.
     * @throws InvalidBitItem
     */
    IBitBrush createBrush(class_1799 stack) throws InvalidBitItem;

    /**
     * Create a brush from a state, once created you can use it many times.
     *
     * @param state
     * @return A brush for the specified state, if null is passed for the item
     * an air brush is created.
     * @throws InvalidBitItem
     */
    IBitBrush createBrushFromState(@Nullable class_2680 state) throws InvalidBitItem;

    /**
     * Convert ray trace information into bit location information, note that
     * the block position can change, be aware.
     *
     * @param hitX
     * @param hitY
     * @param hitZ
     * @param side
     * @param pos
     * @param placement
     * @return details about the target bit, no arguments should be null.
     */
    IBitLocation getBitPos(double hitX, double hitY, double hitZ, class_2350 side, class_2338 pos, boolean placement);

    /**
     * Get an ItemStack for the bit type of the state...
     * <p>
     * VERY IMPORTANT: C&B lets you disable bits, if this happens the Item in
     * this ItemStack WILL BE empty.
     *
     * @param defaultState
     * @return the bit.
     */
    class_1799 getBitItem(class_2680 defaultState) throws InvalidBitItem;

    /**
     * Give a bit to a player, it will end up in their inventory, a bag, or if
     * there is no where to put it, on the ground.
     * <p>
     * CLIENT: destroys the item.
     * <p>
     * SERVER: adds ItemStack to inv/bag/spawns entity.
     *
     * @param player   player to give bits to.
     * @param stack    bits to store.
     * @param spawnPos if null defaults to the players position, absolute position of
     *                 where to spawn bits, should be in the block near where they
     *                 are being extracted from.
     */
    void giveBitToPlayer(class_1657 player, class_1799 stack, class_243 spawnPos);

    /**
     * Access the contents of a bitbag as if it was a normal
     * {@link IItemHandler} with a few extra features.
     *
     * @return internal object to manipulate bag.
     */
    @Nullable
    IBitBag getBitbag(class_1799 stack);

    /**
     * Example: int stackSize =
     * api.getParameter(IntegerParam.BIT_BAG_MAX_STACK_SIZE );
     *
     * @param which - refer to ParameterType for list of possible values.
     * @return value of specified parameter.
     */
    <T extends Object> T getParameter(ParameterType<T> which);

    /**
     * Begins an undo group, starting two operations without ending the previous
     * operation will throw a runtime exception.
     *
     * This is used to merge multiple blocks into a single operation, undo steps
     * will be recorded regardless of usage of this method, however its
     * suggested to use groups in any case where a change well affect more then
     * one block.
     *
     * @formatter:off
     *
     * 				Example:
     *
     *                try { api.beginUndoGroup(); this.manipulateAllTheBlocks();
     *                } finally { api.endUndoGroup(); }
     *
     */
    void beginUndoGroup(class_1657 player);

    /**
     * Ends a previously running undo group, must be called after starting an
     * undo group, closing a group without opening one will result in a runtime
     * exception.
     */
    void endUndoGroup(class_1657 player);

    /**
     * Get a C&B key binding.
     *
     * @param modKeyBinding
     *            the {@link ModKeyBinding} value that denotes the C&B key
     *            binding to return.
     * @return a C&B {@link class_304}.
     */
    @Environment(EnvType.CLIENT)
    class_304 getKeyBinding(ModKeyBinding modKeyBinding);

    /**
     * Renders a model with transparency.
     *
     * @param model
     * @param world
     * @param pos
     * @param alpha
     *            Should be 0-255.
     */
    @Environment(EnvType.CLIENT)
    void renderModel(
            final class_4587 stack,
            final class_1087 model,
            final class_1937 world,
            final class_2338 pos,
            final int alpha,
            final int combinedLight,
            final int combinedOverlay);

    /**
     * Renders a ghost model in the same way that chiseled item blocks are rendered for placement.
     *
     * @param model
     * @param world
     * @param pos
     * @param isUnplaceable
     *            if true, the block will be rendered with a decreased alpha value.
     */
    @Environment(EnvType.CLIENT)
    void renderGhostModel(
            final class_4587 stack,
            final class_1087 model,
            final class_1937 world,
            final class_2338 pos,
            final boolean isUnplaceable,
            final int combinedLight,
            final int combinedOverlay);
}
