package mod.chiselsandbits.api;

import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class EventBlockBitPostModification {

    private final class_1937 w;
    private final class_2338 pos;

    public EventBlockBitPostModification(final class_1937 w, final class_2338 pos) {

        this.w = w;
        this.pos = pos;
    }

    public class_1937 getWorld() {
        return w;
    }

    public class_2338 getPos() {
        return pos;
    }
}
