package mod.chiselsandbits.api;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class EventBlockBitModification {

    private final class_1937 w;
    private final class_2338 pos;
    private final class_1657 player;
    private final class_1268 hand;
    private final class_1799 stackUsed;
    private final boolean placement;

    private boolean cancelled;

    public EventBlockBitModification(
            final class_1937 w,
            final class_2338 pos,
            final class_1657 player,
            final class_1268 hand,
            final class_1799 stackUsed,
            final boolean placement) {

        this.w = w;
        this.pos = pos;
        this.player = player;
        this.hand = hand;
        this.stackUsed = stackUsed;
        this.placement = placement;
    }

    public class_1937 getWorld() {
        return w;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_1657 getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    public class_1799 getItemUsed() {
        return stackUsed;
    }

    public boolean isPlacing() {
        return placement;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}
