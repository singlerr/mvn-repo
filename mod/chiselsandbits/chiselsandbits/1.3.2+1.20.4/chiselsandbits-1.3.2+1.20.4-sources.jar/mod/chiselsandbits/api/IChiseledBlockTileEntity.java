package mod.chiselsandbits.api;

import java.util.Collection;
import net.minecraft.class_238;
import net.minecraft.class_2487;

/**
 * This interface is implemented by Chiseled Block Tile Entities.
 */
public interface IChiseledBlockTileEntity {

    /**
     * Used to access the contents of the chiseled block tile entity, context
     * about world will be derived from the world on the tile entity.
     * <p>
     * Note: that invalid world / position data will prevent some operations
     * such as caving changes.
     *
     * @return {@link IBitAccess} for the tile entity.
     */
    IBitAccess getBitAccess();

    /**
     * Used to write Tile Data into cross world format, can be invoked via
     * interface or via reflection on the tile itself.
     * <p>
     * functions identically to writeToNBT(...)
     *
     * @param tag
     * @param crossWorld
     * @return modified input tag.
     */
    class_2487 writeTileEntityToTag(final class_2487 tag, final boolean crossWorld);

    /**
     * Used for access to the collision, occlusion, and swimming boxes of the
     * chiseled block tile entity.
     *
     * @param type the type of boxes to return
     * @return a collection of the boxes for the tile entity
     */
    Collection<class_238> getBoxes(final BoxType type);
}
