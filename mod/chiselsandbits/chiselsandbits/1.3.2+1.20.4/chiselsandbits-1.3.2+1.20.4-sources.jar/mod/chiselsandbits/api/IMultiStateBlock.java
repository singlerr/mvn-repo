package mod.chiselsandbits.api;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * Implemented by C&B Blocks, can be used to request a material that represents
 * the largest quantity of a C&B block.
 */
public interface IMultiStateBlock {
    class_2680 getPrimaryState(class_1922 world, class_2338 pos);
}
