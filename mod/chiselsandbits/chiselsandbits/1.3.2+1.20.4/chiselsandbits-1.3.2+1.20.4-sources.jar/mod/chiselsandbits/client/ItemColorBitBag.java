package mod.chiselsandbits.client;

import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.registry.ModItems;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_326;

public class ItemColorBitBag implements class_326 {

    @Override
    public int getColor(final class_1799 p_getColor_1_, final int p_getColor_2_) {
        if (p_getColor_2_ == 1) {
            ModItems.ITEM_BIT_BAG_DYED.get();
            class_1767 color = ItemBitBag.getDyedColor(p_getColor_1_);
            if (color != null) {
                return color.method_16357();
            }
        }

        return -1;
    }
}
