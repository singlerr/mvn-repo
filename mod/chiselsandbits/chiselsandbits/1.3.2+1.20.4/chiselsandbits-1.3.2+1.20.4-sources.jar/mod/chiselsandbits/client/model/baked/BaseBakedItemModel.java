package mod.chiselsandbits.client.model.baked;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import org.jetbrains.annotations.Nullable;

public abstract class BaseBakedItemModel extends BaseBakedPerspectiveModel implements class_1087 {
    protected ArrayList<class_777> list = new ArrayList<class_777>();

    @Override
    public final boolean method_4708() {
        return true;
    }

    @Override
    public final boolean method_4712() {
        return true;
    }

    @Override
    public final boolean method_4713() {
        return false;
    }

    @Override
    public List<class_777> method_4707(
            @Nullable final class_2680 state, @Nullable final class_2350 side, final class_5819 rand) {
        if (side != null) {
            return Collections.emptyList();
        }
        return list;
    }

    @Override
    public class_806 method_4710() {
        return class_806.field_4292;
    }
}
