package mod.chiselsandbits.client.culling;

import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.helpers.ModUtil;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2506;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3612;

/**
 * Determine Culling using Block's Native Check.
 * <p>
 * hardcode vanilla stained glass because that looks horrible.
 */
public class MCCullTest implements ICullTest, class_1922 {

    private class_2680 a;
    private class_2680 b;

    @Override
    public boolean isVisible(final int mySpot, final int secondSpot) {
        if (mySpot == 0 || mySpot == secondSpot) {
            return false;
        }

        a = ModUtil.getStateById(mySpot);
        if (a == null) {
            a = class_2246.field_10124.method_9564();
        }
        b = ModUtil.getStateById(secondSpot);
        if (b == null) {
            b = class_2246.field_10124.method_9564();
        }

        if (a.method_26204().getClass() == class_2506.class && a.method_26204() == b.method_26204()) {
            return false;
        }

        if (a.method_26204() instanceof class_2404) {
            return true;
        }

        try {
            return !a.method_26187(b, class_2350.field_11043);
        } catch (final Throwable t) {
            // revert to older logic in the event of some sort of issue.
            return BlockBitInfo.getTypeFromStateID(mySpot).shouldShow(BlockBitInfo.getTypeFromStateID(secondSpot));
        }
    }

    public boolean isVisible(final int mySpot, final int secondSpot, class_2350 face) {
        if (mySpot == 0 || mySpot == secondSpot) {
            return false;
        }

        a = ModUtil.getStateById(mySpot);
        if (a == null) {
            a = class_2246.field_10124.method_9564();
        }
        b = ModUtil.getStateById(secondSpot);
        if (b == null) {
            b = class_2246.field_10124.method_9564();
        }
        if (!a.method_26187(b, face)) {
            return false;
        }

        if (a.method_26204().getClass() == class_2506.class && a.method_26204() == b.method_26204()) {
            return false;
        }

        if (a.method_26204() instanceof class_2404) {
            return true;
        }

        try {
            return !a.method_26187(b, class_2350.field_11043);
        } catch (final Throwable t) {
            // revert to older logic in the event of some sort of issue.
            return BlockBitInfo.getTypeFromStateID(mySpot).shouldShow(BlockBitInfo.getTypeFromStateID(secondSpot));
        }
    }

    @Override
    public class_2586 method_8321(final class_2338 pos) {
        return null;
    }

    @Override
    public class_2680 method_8320(final class_2338 pos) {
        return pos.equals(class_2338.field_10980) ? a : b;
    }

    @Override
    public class_3610 method_8316(final class_2338 pos) {
        return class_3612.field_15906.method_15785();
    }

    @Override
    public int method_31605() {
        return 0;
    }

    @Override
    public int method_31607() {
        return 0;
    }
}
