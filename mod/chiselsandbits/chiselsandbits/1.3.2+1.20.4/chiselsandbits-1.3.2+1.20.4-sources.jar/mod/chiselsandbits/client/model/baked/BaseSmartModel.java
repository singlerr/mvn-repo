package mod.chiselsandbits.client.model.baked;

import java.util.List;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.render.NullBakedModel;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class BaseSmartModel implements DataAwareBakedModel {

    private final class_806 overrides;

    public BaseSmartModel() {
        overrides = new OverrideHelper(this);
    }

    @Override
    public boolean method_4708() {
        return true;
    }

    @Override
    public boolean method_4712() {
        return true;
    }

    @Override
    public boolean method_4713() {
        return false;
    }

    @Override
    public class_1058 method_4711() {
        final class_1058 sprite = class_310.method_1551()
                .method_1541()
                .method_3351()
                .method_3339(class_2246.field_10340.method_9564());

        if (sprite == null) {
            return ClientSide.instance.getMissingIcon();
        }

        return sprite;
    }

    @Override
    public class_809 method_4709() {
        return class_809.field_4301;
    }

    @NotNull
    @Override
    public List<class_777> getQuads(
            @Nullable final class_2680 state,
            @Nullable final class_2350 side,
            @NotNull final class_5819 rand,
            @NotNull final IModelData extraData,
            @NotNull final ChiselRenderType renderType) {

        final DataAwareBakedModel model = (DataAwareBakedModel) handleBlockState(state, rand, extraData, renderType);
        return model.getQuads(state, side, rand, extraData, renderType);
    }

    @Override
    public List<class_777> method_4707(
            @Nullable final class_2680 state, @Nullable final class_2350 side, final class_5819 rand) {
        final class_1087 model = handleBlockState(state, rand);
        return model.method_4707(state, side, rand);
    }

    public class_1087 handleBlockState(final class_2680 state, final class_5819 rand) {
        return NullBakedModel.instance;
    }

    public class_1087 handleBlockState(
            final class_2680 state,
            final class_5819 random,
            final IModelData modelData,
            ChiselRenderType renderType) {
        return NullBakedModel.instance;
    }

    @Override
    public class_806 method_4710() {
        return overrides;
    }

    public class_1087 resolve(
            final class_1087 originalModel, final class_1799 stack, final class_1937 world, final class_1309 entity) {
        return originalModel;
    }

    private static class OverrideHelper extends class_806 {
        final BaseSmartModel parent;

        public OverrideHelper(final BaseSmartModel p) {
            super();

            parent = p;
        }

        @Nullable
        @Override
        public class_1087 method_3495(
                class_1087 bakedModel,
                class_1799 itemStack,
                @Nullable class_638 clientLevel,
                @Nullable class_1309 livingEntity,
                int i) {
            return parent.resolve(bakedModel, itemStack, clientLevel, livingEntity);
        }
    }
}
