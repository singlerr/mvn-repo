package mod.chiselsandbits.client.model.data;

import com.google.common.base.Preconditions;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;
import net.minecraft.class_1920;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2791;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;

public class ModelDataManager {
    private static final Map<class_1923, Set<class_2338>> needModelDataRefresh = new ConcurrentHashMap<>();
    private static final Map<class_1923, Map<class_2338, IModelData>> modelDataCache = new ConcurrentHashMap<>();
    private static WeakReference<class_1920> currentLevel = new WeakReference<>(null);

    private static void cleanCaches(class_1920 level) {
        Preconditions.checkNotNull(level, "Level must not be null");
        Preconditions.checkArgument(
                level == class_310.method_1551().field_1687,
                "Cannot use model data for a level other than the current client level");
        if (level != currentLevel.get()) {
            currentLevel = new WeakReference<>(level);
            needModelDataRefresh.clear();
            modelDataCache.clear();
        }
    }

    public static void requestModelDataRefresh(class_2586 te) {
        Preconditions.checkNotNull(te, "Tile entity must not be null");
        class_1937 level = te.method_10997();

        cleanCaches(level);
        needModelDataRefresh
                .computeIfAbsent(new class_1923(te.method_11016()), $ -> Collections.synchronizedSet(new HashSet<>()))
                .add(te.method_11016());
    }

    private static void refreshModelData(class_1920 level, class_1923 chunk) {
        cleanCaches(level);
        Set<class_2338> needUpdate = needModelDataRefresh.remove(chunk);

        if (needUpdate != null) {
            Map<class_2338, IModelData> data = modelDataCache.computeIfAbsent(chunk, $ -> new ConcurrentHashMap<>());
            for (class_2338 pos : needUpdate) {
                class_2586 toUpdate = level.method_8321(pos);
                if (toUpdate != null && !toUpdate.method_11015()) {

                    data.put(pos, (IModelData) level.getBlockEntityRenderData(pos));
                } else {
                    data.remove(pos);
                }
            }
        }
    }

    public static void onChunkUnload(class_2791 access, class_1936 world) {
        if (!world.method_8608()) {
            return;
        }

        class_1923 chunk = access.method_12004();
        needModelDataRefresh.remove(chunk);
        modelDataCache.remove(chunk);
    }

    public static @Nullable IModelData getModelData(class_1920 level, class_2338 pos) {
        return getModelData(level, new class_1923(pos)).get(pos);
    }

    public static @NotNull IModelData getModelDataOrEmpty(class_1920 level, class_2338 pos) {
        return getModelData(level, new class_1923(pos)).getOrDefault(pos, EmptyModelData.INSTANCE);
    }

    public static Map<class_2338, IModelData> getModelData(class_1920 level, class_1923 pos) {
        refreshModelData(level, pos);
        return modelDataCache.getOrDefault(pos, Collections.emptyMap());
    }
}
