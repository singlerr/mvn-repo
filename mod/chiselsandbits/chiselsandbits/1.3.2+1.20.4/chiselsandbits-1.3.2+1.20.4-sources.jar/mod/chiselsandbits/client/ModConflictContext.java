package mod.chiselsandbits.client;

import committee.nova.mkb.api.IKeyConflictContext;
import committee.nova.mkb.keybinding.KeyConflictContext;
import java.lang.annotation.Annotation;
import java.util.HashSet;
import java.util.Set;
import mod.chiselsandbits.api.KeyBindingContext;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IVoxelBlobItem;
import mod.chiselsandbits.network.packets.PacketAccurateSneakPlace.IItemBlockAccurate;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public enum ModConflictContext implements IKeyConflictContext {
    HOLDING_OFFGRID {
        @Override
        public boolean isActive() {
            if (super.isActive()) {
                return true;
            }

            try {
                final class_1799 held = getPlayer().method_6047();
                return !ModUtil.isEmpty(held) && held.method_7909() instanceof IItemBlockAccurate;
            } catch (final NoPlayerException e) {
                // just fail.
            }

            return false;
        }

        @Override
        public boolean conflicts(final IKeyConflictContext other) {
            return this == other || other == KeyConflictContext.IN_GAME;
        }
    },

    HOLDING_ROTATEABLE {
        @Override
        public boolean isActive() {
            if (super.isActive()) {
                return true;
            }

            try {
                final class_1799 held = getPlayer().method_6047();
                return !ModUtil.isEmpty(held) && held.method_7909() instanceof IVoxelBlobItem;
            } catch (final NoPlayerException e) {
                // just fail.
            }

            return false;
        }

        @Override
        public boolean conflicts(final IKeyConflictContext other) {
            return this == other || other == KeyConflictContext.IN_GAME || other == HOLDING_MENUITEM;
        }
    },

    HOLDING_MENUITEM {
        @Override
        public boolean isActive() {
            if (super.isActive()) {
                return true;
            }

            final ChiselToolType tool = ClientSide.instance.getHeldToolType(class_1268.field_5808);
            return tool != null && tool.hasMenu();
        }

        @Override
        public boolean conflicts(final IKeyConflictContext other) {
            return this == other
                    || other == KeyConflictContext.IN_GAME
                    || other == HOLDING_POSTIVEPATTERN
                    || other == HOLDING_CHISEL
                    || other == HOLDING_TAPEMEASURE;
        }
    },
    HOLDING_TAPEMEASURE {
        @Override
        public boolean isActive() {
            return super.isActive()
                    || ClientSide.instance.getHeldToolType(class_1268.field_5808) == ChiselToolType.TAPEMEASURE;
        }

        @Override
        public boolean conflicts(final IKeyConflictContext other) {
            return this == other || other == KeyConflictContext.IN_GAME;
        }
    },

    HOLDING_POSTIVEPATTERN {
        @Override
        public boolean isActive() {
            return super.isActive()
                    || ClientSide.instance.getHeldToolType(class_1268.field_5808) == ChiselToolType.POSITIVEPATTERN;
        }

        @Override
        public boolean conflicts(final IKeyConflictContext other) {
            return this == other || other == KeyConflictContext.IN_GAME;
        }
    },

    HOLDING_CHISEL {
        @Override
        public boolean isActive() {
            if (super.isActive()) {
                return true;
            }

            final ChiselToolType tool = ClientSide.instance.getHeldToolType(class_1268.field_5808);
            return tool != null && tool.isBitOrChisel();
        }

        @Override
        public boolean conflicts(final IKeyConflictContext other) {
            return this == other || other == KeyConflictContext.IN_GAME;
        }
    };

    private final Set<Class<? extends class_1792>> activeItemClasses = new HashSet<Class<? extends class_1792>>();

    private static class_1657 getPlayer() throws NoPlayerException {
        final class_1657 player = ClientSide.instance.getPlayer();

        if (player == null) {
            throw new NoPlayerException();
        }

        return player;
    }

    public void setItemActive(final class_1792 item) {
        activeItemClasses.add(item.getClass());
    }

    @Override
    public boolean isActive() {
        try {
            final class_1799 held = getPlayer().method_6047();

            if (ModUtil.isEmpty(held)) {
                return false;
            }

            for (final Class<? extends class_1792> itemClass : activeItemClasses) {
                if (itemClass.isInstance(held.method_7909())) {
                    return true;
                }
            }

            if (held.method_7909().getClass().isAnnotationPresent(KeyBindingContext.class)) {
                final Annotation annotation = held.method_7909().getClass().getAnnotation(KeyBindingContext.class);

                if (annotation instanceof KeyBindingContext) {
                    for (final String name : ((KeyBindingContext) annotation).value()) {
                        if (name.equals(getName())) {
                            return true;
                        }
                    }
                }
            }
        } catch (final NoPlayerException e) {
            // just fail.
        }

        return false;
    }

    public String getName() {
        return toString().toLowerCase().replace("holding_", "");
    }
}
