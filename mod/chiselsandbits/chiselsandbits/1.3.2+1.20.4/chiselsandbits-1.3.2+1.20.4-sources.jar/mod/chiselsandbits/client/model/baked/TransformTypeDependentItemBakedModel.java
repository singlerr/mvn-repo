package mod.chiselsandbits.client.model.baked;

import net.minecraft.class_1087;
import net.minecraft.class_4587;
import net.minecraft.class_811;

public interface TransformTypeDependentItemBakedModel {

    class_1087 applyTransform(class_811 context, class_4587 poseStack, boolean leftHand);
}
