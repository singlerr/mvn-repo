package mod.chiselsandbits.client;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.modes.IToolMode;
import mod.chiselsandbits.modes.TapeMeasureModes;
import mod.chiselsandbits.registry.ModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_7833;

public class TapeMeasures {
    private static final double blockSize = 1.0;
    private static final double bitSize = 1.0 / 16.0;
    private static final double halfBit = bitSize / 2.0f;
    private final ArrayList<Measure> measures = new ArrayList<Measure>();

    private Measure preview;

    private static double AABBDistnace(final class_243 eyes, final class_238 box) {
        // snap eyes into the box...
        final double boxPointX = Math.min(box.field_1320, Math.max(box.field_1323, eyes.field_1352));
        final double boxPointY = Math.min(box.field_1325, Math.max(box.field_1322, eyes.field_1351));
        final double boxPointZ = Math.min(box.field_1324, Math.max(box.field_1321, eyes.field_1350));

        // then get the distance to it.
        return Math.sqrt(eyes.method_1028(boxPointX, boxPointY, boxPointZ));
    }

    private static double getLineDistance(final class_243 v, final class_243 w, final class_1657 player, final float partialTicks) {
        final class_243 p = player.method_5836(partialTicks);
        final double segmentLength = v.method_1025(w);

        if (segmentLength == 0.0) {
            return p.method_1022(v);
        }

        final double t = Math.max(0, Math.min(1, p.method_1020(v).method_1026(w.method_1020(v)) / segmentLength));
        final class_243 projection = v.method_1019(w.method_1020(v).method_1021(t));
        return p.method_1022(projection);
    }

    public void clear() {
        measures.clear();
    }

    public void setPreviewMeasure(
            final BitLocation a, final BitLocation b, final IToolMode chMode, final class_1799 itemStack) {
        final class_1657 player = ClientSide.instance.getPlayer();

        if (a == null || b == null) {
            preview = null;
        } else {
            preview = new Measure(a, b, chMode, getDimension(player), getColor(itemStack));
        }
    }

    public void addMeasure(
            final BitLocation a, final BitLocation b, final IToolMode chMode, final class_1799 itemStack) {
        final class_1657 player = ClientSide.instance.getPlayer();

        while (measures.size() > 0
                && measures.size()
                        >= ChiselsAndBits.getConfig()
                                .getClient()
                                .maxTapeMeasures
                                .get()) {
            measures.remove(0);
        }

        final Measure newMeasure = new Measure(a, b, chMode, getDimension(player), getColor(itemStack));

        if (ChiselsAndBits.getConfig().getClient().displayMeasuringTapeInChat.get()) {
            final class_238 box = newMeasure.getBoundingBox();

            final double LenX = box.field_1320 - box.field_1323;
            final double LenY = box.field_1325 - box.field_1322;
            final double LenZ = box.field_1324 - box.field_1321;
            final double Len = newMeasure.getVecA().method_1022(newMeasure.getVecB());

            final String out = chMode == TapeMeasureModes.DISTANCE
                    ? getSize(Len)
                    : DeprecationHelper.translateToLocal(
                            "mod.chiselsandbits.tapemeasure.chatmsg", getSize(LenX), getSize(LenY), getSize(LenZ));

            final class_5250 chatMsg = class_2561.method_43470(out);

            // NOT 100% Accurate, if anyone wants to try and resolve this, yay
            chatMsg.method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(newMeasure.color.method_16357())));

            player.method_43496(chatMsg);
        }

        measures.add(newMeasure);
    }

    private class_1767 getColor(final class_1799 itemStack) {
        return ModItems.ITEM_TAPE_MEASURE.get().getTapeColor(itemStack);
    }

    private class_2960 getDimension(final class_1657 player) {
        return player.method_5770().method_27983().method_41185();
    }

    public void render(final class_4587 matrixStack, final class_4597 buffers, final float partialTicks) {
        if (!measures.isEmpty() || preview != null) {
            final class_1657 player = ClientSide.instance.getPlayer();

            if (hasTapeMeasure(player.field_7514)) {
                final ArrayList<Measure> sortList = new ArrayList<Measure>(measures.size() + 1);

                if (preview != null) {
                    preview.calcDistance(partialTicks);
                    sortList.add(preview);
                }

                for (final Measure m : measures) {
                    m.calcDistance(partialTicks);
                    sortList.add(m);
                }

                Collections.sort(sortList, new Comparator<Measure>() {

                    @Override
                    public int compare(final Measure a, final Measure b) {
                        return a.distance < b.distance ? 1 : a.distance > b.distance ? -1 : 0;
                    }
                });

                for (final Measure m : sortList) {
                    renderMeasure(m, m.distance, matrixStack, buffers, partialTicks);
                }
            }
        }
    }

    private boolean hasTapeMeasure(final class_1661 inventory) {
        for (int x = 0; x < inventory.method_5439(); x++) {
            final class_1799 is = inventory.method_5438(x);
            if (!is.method_7960() && is.method_7909() == ModItems.ITEM_TAPE_MEASURE.get()) {
                return true;
            }
        }

        return false;
    }

    private void renderMeasure(
            final Measure m,
            final double distance,
            final class_4587 matrixStack,
            final class_4597 buffers,
            final float partialTicks) {
        final class_1657 player = ClientSide.instance.getPlayer();

        if (m.DimensionId != getDimension(player)) {
            return;
        }

        final int alpha = getAlphaFromRange(distance);
        if (alpha < 30) {
            return;
        }

        final int val = m.color.method_16357();
        final int red = val >> 16 & 0xff;
        final int green = val >> 8 & 0xff;
        final int blue = val & 0xff;
        if (m.mode == TapeMeasureModes.DISTANCE) {
            final class_243 a = m.getVecA();
            final class_243 b = m.getVecB();

            RenderHelper.drawLineWithColor(
                    matrixStack, buffers, a, b, class_2338.field_10980, false, red, green, blue, alpha, (int) (alpha / 3.4));

            RenderSystem.disableDepthTest();
            RenderSystem.disableCull();

            final double Len = a.method_1022(b) + bitSize;

            renderSize(
                    matrixStack,
                    player,
                    partialTicks,
                    (a.field_1352 + b.field_1352) * 0.5,
                    (a.field_1351 + b.field_1351) * 0.5,
                    (a.field_1350 + b.field_1350) * 0.5,
                    Len,
                    red,
                    green,
                    blue);

            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            return;
        }

        final class_238 box = m.getBoundingBox();
        RenderHelper.drawSelectionBoundingBoxIfExistsWithColor(
                matrixStack,
                buffers,
                box.method_1012(-0.001, -0.001, -0.001),
                class_2338.field_10980,
                player,
                partialTicks,
                false,
                red,
                green,
                blue,
                alpha,
                (int) (alpha / 3.4));

        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        final double LenX = box.field_1320 - box.field_1323;
        final double LenY = box.field_1325 - box.field_1322;
        final double LenZ = box.field_1324 - box.field_1321;

        /**
         * TODO: Figure out some better logic for which lines to display the
         * numbers on.
         **/
        renderSize(
                matrixStack,
                player,
                partialTicks,
                box.field_1323,
                (box.field_1325 + box.field_1322) * 0.5,
                box.field_1321,
                LenY,
                red,
                green,
                blue);
        renderSize(
                matrixStack,
                player,
                partialTicks,
                (box.field_1323 + box.field_1320) * 0.5,
                box.field_1322,
                box.field_1321,
                LenX,
                red,
                green,
                blue);
        renderSize(
                matrixStack,
                player,
                partialTicks,
                box.field_1323,
                box.field_1322,
                (box.field_1321 + box.field_1324) * 0.5,
                LenZ,
                red,
                green,
                blue);

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    }

    private int getAlphaFromRange(final double distance) {
        if (distance < 16) {
            return 102;
        }

        return (int) (102 - (distance - 16) * 6);
    }

    private void renderSize(
            final class_4587 matrixStack,
            final class_1657 player,
            final float partialTicks,
            final double x,
            final double y,
            final double z,
            final double len,
            final int red,
            final int green,
            final int blue) {
        final double letterSize = 5.0;
        final double zScale = 0.001;

        final class_327 fontRenderer = class_310.method_1551().field_1772;
        final String size = getSize(len);

        matrixStack.method_22903();
        matrixStack.method_22904(x, y + getScale(len) * letterSize, z);
        billBoard(matrixStack, player, partialTicks);
        matrixStack.method_22905(getScale(len), -getScale(len), (float) zScale);
        matrixStack.method_22904(-fontRenderer.method_1727(size) * 0.5, 0, 0);
        RenderSystem.disableDepthTest();
        class_4597.class_4598 buffer =
                class_4597.method_22991(class_289.method_1348().method_1349());
        fontRenderer.method_27521(
                size,
                0,
                0,
                red << 16 | green << 8 | blue,
                true,
                matrixStack.method_23760().method_23761(),
                buffer,
                class_327.class_6415.field_33993,
                0,
                15728880);
        buffer.method_22993();
        RenderSystem.enableDepthTest();
        matrixStack.method_22909();
    }

    private float getScale(final double maxLen) {
        final double maxFontSize = 0.04;
        final double minFontSize = 0.004;

        final double delta = Math.min(1.0, maxLen / 4.0);
        double scale = maxFontSize * delta + minFontSize * (1.0 - delta);

        if (maxLen < 0.25) {
            scale = minFontSize;
        }

        return (float) Math.min(maxFontSize, scale);
    }

    private void billBoard(final class_4587 matrixStack, final class_1657 player, final float partialTicks) {
        final class_1297 view = class_310.method_1551().field_1719;
        if (view != null) {
            final float yaw = view.field_5982 + (view.field_6031 - view.field_5982) * partialTicks;
            matrixStack.method_22907(class_7833.field_40716.rotationDegrees(180 - yaw));
            final float pitch = view.field_6004 + (view.field_5965 - view.field_6004) * partialTicks;
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(-pitch));
        }
    }

    private String getSize(final double d) {
        final double blocks = Math.floor(d);
        final double bits = d - blocks;

        final StringBuilder b = new StringBuilder();

        if (blocks > 0) {
            b.append((int) blocks).append("m");
        }

        if (bits * 16 > 0.9999) {
            if (b.length() > 0) {
                b.append(" ");
            }
            b.append((int) (bits * 16)).append("b");
        }

        return b.toString();
    }

    private class Measure {
        public final IToolMode mode;
        public final BitLocation a;
        public final BitLocation b;
        public final class_1767 color;
        public final class_2960 DimensionId;
        public double distance = 1;

        public Measure(
                final BitLocation a2,
                final BitLocation b2,
                final IToolMode chMode,
                final class_2960 dimentionid,
                final class_1767 color) {
            a = a2;
            b = b2;
            mode = chMode;
            DimensionId = dimentionid;
            this.color = color;
        }

        public class_238 getBoundingBox() {
            if (mode == TapeMeasureModes.BLOCK) {
                final double ax = a.blockPos.method_10263();
                final double ay = a.blockPos.method_10264();
                final double az = a.blockPos.method_10260();
                final double bx = b.blockPos.method_10263();
                final double by = b.blockPos.method_10264();
                final double bz = b.blockPos.method_10260();

                return new class_238(
                        Math.min(ax, bx),
                        Math.min(ay, by),
                        Math.min(az, bz),
                        Math.max(ax, bx) + blockSize,
                        Math.max(ay, by) + blockSize,
                        Math.max(az, bz) + blockSize);
            }

            final double ax = a.blockPos.method_10263() + bitSize * a.bitX;
            final double ay = a.blockPos.method_10264() + bitSize * a.bitY;
            final double az = a.blockPos.method_10260() + bitSize * a.bitZ;
            final double bx = b.blockPos.method_10263() + bitSize * b.bitX;
            final double by = b.blockPos.method_10264() + bitSize * b.bitY;
            final double bz = b.blockPos.method_10260() + bitSize * b.bitZ;

            return new class_238(
                    Math.min(ax, bx),
                    Math.min(ay, by),
                    Math.min(az, bz),
                    Math.max(ax, bx) + bitSize,
                    Math.max(ay, by) + bitSize,
                    Math.max(az, bz) + bitSize);
        }

        public class_243 getVecA() {
            final double ax = a.blockPos.method_10263() + bitSize * a.bitX + halfBit;
            final double ay = a.blockPos.method_10264() + bitSize * a.bitY + halfBit;
            final double az = a.blockPos.method_10260() + bitSize * a.bitZ + halfBit;
            return new class_243(ax, ay, az);
        }

        public class_243 getVecB() {
            final double bx = b.blockPos.method_10263() + bitSize * b.bitX + halfBit;
            final double by = b.blockPos.method_10264() + bitSize * b.bitY + halfBit;
            final double bz = b.blockPos.method_10260() + bitSize * b.bitZ + halfBit;
            return new class_243(bx, by, bz);
        }

        public void calcDistance(final float partialTicks) {
            if (mode == TapeMeasureModes.DISTANCE) {
                final class_243 a = getVecA();
                final class_243 b = getVecB();
                final class_1657 player = ClientSide.instance.getPlayer();
                distance = getLineDistance(a, b, player, partialTicks);
            } else {
                final class_1657 player = ClientSide.instance.getPlayer();
                final class_243 eyes = player.method_5836(partialTicks);
                final class_238 box = getBoundingBox();
                if (box.method_1006(eyes)) {
                    distance = 0.0;
                } else {
                    distance = AABBDistnace(eyes, box);
                }
            }
        }
    }
}
