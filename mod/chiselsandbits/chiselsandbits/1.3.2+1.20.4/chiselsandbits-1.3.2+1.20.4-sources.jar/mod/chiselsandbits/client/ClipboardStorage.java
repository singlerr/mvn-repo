package mod.chiselsandbits.client;

import com.google.common.collect.Lists;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import net.minecraft.class_2487;
import net.minecraft.class_2507;

public class ClipboardStorage {

    private final File file;

    public ClipboardStorage(final File file) {
        this.file = file;
    }

    public void write(final List<class_2487> items) throws IOException {
        if (!ChiselsAndBits.getConfig().getClient().persistCreativeClipboard.get()) {
            return;
        }

        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdir();
        }

        class_2487 root = new class_2487();
        root.method_10569("size", items.size());
        for (int i = 0; i < items.size(); i++) {
            root.method_10566("clipboard_" + i, items.get(i));
        }
        class_2507.method_10630(root, file.toPath());
    }

    public List<class_2487> read() throws IOException {
        if (!ChiselsAndBits.getConfig().getClient().persistCreativeClipboard.get()) {
            return Lists.newArrayList();
        }

        if (!file.getParentFile().exists()) {
            file.mkdir();
            return Lists.newArrayList();
        }

        if (!file.exists()) {
            return Lists.newArrayList();
        }

        List<class_2487> items = new ArrayList<>();
        class_2487 root = class_2507.method_10633(file.toPath());
        int size = root.method_10550("size");

        for (int i = 0; i < size; i++) {
            try {
                items.add((class_2487) root.method_10580("clipboard_" + i));
            } catch (Exception ignore) {

            }
        }

        return items;
    }
}
