package mod.chiselsandbits.client;

import com.google.common.collect.ImmutableList;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.chiseledblock.NBTBlobConverter;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.registry.ModItemGroups;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreativeClipboardTab implements ICacheClearable {
    private static final List<class_1799> myWorldItems = new ArrayList<class_1799>();
    private static final Logger log = LoggerFactory.getLogger(CreativeClipboardTab.class);
    static boolean renewMappings = true;
    private static List<class_2487> myCrossItems = new ArrayList<class_2487>();
    private static ClipboardStorage clipStorage = null;

    private static CreativeClipboardTab instance;

    private CreativeClipboardTab() {
        ChiselsAndBits.getInstance().addClearable(this);
    }

    public static CreativeClipboardTab getInstance() {
        if (instance == null) {
            return (instance = new CreativeClipboardTab());
        }
        return instance;
    }

    public void load(final File file) {
        clipStorage = new ClipboardStorage(file);
        try {
            myCrossItems = clipStorage.read();
        } catch (IOException e) {
            myCrossItems = Collections.emptyList();
            log.info("Error occurred while reading clipboards", e);
        }
    }

    public void addItem(final class_1799 iss) {
        // this is a client side things.
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            final IBitAccess bitData = ChiselsAndBits.getApi().createBitItem(iss);

            if (bitData == null) {
                return;
            }

            final class_1799 is = bitData.getBitsAsItem(null, ItemType.CHISELED_BLOCK, true);

            if (is == null) {
                return;
            }

            // remove duplicates if they exist...
            for (final class_2487 isa : myCrossItems) {
                if (isa.equals(is.method_7969())) {
                    myCrossItems.remove(isa);
                    break;
                }
            }

            // add item to front...
            myCrossItems.add(0, is.method_7969());

            // remove extra items from back..
            while (myCrossItems.size()
                            > ChiselsAndBits.getConfig()
                                    .getServer()
                                    .creativeClipboardSize
                                    .get()
                    && !myCrossItems.isEmpty()) {
                myCrossItems.remove(myCrossItems.size() - 1);
            }

            try {
                clipStorage.write(myCrossItems);
            } catch (IOException e) {
                log.info("Error occurred while saving clipboard", e);
            }
            myWorldItems.clear();
            renewMappings = true;
        }

        ModItemGroups.CLIPBOARD.get().method_47313().clear();
        ModItemGroups.CLIPBOARD.get().method_47313().addAll(getClipboard());
    }

    public List<class_1799> getClipboard() {
        if (renewMappings) {
            myWorldItems.clear();
            renewMappings = false;

            for (final class_2487 nbt : myCrossItems) {
                final NBTBlobConverter c = new NBTBlobConverter();
                c.readChisleData(nbt.method_10562(ModUtil.NBT_BLOCKENTITYTAG), VoxelBlob.VERSION_ANY);

                // recalculate.
                c.updateFromBlob();

                final class_1799 worldItem = c.getItemStack(false);

                if (worldItem != null) {
                    myWorldItems.add(worldItem);
                }
            }
        }

        return ImmutableList.copyOf(myWorldItems);
    }

    @Override
    public void clearCache() {
        renewMappings = true;
    }
}
