package mod.chiselsandbits.client.model.baked;

import java.util.List;
import java.util.Set;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface DataAwareBakedModel extends class_1087 {

    List<class_777> getQuads(
            @Nullable final class_2680 state,
            @Nullable final class_2350 side,
            @NotNull final class_5819 rand,
            @NotNull final IModelData extraData,
            @NotNull final ChiselRenderType renderType);

    @Deprecated
    void updateModelData(
            @NotNull final class_1920 world,
            @NotNull final class_2338 pos,
            @NotNull final class_2680 state,
            @NotNull final IModelData modelData);

    Set<ChiselRenderType> getRenderTypes(
            @NotNull final class_1920 world,
            @NotNull final class_2338 pos,
            @NotNull final class_2680 state,
            @NotNull IModelData modelData);
}
