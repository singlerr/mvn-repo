package mod.chiselsandbits.client.gui;

import net.minecraft.class_1058;

public class SpriteIconPositioning {
    public class_1058 sprite;

    public double left;
    public double top;
    public double width;
    public double height;
}
