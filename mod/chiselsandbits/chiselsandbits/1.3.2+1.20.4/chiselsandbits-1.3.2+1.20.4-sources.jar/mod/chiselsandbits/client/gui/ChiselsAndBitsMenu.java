package mod.chiselsandbits.client.gui;

import com.google.common.base.Stopwatch;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import mod.chiselsandbits.api.ReplacementStateHandler;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.modes.IToolMode;
import net.minecraft.class_1058;
import net.minecraft.class_1268;
import net.minecraft.class_1723;
import net.minecraft.class_1767;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.lwjgl.opengl.GL11;

public class ChiselsAndBitsMenu extends class_437 {

    public static final ChiselsAndBitsMenu instance = new ChiselsAndBitsMenu();
    private final float TIME_SCALE = 0.01f;
    public IToolMode switchTo = null;
    public ButtonAction doAction = null;
    public boolean actionUsed = false;
    private float visibility = 0.0f;
    private boolean canRaise = true;
    private Stopwatch lastChange = Stopwatch.createStarted();

    protected ChiselsAndBitsMenu() {
        super(class_2561.method_43470("Menu"));
    }

    private float clampVis(final float f) {
        return Math.max(0.0f, Math.min(1.0f, f));
    }

    public boolean raiseVisibility() {
        if (!isCanRaise()) {
            return false;
        }

        visibility = clampVis(visibility + lastChange.elapsed(TimeUnit.MILLISECONDS) * TIME_SCALE);
        lastChange = Stopwatch.createStarted();
        return true;
    }

    public void decreaseVisibility() {
        setCanRaise(true);
        visibility = clampVis(visibility - lastChange.elapsed(TimeUnit.MILLISECONDS) * TIME_SCALE);
        lastChange = Stopwatch.createStarted();
    }

    public boolean isCanRaise() {
        return canRaise;
    }

    public void setCanRaise(final boolean canRaise) {
        this.canRaise = canRaise;
    }

    public boolean isVisible() {
        return visibility > 0.001;
    }

    public void configure(final int scaledWidth, final int scaledHeight) {
        field_22789 = scaledWidth;
        field_22790 = scaledHeight;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int i, int j, float f) {
        this.render(guiGraphics, guiGraphics.method_51448(), i, j, f);
    }

    public void render(
            class_332 graphics,
            final class_4587 matrixStack,
            final int mouseX,
            final int mouseY,
            final float partialTicks) {
        final ChiselToolType tool = ClientSide.instance.getHeldToolType(class_1268.field_5808);

        if (tool == null) {
            return;
        }

        matrixStack.method_22903();
        // matrixStack.translate( 0.0F, 0.0F, 200.0F );

        final int start = (int) (visibility * 98) << 24;
        final int end = (int) (visibility * 128) << 24;

        graphics.method_25296(0, 0, field_22789, field_22790, start, end);

        //        RenderSystem.disableTexture();
        RenderSystem.enableBlend();

        //        RenderSystem.disableAlphaTest();
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
        //        RenderSystem.shadeModel(GL11.GL_SMOOTH);
        final class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_1349();

        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        final double vecX = mouseX - field_22789 / 2;
        final double vecY = (mouseY - field_22790 / 2);
        double radians = Math.atan2(vecY, vecX);

        final double ring_inner_edge = 20;
        final double ring_outer_edge = 50;
        final double text_distnace = 65;
        final double quarterCircle = Math.PI / 2.0;

        if (radians < -quarterCircle) {
            radians = radians + Math.PI * 2;
        }

        final double middle_x = field_22789 / 2;
        final double middle_y = field_22790 / 2;

        final ArrayList<MenuRegion> modes = new ArrayList<MenuRegion>();
        final ArrayList<MenuButton> btns = new ArrayList<MenuButton>();

        if (tool == ChiselToolType.BIT) {
            if (ReplacementStateHandler.getInstance().isReplacing()) {
                btns.add(new MenuButton(
                        LocalStrings.BitOptionReplace.toString(),
                        ButtonAction.REPLACE_TOGGLE,
                        text_distnace,
                        -44,
                        ClientSide.swapIcon,
                        class_2350.field_11034));
            } else {
                btns.add(new MenuButton(
                        LocalStrings.BitOptionPlace.toString(),
                        ButtonAction.REPLACE_TOGGLE,
                        text_distnace,
                        -44,
                        ClientSide.placeIcon,
                        class_2350.field_11034));
            }
        }

        btns.add(new MenuButton(
                "mod.chiselsandbits.other.undo",
                ButtonAction.UNDO,
                text_distnace,
                -20,
                ClientSide.undoIcon,
                class_2350.field_11034));
        btns.add(new MenuButton(
                "mod.chiselsandbits.other.redo",
                ButtonAction.REDO,
                text_distnace,
                4,
                ClientSide.redoIcon,
                class_2350.field_11034));

        if (tool == ChiselToolType.CHISELED_BLOCK
                || tool == ChiselToolType.NEGATIVEPATTERN
                || tool == ChiselToolType.POSITIVEPATTERN) {
            btns.add(new MenuButton(
                    "mod.chiselsandbits.other.roll_x",
                    ButtonAction.ROLL_X,
                    -text_distnace - 18,
                    -20,
                    ClientSide.roll_x,
                    class_2350.field_11039));
            btns.add(new MenuButton(
                    "mod.chiselsandbits.other.roll_z",
                    ButtonAction.ROLL_Z,
                    -text_distnace - 18,
                    4,
                    ClientSide.roll_z,
                    class_2350.field_11039));
        }

        if (tool == ChiselToolType.TAPEMEASURE) {
            final int colorSize = class_1767.values().length / 4 * 24 - 4;
            double underring = -ring_outer_edge - 34;
            double bntPos = -colorSize;
            final int bntSize = 24;
            class_2350 textSide = class_2350.field_11036;
            for (final class_1767 color : class_1767.values()) {
                final ButtonAction action = ButtonAction.valueOf(color.name());
                if (bntPos > colorSize) {
                    underring = ring_outer_edge;
                    bntPos = -colorSize;
                    textSide = class_2350.field_11033;
                }

                btns.add(new MenuButton(
                        "chiselsandbits.color." + color.method_7792(),
                        action,
                        bntPos,
                        underring,
                        color.method_16357(),
                        textSide));
                bntPos += bntSize;
            }
        }

        for (final IToolMode mode : tool.getAvailableModes()) {
            if (!mode.isDisabled()) {
                modes.add(new MenuRegion(mode));
            }
        }

        switchTo = null;
        doAction = null;

        if (!modes.isEmpty()) {
            final int totalModes = Math.max(3, modes.size());
            int currentMode = 0;
            final double fragment = Math.PI * 0.005;
            final double fragment2 = Math.PI * 0.0025;
            final double perObject = 2.0 * Math.PI / totalModes;

            for (final MenuRegion mnuRgn : modes) {
                final double begin_rad = currentMode * perObject - quarterCircle;
                final double end_rad = (currentMode + 1) * perObject - quarterCircle;

                mnuRgn.x1 = Math.cos(begin_rad);
                mnuRgn.x2 = Math.cos(end_rad);
                mnuRgn.y1 = Math.sin(begin_rad);
                mnuRgn.y2 = Math.sin(end_rad);

                final double x1m1 = Math.cos(begin_rad + fragment) * ring_inner_edge;
                final double x2m1 = Math.cos(end_rad - fragment) * ring_inner_edge;
                final double y1m1 = Math.sin(begin_rad + fragment) * ring_inner_edge;
                final double y2m1 = Math.sin(end_rad - fragment) * ring_inner_edge;

                final double x1m2 = Math.cos(begin_rad + fragment2) * ring_outer_edge;
                final double x2m2 = Math.cos(end_rad - fragment2) * ring_outer_edge;
                final double y1m2 = Math.sin(begin_rad + fragment2) * ring_outer_edge;
                final double y2m2 = Math.sin(end_rad - fragment2) * ring_outer_edge;

                final float a = 0.5f;
                float f = 0f;

                final boolean quad = inTriangle(
                                x1m1, y1m1,
                                x2m2, y2m2,
                                x2m1, y2m1,
                                vecX, vecY)
                        || inTriangle(
                                x1m1, y1m1,
                                x1m2, y1m2,
                                x2m2, y2m2,
                                vecX, vecY);

                if (begin_rad <= radians && radians <= end_rad && quad) {
                    f = 1;
                    mnuRgn.highlighted = true;
                    switchTo = mnuRgn.mode;
                }

                buffer.method_22912(middle_x + x1m1, middle_y + y1m1, 0)
                        .method_22915(f, f, f, a)
                        .method_1344();
                buffer.method_22912(middle_x + x2m1, middle_y + y2m1, 0)
                        .method_22915(f, f, f, a)
                        .method_1344();
                buffer.method_22912(middle_x + x2m2, middle_y + y2m2, 0)
                        .method_22915(f, f, f, a)
                        .method_1344();
                buffer.method_22912(middle_x + x1m2, middle_y + y1m2, 0)
                        .method_22915(f, f, f, a)
                        .method_1344();

                currentMode++;
            }
        }

        for (final MenuButton btn : btns) {
            final float a = 0.5f;
            float f = 0f;

            if (btn.x1 <= vecX && btn.x2 >= vecX && btn.y1 <= vecY && btn.y2 >= vecY) {
                f = 1;
                btn.highlighted = true;
                doAction = btn.action;
            }

            buffer.method_22912(middle_x + btn.x1, middle_y + btn.y1, 0)
                    .method_22915(f, f, f, a)
                    .method_1344();
            buffer.method_22912(middle_x + btn.x1, middle_y + btn.y2, 0)
                    .method_22915(f, f, f, a)
                    .method_1344();
            buffer.method_22912(middle_x + btn.x2, middle_y + btn.y2, 0)
                    .method_22915(f, f, f, a)
                    .method_1344();
            buffer.method_22912(middle_x + btn.x2, middle_y + btn.y1, 0)
                    .method_22915(f, f, f, a)
                    .method_1344();
        }

        tessellator.method_1350();

        graphics.method_51422(1, 1, 1, 1);
        RenderSystem.disableBlend();
        RenderSystem.bindTexture(class_310.method_1551()
                .method_1531()
                .method_4619(class_1723.field_21668)
                .method_4624());

        for (final MenuRegion mnuRgn : modes) {

            final double x = (mnuRgn.x1 + mnuRgn.x2) * 0.5 * (ring_outer_edge * 0.6 + 0.4 * ring_inner_edge);
            final double y = (mnuRgn.y1 + mnuRgn.y2) * 0.5 * (ring_outer_edge * 0.6 + 0.4 * ring_inner_edge);

            final SpriteIconPositioning sip = ClientSide.instance.getIconForMode(mnuRgn.mode);

            final double scalex = 15 * sip.width * 0.5;
            final double scaley = 15 * sip.height * 0.5;
            final double x1 = x - scalex;
            final double x2 = x + scalex;
            final double y1 = y - scaley;
            final double y2 = y + scaley;

            final class_1058 sprite = sip.sprite;
            final class_2960 iconId =
                    sprite.method_45851().method_45816().method_45138("textures/icons/").method_48331(".png");
            RenderSystem.setShader(class_757::method_34541);
            RenderSystem.setShaderTexture(0, iconId);
            graphics.method_25293(
                    iconId,
                    (int) (middle_x + x1),
                    (int) (middle_y + y1),
                    (int) (x2 - x1),
                    (int) (y2 - y1),
                    0,
                    0,
                    18,
                    18,
                    18,
                    18);
        }

        for (final MenuButton btn : btns) {
            final class_1058 sprite = btn.icon == null ? ClientSide.white : btn.icon;
            class_2960 iconId =
                    sprite.method_45851().method_45816().method_45138("textures/icons/").method_48331(".png");
            RenderSystem.setShader(class_757::method_34541);
            RenderSystem.setShaderTexture(0, iconId);

            final double btnx1 = btn.x1 + 1;
            final double btnx2 = btn.x2 - 1;
            final double btny1 = btn.y1 + 1;
            final double btny2 = btn.y2 - 1;

            graphics.method_25293(
                    iconId,
                    (int) (middle_x + btnx1),
                    (int) (middle_y + btny1),
                    (int) (btnx2 - btnx1),
                    (int) (btny2 - btny1),
                    0,
                    0,
                    18,
                    18,
                    18,
                    18);
        }

        for (final MenuRegion mnuRgn : modes) {
            if (mnuRgn.highlighted) {
                final double x = (mnuRgn.x1 + mnuRgn.x2) * 0.5;
                final double y = (mnuRgn.y1 + mnuRgn.y2) * 0.5;

                int fixed_x = (int) (x * text_distnace);
                final int fixed_y = (int) (y * text_distnace);
                final String text = mnuRgn.mode.getName().getLocal();

                if (x <= -0.2) {
                    fixed_x -= field_22793.method_1727(text);
                } else if (-0.2 <= x && x <= 0.2) {
                    fixed_x -= field_22793.method_1727(text) / 2;
                }
                graphics.method_25303(field_22793, text, (int) middle_x + fixed_x, (int) middle_y + fixed_y, 0xffffffff);
            }
        }

        for (final MenuButton btn : btns) {
            if (btn.highlighted) {
                final String text = DeprecationHelper.translateToLocal(btn.name);

                if (btn.textSide == class_2350.field_11039) {
                    graphics.method_25303(
                            field_22793,
                            text,
                            (int) (middle_x + btn.x1 - 8) - field_22793.method_1727(text),
                            (int) (middle_y + btn.y1 + 6),
                            0xffffffff);
                } else if (btn.textSide == class_2350.field_11034) {
                    graphics.method_25303(
                            field_22793, text, (int) (middle_x + btn.x2 + 8), (int) (middle_y + btn.y1 + 6), 0xffffffff);
                } else if (btn.textSide == class_2350.field_11036) {
                    graphics.method_25303(
                            field_22793,
                            text,
                            (int) (middle_x + (btn.x1 + btn.x2) * 0.5 - field_22793.method_1727(text) * 0.5),
                            (int) (middle_y + btn.y1 - 14),
                            0xffffffff);
                } else if (btn.textSide == class_2350.field_11033) {
                    graphics.method_25303(
                            field_22793,
                            text,
                            (int) (middle_x + (btn.x1 + btn.x2) * 0.5 - field_22793.method_1727(text) * 0.5),
                            (int) (middle_y + btn.y1 + 24),
                            0xffffffff);
                }
            }
        }

        matrixStack.method_22909();
    }

    private boolean inTriangle(
            final double x1,
            final double y1,
            final double x2,
            final double y2,
            final double x3,
            final double y3,
            final double x,
            final double y) {
        final double ab = (x1 - x) * (y2 - y) - (x2 - x) * (y1 - y);
        final double bc = (x2 - x) * (y3 - y) - (x3 - x) * (y2 - y);
        final double ca = (x3 - x) * (y1 - y) - (x1 - x) * (y3 - y);
        return sign(ab) == sign(bc) && sign(bc) == sign(ca);
    }

    private int sign(final double n) {
        return n > 0 ? 1 : -1;
    }

    @Override
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        this.visibility = 0f;
        canRaise = false;
        this.field_22787.method_1507(null);

        if (this.field_22787.field_1755 == null) {
            this.field_22787.method_15995(true);
            this.field_22787.method_1483().method_4880();
            this.field_22787.field_1729.method_1612();
        }
        return true;
    }

    private static class MenuButton {

        public final ButtonAction action;
        public double x1, x2;
        public double y1, y2;
        public boolean highlighted;
        public class_1058 icon;
        public int color;
        public String name;
        public class_2350 textSide;

        public MenuButton(
                final String name,
                final ButtonAction action,
                final double x,
                final double y,
                final class_1058 ico,
                final class_2350 textSide) {
            this.name = name;
            this.action = action;
            x1 = x;
            x2 = x + 18;
            y1 = y;
            y2 = y + 18;
            icon = ico;
            color = 0xffffff;
            this.textSide = textSide;
        }

        public MenuButton(
                final String name,
                final ButtonAction action,
                final double x,
                final double y,
                final int col,
                final class_2350 textSide) {
            this.name = name;
            this.action = action;
            x1 = x;
            x2 = x + 18;
            y1 = y;
            y2 = y + 18;
            color = col;
            this.textSide = textSide;
        }
    }

    static class MenuRegion {

        public final IToolMode mode;
        public double x1, x2;
        public double y1, y2;
        public boolean highlighted;

        public MenuRegion(final IToolMode mode) {
            this.mode = mode;
        }
    }
}
