package mod.chiselsandbits.client.model.baked;

import net.minecraft.class_1087;
import net.minecraft.class_806;

public abstract class BaseBakedBlockModel extends BaseBakedPerspectiveModel implements class_1087, DataAwareBakedModel {

    @Override
    public final boolean method_4708() {
        return true;
    }

    @Override
    public final boolean method_4712() {
        return true;
    }

    @Override
    public final boolean method_4713() {
        return false;
    }

    @Override
    public class_806 method_4710() {
        return class_806.field_4292;
    }
}
