package mod.chiselsandbits.mixin.compat.client;

import mod.chiselsandbits.compat.client.OverlayRenderCallback;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_329.class)
public abstract class GuiMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Unique
    private float partialTicks;

    @Inject(method = "render", at = @At("HEAD"))
    public void render(class_332 matrixStack, float f, CallbackInfo ci) {
        partialTicks = f;
    }

    // This might be the wrong method to inject to
    @Inject(
            method = "renderPlayerHealth",
            at =
                    @At(
                            value = "INVOKE",
                            shift = At.Shift.AFTER,
                            target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V"),
            cancellable = true)
    private void renderStatusBars(class_332 guiGraphics, CallbackInfo ci) {
        if (OverlayRenderCallback.EVENT
                .invoker()
                .onOverlayRender(guiGraphics, partialTicks, minecraft.method_22683(), OverlayRenderCallback.Types.AIR)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderHearts", at = @At(value = "HEAD"), cancellable = true)
    private void renderHealth(
            class_332 guiGraphics,
            class_1657 player,
            int i,
            int j,
            int k,
            int l,
            float f,
            int m,
            int n,
            int o,
            boolean bl,
            CallbackInfo ci) {
        if (OverlayRenderCallback.EVENT
                .invoker()
                .onOverlayRender(
                        guiGraphics, partialTicks, minecraft.method_22683(), OverlayRenderCallback.Types.PLAYER_HEALTH)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void renderCrosshair(class_332 guiGraphics, CallbackInfo ci) {
        if (OverlayRenderCallback.EVENT
                .invoker()
                .onOverlayRender(
                        guiGraphics, partialTicks, minecraft.method_22683(), OverlayRenderCallback.Types.CROSSHAIRS)) {
            ci.cancel();
        }
    }
}
