package mod.chiselsandbits.mixin.compat.client;

import mod.chiselsandbits.compat.client.TextureStitchCallback;
import net.minecraft.class_1059;
import net.minecraft.class_7766;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1059.class)
public abstract class TextureAtlasMixin {
    @Inject(method = "upload", at = @At("RETURN"))
    private void port_lib$postStitch(class_7766.class_7767 preparations, CallbackInfo ci) {
        TextureStitchCallback.POST.invoker().stitch((class_1059) (Object) this);
    }
}
