package mod.chiselsandbits.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import mod.chiselsandbits.chiseledblock.LegacyBlockEntityProperties;
import net.minecraft.class_2338;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3499.class)
public abstract class StructureTemplateMixin {

    @Inject(
            method = "placeInWorld",
            at =
                    @At(
                            value = "INVOKE_ASSIGN",
                            target =
                                    "Lnet/minecraft/world/level/block/state/BlockState;mirror(Lnet/minecraft/world/level/block/Mirror;)Lnet/minecraft/world/level/block/state/BlockState;"))
    private void mod$invokeMirror(
            class_5425 serverLevelAccessor,
            class_2338 blockPos,
            class_2338 blockPos2,
            class_3492 structurePlaceSettings,
            class_5819 randomSource,
            int i,
            CallbackInfoReturnable<Boolean> cir,
            @Local(ordinal = 2) class_2338 pos,
            @Local(ordinal = 0) class_3499.class_3501 info) {
        if (!(serverLevelAccessor.method_8321(pos) instanceof LegacyBlockEntityProperties properties)) {
            return;
        }

        properties.mirror(serverLevelAccessor, pos, info.comp_1342(), structurePlaceSettings.method_15114());
    }
}
