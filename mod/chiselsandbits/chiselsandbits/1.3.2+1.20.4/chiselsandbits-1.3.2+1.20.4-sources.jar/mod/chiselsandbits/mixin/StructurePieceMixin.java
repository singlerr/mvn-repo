package mod.chiselsandbits.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import mod.chiselsandbits.chiseledblock.LegacyBlockEntityProperties;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2680;
import net.minecraft.class_3341;
import net.minecraft.class_3443;
import net.minecraft.class_5281;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3443.class)
public abstract class StructurePieceMixin {

    @Shadow
    private class_2415 mirror;

    @Inject(
            method = "placeBlock",
            at =
                    @At(
                            value = "INVOKE_ASSIGN",
                            target =
                                    "Lnet/minecraft/world/level/block/state/BlockState;mirror(Lnet/minecraft/world/level/block/Mirror;)Lnet/minecraft/world/level/block/state/BlockState;"))
    private void mod$invokeMirror(
            class_5281 worldGenLevel,
            class_2680 blockState,
            int i,
            int j,
            int k,
            class_3341 boundingBox,
            CallbackInfo ci,
            @Local(ordinal = 0) class_2338 pos) {
        if (!(worldGenLevel.method_8321(pos) instanceof LegacyBlockEntityProperties properties)) {
            return;
        }
        properties.mirror(worldGenLevel, pos, blockState, mirror);
    }
}
