package mod.chiselsandbits.mixin.compat.client;

import committee.nova.mkb.api.IKeyBinding;
import committee.nova.mkb.keybinding.KeyModifier;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_315;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_459;
import net.minecraft.class_4667;
import net.minecraft.class_6599;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_6599.class, priority = 999)
public abstract class KeyBindsScreenMixin extends class_4667 {

    @Shadow
    @Nullable
    public class_304 selectedKey;

    @Shadow
    public long lastKeySelection;

    @Shadow
    private class_459 keyBindsList;

    @Unique
    private KeyModifier modifier = KeyModifier.NONE;

    public KeyBindsScreenMixin(class_437 screen, class_315 options, class_2561 component) {
        super(screen, options, component);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"))
    private void chisels$resetKeyModifier(double d, double e, int i, CallbackInfoReturnable<Boolean> cir) {
        modifier = KeyModifier.NONE;
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void chisels$keyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (selectedKey != null) {
            final IKeyBinding extended = (IKeyBinding) selectedKey;
            if (keyCode == 256) {
                extended.setKeyModifierAndCode(KeyModifier.getActiveModifier(), class_3675.field_16237);
                field_21336.method_1641(selectedKey, class_3675.field_16237);
            } else {
                extended.setKeyModifierAndCode(
                        KeyModifier.getActiveModifier(), class_3675.method_15985(keyCode, scanCode));
                field_21336.method_1641(selectedKey, class_3675.method_15985(keyCode, scanCode));
            }

            if (!KeyModifier.isKeyCodeModifier(((IKeyBinding) selectedKey).getKey())
                    || (KeyModifier.getActiveModifier().matches(extended.getKey()) && modifier != KeyModifier.NONE)) {
                this.selectedKey = null;
            }

            if (KeyModifier.isKeyCodeModifier(extended.getKey())) {
                modifier = KeyModifier.getActiveModifier();
            }

            this.lastKeySelection = class_156.method_658();
            this.keyBindsList.method_49006();
            cir.setReturnValue(true);
            cir.cancel();
            return;
        }
        cir.setReturnValue(super.method_25404(keyCode, scanCode, modifiers));
        cir.cancel();
    }
}
