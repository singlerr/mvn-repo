package mod.chiselsandbits.mixin;

import mod.chiselsandbits.utils.ModClientHooks;
import net.minecraft.class_1087;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2373;
import net.minecraft.class_2504;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_918.class)
public abstract class ItemRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void mod$setRenderType(
            class_1799 itemStack,
            class_811 itemDisplayContext,
            boolean bl,
            class_4587 poseStack,
            class_4597 multiBufferSource,
            int i,
            int j,
            class_1087 bakedModel,
            CallbackInfo ci) {
        boolean bl3;
        if (itemDisplayContext != class_811.field_4317
                && !itemDisplayContext.method_29998()
                && itemStack.method_7909() instanceof class_1747) {
            class_2248 block = ((class_1747) itemStack.method_7909()).method_7711();
            bl3 = !(block instanceof class_2373) && !(block instanceof class_2504);
        } else {
            bl3 = true;
        }
        ModClientHooks.setRenderType(class_4696.method_23678(itemStack, bl3));
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void mod$clearRenderType(
            class_1799 itemStack,
            class_811 itemDisplayContext,
            boolean bl,
            class_4587 poseStack,
            class_4597 multiBufferSource,
            int i,
            int j,
            class_1087 bakedModel,
            CallbackInfo ci) {
        ModClientHooks.setRenderType(null);
    }
}
