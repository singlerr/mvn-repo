package mod.chiselsandbits.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import mod.chiselsandbits.utils.ModClientHooks;
import net.minecraft.class_1921;
import net.minecraft.class_750;
import net.minecraft.class_846;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_846.class_851.class_4578.class)
public abstract class SectionRenderDispatcherMixin {

    @Inject(
            method = "compile",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/renderer/SectionBufferBuilderPack;builder(Lnet/minecraft/client/renderer/RenderType;)Lcom/mojang/blaze3d/vertex/BufferBuilder;",
                            ordinal = 1))
    private void mod$setRenderType(
            float f,
            float g,
            float h,
            class_750 sectionBufferBuilderPack,
            CallbackInfoReturnable<class_846.class_851.class_4578.class_7435> cir,
            @Local(ordinal = 0) class_1921 renderType) {
        ModClientHooks.setRenderType(renderType);
    }

    @Inject(
            method = "compile",
            at =
                    @At(
                            value = "INVOKE",
                            target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V",
                            shift = At.Shift.AFTER))
    private void mod$clearRenderType(
            float f,
            float g,
            float h,
            class_750 sectionBufferBuilderPack,
            CallbackInfoReturnable<class_846.class_851.class_4578.class_7435> cir) {
        ModClientHooks.setRenderType(null);
    }
}
