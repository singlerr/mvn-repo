package mod.chiselsandbits.mixin;

import mod.chiselsandbits.events.extra.EntityItemPickupEvent;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin {

    @Inject(
            method = "playerTouch",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getCount()I"),
            cancellable = true)
    private void mod$onItemPickup(class_1657 player, CallbackInfo ci) {
        boolean result = EntityItemPickupEvent.EVENT.invoker().handle((class_1542) (Object) this, player);

        if (result) {
            ci.cancel();
        }
    }
}
