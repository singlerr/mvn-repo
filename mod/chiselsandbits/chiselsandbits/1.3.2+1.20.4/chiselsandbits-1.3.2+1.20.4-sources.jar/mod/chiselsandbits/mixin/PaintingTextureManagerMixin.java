package mod.chiselsandbits.mixin;

import mod.chiselsandbits.events.extra.ResourceRegistrationEvent;
import net.minecraft.class_1060;
import net.minecraft.class_4044;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4044.class)
public abstract class PaintingTextureManagerMixin {

    @Inject(method = "<init>", at = @At("RETURN"))
    private void mod$invokeRegistrationEvent(class_1060 textureManager, CallbackInfo ci) {
        ResourceRegistrationEvent.EVENT.invoker().handle();
    }
}
