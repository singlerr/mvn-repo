package mod.chiselsandbits.utils;

import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import org.jetbrains.annotations.Nullable;

public class SingleBlockBlockReader implements class_1922 {

    private final class_2680 state;
    private final class_2248 blk;

    public SingleBlockBlockReader(final class_2680 state, final class_2248 blk) {
        this.state = state;
        this.blk = blk;
    }

    public SingleBlockBlockReader(final class_2680 state) {
        this.state = state;
        this.blk = state.method_26204();
    }

    @Nullable
    @Override
    public class_2586 method_8321(final class_2338 pos) {
        if (pos == class_2338.field_10980 && state.method_31709()) {
            return ((class_2343) blk).method_10123(pos, state);
        }

        return null;
    }

    @Override
    public class_2680 method_8320(final class_2338 pos) {
        if (pos == class_2338.field_10980) {
            return state;
        }
        return class_2246.field_10124.method_9564();
    }

    @Override
    public class_3610 method_8316(final class_2338 pos) {
        return class_3612.field_15906.method_15785();
    }

    @Override
    public int method_31605() {
        return 0;
    }

    @Override
    public int method_31607() {
        return 0;
    }
}
