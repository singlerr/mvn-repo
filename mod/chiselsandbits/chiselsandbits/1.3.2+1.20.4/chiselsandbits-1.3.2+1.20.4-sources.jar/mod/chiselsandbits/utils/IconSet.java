package mod.chiselsandbits.utils;

import net.minecraft.class_1058;
import net.minecraft.class_2960;

public record IconSet(class_2960 name, class_1058 sprite) {}
