package mod.chiselsandbits.utils;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2874;
import net.minecraft.class_2902;
import net.minecraft.class_3568;
import net.minecraft.class_4538;
import net.minecraft.class_4543;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import org.jetbrains.annotations.Nullable;

public class SingleBlockWorldReader extends SingleBlockBlockReader implements class_4538 {
    private final class_4538 reader;

    public SingleBlockWorldReader(final class_2680 state, final class_2248 blk, final class_4538 reader) {
        super(state, blk);
        this.reader = reader;
    }

    @Nullable
    @Override
    public class_2791 method_8402(final int x, final int z, final class_2806 requiredStatus, final boolean nonnull) {
        return this.reader.method_8402(x, z, requiredStatus, nonnull);
    }

    @Override
    public boolean method_8393(final int chunkX, final int chunkZ) {
        return this.reader.method_8393(chunkX, chunkZ);
    }

    @Override
    public int method_8624(final class_2902.class_2903 heightmapType, final int x, final int z) {
        return this.reader.method_8624(heightmapType, x, z);
    }

    @Override
    public int method_8594() {
        return 15;
    }

    @Override
    public class_4543 method_22385() {
        return this.reader.method_22385();
    }

    @Override
    public class_6880<class_1959> method_16359(int i, int j, int k) {
        return reader.method_16359(i, j, k);
    }

    @Override
    public class_6880<class_1959> method_22387(int i, int j, int k) {
        return this.reader.method_22387(i, j, k);
    }

    @Override
    public boolean method_8608() {
        return this.reader.method_8608();
    }

    @Override
    public int method_8615() {
        return 64;
    }

    @Override
    public class_2874 method_8597() {
        return this.reader.method_8597();
    }

    @Override
    public class_5455 method_30349() {
        return reader.method_30349();
    }

    @Override
    public class_7699 method_45162() {
        return reader.method_45162();
    }

    @Override
    public float method_24852(final class_2350 p_230487_1_, final boolean p_230487_2_) {
        return this.reader.method_24852(p_230487_1_, p_230487_2_);
    }

    @Override
    public class_3568 method_22336() {
        return this.reader.method_22336();
    }

    @Override
    public class_2784 method_8621() {
        return this.reader.method_8621();
    }

    @Override
    public List<class_265> method_20743(@Nullable class_1297 entity, class_238 aABB) {
        return reader.method_20743(entity, aABB);
    }
}
