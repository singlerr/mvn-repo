package mod.chiselsandbits.utils;

import java.util.function.Supplier;
import mod.chiselsandbits.core.Log;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_6539;
import net.minecraft.class_853;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class ChuckRenderCacheWrapper implements class_1920 {
    private final class_853 chunkRenderCache;

    public ChuckRenderCacheWrapper(final class_853 chunkRenderCache) {
        this.chunkRenderCache = chunkRenderCache;
    }

    @Override
    public float method_24852(final class_2350 p_230487_1_, final boolean p_230487_2_) {
        return chunkRenderCache.method_24852(p_230487_1_, p_230487_2_);
    }

    @Override
    public class_3568 method_22336() {
        return chunkRenderCache.method_22336();
    }

    @Override
    public int method_23752(final class_2338 blockPosIn, final class_6539 colorResolverIn) {
        return this.whenPosValidOrElse(
                blockPosIn, () -> chunkRenderCache.method_23752(blockPosIn, colorResolverIn), () -> 0);
    }

    @Nullable
    @Override
    public class_2586 method_8321(final class_2338 pos) {
        return this.whenPosValidOrElse(pos, () -> chunkRenderCache.method_8321(pos), () -> null);
    }

    @Override
    public class_2680 method_8320(final class_2338 pos) {
        return this.whenPosValidOrElse(pos, () -> chunkRenderCache.method_8320(pos), class_2246.field_10124::method_9564);
    }

    @Override
    public class_3610 method_8316(final class_2338 pos) {
        return this.whenPosValidOrElse(pos, () -> chunkRenderCache.method_8316(pos), class_3612.field_15906::method_15785);
    }

    private boolean falseWhenInvalidPos(final class_2338 pos, final Supplier<Boolean> validSupplier) {
        return this.whenPosValidOrElse(pos, validSupplier, () -> false);
    }

    private <T> T whenPosValidOrElse(
            final class_2338 pos, final Supplier<T> validSupplier, final Supplier<T> invalidSupplier) {
        if (pos.method_10264() < 0 || pos.method_10264() > 255) {
            return invalidSupplier.get();
        }

        try {
            return validSupplier.get();
        } catch (Exception e) {
            Log.logError("Failed to process cached wrapped info for: " + pos, e);
            return invalidSupplier.get();
        }
    }

    @Override
    public int method_31605() {
        return 0;
    }

    @Override
    public int method_31607() {
        return 0;
    }
}
