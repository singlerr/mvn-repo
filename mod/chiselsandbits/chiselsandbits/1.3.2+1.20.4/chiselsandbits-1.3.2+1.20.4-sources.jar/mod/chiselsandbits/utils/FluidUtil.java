package mod.chiselsandbits.utils;

import com.google.common.base.Preconditions;
import javax.annotation.Nonnull;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1074;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;
import net.minecraftforge.fluids.FluidActionResult;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.items.CapabilityItemHandler;

public final class FluidUtil {

    private FluidUtil() {}

    public static String getTranslationKey(class_3611 fluid) {
        String translationKey;

        if (fluid == class_3612.field_15906) {
            translationKey = "";
        } else if (fluid == class_3612.field_15910) {
            translationKey = "block.minecraft.water";
        } else if (fluid == class_3612.field_15908) {
            translationKey = "block.minecraft.lava";
        } else {
            class_2960 id = class_7923.field_41173.method_10221(fluid);
            String key = class_156.method_646("block", id);
            String translated = class_1074.method_4662(key);
            translationKey = translated.equals(key) ? class_156.method_646("fluid", id) : key;
        }

        return translationKey;
    }

    public static class_2960 getRegistryName(class_3611 fluid) {
        return class_7923.field_41173.method_10221(fluid);
    }

    public static int getColor(class_3611 fluid) {
        return FluidVariantRendering.getColor(FluidVariant.of(fluid));
    }

    public static class_1058 getStillTexture(class_3611 fluid) {
        return FluidVariantRendering.getSprites(FluidVariant.of(fluid))[0];
    }

    public static class_1058 getFlowingTexture(class_3611 fluid) {
        return FluidVariantRendering.getSprites(FluidVariant.of(fluid))[1];
    }

    private static FluidVariant getVariant(class_3611 fluid) {
        if (!fluid.method_15793(fluid.method_15785()) && fluid != class_3612.field_15906) {
            return getVariant(getSource(fluid));
        } else {
            return FluidVariant.of(fluid);
        }
    }

    private static class_3611 getSource(class_3611 fluid) {
        if (fluid instanceof class_3609 flowingFluid) {
            return flowingFluid.method_15751();
        }
        return fluid;
    }

    public static boolean interactWithFluidHandler(
            @Nonnull class_1657 player, @Nonnull class_1268 hand, @Nonnull IFluidHandler handler) {
        Preconditions.checkNotNull(player);
        Preconditions.checkNotNull(hand);
        Preconditions.checkNotNull(handler);

        class_1799 heldItem = player.method_5998(hand);
        if (!heldItem.method_7960()) {
            return player.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY)
                    .map(playerInventory -> {
                        FluidActionResult fluidActionResult =
                                net.minecraftforge.fluids.FluidUtil.tryFillContainerAndStow(
                                        heldItem, handler, playerInventory, Integer.MAX_VALUE, player, true);
                        if (!fluidActionResult.isSuccess()) {
                            fluidActionResult = net.minecraftforge.fluids.FluidUtil.tryEmptyContainerAndStow(
                                    heldItem, handler, playerInventory, Integer.MAX_VALUE, player, true);
                        }

                        if (fluidActionResult.isSuccess()) {
                            player.method_6122(hand, fluidActionResult.getResult());
                            return true;
                        }
                        return false;
                    })
                    .orElse(false);
        }
        return false;
    }
}
