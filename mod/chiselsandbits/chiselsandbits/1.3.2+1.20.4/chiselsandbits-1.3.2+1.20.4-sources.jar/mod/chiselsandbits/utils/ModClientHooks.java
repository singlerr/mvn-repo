package mod.chiselsandbits.utils;

import net.minecraft.class_1921;

public final class ModClientHooks {

    private static final ThreadLocal<class_1921> renderType = new ThreadLocal<>();

    public static class_1921 getRenderType() {
        return renderType.get();
    }

    public static void setRenderType(class_1921 type) {
        renderType.set(type);
    }
}
