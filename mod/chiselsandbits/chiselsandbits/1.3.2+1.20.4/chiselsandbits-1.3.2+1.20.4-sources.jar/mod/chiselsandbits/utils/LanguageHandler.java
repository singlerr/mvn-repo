package mod.chiselsandbits.utils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import mod.chiselsandbits.core.Log;
import net.fabricmc.api.EnvType;
import net.minecraft.class_1657;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Helper class for localization and sending player messages.
 */
public final class LanguageHandler {
    /**
     * Private constructor to hide implicit one.
     */
    private LanguageHandler() {
        // Intentionally left empty.
    }

    /**
     * Send a message to the player.
     *
     * @param player  the player to send to.
     * @param key     the key of the message.
     * @param message the message to send.
     */
    public static void sendPlayerMessage(@NotNull final class_1657 player, final String key, final Object... message) {
        player.method_43496(buildChatComponent(key.toLowerCase(Locale.US), message));
    }

    public static class_2561 buildChatComponent(final String key, final Object... message) {
        class_5250 translation = null;

        int onlyArgsUntil = 0;
        for (final Object object : message) {
            if (object instanceof class_2561) {
                if (onlyArgsUntil == 0) {
                    onlyArgsUntil = -1;
                }
                break;
            }
            onlyArgsUntil++;
        }

        if (onlyArgsUntil >= 0) {
            final Object[] args = new Object[onlyArgsUntil];
            System.arraycopy(message, 0, args, 0, onlyArgsUntil);
            translation = class_2561.method_43469(key, args);
        }

        for (final Object object : message) {
            if (translation == null) {
                if (object instanceof class_2561) {
                    translation = class_2561.method_43471(key);
                } else {
                    translation = class_2561.method_43469(key, object);
                    continue;
                }
            }

            if (object instanceof class_2561) {
                translation.method_10852(class_2561.method_43470(" "));
                translation.method_10852((class_2561) object);
            } else if (object instanceof String) {
                boolean isInArgs = false;
                for (final Object obj : ((class_2588) translation.method_10851()).method_11023()) {
                    if (obj.equals(object)) {
                        isInArgs = true;
                        break;
                    }
                }

                if (!isInArgs) {
                    translation.method_27693(" " + object);
                }
            }
        }

        if (translation == null) {
            translation = class_2561.method_43471(key);
        }

        return translation;
    }

    /**
     * Localize a string and use String.format().
     *
     * @param inputKey translation key.
     * @param args     Objects for String.format().
     * @return Localized string.
     */
    public static String format(final String inputKey, final Object... args) {
        final String key = inputKey.toLowerCase(Locale.US);
        final String result;
        if (args.length == 0) {
            result = class_2561.method_43471(key).getString();
        } else {
            result = class_2561.method_43469(key, args).getString();
        }
        return result.isEmpty() ? key : result;
    }

    /**
     * Send message to a list of players.
     *
     * @param players the list of players.
     * @param key     key of the message.
     * @param message the message.
     */
    public static void sendPlayersMessage(
            @Nullable final List<class_1657> players, final String key, final Object... message) {
        if (players == null || players.isEmpty()) {
            return;
        }

        final class_2561 textComponent = buildChatComponent(key.toLowerCase(Locale.US), message);

        for (final class_1657 player : players) {
            player.method_43496(textComponent);
        }
    }

    public static void sendMessageToPlayer(final class_1657 player, final String key, final Object... format) {
        player.method_43496(class_2561.method_43470(translateKeyWithFormat(key, format)));
    }

    /**
     * Translates key to readable string and formats it.
     *
     * @param key    translation key
     * @param format String.format() attributes
     * @return formatted string
     */
    public static String translateKeyWithFormat(final String key, final Object... format) {
        return String.format(translateKey(key.toLowerCase(Locale.US)), format);
    }

    /**
     * Translates key to readable string.
     *
     * @param key translation key
     * @return readable string
     */
    public static String translateKey(final String key) {
        return LanguageCache.getInstance().translateKey(key.toLowerCase(Locale.US));
    }

    /**
     * Sets our cache to use mc default one.
     */
    public static void setMClanguageLoaded() {
        LanguageCache.getInstance().isMCloaded = true;
        LanguageCache.getInstance().languageMap = null;
    }

    public static void loadLangPath(final String path) {
        LanguageCache.getInstance().load(path);
    }

    private static class LanguageCache {
        private static LanguageCache instance;
        private boolean isMCloaded = false;
        private Map<String, String> languageMap;

        private LanguageCache() {
            final String fileLoc = "assets/" + Constants.MOD_ID + "/lang/%s.json";
            load(fileLoc);
        }

        private static LanguageCache getInstance() {
            return instance == null ? instance = new LanguageCache() : instance;
        }

        private void load(final String path) {
            final String defaultLocale = "en_us";

            //noinspection ConstantConditions Trust me, Minecraft.getInstance() can be null, when you run Data
            // Generators!
            String locale = EnvExecutor.callWhenOn(
                    EnvType.CLIENT,
                    () -> () -> class_310.method_1551() == null || class_310.method_1551().field_1690 == null
                            ? null
                            : class_310.method_1551().field_1690.field_1883);

            if (locale == null) {
                locale = defaultLocale;
            }

            InputStream is =
                    Thread.currentThread().getContextClassLoader().getResourceAsStream(String.format(path, locale));
            if (is == null) {
                is = Thread.currentThread()
                        .getContextClassLoader()
                        .getResourceAsStream(String.format(path, defaultLocale));
            }

            try {
                languageMap = new Gson()
                        .fromJson(
                                new InputStreamReader(Objects.requireNonNull(is), StandardCharsets.UTF_8),
                                new TypeToken<Map<String, String>>() {}.getType());
                is.close();
            } catch (IOException | NullPointerException e) {
                Log.logError("Could not load langauge.", e);
            }
        }

        private String translateKey(final String key) {
            if (isMCloaded) {
                return class_2477.method_10517().method_48307(key);
            } else {
                final String res = languageMap.get(key);
                return res == null ? key : res;
            }
        }
    }
}
