package mod.chiselsandbits.utils.forge;

import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_293;

/**
 * Represents a consumer of vertex information.
 * Can be used to pipe a vertex's information into a target system,
 * or to read a single piece of information from a packet vertex.
 */
public interface IVertexConsumer {
    /**
     * @return the format that should be used for passed data.
     */
    class_293 getVertexFormat();

    void setQuadTint(int tint);

    void setQuadOrientation(class_2350 orientation);

    void setApplyDiffuseLighting(boolean diffuse);

    void setTexture(class_1058 texture);

    void put(int vertexIndex, int element, float... data);

    default void onComplete() {}
}
