package mod.chiselsandbits.utils;

import net.minecraft.class_4587;
import net.minecraft.class_4590;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class TransformationUtils {

    private TransformationUtils() {
        throw new IllegalStateException("Tried to initialize TransformationUtils. But this is a utility class!");
    }

    public static void push(class_4587 stack, final class_4590 transformation, final boolean requiresStackPush) {
        if (requiresStackPush) {
            stack.method_22903();
        }

        Vector3f trans = transformation.method_35865();
        stack.method_46416(trans.x(), trans.y(), trans.z());

        stack.method_22907(transformation.method_22937());

        Vector3f scale = transformation.method_35866();
        stack.method_22905(scale.x(), scale.y(), scale.z());

        stack.method_22907(transformation.method_35867());
    }

    public static Quaternionf quatFromXYZ(Vector3f xyz, boolean degrees) {
        return quatFromXYZ(xyz.x, xyz.y, xyz.z, degrees);
    }

    public static Quaternionf quatFromXYZ(float[] xyz, boolean degrees) {
        return quatFromXYZ(xyz[0], xyz[1], xyz[2], degrees);
    }

    public static Quaternionf quatFromXYZ(float x, float y, float z, boolean degrees) {
        float conversionFactor = degrees ? 0.017453292F : 1.0F;
        return (new Quaternionf()).rotationXYZ(x * conversionFactor, y * conversionFactor, z * conversionFactor);
    }
}
