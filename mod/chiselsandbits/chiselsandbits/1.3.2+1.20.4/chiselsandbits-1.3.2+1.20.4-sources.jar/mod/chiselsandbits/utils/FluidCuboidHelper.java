package mod.chiselsandbits.utils;

import static net.minecraft.class_2350.field_11033;
import static net.minecraft.class_2350.field_11034;
import static net.minecraft.class_2350.field_11043;
import static net.minecraft.class_2350.field_11035;
import static net.minecraft.class_2350.field_11036;
import static net.minecraft.class_2350.field_11039;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public final class FluidCuboidHelper {

    private FluidCuboidHelper() {
        throw new IllegalStateException("Tried to initialize: FluidCuboidHelper but this is a Utility class.");
    }

    /**
     * Renders a fluid block with offset from the matrices and from x1/y1/z1 to x2/y2/z2 using block model coordinates, so from 0-16
     */
    //    public static void renderScaledFluidCuboid(
    //           /* FluidStack fluid,*/
    //            PoseStack matrices,
    //            VertexConsumer renderer,
    //            int combinedLight,
    //            final int combinedOverlay,
    //            float x1,
    //            float y1,
    //            float z1,
    //            float x2,
    //            float y2,
    //            float z2) {
    //        renderFluidCuboid(
    //                fluid,
    //                matrices,
    //                renderer,
    //                combinedLight,
    //                combinedOverlay,
    //                x1 / 16,
    //                y1 / 16,
    //                z1 / 16,
    //                x2 / 16,
    //                y2 / 16,
    //                z2 / 16);
    //    }

    /**
     * Renders a fluid block with offset from the matrices and from x1/y1/z1 to x2/y2/z2 inside the block local coordinates, so from 0-1
     */
    //    public static void renderFluidCuboid(
    //            FluidStack fluid,
    //            PoseStack matrices,
    //            VertexConsumer renderer,
    //            int combinedLight,
    //            final int combinedOverlay,
    //            float x1,
    //            float y1,
    //            float z1,
    //            float x2,
    //            float y2,
    //            float z2) {
    //
    //        int color = FluidUtil.getColor(fluid.getFluid());
    //        renderFluidCuboid(fluid, matrices, renderer, combinedLight, combinedOverlay, x1, y1, z1, x2, y2, z2,
    // color);
    //    }

    /**
     * Renders a fluid block with offset from the matrices and from x1/y1/z1 to x2/y2/z2 inside the block local coordinates, so from 0-1
     */
    //    public static void renderFluidCuboid(
    //            FluidStack fluid,
    //            PoseStack matrices,
    //            VertexConsumer renderer,
    //            int combinedLight,
    //            final int combinedOverlay,
    //            float x1,
    //            float y1,
    //            float z1,
    //            float x2,
    //            float y2,
    //            float z2,
    //            int color) {
    //        TextureAtlasSprite still = Minecraft.getInstance()
    //                .getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
    //                .apply(FluidUtil.getStillTexture(fluid.getFluid()).contents().name());
    //        TextureAtlasSprite flowing = Minecraft.getInstance()
    //                .getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
    //                .apply(FluidUtil.getFlowingTexture(fluid.getFluid()).contents().name());
    //
    //        renderFluidCuboid(
    //                still, flowing, color, matrices, renderer, combinedOverlay, combinedLight, x1, y1, z1, x2, y2,
    // z2);
    //    }
    public static void renderFluidCuboid(
            class_1058 still,
            class_1058 flowing,
            int color,
            class_4587 matrices,
            class_4588 renderer,
            final int combinedOverlay,
            int combinedLight,
            float x1,
            float y1,
            float z1,
            float x2,
            float y2,
            float z2) {
        matrices.method_22903();
        matrices.method_46416(x1, y1, z1);

        // x/y/z2 - x/y/z1 is because we need the width/height/depth
        putTexturedQuad(
                renderer,
                matrices.method_23760(),
                still,
                x2 - x1,
                y2 - y1,
                z2 - z1,
                field_11033,
                color,
                combinedOverlay,
                combinedLight,
                false);
        putTexturedQuad(
                renderer,
                matrices.method_23760(),
                flowing,
                x2 - x1,
                y2 - y1,
                z2 - z1,
                class_2350.field_11043,
                color,
                combinedOverlay,
                combinedLight,
                true);
        putTexturedQuad(
                renderer,
                matrices.method_23760(),
                flowing,
                x2 - x1,
                y2 - y1,
                z2 - z1,
                class_2350.field_11034,
                color,
                combinedOverlay,
                combinedLight,
                true);
        putTexturedQuad(
                renderer,
                matrices.method_23760(),
                flowing,
                x2 - x1,
                y2 - y1,
                z2 - z1,
                class_2350.field_11035,
                color,
                combinedOverlay,
                combinedLight,
                true);
        putTexturedQuad(
                renderer,
                matrices.method_23760(),
                flowing,
                x2 - x1,
                y2 - y1,
                z2 - z1,
                class_2350.field_11039,
                color,
                combinedOverlay,
                combinedLight,
                true);
        putTexturedQuad(
                renderer,
                matrices.method_23760(),
                still,
                x2 - x1,
                y2 - y1,
                z2 - z1,
                field_11036,
                color,
                combinedOverlay,
                combinedLight,
                false);
        matrices.method_22909();
    }

    public static void putTexturedQuad(
            class_4588 renderer,
            class_4587.class_4665 matrix,
            class_1058 sprite,
            float w,
            float h,
            float d,
            class_2350 face,
            int color,
            final int overlay,
            int brightness,
            boolean flowing) {
        putTexturedQuad(renderer, matrix, sprite, w, h, d, face, color, overlay, brightness, flowing, false, false);
    }

    public static void putTexturedQuad(
            class_4588 renderer,
            class_4587.class_4665 matrix,
            class_1058 sprite,
            float w,
            float h,
            float d,
            class_2350 face,
            int color,
            final int overlay,
            int brightness,
            boolean flowing,
            boolean flipHorizontally,
            boolean flipVertically) {
        int l1 = brightness >> 0x10 & 0xFFFF;
        int l2 = brightness & 0xFFFF;

        int o1 = overlay >> 0x10 & 0xFFFF;
        int o2 = overlay & 0xFFFF;

        int a = color >> 24 & 0xFF;
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int b = color & 0xFF;

        putTexturedQuad(
                renderer,
                matrix,
                sprite,
                w,
                h,
                d,
                face,
                r,
                g,
                b,
                a,
                l1,
                l2,
                o1,
                o2,
                flowing,
                flipHorizontally,
                flipVertically);
    }

    /* Fluid cuboids */
    // x and x+w has to be within [0,1], same for y/h and z/d
    public static void putTexturedQuad(
            class_4588 renderer,
            class_4587.class_4665 matrices,
            class_1058 sprite,
            float w,
            float h,
            float d,
            class_2350 face,
            int r,
            int g,
            int b,
            int a,
            int light1,
            int light2,
            final int overlay1,
            final int overlay2,
            boolean flowing,
            boolean flipHorizontally,
            boolean flipVertically) {
        // safety
        if (sprite == null) {
            return;
        }
        float minU;
        float maxU;
        float minV;
        float maxV;

        float size = 16f;
        if (flowing) {
            size = 8f;
        }

        float xt1 = 0;
        float xt2 = w;
        while (xt2 > 1f) {
            xt2 -= 1f;
        }
        float yt1 = 0;
        float yt2 = h;
        while (yt2 > 1f) {
            yt2 -= 1f;
        }
        float zt1 = 0;
        float zt2 = d;
        while (zt2 > 1f) {
            zt2 -= 1f;
        }

        // flowing stuff should start from the bottom, not from the start
        if (flowing) {
            float tmp = 1f - yt1;
            yt1 = 1f - yt2;
            yt2 = tmp;
        }

        switch (face) {
            case field_11033:
            case field_11036:
                minU = sprite.method_4580(xt1 * size);
                maxU = sprite.method_4580(xt2 * size);
                minV = sprite.method_4570(zt1 * size);
                maxV = sprite.method_4570(zt2 * size);
                break;
            case field_11043:
            case field_11035:
                minU = sprite.method_4580(xt2 * size);
                maxU = sprite.method_4580(xt1 * size);
                minV = sprite.method_4570(yt1 * size);
                maxV = sprite.method_4570(yt2 * size);
                break;
            case field_11039:
            case field_11034:
                minU = sprite.method_4580(zt2 * size);
                maxU = sprite.method_4580(zt1 * size);
                minV = sprite.method_4570(yt1 * size);
                maxV = sprite.method_4570(yt2 * size);
                break;
            default:
                minU = sprite.method_4594();
                maxU = sprite.method_4577();
                minV = sprite.method_4593();
                maxV = sprite.method_4575();
        }

        if (flipHorizontally) {
            float tmp = minV;
            minV = maxV;
            maxV = tmp;
        }

        if (flipVertically) {
            float tmp = minU;
            minU = maxU;
            maxU = tmp;
        }

        final Matrix4f worldMatrix = matrices.method_23761();
        final Matrix3f normalMatrix = matrices.method_23762();

        switch (face) {
            case field_11033:
                renderer.method_22918(worldMatrix, 0, 0, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11033.method_10148(), field_11033.method_10164(), field_11033.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, 0, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11033.method_10148(), field_11033.method_10164(), field_11033.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, 0, d)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11033.method_10148(), field_11033.method_10164(), field_11033.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, 0, d)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11033.method_10148(), field_11033.method_10164(), field_11033.method_10165())
                        .method_1344();
                break;
            case field_11036:
                renderer.method_22918(worldMatrix, 0, h, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11036.method_10148(), field_11036.method_10164(), field_11036.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, h, d)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11036.method_10148(), field_11036.method_10164(), field_11036.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, h, d)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11036.method_10148(), field_11036.method_10164(), field_11036.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, h, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11036.method_10148(), field_11036.method_10164(), field_11036.method_10165())
                        .method_1344();
                break;
            case field_11043:
                renderer.method_22918(worldMatrix, 0, 0, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11043.method_10148(), field_11043.method_10164(), field_11043.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, h, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11043.method_10148(), field_11043.method_10164(), field_11043.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, h, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11043.method_10148(), field_11043.method_10164(), field_11043.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, 0, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11043.method_10148(), field_11043.method_10164(), field_11043.method_10165())
                        .method_1344();
                break;
            case field_11035:
                renderer.method_22918(worldMatrix, 0, 0, d)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11035.method_10148(), field_11035.method_10164(), field_11035.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, 0, d)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11035.method_10148(), field_11035.method_10164(), field_11035.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, h, d)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11035.method_10148(), field_11035.method_10164(), field_11035.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, h, d)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11035.method_10148(), field_11035.method_10164(), field_11035.method_10165())
                        .method_1344();
                break;
            case field_11039:
                renderer.method_22918(worldMatrix, 0, 0, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11039.method_10148(), field_11039.method_10164(), field_11039.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, 0, d)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11039.method_10148(), field_11039.method_10164(), field_11039.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, h, d)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11039.method_10148(), field_11039.method_10164(), field_11039.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, 0, h, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11039.method_10148(), field_11039.method_10164(), field_11039.method_10165())
                        .method_1344();
                break;
            case field_11034:
                renderer.method_22918(worldMatrix, w, 0, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11034.method_10148(), field_11034.method_10164(), field_11034.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, h, 0)
                        .method_1336(r, g, b, a)
                        .method_22913(minU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11034.method_10148(), field_11034.method_10164(), field_11034.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, h, d)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, minV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11034.method_10148(), field_11034.method_10164(), field_11034.method_10165())
                        .method_1344();
                renderer.method_22918(worldMatrix, w, 0, d)
                        .method_1336(r, g, b, a)
                        .method_22913(maxU, maxV)
                        .method_22917(overlay1, overlay2)
                        .method_22921(light1, light2)
                        .method_23763(normalMatrix, field_11034.method_10148(), field_11034.method_10164(), field_11034.method_10165())
                        .method_1344();
                break;
        }
    }
}
