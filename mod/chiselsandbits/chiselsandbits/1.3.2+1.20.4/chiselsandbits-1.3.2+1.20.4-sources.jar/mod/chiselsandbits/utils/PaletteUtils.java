package mod.chiselsandbits.utils;

import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_2814;
import net.minecraft.class_2816;
import net.minecraft.class_2834;
import net.minecraft.class_2837;
import net.minecraft.class_3513;

public class PaletteUtils {

    private PaletteUtils() {
        throw new IllegalStateException("Can not instantiate an instance of: PaletteUtils. This is a utility class");
    }

    public static List<class_2680> getOrderedListInPalette(final class_2837<class_2680> stateIPalette) {
        if (stateIPalette instanceof class_2834) {
            return Arrays.asList(((class_2834<class_2680>) stateIPalette).field_12904);
        }

        if (stateIPalette instanceof class_2814) {
            final class_3513<class_2680> map =
                    ((class_2814<class_2680>) stateIPalette).field_12824;

            final List<class_2680> dataList = Lists.newArrayList(map);
            dataList.sort(Comparator.comparing(map::method_10206));

            return dataList;
        }

        if (stateIPalette instanceof class_2816) {
            final List<class_2680> dataList = Lists.newArrayList(class_2248.field_10651);
            dataList.sort(Comparator.comparing(class_2248.field_10651::method_10206));

            return dataList;
        }

        throw new IllegalArgumentException("The given palette type is unknown.");
    }

    public static void read(final class_2837<class_2680> stateIPalette, final class_2540 buffer) {
        if (stateIPalette instanceof class_2834<class_2680> palette) {
            palette.field_12901 = buffer.method_10816();

            final Object[] statesArray = palette.field_12904;

            for (int i = 0; i < palette.field_12901; ++i) {
                final Object registryEntry = palette.field_12900.method_10200(buffer.method_10816());
                statesArray[i] = registryEntry;
            }
        }

        if (stateIPalette instanceof class_2814<class_2680> palette) {
            palette.field_12824.method_15229();
            int i = buffer.method_10816();

            for (int j = 0; j < i; ++j) {
                palette.field_12824.method_15225(palette.field_12821.method_10200(buffer.method_10816()));
            }
        }
    }
}
