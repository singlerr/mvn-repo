package mod.chiselsandbits.utils;

import net.minecraft.class_1799;

public final class ItemStackUtils {

    private ItemStackUtils() {}

    public static class_1799 getContainerItem(class_1799 stack) {
        if (stack.method_7909().method_7857()) {
            return new class_1799(stack.method_7909().method_7858());
        }
        return class_1799.field_8037;
    }
}
