package mod.chiselsandbits.utils;

import mod.chiselsandbits.utils.forge.IVertexConsumer;
import net.minecraft.class_2350;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_296;
import net.minecraft.class_777;

public final class LightUtil {

    private LightUtil() {
        throw new IllegalStateException("Tried to construct a LightUtil instance, but this is a utility class!");
    }

    public static void pack(float[] from, int[] to, class_293 formatTo, int v, int e) {
        class_296 element = formatTo.method_1357().get(e);
        int vertexStart = v * formatTo.method_1362() + formatTo.field_1597.getInt(e);
        int count = element.method_34451();
        class_296.class_297 type = element.method_1386();
        int size = type.method_1391();
        int mask = (256 << (8 * (size - 1))) - 1;
        for (int i = 0; i < 4; i++) {
            if (i < count) {
                int pos = vertexStart + size * i;
                int index = pos >> 2;
                int offset = pos & 3;
                int bits = 0;
                float f = i < from.length ? from[i] : 0;
                if (type == class_296.class_297.field_1623) {
                    bits = Float.floatToRawIntBits(f);
                } else if (type == class_296.class_297.field_1624
                        || type == class_296.class_297.field_1622
                        || type == class_296.class_297.field_1619) {
                    bits = Math.round(f * mask);
                } else {
                    bits = Math.round(f * (mask >> 1));
                }
                to[index] &= ~(mask << (offset * 8));
                to[index] |= (((bits & mask) << (offset * 8)));
            }
        }
    }

    public static void pipe(IVertexConsumer consumer) {}

    public static void put(IVertexConsumer consumer, class_777 quad) {
        consumer.setTexture(quad.method_35788());
        consumer.setQuadOrientation(quad.method_3358());
        if (quad.method_3360()) {
            consumer.setQuadTint(quad.method_3359());
        }
        consumer.setApplyDiffuseLighting(quad.method_24874());
        float[] data = new float[4];
        class_293 format = class_290.field_1590;
        int elementCount = consumer.getVertexFormat().method_1357().size();
        for (int v = 0; v < 4; v++) {
            for (int e = 0; e < elementCount; e++) {
                unpack(quad.method_3357(), data, format, v, e);
                consumer.put(v, e, data);
            }
        }

        consumer.onComplete();
    }

    public static void unpack(int[] from, float[] to, class_293 formatFrom, int v, int e) {
        int length = Math.min(4, to.length);
        class_296 element = formatFrom.method_1357().get(e);
        int vertexStart = v * formatFrom.method_1362() + formatFrom.field_1597.getInt(e);
        int count = element.method_34451();
        class_296.class_297 type = element.method_1386();
        class_296.class_298 usage = element.method_1382();
        int size = type.method_1391();
        int mask = (256 << (8 * (size - 1))) - 1;
        for (int i = 0; i < length; i++) {
            if (i < count) {
                int pos = vertexStart + size * i;
                int index = pos >> 2;
                int offset = pos & 3;
                int bits = from[index];
                bits = bits >>> (offset * 8);
                if ((pos + size - 1) / 4 != index) {
                    bits |= from[index + 1] << ((4 - offset) * 8);
                }
                bits &= mask;
                if (type == class_296.class_297.field_1623) {
                    to[i] = Float.intBitsToFloat(bits);
                } else if (type == class_296.class_297.field_1624 || type == class_296.class_297.field_1622) {
                    to[i] = (float) bits / mask;
                } else if (type == class_296.class_297.field_1619) {
                    to[i] = (float) ((double) (bits & 0xFFFFFFFFL) / 0xFFFFFFFFL);
                } else if (type == class_296.class_297.field_1621) {
                    to[i] = ((float) (byte) bits) / (mask >> 1);
                } else if (type == class_296.class_297.field_1625) {
                    to[i] = ((float) (short) bits) / (mask >> 1);
                } else if (type == class_296.class_297.field_1617) {
                    to[i] = (float) ((double) (bits & 0xFFFFFFFFL) / (0xFFFFFFFFL >> 1));
                }
            } else {
                to[i] = (i == 3 && usage == class_296.class_298.field_1633) ? 1 : 0;
            }
        }
    }

    public static float diffuseLight(class_2350 side) {
        return switch (side) {
            case field_11033 -> .5f;
            case field_11036 -> 1f;
            case field_11043, field_11035 -> .8f;
            default -> .6f;
        };
    }
}
