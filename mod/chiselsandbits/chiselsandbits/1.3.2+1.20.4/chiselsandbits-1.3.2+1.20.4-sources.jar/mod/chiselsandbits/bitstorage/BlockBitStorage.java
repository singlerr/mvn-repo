package mod.chiselsandbits.bitstorage;

import com.google.common.collect.Lists;
import java.util.List;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.ExceptionNoTileEntity;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.utils.FluidUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import org.jetbrains.annotations.Nullable;

public class BlockBitStorage extends class_2248 implements class_2343 {

    private static final class_2769<class_2350> FACING = class_2383.field_11177;

    public BlockBitStorage(class_4970.class_2251 properties) {
        super(properties);
    }

    @Nullable
    @Override
    public class_2680 method_9605(final class_1750 context) {
        return method_9564().method_11657(FACING, context.method_8042());
    }

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new TileEntityBitStorage(blockPos, blockState);
    }

    public TileEntityBitStorage getTileEntity(final class_2586 te) throws ExceptionNoTileEntity {
        if (te instanceof TileEntityBitStorage) {
            return (TileEntityBitStorage) te;
        }
        throw new ExceptionNoTileEntity();
    }

    public TileEntityBitStorage getTileEntity(final class_1922 world, final class_2338 pos)
            throws ExceptionNoTileEntity {
        return getTileEntity(world.method_8321(pos));
    }

    @Override
    public class_1269 method_9534(
            final class_2680 state,
            final class_1937 worldIn,
            final class_2338 pos,
            final class_1657 player,
            final class_1268 handIn,
            final class_3965 hit) {
        try {
            final TileEntityBitStorage tank = getTileEntity(worldIn, pos);
            final class_1799 current = ModUtil.nonNull(player.field_7514.method_7391());

            if (!ModUtil.isEmpty(current)) {
                final IFluidHandler wrappedTank = tank.getPseudoFluidHandler();
                if (FluidUtil.interactWithFluidHandler(player, handIn, wrappedTank)) {
                    return class_1269.field_5812;
                }

                if (tank.addHeldBits(current, player)) {
                    return class_1269.field_5812;
                }
            } else {
                if (tank.addAllPossibleBits(player)) {
                    return class_1269.field_5812;
                }
            }

            if (tank.extractBits(player, hit.method_17784().field_1352, hit.method_17784().field_1351, hit.method_17784().field_1350, pos)) {
                return class_1269.field_5812;
            }
        } catch (final ExceptionNoTileEntity e) {
            Log.noTileError(e);
        }

        return class_1269.field_5814;
    }

    @Environment(EnvType.CLIENT)
    public float method_9575(class_2680 state, class_1922 worldIn, class_2338 pos) {
        return 1.0F;
    }

    public boolean method_9579(class_2680 state, class_1922 reader, class_2338 pos) {
        return true;
    }

    @Override
    public List<class_1799> method_9560(class_2680 blockState, class_8567.class_8568 builder) {
        if (builder.method_51876(class_181.field_1228) == null) {
            return Lists.newArrayList();
        }

        return Lists.newArrayList(
                getTankDrop((TileEntityBitStorage) builder.method_51876(class_181.field_1228)));
    }

    public class_1799 getTankDrop(final TileEntityBitStorage bitTank) {
        final class_1799 tankStack = new class_1799(this);
        tankStack
                .getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY)
                .ifPresent(s -> s.fill(
                        bitTank.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY)
                                .map(t -> t.drain(Integer.MAX_VALUE, IFluidHandler.FluidAction.EXECUTE))
                                .orElse(FluidStack.EMPTY),
                        IFluidHandler.FluidAction.EXECUTE));
        return tankStack;
    }
}
