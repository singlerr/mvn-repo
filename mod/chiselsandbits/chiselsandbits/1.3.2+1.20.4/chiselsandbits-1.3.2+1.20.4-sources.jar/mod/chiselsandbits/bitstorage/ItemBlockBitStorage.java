package mod.chiselsandbits.bitstorage;

import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.LocalStrings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.fluids.FluidAttributes;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidHandlerItemStack;
import org.jetbrains.annotations.Nullable;

public class ItemBlockBitStorage extends class_1747 {

    public ItemBlockBitStorage(final class_2248 block, class_1792.class_1793 builder) {
        super(block, builder);
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(
            final class_1799 stack,
            @Nullable final class_1937 worldIn,
            final List<class_2561> tooltip,
            final class_1836 flagIn) {
        super.method_7851(stack, worldIn, tooltip, flagIn);
        if (CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY == null) {
            return;
        }

        FluidStack fluid = stack.getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY)
                .map(h -> h.getFluidInTank(0))
                .orElse(FluidStack.EMPTY);

        if (fluid.isEmpty()) {
            ChiselsAndBits.getConfig().getCommon().helpText(LocalStrings.HelpBitTankEmpty, tooltip);
        } else {
            ChiselsAndBits.getConfig()
                    .getCommon()
                    .helpText(
                            LocalStrings.HelpBitTankFilled,
                            tooltip,
                            DeprecationHelper.translateToLocal(fluid.getTranslationKey()),
                            String.valueOf((int) Math.floor(fluid.getAmount() * 4.096)));
        }
    }

    @Nullable
    @Override
    public ICapabilityProvider initCapabilities(final class_1799 stack, @Nullable final class_2487 nbt) {
        return new FluidHandlerItemStack(stack, FluidAttributes.BUCKET_VOLUME);
    }

    @Override
    protected boolean method_7710(
            final class_2338 pos,
            final class_1937 worldIn,
            @Nullable final class_1657 player,
            final class_1799 stack,
            final class_2680 state) {
        super.method_7710(pos, worldIn, player, stack, state);
        if (worldIn.field_9236) {
            return false;
        }

        final class_2586 tileEntity = worldIn.method_8321(pos);
        if (!(tileEntity instanceof TileEntityBitStorage tileEntityBitStorage)) {
            return false;
        }

        tileEntityBitStorage
                .getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY)
                .ifPresent(t -> t.fill(
                        stack.getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY)
                                .map(s -> s.drain(Integer.MAX_VALUE, IFluidHandler.FluidAction.EXECUTE))
                                .orElse(FluidStack.EMPTY),
                        IFluidHandler.FluidAction.EXECUTE));

        return true;
    }
}
