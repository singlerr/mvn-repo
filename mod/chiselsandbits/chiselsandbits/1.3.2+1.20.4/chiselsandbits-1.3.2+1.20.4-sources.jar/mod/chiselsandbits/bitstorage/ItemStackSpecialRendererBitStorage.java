package mod.chiselsandbits.bitstorage;

import mod.chiselsandbits.registry.ModBlocks;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_756;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;

public class ItemStackSpecialRendererBitStorage extends class_756 {
    public ItemStackSpecialRendererBitStorage() {
        super(
                class_310.method_1551().method_31975(),
                class_310.method_1551().method_31974());
    }

    @Override
    public void method_3166(
            class_1799 stack,
            class_811 itemDisplayContext,
            class_4587 matrixStack,
            class_4597 buffer,
            int combinedLight,
            int combinedOverlay) {
        final class_1087 model = class_310.method_1551()
                .method_1554()
                .method_4742(new class_1091(
                        class_7923.field_41175.method_10221(ModBlocks.BIT_STORAGE_BLOCK.get()), "facing=east"));

        class_310.method_1551()
                .method_1541()
                .method_3350()
                .method_3367(
                        matrixStack.method_23760(),
                        buffer.getBuffer(class_1921.method_23583()),
                        ModBlocks.BIT_STORAGE_BLOCK.get().method_9564(),
                        model,
                        1f,
                        1f,
                        1f,
                        combinedLight,
                        combinedOverlay);

        final TileEntityBitStorage tileEntity = new TileEntityBitStorage(class_2338.field_10980, class_2246.field_10124.method_9564());
        tileEntity
                .getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY)
                .ifPresent(t -> t.fill(
                        stack.getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY)
                                .map(s -> s.drain(Integer.MAX_VALUE, IFluidHandler.FluidAction.SIMULATE))
                                .orElse(FluidStack.EMPTY),
                        IFluidHandler.FluidAction.EXECUTE));
        class_310.method_1551()
                .method_31975()
                .method_23077(tileEntity, matrixStack, buffer, combinedLight, combinedOverlay);
    }
}
