package mod.chiselsandbits.bitstorage;

import java.util.Objects;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.IBitBag;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.registry.ModTileEntityTypes;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_7923;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.items.IItemHandler;
import org.jetbrains.annotations.NotNull;

public class TileEntityBitStorage extends class_2586 implements IItemHandler {

    public static final int MAX_CONTENTS = 4096;
    // best conversion...
    // 125mb = 512bits
    public static final int MB_PER_BIT_CONVERSION = 125;
    public static final int BITS_PER_MB_CONVERSION = 512;
    private final PseudoFluidHandler pseudoFluidHandler = new PseudoFluidHandler(this);
    public LazyOptional<IItemHandler> itemHandler = LazyOptional.of(() -> this);
    public LazyOptional<IFluidHandler> fluidHandler = LazyOptional.of(() -> pseudoFluidHandler);
    private class_2680 state = null;
    private class_3611 myFluid = null;
    private int bits = 0;
    private int oldLV = -1;

    public TileEntityBitStorage(class_2338 pos, class_2680 state) {
        super(ModTileEntityTypes.BIT_STORAGE.get(), pos, state);
    }

    public PseudoFluidHandler getPseudoFluidHandler() {
        return pseudoFluidHandler;
    }

    @Override
    public class_2487 method_16887() {
        return method_38242();
    }

    @Override
    public class_2622 method_38235() {
        return new class_2622(
                method_11016(), ModTileEntityTypes.BIT_STORAGE.get(), method_38242());
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        final String fluid = nbt.method_10558("fluid");

        if (fluid.equals("")) {
            final int rawState = nbt.method_10550("blockstate");
            if (rawState != -1) {
                this.state = ModUtil.getStateById(rawState);
            } else {
                this.state = null;
            }
        } else {
            myFluid = class_7923.field_41173.method_10223(new class_2960(fluid));
        }

        bits = nbt.method_10550("bits");
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);

        nbt.method_10582(
                "fluid",
                myFluid == null
                        ? ""
                        : Objects.requireNonNull(class_7923.field_41173.method_10221(myFluid))
                                .toString());
        nbt.method_10569("blockstate", myFluid != null || state == null ? -1 : ModUtil.getStateId(state));
        nbt.method_10569("bits", bits);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> LazyOptional<T> getCapability(final Capability<T> capability, final class_2350 facing) {
        if (capability == net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return itemHandler.cast();
        }

        if (capability == net.minecraftforge.fluids.capability.CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY) {
            return fluidHandler.cast();
        }

        return super.getCapability(capability, facing);
    }

    @Override
    public int getSlots() {
        return 1;
    }

    @Override
    public class_1799 getStackInSlot(final int slot) {
        if (bits > 0 && slot == 0 && (myFluid != null || state != null)) {
            if (myFluid != null) {
                return getFluidBitStack(myFluid, bits);
            } else {
                return getBlockBitStack(state, bits);
            }
        }

        return ModUtil.getEmptyStack();
    }

    public @Nonnull class_1799 getFluidBitStack(final class_3611 liquid, final int amount) {
        if (liquid == null) {
            return ModUtil.getEmptyStack();
        }

        return ItemChiseledBit.createStack(
                ModUtil.getStateId(liquid.method_15785().method_15759()), amount, false);
    }

    public @Nonnull class_1799 getBlockBitStack(final class_2680 blockState, final int amount) {
        if (blockState == null) {
            return ModUtil.getEmptyStack();
        }

        return ItemChiseledBit.createStack(ModUtil.getStateId(blockState), amount, false);
    }

    @Override
    public @Nonnull class_1799 insertItem(final int slot, final class_1799 stack, final boolean simulate) {
        if (!ModUtil.isEmpty(stack) && stack.method_7909() instanceof ItemChiseledBit) {
            final int state = ItemChiseledBit.getStackState(stack);
            final class_2680 blk = ModUtil.getStateById(state);

            final class_1799 fluidInsertion = attemptFluidBitStackInsertion(stack, simulate, blk);
            if (fluidInsertion != stack) {
                return fluidInsertion;
            }

            return attemptSolidBitStackInsertion(stack, simulate, blk);
        } else if (!ModUtil.isEmpty(stack) && BlockBitInfo.canChisel(stack) && myFluid == null) {
            final class_2680 stackState = ModUtil.getStateFromItem(stack);
            if (stackState.method_26204() != class_2246.field_10124) {
                if (this.state == null) {
                    this.state = stackState;
                    this.bits = 4096;
                } else if (ModUtil.getStateId(this.state) == ModUtil.getStateId(stackState)) {

                }
            }
        }
        return stack;
    }

    @NotNull
    private class_1799 attemptFluidBitStackInsertion(
            final class_1799 stack, final boolean simulate, final class_2680 blk) {
        class_3611 f = null;
        for (final class_3611 fl : class_7923.field_41173) {
            if (fl.method_15785().method_15759().method_26204() == blk.method_26204()) {
                f = fl;
                break;
            }
        }

        if (f == null) {
            return stack;
        }

        final class_1799 bitItem = getFluidBitStack(myFluid, bits);
        final boolean canInsert = ModUtil.isEmpty(bitItem)
                || class_1799.method_31577(bitItem, stack) && bitItem.method_7909() == stack.method_7909()
                || state == null;

        if (canInsert) {
            final int merged = bits + ModUtil.getStackSize(stack);
            final int amount = Math.min(merged, MAX_CONTENTS);

            if (!simulate) {
                final class_3611 oldFluid = myFluid;
                final class_2680 oldState = state;
                final int oldBits = bits;

                myFluid = f;
                state = null;
                bits = amount;

                if (bits != oldBits || myFluid != oldFluid || oldState != null) {
                    saveAndUpdate();
                }
            }

            if (amount < merged) {
                final class_1799 out = ModUtil.copy(stack);
                ModUtil.setStackSize(out, merged - amount);
                return out;
            }

            return ModUtil.getEmptyStack();
        }
        return stack;
    }

    @NotNull
    private class_1799 attemptSolidBitStackInsertion(
            final class_1799 stack, final boolean simulate, final class_2680 blk) {
        class_3611 f = null;
        for (final class_3611 fl : class_7923.field_41173) {
            if (fl.method_15785().method_15759().method_26204() == blk.method_26204()) {
                f = fl;
                break;
            }
        }

        if (f != null) {
            return stack;
        }

        final class_1799 bitItem = getBlockBitStack(blk, bits);
        final boolean canInsert = ModUtil.isEmpty(bitItem)
                || class_1799.method_31577(bitItem, stack) && bitItem.method_7909() == stack.method_7909();

        if (canInsert) {
            final int merged = bits + ModUtil.getStackSize(stack);
            final int amount = Math.min(merged, MAX_CONTENTS);

            if (!simulate) {
                final class_3611 oldFluid = myFluid;
                final class_2680 oldBlockState = this.state;
                final int oldBits = bits;

                myFluid = null;
                state = blk;
                bits = amount;

                if (bits != oldBits || state != oldBlockState || oldFluid != null) {
                    saveAndUpdate();
                }
            }

            if (amount < merged) {
                final class_1799 out = ModUtil.copy(stack);
                ModUtil.setStackSize(out, merged - amount);
                return out;
            }

            return ModUtil.getEmptyStack();
        }
        return stack;
    }

    private void saveAndUpdate() {
        if (field_11863 == null || method_10997() == null) {
            return;
        }

        method_5431();
        ModUtil.sendUpdate(field_11863, method_11016());

        final int lv = getLightValue();
        if (oldLV != lv) {
            method_10997().method_22336().method_15513(method_11016());
            oldLV = lv;
        }
    }

    /**
     * Dosn't limit to stack size...
     *
     * @param slot
     * @param amount
     * @param simulate
     * @return
     */
    public @Nonnull class_1799 extractBits(final int slot, final int amount, final boolean simulate) {
        final class_1799 contents = getStackInSlot(slot);

        if (!contents.method_7960() && amount > 0) {
            // how many to extract?
            ModUtil.setStackSize(contents, Math.min(amount, ModUtil.getStackSize(contents)));

            // modulate?
            if (!simulate) {
                final int oldBits = bits;

                bits -= ModUtil.getStackSize(contents);
                if (bits <= 0) {
                    bits = 0;
                    state = null;
                    myFluid = null;
                }

                if (bits != oldBits) {
                    saveAndUpdate();
                }
            }

            return contents;
        }

        return ModUtil.getEmptyStack();
    }

    @Override
    public class_1799 extractItem(final int slot, final int amount, final boolean simulate) {
        return extractBits(slot, Math.min(amount, ModItems.ITEM_BLOCK_BIT.get().method_7882()), simulate);
    }

    //    public FluidStack getAccessableFluid() {
    //        if (myFluid == null && state != null) return FluidStack.EMPTY;
    //
    //        int mb = (bits - bits % BITS_PER_MB_CONVERSION) / BITS_PER_MB_CONVERSION;
    //        mb *= MB_PER_BIT_CONVERSION;
    //
    //        if (mb > 0 && myFluid != null) {
    //            return new FluidStack(myFluid, mb);
    //        }
    //
    //        return FluidStack.EMPTY;
    //    }
    //
    //    FluidStack getBitsAsFluidStack() {
    //        if (myFluid == null && state != null) return FluidStack.EMPTY;
    //
    //        if (bits > 0 && myFluid != null) {
    //            return new FluidStack(myFluid, bits);
    //        }
    //
    //        return null;
    //    }

    public int getLightValue() {
        final class_2680 workingState =
                myFluid == null ? state : myFluid.method_15785().method_15759();
        if (workingState == null) {
            return 0;
        }

        return DeprecationHelper.getLightValue(workingState);
    }

    boolean extractBits(
            final class_1657 playerIn, final double hitX, final double hitY, final double hitZ, final class_2338 pos) {
        if (!playerIn.method_5715()) {
            final class_1799 is = extractItem(0, 64, false);
            if (!is.method_7960()) {
                ChiselsAndBits.getApi()
                        .giveBitToPlayer(
                                playerIn, is, new class_243(hitX + pos.method_10263(), hitY + pos.method_10264(), hitZ + pos.method_10260()));
            }
            return true;
        }

        return false;
    }

    boolean addAllPossibleBits(final class_1657 playerIn) {
        if (playerIn.method_5715()) {
            boolean change = false;
            for (int x = 0; x < playerIn.field_7514.method_5439(); x++) {
                final class_1799 stackInSlot = ModUtil.nonNull(playerIn.field_7514.method_5438(x));
                if (ChiselsAndBits.getApi().getItemType(stackInSlot) == ItemType.CHISELED_BIT) {
                    playerIn.field_7514.method_5447(x, insertItem(0, stackInSlot, false));
                    change = true;
                }

                if (ChiselsAndBits.getApi().getItemType(stackInSlot) == ItemType.BIT_BAG) {
                    final IBitBag bag = ChiselsAndBits.getApi().getBitbag(stackInSlot);

                    if (bag == null) {
                        continue;
                    }

                    for (int y = 0; y < bag.getSlots(); ++y) {
                        bag.insertItem(y, insertItem(0, bag.extractItem(y, bag.getSlotLimit(y), false), false), false);
                        change = true;
                    }
                }
            }

            if (change) {
                playerIn.field_7514.method_5431();
            }

            return change;
        }

        return false;
    }

    boolean addHeldBits(final @Nonnull class_1799 current, final class_1657 playerIn) {
        if (playerIn.method_5715() || this.bits == 0) {
            if (ChiselsAndBits.getApi().getItemType(current) == ItemType.CHISELED_BIT
                    || BlockBitInfo.canChisel(current)) {
                final class_1799 resultStack = insertItem(0, current, false);
                if (!playerIn.method_7337()) {
                    playerIn.field_7514.method_5447(playerIn.field_7514.field_7545, resultStack);
                    playerIn.field_7514.method_5431();
                }
                return true;
            }
        }

        return false;
    }

    @Override
    public int getSlotLimit(final int slot) {
        return TileEntityBitStorage.BITS_PER_MB_CONVERSION;
    }

    @Override
    public boolean isItemValid(final int slot, @NotNull final class_1799 stack) {
        return !ModUtil.isEmpty(stack) && (stack.method_7909() instanceof ItemChiseledBit || BlockBitInfo.canChisel(stack));
    }

    public class_2680 getState() {
        return state;
    }

    public class_3611 getMyFluid() {
        return myFluid;
    }

    public int getBits() {
        return bits;
    }

    private static class PseudoFluidHandler implements IFluidHandler {

        private final TileEntityBitStorage source;

        public PseudoFluidHandler(TileEntityBitStorage source) {
            this.source = source;
        }

        @Override
        public int getTanks() {
            return 1;
        }

        @NotNull
        @Override
        public net.minecraftforge.fluids.FluidStack getFluidInTank(final int tank) {
            /*   return new net.minecraftforge.fluids.FluidStack(
            source.getAccessableFluid().getFluid(),
            source.getAccessableFluid().getAmount());*/
            return FluidStack.EMPTY;
        }

        @Override
        public long getTankCapacityInDroplets(int i) {
            return getTankCapacity(i);
        }

        @Override
        public long fillDroplets(net.minecraftforge.fluids.FluidStack fluidStack, FluidAction fluidAction) {
            return fill(fluidStack, fluidAction);
        }

        @Override
        public int getTankCapacity(final int tank) {
            return MAX_CONTENTS;
        }

        @Override
        public boolean isFluidValid(final int tank, @NotNull final net.minecraftforge.fluids.FluidStack stack) {
            //            if (source.getAccessableFluid().isEmpty() && source.state == null) return true;
            //
            //            if (source.state != null) return false;
            //            return Objects.equals(
            //                    FluidUtil.getRegistryName(source.getAccessableFluid().getFluid()),
            //                    FluidUtil.getRegistryName(stack.getFluid()));
            return false;
        }

        @Override
        public int fill(final net.minecraftforge.fluids.FluidStack resource, final FluidAction action) {
            //            if (resource == null || source.state != null) {
            //                return 0;
            //            }
            //
            //            final int possibleAmount =
            //                    resource.getAmount() - resource.getAmount() %
            // TileEntityBitStorage.MB_PER_BIT_CONVERSION;
            //
            //            if (possibleAmount > 0) {
            //                final int bitCount = possibleAmount
            //                        * TileEntityBitStorage.BITS_PER_MB_CONVERSION
            //                        / TileEntityBitStorage.MB_PER_BIT_CONVERSION;
            //                final ItemStack bitItems = source.getFluidBitStack(resource.getFluid(), bitCount);
            //                final ItemStack leftOver = source.insertItem(0, bitItems, action.simulate());
            //
            //                if (ModUtil.isEmpty(leftOver)) {
            //                    return possibleAmount;
            //                }
            //
            //                int mbUsedUp = ModUtil.getStackSize(leftOver);
            //
            //                // round up...
            //                mbUsedUp *= TileEntityBitStorage.MB_PER_BIT_CONVERSION;
            //                mbUsedUp += TileEntityBitStorage.BITS_PER_MB_CONVERSION - 1;
            //                mbUsedUp /= TileEntityBitStorage.BITS_PER_MB_CONVERSION;
            //
            //                return resource.getAmount() - mbUsedUp;
            //            }

            return 0;
        }

        @NotNull
        @Override
        public net.minecraftforge.fluids.FluidStack drain(
                final net.minecraftforge.fluids.FluidStack resource, final FluidAction action) {
            //            if (resource == null || source.state != null) {
            //                return net.minecraftforge.fluids.FluidStack.EMPTY;
            //            }
            //
            //            final FluidStack a = source.getAccessableFluid();
            //
            //            if (a != null
            //                    && resource.containsFluid(new net.minecraftforge.fluids.FluidStack(
            //                            a.getFluid(), a.getAmount()))) // right type of fluid.
            //            {
            //                final int aboutHowMuch = (int) resource.getAmount();
            //
            //                final int mbThatCanBeRemoved = (int) Math.min(
            //                        a.getAmount(), aboutHowMuch - aboutHowMuch %
            // TileEntityBitStorage.MB_PER_BIT_CONVERSION);
            //                if (mbThatCanBeRemoved > 0) {
            //                    a.setAmount(mbThatCanBeRemoved);
            //
            //                    if (action.execute()) {
            //                        final int bitCount = mbThatCanBeRemoved
            //                                * TileEntityBitStorage.BITS_PER_MB_CONVERSION
            //                                / TileEntityBitStorage.MB_PER_BIT_CONVERSION;
            //                        source.extractBits(0, bitCount, false);
            //                    }
            //
            //                    return new net.minecraftforge.fluids.FluidStack(a.getFluid(), a.getAmount());
            //                }
            //            }

            return net.minecraftforge.fluids.FluidStack.EMPTY;
        }

        @NotNull
        @Override
        public net.minecraftforge.fluids.FluidStack drain(final long maxDrain, final FluidAction action) {
            //            if (maxDrain <= 0 || source.state != null) {
            //                return net.minecraftforge.fluids.FluidStack.EMPTY;
            //            }
            //
            //            final FluidStack a = source.getAccessableFluid();
            //
            //            if (a != null) // right type of fluid.
            //            {
            //                final int aboutHowMuch = (int) maxDrain;
            //
            //                final int mbThatCanBeRemoved = (int) Math.min(
            //                        a.getAmount(), aboutHowMuch - aboutHowMuch %
            // TileEntityBitStorage.MB_PER_BIT_CONVERSION);
            //                if (mbThatCanBeRemoved > 0) {
            //                    a.setAmount(mbThatCanBeRemoved);
            //
            //                    if (action.execute()) {
            //                        final int bitCount = mbThatCanBeRemoved
            //                                * TileEntityBitStorage.BITS_PER_MB_CONVERSION
            //                                / TileEntityBitStorage.MB_PER_BIT_CONVERSION;
            //                        source.extractBits(0, bitCount, false);
            //                    }
            //
            //                    return new net.minecraftforge.fluids.FluidStack(a.getFluid(), a.getAmount());
            //                }
            //            }

            return net.minecraftforge.fluids.FluidStack.EMPTY;
        }
    }
}
