package mod.chiselsandbits.bitstorage;

import java.util.Objects;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import mod.chiselsandbits.render.chiseledblock.ChiseledBlockBakedModel;
import mod.chiselsandbits.render.chiseledblock.ChiseledBlockSmartModel;
import mod.chiselsandbits.utils.FluidUtil;
import mod.chiselsandbits.utils.SimpleMaxSizedCache;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import net.minecraft.class_827;

public class TileEntitySpecialRenderBitStorage implements class_827<TileEntityBitStorage> {

    private static final SimpleMaxSizedCache<CacheKey, VoxelBlob> STORAGE_CONTENTS_BLOB_CACHE =
            new SimpleMaxSizedCache<>(ChiselsAndBits.getConfig()
                    .getClient()
                    .bitStorageContentCacheSize
                    .get());

    public TileEntitySpecialRenderBitStorage(class_824 dispatcher) {}

    @Override
    public void render(
            final TileEntityBitStorage te,
            final float partialTicks,
            final class_4587 matrixStackIn,
            final class_4597 buffer,
            final int combinedLightIn,
            final int combinedOverlayIn) {
        if (te.getMyFluid() != null) {
            //            final FluidStack fluidStack = te.getBitsAsFluidStack();
            //            if (fluidStack != null) {
            //                RenderType.chunkBufferLayers().forEach(renderType -> {
            //                    if (!RenderTypeUtils.canRenderInLayer(fluidStack.getFluid().defaultFluidState(),
            // renderType))
            //                        return;
            //
            //                    if (renderType == RenderType.translucent() && Minecraft.useShaderTransparency())
            //                        renderType = Sheets.translucentCullBlockSheet();
            //
            //                    final VertexConsumer builder = buffer.getBuffer(renderType);
            //
            //                    final float fullness = (float) fluidStack.getAmount() / (float)
            // TileEntityBitStorage.MAX_CONTENTS;
            //
            //                    FluidCuboidHelper.renderScaledFluidCuboid(
            //                            fluidStack,
            //                            matrixStackIn,
            //                            builder,
            //                            combinedLightIn,
            //                            combinedOverlayIn,
            //                            1,
            //                            1,
            //                            1,
            //                            15,
            //                            15 * fullness,
            //                            15);
            //                });
            //            }

            return;
        }

        final int bits = te.getBits();
        final class_2680 state = te.getMyFluid() == null
                ? te.getState()
                : te.getMyFluid().method_15785().method_15759();
        if (bits <= 0 || state == null) {
            return;
        }

        VoxelBlob innerModelBlob = STORAGE_CONTENTS_BLOB_CACHE.get(new CacheKey(ModUtil.getStateId(state), bits));
        if (innerModelBlob == null) {
            innerModelBlob = new VoxelBlob();
            innerModelBlob.fillAmountFromBottom(ModUtil.getStateId(state), bits);
            STORAGE_CONTENTS_BLOB_CACHE.put(new CacheKey(ModUtil.getStateId(state), bits), innerModelBlob);
        }

        matrixStackIn.method_22903();
        matrixStackIn.method_46416(2 / 16f, 2 / 16f, 2 / 16f);
        matrixStackIn.method_22905(12 / 16f, 12 / 16f, 12 / 16f);
        final VoxelBlob finalInnerModelBlob = innerModelBlob;
        class_1921.method_22720().forEach(renderType -> {
            final ChiseledBlockBakedModel innerModel = ChiseledBlockSmartModel.getCachedModel(
                    ModUtil.getStateId(state),
                    finalInnerModelBlob,
                    ChiselRenderType.fromLayer(renderType, te.getMyFluid() != null),
                    class_290.field_1590,
                    Objects.requireNonNull(te.method_10997()).method_8409());

            if (!innerModel.isEmpty()) {
                final float r =
                        te.getMyFluid() == null ? 1f : ((FluidUtil.getColor(te.getMyFluid()) >> 16) & 0xff) / 255F;
                final float g =
                        te.getMyFluid() == null ? 1f : ((FluidUtil.getColor(te.getMyFluid()) >> 8) & 0xff) / 255f;
                final float b = te.getMyFluid() == null ? 1f : ((FluidUtil.getColor(te.getMyFluid())) & 0xff) / 255f;
                class_310.method_1551()
                        .method_1541()
                        .method_3350()
                        .method_3367(
                                matrixStackIn.method_23760(),
                                buffer.getBuffer(renderType),
                                state,
                                innerModel,
                                r,
                                g,
                                b,
                                combinedLightIn,
                                combinedOverlayIn);
            }
        });
        matrixStackIn.method_22909();
    }

    private static final class CacheKey {
        private final int blockStateId;
        private final int bitCount;

        private CacheKey(final int blockStateId, final int bitCount) {
            this.blockStateId = blockStateId;
            this.bitCount = bitCount;
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof CacheKey cacheKey)) {
                return false;
            }
            return blockStateId == cacheKey.blockStateId && bitCount == cacheKey.bitCount;
        }

        @Override
        public int hashCode() {
            return Objects.hash(blockStateId, bitCount);
        }
    }
}
