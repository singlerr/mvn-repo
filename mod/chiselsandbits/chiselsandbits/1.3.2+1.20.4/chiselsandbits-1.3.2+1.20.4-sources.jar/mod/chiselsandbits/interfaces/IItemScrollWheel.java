package mod.chiselsandbits.interfaces;

import net.minecraft.class_1657;
import net.minecraft.class_1799;

public interface IItemScrollWheel {

    void scroll(class_1657 player, class_1799 stack, int dwheel);
}
