package mod.chiselsandbits.interfaces;

import net.minecraft.class_1799;

public interface IPatternItem {

    class_1799 getPatternedItem(class_1799 stack, final boolean wantRealBlocks);

    boolean isWritten(class_1799 stack);
}
