package mod.chiselsandbits.interfaces;

import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2470;

public interface IVoxelBlobItem {

    void rotate(final class_1799 is, final class_2350.class_2351 axis, final class_2470 rotation);
}
