package mod.chiselsandbits.chiseledblock;

import com.communi.suggestu.saecularia.caudices.core.block.IBlockWithWorldlyProperties;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_8235;
import net.minecraft.class_8567;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings({"deprecation", "NullableProblems"})
public class ReflectionHelperBlock extends class_2248 implements IBlockWithWorldlyProperties {
    private final ThreadLocal<String> lastInvokedThreadLocalMethodName = ThreadLocal.withInitial(() -> "unknown");

    public ReflectionHelperBlock() {
        super(class_2251.method_9637());
    }

    private void markMethod() {
        setLastInvokedThreadLocalMethodName(StackWalker.getInstance()
                .walk(stream -> stream.filter(frame -> !frame.toString().contains("idea.debugger"))
                        .skip(1)
                        .findFirst()
                        .map(StackWalker.StackFrame::getMethodName)
                        .orElse("unknown")));
    }

    @Nullable
    @Override
    public class_265 method_9571(
            @Nullable final class_2680 state, @Nullable final class_1922 worldIn, @Nullable final class_2338 pos) {
        markMethod();
        return class_259.method_1073();
    }

    @Nullable
    @Override
    public class_265 method_25959(
            @Nullable final class_2680 state, @Nullable final class_1922 reader, @Nullable final class_2338 pos) {
        markMethod();
        return class_259.method_1073();
    }

    @Nullable
    @Override
    public class_265 method_9530(
            @Nullable final class_2680 state,
            @Nullable final class_1922 worldIn,
            @Nullable final class_2338 pos,
            @Nullable final class_3726 context) {
        markMethod();
        return class_259.method_1073();
    }

    @Nullable
    @Override
    public class_265 method_9549(
            @Nullable final class_2680 state,
            @Nullable final class_1922 worldIn,
            @Nullable final class_2338 pos,
            @Nullable final class_3726 context) {
        markMethod();
        return class_259.method_1073();
    }

    @Override
    public float method_9594(
            @Nullable final class_2680 state,
            @Nullable final class_1657 player,
            @Nullable final class_1922 worldIn,
            @Nullable final class_2338 pos) {
        markMethod();
        return 0;
    }

    @Override
    public float method_9520() {
        markMethod();
        return 0;
    }

    @Override
    public float getFriction(class_2680 state, class_4538 levelReader, class_2338 pos, @Nullable class_1297 entity) {
        markMethod();
        return 0f;
    }

    @Override
    public int getLightEmission(class_2680 state, class_1922 blockGetter, class_2338 pos) {
        markMethod();
        return 0;
    }

    @Override
    public boolean canHarvestBlock(class_2680 state, class_1922 blockGetter, class_2338 pos, class_1657 player) {
        markMethod();
        return false;
    }

    @Override
    public class_1799 getCloneItemStack(
            class_2680 state, class_239 target, class_4538 blockGetter, class_2338 pos, class_1657 player) {
        markMethod();
        return class_1799.field_8037;
    }

    @Override
    public class_2680 rotate(class_2680 state, class_1936 levelAccessor, class_2338 pos, class_2470 rotation) {
        markMethod();
        return state;
    }

    @Override
    public boolean shouldCheckWeakPower(
            class_2680 blockState, class_8235 signalGetter, class_2338 blockPos, class_2350 direction) {
        markMethod();
        return false;
    }

    @Override
    public boolean shouldDisplayFluidOverlay(
            class_2680 state, class_1920 blockAndTintGetter, class_2338 pos, class_3610 fluidState) {
        markMethod();
        return false;
    }

    @Override
    public float[] getBeaconColorMultiplier(
            class_2680 state, class_4538 levelReader, class_2338 pos, class_2338 beaconPos) {
        markMethod();
        return new float[4];
    }

    @Override
    public class_2498 getSoundType(class_2680 state, class_4538 levelReader, class_2338 pos, @Nullable class_1297 entity) {
        markMethod();
        return class_2498.field_27197;
    }

    @Override
    public float getExplosionResistance(
            final class_2680 state, final class_1922 world, final class_2338 pos, final class_1927 explosion) {
        markMethod();
        return 0f;
    }

    @Override
    public List<class_1799> method_9560(class_2680 p_287732_, class_8567.class_8568 p_287596_) {
        markMethod();
        return Lists.newArrayList();
    }

    public String getLastInvokedThreadLocalMethodName() {
        return lastInvokedThreadLocalMethodName.get();
    }

    public void setLastInvokedThreadLocalMethodName(String lastInvokedThreadLocalMethodName) {
        this.lastInvokedThreadLocalMethodName.set(lastInvokedThreadLocalMethodName);
    }
}
