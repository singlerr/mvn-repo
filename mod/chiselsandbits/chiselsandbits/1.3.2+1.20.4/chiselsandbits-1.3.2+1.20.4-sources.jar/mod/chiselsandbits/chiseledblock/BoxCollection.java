package mod.chiselsandbits.chiseledblock;

import java.util.Collection;
import java.util.Iterator;
import net.minecraft.class_238;

public class BoxCollection implements Collection<class_238> {

    private final class_238[][] arrays;

    public BoxCollection(final class_238[] a) {
        arrays = new class_238[1][];
        arrays[0] = a;
    }

    public BoxCollection(final class_238[] a, final class_238[] b) {
        arrays = new class_238[2][];
        arrays[0] = a;
        arrays[1] = b;
    }

    public BoxCollection(final class_238[] a, final class_238[] b, final class_238[] c) {
        arrays = new class_238[3][];
        arrays[0] = a;
        arrays[1] = b;
        arrays[2] = c;
    }

    @Override
    public boolean add(final class_238 e) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean addAll(final Collection<? extends class_238> c) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean contains(final Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean containsAll(final Collection<?> c) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean isEmpty() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Iterator<class_238> iterator() {
        return new BoxIterator(arrays);
    }

    @Override
    public boolean remove(final Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean removeAll(final Collection<?> c) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean retainAll(final Collection<?> c) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        int size = 0;

        for (final class_238[] bb : arrays) {
            if (bb != null) {
                size += bb.length;
            }
        }

        return size;
    }

    @Override
    public Object[] toArray() {
        int s = size();
        final class_238[] storage = new class_238[s];

        s = 0;
        for (final class_238 bb : this) {
            storage[s++] = bb;
        }

        return storage;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T[] toArray(T[] a) {
        int s = 0;
        for (final class_238 bb : this) {
            a[s++] = (T) bb;
        }

        return a;
    }

    static class BoxIterator implements Iterator<class_238> {

        private final class_238[][] arrays;
        private int arrayOffset = 0, idx = -1;

        public BoxIterator(final class_238[][] a) {
            arrays = a;
            findNextItem();
        }

        private void findNextItem() {
            ++idx;

            if (arrays[arrayOffset] == null || idx >= arrays[arrayOffset].length) {
                idx = -1;
                ++arrayOffset;

                if (hasNext()) {
                    findNextItem();
                }
            }
        }

        @Override
        public boolean hasNext() {
            return arrays.length > arrayOffset;
        }

        @Override
        public class_238 next() {
            final class_238 box = arrays[arrayOffset][idx];

            findNextItem();

            return box;
        }

        @Override
        public void remove() {
            throw new RuntimeException("Not Implemented.");
        }
    }
}
