package mod.chiselsandbits.chiseledblock;

import io.netty.util.collection.IntObjectHashMap;
import io.netty.util.collection.IntObjectMap;
import java.util.HashMap;
import mod.chiselsandbits.api.IgnoreBlockLogic;
import mod.chiselsandbits.chiseledblock.data.VoxelType;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.registry.ModTags;
import mod.chiselsandbits.render.helpers.ModelUtil;
import mod.chiselsandbits.utils.ClassUtils;
import mod.chiselsandbits.utils.FluidUtil;
import mod.chiselsandbits.utils.SingleBlockBlockReader;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2404;
import net.minecraft.class_2490;
import net.minecraft.class_2680;
import net.minecraft.class_3611;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.class_8567;
import net.minecraft.class_8923;

public class BlockBitInfo {
    // imc api...
    private static final HashMap<class_2248, Boolean> ignoreLogicBlocks = new HashMap<>();
    // cache data..
    private static final HashMap<class_2680, BlockBitInfo> stateBitInfo = new HashMap<>();
    private static final HashMap<class_2248, SupportsAnalysisResult> supportedBlocks = new HashMap<>();
    private static final HashMap<class_2248, Boolean> forcedBlocks = new HashMap<>();
    private static final HashMap<class_2248, class_3611> fluidBlocks = new HashMap<>();
    private static final IntObjectMap<class_3611> fluidStates = new IntObjectHashMap<>();
    private static final HashMap<class_2680, Integer> bitColor = new HashMap<>();

    static {
        ignoreLogicBlocks.put(class_2246.field_10098, true);
        ignoreLogicBlocks.put(class_2246.field_28673, true);
        ignoreLogicBlocks.put(class_2246.field_42731, true);
        ignoreLogicBlocks.put(class_2246.field_37551, true);
        ignoreLogicBlocks.put(class_2246.field_28674, true);
        ignoreLogicBlocks.put(class_2246.field_10539, true);
        ignoreLogicBlocks.put(class_2246.field_10035, true);
        ignoreLogicBlocks.put(class_2246.field_10335, true);
        ignoreLogicBlocks.put(class_2246.field_10503, true);
        ignoreLogicBlocks.put(class_2246.field_9988, true);
        ignoreLogicBlocks.put(class_2246.field_10477, true);
    }

    public final boolean isCompatible;
    public final float hardness;
    public final float explosionResistance;

    private BlockBitInfo(final boolean isCompatible, final float hardness, final float explosionResistance) {
        this.isCompatible = isCompatible;
        this.hardness = hardness;
        this.explosionResistance = explosionResistance;
    }

    public static int getColorFor(final class_2680 state, final int tint) {
        Integer out = bitColor.get(state);

        if (out == null) {
            final class_2248 blk = state.method_26204();

            final class_3611 fluid = BlockBitInfo.getFluidFromBlock(blk);
            if (fluid != null) {
                out = FluidUtil.getColor(fluid);
            } else {
                final class_1799 target = ModUtil.getItemStackFromBlockState(state);

                if (ModUtil.isEmpty(target)) {
                    out = 0xffffff;
                } else {
                    out = ModelUtil.getItemStackColor(target, tint);
                }
            }

            bitColor.put(state, out);
        }

        return out;
    }

    public static void recalculate() {
        recalculateFluids();
    }

    public static void recalculateFluids() {
        fluidBlocks.clear();

        for (final class_3611 o : class_7923.field_41173) {
            if (o.method_15785().method_15771()) {
                BlockBitInfo.addFluidBlock(o);
            }
        }
    }

    public static void addFluidBlock(final class_3611 fluid) {
        fluidBlocks.put(fluid.method_15785().method_15759().method_26204(), fluid);

        for (final class_2680 state : fluid.method_15785()
                .method_15759()
                .method_26204()
                .method_9595()
                .method_11662()) {
            try {
                fluidStates.put(ModUtil.getStateId(state), fluid);
            } catch (final Throwable t) {
                Log.logError("Error while determining fluid state.", t);
            }
        }

        stateBitInfo.clear();
        supportedBlocks.clear();
    }

    public static class_3611 getFluidFromBlock(final class_2248 blk) {
        return fluidBlocks.get(blk);
    }

    public static VoxelType getTypeFromStateID(final int bit) {
        if (bit == 0) {
            return VoxelType.AIR;
        }

        return fluidStates.containsKey(bit) ? VoxelType.FLUID : VoxelType.SOLID;
    }

    public static void ignoreBlockLogic(final class_2248 which) {
        ignoreLogicBlocks.put(which, true);
        reset();
    }

    public static void forceStateCompatibility(final class_2248 which, final boolean forceStatus) {
        forcedBlocks.put(which, forceStatus);
        reset();
    }

    public static void reset() {
        stateBitInfo.clear();
        supportedBlocks.clear();
    }

    public static BlockBitInfo getBlockInfo(final class_2680 state) {
        BlockBitInfo bit = stateBitInfo.get(state);

        if (bit == null) {
            bit = BlockBitInfo.createFromState(state);
            stateBitInfo.put(state, bit);
        }

        return bit;
    }

    @SuppressWarnings("deprecation")
    public static SupportsAnalysisResult doSupportAnalysis(final class_2680 state) {
        if (state.method_26204() instanceof BlockChiseled) {
            return new SupportsAnalysisResult(
                    true, LocalStrings.ChiselSupportGenericNotSupported, LocalStrings.ChiselSupportIsAlreadyChiseled);
        }

        if (forcedBlocks.containsKey(state.method_26204())) {
            final boolean forcing = forcedBlocks.get(state.method_26204());
            return new SupportsAnalysisResult(
                    forcing, LocalStrings.ChiselSupportForcedUnsupported, LocalStrings.ChiselSupportForcedSupported);
        }

        final class_2248 blk = state.method_26204();
        if (supportedBlocks.containsKey(blk)) {
            return supportedBlocks.get(blk);
        }

        if (state.method_26164(ModTags.Blocks.BLOCKED_CHISELABLE)) {
            final SupportsAnalysisResult result = new SupportsAnalysisResult(
                    false, LocalStrings.ChiselSupportTagBlackListed, LocalStrings.ChiselSupportTagWhitelisted);
            supportedBlocks.put(blk, result);
            return result;
        }

        if (state.method_26164(ModTags.Blocks.FORCED_CHISELABLE)) {
            final SupportsAnalysisResult result = new SupportsAnalysisResult(
                    true, LocalStrings.ChiselSupportTagBlackListed, LocalStrings.ChiselSupportTagWhitelisted);
            supportedBlocks.put(blk, result);

            final BlockBitInfo info = BlockBitInfo.createFromState(state);
            stateBitInfo.put(state, info);

            return result;
        }

        try {
            // require basic hardness behavior...
            final ReflectionHelperBlock pb = ModBlocks.REFLECTION_HELPER_BLOCK.get();
            final Class<? extends class_2248> blkClass = blk.getClass();

            // custom dropping behavior?
            pb.method_9560(state, null);
            final Class<?> wc = ClassUtils.getDeclaringClass(
                    blkClass, pb.getLastInvokedThreadLocalMethodName(), class_2680.class, class_8567.class_8568.class);
            final boolean quantityDroppedTest =
                    wc == class_2248.class || wc == class_4970.class || wc == class_2404.class;

            final boolean isNotSlab = class_1792.method_7867(blk) != class_1802.field_8162 || state.method_26204() instanceof class_2404;
            boolean itemExistsOrNotSpecialDrops = quantityDroppedTest || isNotSlab;

            // ignore blocks with custom collision.
            pb.method_9530(null, null, null, null);
            Class<?> collisionClass = ClassUtils.getDeclaringClass(
                    blkClass,
                    pb.getLastInvokedThreadLocalMethodName(),
                    class_2680.class,
                    class_1922.class,
                    class_2338.class,
                    class_3726.class);
            boolean noCustomCollision = collisionClass == class_2248.class
                    || collisionClass == class_4970.class
                    || blk.getClass() == class_2490.class
                    || collisionClass == class_2404.class;

            // full cube specifically is tied to lighting... so for glass
            // Compatibility use isFullBlock which can be true for glass.
            boolean isFullBlock = state.method_26225() || blk instanceof class_8923 || blk instanceof class_2404;
            final BlockBitInfo info = BlockBitInfo.createFromState(state);

            final boolean tickingBehavior = blk.method_9542(state)
                    && ChiselsAndBits.getConfig()
                            .getServer()
                            .blackListRandomTickingBlocks
                            .get();
            boolean hasBehavior = (blk instanceof class_2343 || tickingBehavior);

            final Boolean IgnoredLogic = ignoreLogicBlocks.get(blk);
            if (blkClass.isAnnotationPresent(IgnoreBlockLogic.class) || IgnoredLogic != null && IgnoredLogic) {
                isFullBlock = true;
                noCustomCollision = true;
                hasBehavior = false;
                itemExistsOrNotSpecialDrops = true;
            }

            if (info.isCompatible
                    && noCustomCollision
                    && info.hardness >= -0.01f
                    && isFullBlock
                    && !hasBehavior
                    && itemExistsOrNotSpecialDrops) {
                final SupportsAnalysisResult result = new SupportsAnalysisResult(
                        true,
                        LocalStrings.ChiselSupportGenericNotSupported,
                        (blkClass.isAnnotationPresent(IgnoreBlockLogic.class) || IgnoredLogic != null && IgnoredLogic)
                                ? LocalStrings.ChiselSupportLogicIgnored
                                : LocalStrings.ChiselSupportGenericSupported);

                supportedBlocks.put(blk, result);
                stateBitInfo.put(state, info);
                return result;
            }

            if (fluidBlocks.containsKey(blk)) {
                stateBitInfo.put(state, info);

                final SupportsAnalysisResult result = new SupportsAnalysisResult(
                        true,
                        LocalStrings.ChiselSupportGenericNotSupported,
                        LocalStrings.ChiselSupportGenericFluidSupport);

                supportedBlocks.put(blk, result);
                return result;
            }

            SupportsAnalysisResult result = null;
            if (!info.isCompatible) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportCompatDeactivated, LocalStrings.ChiselSupportGenericSupported);
            } else if (!noCustomCollision) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportCustomCollision, LocalStrings.ChiselSupportGenericSupported);
            } else if (info.hardness < -0.01f) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportNoHardness, LocalStrings.ChiselSupportGenericSupported);
            } else if (!isNotSlab) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportIsSlab, LocalStrings.ChiselSupportGenericSupported);
            } else if (!isFullBlock) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportNotFullBlock, LocalStrings.ChiselSupportGenericSupported);
            } else if (hasBehavior) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportHasBehaviour, LocalStrings.ChiselSupportGenericSupported);
            } else if (!quantityDroppedTest) {
                result = new SupportsAnalysisResult(
                        false, LocalStrings.ChiselSupportHasCustomDrops, LocalStrings.ChiselSupportGenericSupported);
            }

            supportedBlocks.put(blk, result);
            return result;
        } catch (final Throwable t) {
            final SupportsAnalysisResult result = new SupportsAnalysisResult(
                    false, LocalStrings.ChiselSupportFailureToAnalyze, LocalStrings.ChiselSupportGenericSupported);
            // if the above test fails for any reason, then the block cannot be
            // supported.
            supportedBlocks.put(blk, result);
            return result;
        }
    }

    public static boolean isSupported(final class_2680 state) {
        return doSupportAnalysis(state).isSupported();
    }

    private static Class<?> getDeclaringClass(
            final Class<?> blkClass, final String methodName, final Class<?>... args) {
        try {
            return blkClass.getMethod(methodName, args).getDeclaringClass();
        } catch (final NoSuchMethodException e) {
            // nothing here...
        } catch (final SecurityException e) {
            // nothing here..
        } catch (final NoClassDefFoundError e) {
            Log.eligibility("Unable to determine blocks eligibility for chiseling, " + blkClass.getName()
                    + " attempted to load " + e.getMessage() + " missing @OnlyIn( Dist.CLIENT ) or @Optional?");
            return blkClass;
        } catch (final Throwable t) {
            return blkClass;
        }

        return getDeclaringClass(blkClass.getSuperclass(), methodName, args);
    }

    public static BlockBitInfo createFromState(final class_2680 state) {
        try {
            final ReflectionHelperBlock reflectBlock = ModBlocks.REFLECTION_HELPER_BLOCK.get();
            final class_2248 blk = state.method_26204();
            final Class<? extends class_2248> blkClass = blk.getClass();

            reflectBlock.method_9594(null, null, null, null);
            final Class<?> b_Class = ClassUtils.getDeclaringClass(
                    blkClass,
                    reflectBlock.getLastInvokedThreadLocalMethodName(),
                    class_2680.class,
                    class_1657.class,
                    class_1922.class,
                    class_2338.class);
            final boolean test_b = b_Class == class_2248.class || b_Class == class_4970.class;

            reflectBlock.method_9520();
            Class<?> exploResistanceClz =
                    ClassUtils.getDeclaringClass(blkClass, reflectBlock.getLastInvokedThreadLocalMethodName());
            final boolean test_c = exploResistanceClz == class_2248.class || exploResistanceClz == class_4970.class;

            reflectBlock.getExplosionResistance(null, null, null, null);
            exploResistanceClz = ClassUtils.getDeclaringClass(
                    blkClass,
                    reflectBlock.getLastInvokedThreadLocalMethodName(),
                    class_2680.class,
                    class_1922.class,
                    class_2338.class,
                    class_1927.class);
            final boolean test_d = exploResistanceClz == class_2248.class
                    || exploResistanceClz == class_4970.class
                    || exploResistanceClz == null;

            final boolean isFluid = fluidStates.containsKey(ModUtil.getStateId(state));

            // is it perfect?
            if (test_b && test_c && test_d && !isFluid) {
                final float blockHardness =
                        state.method_26214(new SingleBlockBlockReader(state, state.method_26204()), class_2338.field_10980);
                final float resistance = blk.method_9520();

                return new BlockBitInfo(true, blockHardness, resistance);
            } else {
                // less accurate, we can just pretend they are some fixed
                // hardness... say like stone?

                final class_2248 stone = class_2246.field_10340;
                return new BlockBitInfo(
                        ChiselsAndBits.getConfig().getServer().compatabilityMode.get(), 2f, 6f);
            }
        } catch (final Exception err) {
            return new BlockBitInfo(false, -1, -1);
        }
    }

    public static boolean canChisel(final class_2680 state) {
        return state.method_26204() instanceof BlockChiseled || isSupported(state);
    }

    public static boolean canChisel(final class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }

        if (stack.method_7909() instanceof ItemBlockChiseled) {
            return true;
        }

        if (stack.method_7909() instanceof class_1747 blockItem) {
            final class_2248 block = blockItem.method_7711();
            final class_2680 blockState = block.method_9564();
            final BlockBitInfo.SupportsAnalysisResult result = BlockBitInfo.doSupportAnalysis(blockState);

            return result.supported;
        }

        return false;
    }

    public static boolean isChiseled(final class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }

        return stack.method_7909() instanceof ItemBlockChiseled;
    }

    public static class SupportsAnalysisResult {
        private final boolean supported;
        private final LocalStrings unsupportedReason;
        private final LocalStrings supportedReason;

        public SupportsAnalysisResult(
                final boolean supported, final LocalStrings unsupportedReason, final LocalStrings supportedReason) {
            this.supported = supported;
            this.unsupportedReason = unsupportedReason;
            this.supportedReason = supportedReason;
        }

        public boolean isSupported() {
            return supported;
        }

        public LocalStrings getUnsupportedReason() {
            return unsupportedReason;
        }

        public LocalStrings getSupportedReason() {
            return supportedReason;
        }
    }
}
