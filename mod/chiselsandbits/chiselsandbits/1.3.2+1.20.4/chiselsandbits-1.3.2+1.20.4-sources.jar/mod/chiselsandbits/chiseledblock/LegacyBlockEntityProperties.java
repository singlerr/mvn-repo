package mod.chiselsandbits.chiseledblock;

import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2680;

public interface LegacyBlockEntityProperties {

    default class_2680 mirror(class_1936 level, class_2338 pos, class_2680 blockState, class_2415 mirror) {
        return blockState;
    }
}
