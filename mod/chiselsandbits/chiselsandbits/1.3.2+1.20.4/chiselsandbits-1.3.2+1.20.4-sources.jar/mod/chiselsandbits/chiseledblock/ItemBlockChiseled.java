package mod.chiselsandbits.chiseledblock;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.ChiselsAndBitsEvents;
import mod.chiselsandbits.api.EventBlockBitModification;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.chiseledblock.BlockChiseled.ReplaceWithChiseledValue;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.IntegerBox;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.LocalStrings;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IItemScrollWheel;
import mod.chiselsandbits.interfaces.IVoxelBlobItem;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.network.packets.PacketAccurateSneakPlace;
import mod.chiselsandbits.network.packets.PacketAccurateSneakPlace.IItemBlockAccurate;
import mod.chiselsandbits.network.packets.PacketRotateVoxelBlob;
import mod.chiselsandbits.render.helpers.SimpleInstanceCache;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2488;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2968;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5250;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ItemBlockChiseled extends class_1747 implements IVoxelBlobItem, IItemScrollWheel, IItemBlockAccurate {

    private static final Logger log = LoggerFactory.getLogger(ItemBlockChiseled.class);
    SimpleInstanceCache<class_1799, List<class_2561>> tooltipCache =
            new SimpleInstanceCache<class_1799, List<class_2561>>(null, new ArrayList<class_2561>());

    public ItemBlockChiseled(final class_2248 block, class_1792.class_1793 builder) {
        super(block, builder);
    }

    public static boolean tryPlaceBlockAt(
            final @Nonnull class_2248 block,
            final @Nonnull class_1799 stack,
            final @Nonnull class_1657 player,
            final @Nonnull class_1937 world,
            @Nonnull class_2338 pos,
            final @Nonnull class_2350 side,
            final @Nonnull class_1268 hand,
            final double hitX,
            final double hitY,
            final double hitZ,
            final class_2338 partial,
            final boolean modulateWorld) {
        final VoxelBlob[][][] blobs = new VoxelBlob[2][2][2];

        // you can't place empty blocks...
        if (!stack.method_7985()) {
            return false;
        }

        final VoxelBlob source = ModUtil.getBlobFromStack(stack, player);

        final IntegerBox modelBounds = source.getBounds();
        class_2338 offset = partial == null || modelBounds == null
                ? new class_2338(0, 0, 0)
                : ModUtil.getPartialOffset(side, partial, modelBounds);
        if (offset.method_10263() < 0) {
            pos = pos.method_10069(-1, 0, 0);
            offset = offset.method_10069(VoxelBlob.dim, 0, 0);
        }

        if (offset.method_10264() < 0) {
            pos = pos.method_10069(0, -1, 0);
            offset = offset.method_10069(0, VoxelBlob.dim, 0);
        }

        if (offset.method_10260() < 0) {
            pos = pos.method_10069(0, 0, -1);
            offset = offset.method_10069(0, 0, VoxelBlob.dim);
        }

        for (int x = 0; x < 2; x++) {
            for (int y = 0; y < 2; y++) {
                for (int z = 0; z < 2; z++) {
                    blobs[x][y][z] = source.offset(
                            offset.method_10263() - source.detail * x,
                            offset.method_10264() - source.detail * y,
                            offset.method_10260() - source.detail * z);
                    final int solids = blobs[x][y][z].filled();
                    if (solids > 0) {
                        final class_2338 bp = pos.method_10069(x, y, z);

                        final EventBlockBitModification bmm =
                                new EventBlockBitModification(world, bp, player, hand, stack, true);
                        ChiselsAndBitsEvents.BLOCK_BIT_MODIFICATION.invoker().handle(bmm);
                        // test permissions.
                        if (!world.method_8505(player, bp) || bmm.isCancelled()) {
                            return false;
                        }

                        if (world.method_22347(bp)
                                || world.method_8320(bp)
                                        .method_26166(new class_1750(
                                                player,
                                                hand,
                                                stack,
                                                new class_3965(new class_243(hitX, hitY, hitZ), side, pos, false)))) {
                            continue;
                        }

                        final TileEntityBlockChiseled target = ModUtil.getChiseledTileEntity(world, bp, true);
                        if (target != null) {
                            if (!target.canMerge(blobs[x][y][z])) {
                                return false;
                            }

                            blobs[x][y][z] = blobs[x][y][z].merge(target.getBlob());
                            continue;
                        }

                        return false;
                    }
                }
            }
        }

        if (modulateWorld) {
            UndoTracker.getInstance().beginGroup(player);
            try {
                for (int x = 0; x < 2; x++) {
                    for (int y = 0; y < 2; y++) {
                        for (int z = 0; z < 2; z++) {
                            if (blobs[x][y][z].filled() > 0) {
                                final class_2338 bp = pos.method_10069(x, y, z);
                                final class_2680 state = world.method_8320(bp);

                                if (world.method_8320(bp)
                                        .method_26166(new class_1750(
                                                player,
                                                hand,
                                                stack,
                                                new class_3965(
                                                        new class_243(hitX, hitY, hitZ),
                                                        side,
                                                        bp,
                                                        false) // TODO: Figure is a recalc of the hit vector is needed
                                                // here.
                                                ))) {
                                    // clear it...

                                    world.method_8501(bp, class_2246.field_10124.method_9564());
                                }

                                if (world.method_22347(bp)) {
                                    final int commonBlock = blobs[x][y][z].getVoxelStats().mostCommonState;
                                    ReplaceWithChiseledValue rv =
                                            BlockChiseled.replaceWithChiseled(world, bp, state, commonBlock, true);
                                    if (rv.success && rv.te != null) {
                                        rv.te.completeEditOperation(blobs[x][y][z]);
                                    }

                                    continue;
                                }

                                final TileEntityBlockChiseled target = ModUtil.getChiseledTileEntity(world, bp, true);
                                if (target != null) {
                                    // Here
                                    target.completeEditOperation(blobs[x][y][z]);
                                    continue;
                                }

                                return false;
                            }
                        }
                    }
                }
            } finally {
                UndoTracker.getInstance().endGroup(player);
            }
        }

        return true;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_7851(
            final class_1799 stack,
            @Nullable final class_1937 worldIn,
            final List<class_2561> tooltip,
            final class_1836 flagIn) {
        super.method_7851(stack, worldIn, tooltip, flagIn);
        ChiselsAndBits.getConfig()
                .getCommon()
                .helpText(
                        LocalStrings.HelpChiseledBlock,
                        tooltip,
                        ClientSide.instance.getKeyName(class_310.method_1551().field_1690.field_1904),
                        ClientSide.instance.getKeyName(ClientSide.getOffGridPlacementKey()));

        if (stack.method_7985()) {
            if (ClientSide.instance.holdingShift()) {
                if (tooltipCache.needsUpdate(stack)) {
                    final VoxelBlob blob = ModUtil.getBlobFromStack(stack, null);
                    tooltipCache.updateCachedValue(blob.listContents(new ArrayList<>()));
                }

                tooltip.addAll(tooltipCache.getCached());
            } else {
                tooltip.add(class_2561.method_43470(LocalStrings.ShiftDetails.getLocal()));
            }
        }
    }

    @Override
    protected boolean method_7709(final class_1750 p_195944_1_, final class_2680 p_195944_2_) {
        // TODO: Check for offgrid logic.
        return canPlaceBlockHere(
                p_195944_1_.method_8045(),
                p_195944_1_.method_8037(),
                p_195944_1_.method_8038(),
                p_195944_1_.method_8036(),
                p_195944_1_.method_20287(),
                p_195944_1_.method_8041(),
                p_195944_1_.method_17698().field_1352,
                p_195944_1_.method_17698().field_1351,
                p_195944_1_.method_17698().field_1350,
                false);
    }

    public boolean vanillaStylePlacementTest(
            final @Nonnull class_1937 worldIn,
            @Nonnull class_2338 pos,
            @Nonnull class_2350 side,
            final class_1657 player,
            final class_1268 hand,
            final class_1799 stack) {
        final class_2248 block = worldIn.method_8320(pos).method_26204();

        if (block == class_2246.field_10477) {
            side = class_2350.field_11036;
        } else if (!block.method_9616(
                worldIn.method_8320(pos),
                new class_1750(
                        player, hand, stack, new class_3965(new class_243(0.5, 0.5, 0.5), side, pos, false)))) {
            pos = pos.method_10093(side);
        }

        return true;
    }

    public boolean canPlaceBlockHere(
            final @Nonnull class_1937 worldIn,
            final @Nonnull class_2338 pos,
            final @Nonnull class_2350 side,
            final class_1657 player,
            final class_1268 hand,
            final class_1799 stack,
            final double hitX,
            final double hitY,
            final double hitZ,
            boolean offgrid) {
        if (vanillaStylePlacementTest(worldIn, pos, side, player, hand, stack)) {
            return true;
        }

        if (offgrid) {
            return true;
        }

        if (tryPlaceBlockAt(
                method_7711(),
                stack,
                player,
                worldIn,
                pos,
                side,
                class_1268.field_5808,
                hitX,
                hitY,
                hitZ,
                null,
                false)) {
            return true;
        }

        return tryPlaceBlockAt(
                method_7711(),
                stack,
                player,
                worldIn,
                pos.method_10093(side),
                side,
                class_1268.field_5808,
                hitX,
                hitY,
                hitZ,
                null,
                false);
    }

    @Override
    public class_1269 method_7884(final class_1838 context) {
        final class_1799 stack = context.method_8036().method_5998(context.method_20287());

        if (!context.method_8045().field_9236 && !(context.method_8036() instanceof FakePlayer)) {
            // Say it "worked", Don't do anything we'll get a better packet.
            return class_1269.field_5812;
        }

        // send accurate packet.
        final PacketAccurateSneakPlace pasp = new PacketAccurateSneakPlace(
                context.method_8041(),
                context.method_8037(),
                context.method_20287(),
                context.method_8038(),
                context.method_17698().field_1352,
                context.method_17698().field_1351,
                context.method_17698().field_1350,
                ClientSide.offGridPlacement(context.method_8036()) // TODO: Figure out the placement logic.
                );

        ChiselsAndBits.getNetworkChannel().sendToServer(pasp);
        // constructor of BlockPlaceContext set its block pos to relative block pos of original, this cause placed
        // chiseled block over 1 bit
        return tryPlace(new class_1750(context), ClientSide.offGridPlacement(context.method_8036()));
    }

    @Override
    public class_1269 method_7712(final class_1750 context) {
        return tryPlace(context, false);
    }

    @Override
    protected boolean method_7708(final class_1750 context, final class_2680 state) {
        return placeBitBlock(
                context.method_8041(),
                context.method_8036(),
                context.method_8045(),
                context.method_8037(),
                context.method_8038(),
                context.method_17698().field_1352,
                context.method_17698().field_1351,
                context.method_17698().field_1350,
                state,
                false);
    }

    public boolean placeBitBlock(
            final class_1799 stack,
            final class_1657 player,
            final class_1937 world,
            final class_2338 pos,
            final class_2350 side,
            final double hitX,
            final double hitY,
            final double hitZ,
            final class_2680 newState,
            boolean offgrid) {
        if (offgrid) {

            final BitLocation bl = new BitLocation(
                    new class_3965(new class_243(hitX, hitY, hitZ), side, pos.method_10093(side.method_10153()), false),
                    BitOperation.PLACE);
            return tryPlaceBlockAt(
                    field_7901,
                    stack,
                    player,
                    world,
                    bl.blockPos,
                    side,
                    class_1268.field_5808,
                    hitX,
                    hitY,
                    hitZ,
                    new class_2338(bl.bitX, bl.bitY, bl.bitZ),
                    true);
        } else {
            return tryPlaceBlockAt(
                    field_7901, stack, player, world, pos, side, class_1268.field_5808, hitX, hitY, hitZ, null, true);
        }
    }

    @Override
    public class_2561 method_7864(final class_1799 stack) {
        final class_2487 comp = stack.method_7969();

        if (comp != null) {
            final class_2487 BlockEntityTag = comp.method_10562(ModUtil.NBT_BLOCKENTITYTAG);
            if (BlockEntityTag != null) {
                final NBTBlobConverter c = new NBTBlobConverter();
                c.readChisleData(BlockEntityTag, VoxelBlob.VERSION_ANY);

                final class_2680 state = c.getPrimaryBlockState();
                class_2561 name = ItemChiseledBit.getBitStateName(state);

                if (name != null) {
                    final class_2561 parent = super.method_7864(stack);
                    if (!(parent instanceof class_5250 formattedParent)) {
                        return parent;
                    }

                    return formattedParent.method_27693(" - ").method_10852(name);
                }
            }
        }

        return super.method_7864(stack);
    }

    @Override
    public void scroll(final class_1657 player, final class_1799 stack, final int dwheel) {
        final PacketRotateVoxelBlob p = new PacketRotateVoxelBlob(
                class_2350.class_2351.field_11052, dwheel > 0 ? class_2470.field_11463 : class_2470.field_11465);
        ChiselsAndBits.getNetworkChannel().sendToServer(p);
    }

    @Override
    public void rotate(final class_1799 stack, final class_2350.class_2351 axis, final class_2470 rotation) {
        class_2350 side = ModUtil.getSide(stack);

        if (axis == class_2351.field_11052) {
            switch (rotation) {
                case field_11464:
                    side = side.method_10170();
                case field_11463:
                    side = side.method_10170();
                    break;
                case field_11465:
                    side = side.method_10160();
                    break;
                default:
                case field_11467:
                    break;
            }
        } else {
            IBitAccess ba = ChiselsAndBits.getApi().createBitItem(stack);
            ba.rotate(axis, rotation);
            stack.method_7980(ba.getBitsAsItem(side, ChiselsAndBits.getApi().getItemType(stack), false)
                    .method_7969());
        }

        ModUtil.setSide(stack, side);
    }

    @Override
    public class_1269 tryPlace(final class_1838 context, final boolean offgrid) {
        final class_2680 state = context.method_8045().method_8320(context.method_8037());
        final class_2248 block = state.method_26204();

        class_2350 side = context.method_8038();
        class_2338 pos = context.method_8037();

        if (block == class_2246.field_10477 && state.method_11654(class_2488.field_11518).intValue() < 1) {
            side = class_2350.field_11036;
        } else {
            boolean canMerge = false;
            if (context.method_8041().method_7985()) {
                final TileEntityBlockChiseled tebc =
                        ModUtil.getChiseledTileEntity(context.method_8045(), context.method_8037(), true);

                if (tebc != null) {
                    final VoxelBlob blob = ModUtil.getBlobFromStack(context.method_8041(), context.method_8036());
                    canMerge = tebc.canMerge(blob);
                }
            }

            class_1750 replacementCheckContext =
                    context instanceof class_1750 ? (class_1750) context : new class_1750(context);
            if (context.method_8036()
                            .method_5770()
                            .method_8320(context.method_8037())
                            .method_26204()
                    instanceof BlockChiseled) {
                replacementCheckContext = new class_2968(
                        context.method_8045(), pos, class_2350.field_11033, class_1799.field_8037, class_2350.field_11036);
            }

            if (!canMerge && !offgrid && !state.method_26166(replacementCheckContext)) {
                pos = pos.method_10093(side);
            }
        }

        if (ModUtil.isEmpty(context.method_8041())) {
            return class_1269.field_5814;
        } else if (!context.method_8036().method_7343(pos, side, context.method_8041())) {
            return class_1269.field_5814;
        } else if (pos.method_10264() == 255
                && DeprecationHelper.getStateFromItem(context.method_8041()).method_51367()) {
            return class_1269.field_5814;
        } else if (context instanceof class_1750
                && canPlaceBlockHere(
                        context.method_8045(),
                        pos,
                        side,
                        context.method_8036(),
                        context.method_20287(),
                        context.method_8041(),
                        context.method_17698().field_1352,
                        context.method_17698().field_1351,
                        context.method_17698().field_1350,
                        offgrid)) {
            final class_2680 BlockState1 = method_7707((class_1750) context);

            if (placeBitBlock(
                    context.method_8041(),
                    context.method_8036(),
                    context.method_8045(),
                    pos,
                    side,
                    context.method_17698().field_1352,
                    context.method_17698().field_1351,
                    context.method_17698().field_1350,
                    BlockState1,
                    offgrid)) {
                context.method_8045()
                        .method_8486(
                                pos.method_10263() + 0.5,
                                pos.method_10264() + 0.5,
                                pos.method_10260() + 0.5,
                                DeprecationHelper.getSoundType(this.method_7711()).method_10598(),
                                class_3419.field_15245,
                                (DeprecationHelper.getSoundType(this.field_7901).method_10597() + 1.0F) / 2.0F,
                                DeprecationHelper.getSoundType(this.field_7901).method_10599() * 0.8F,
                                false);

                if (!context.method_8036().method_7337()
                        && context.method_8041().method_7909() instanceof ItemBlockChiseled) {
                    ModUtil.adjustStackSize(context.method_8041(), -1);
                }

                return class_1269.field_5812;
            }

            return class_1269.field_5814;
        } else {
            return class_1269.field_5814;
        }
    }
}
