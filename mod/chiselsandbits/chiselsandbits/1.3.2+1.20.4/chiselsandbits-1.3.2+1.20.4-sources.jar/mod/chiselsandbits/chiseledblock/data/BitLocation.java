package mod.chiselsandbits.chiseledblock.data;

import javax.annotation.Nonnull;
import mod.chiselsandbits.api.IBitLocation;
import mod.chiselsandbits.helpers.BitOperation;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class BitLocation implements IBitLocation {
    private static final double One32nd = 0.5 / VoxelBlob.dim;

    @Nonnull
    public class_2338 blockPos;

    public int bitX, bitY, bitZ;

    public BitLocation(final class_3965 mop, final BitOperation type) {
        final class_243 hitVec = mop.method_17784();
        final class_243 accuratePos = new class_243(
                mop.method_17777().method_10263(),
                mop.method_17777().method_10264(),
                mop.method_17777().method_10260());
        final class_243 faceOffset = new class_243(
                mop.method_17780().method_10153().method_10148() * One32nd,
                mop.method_17780().method_10153().method_10164() * One32nd,
                mop.method_17780().method_10153().method_10165() * One32nd);
        final class_243 hitDelta = hitVec.method_1020(accuratePos).method_1019(faceOffset);
        final class_243 inBlockPosAccurate = hitDelta.method_1021(16d);
        final class_2382 inBlockPos =
                new class_2382((int) inBlockPosAccurate.method_10216(), (int) inBlockPosAccurate.method_10214(), (int) inBlockPosAccurate.method_10215());
        final class_2382 normalizedInBlockPos = new class_2382(
                snapToValid(inBlockPos.method_10263()), snapToValid(inBlockPos.method_10264()), snapToValid(inBlockPos.method_10260()));
        final class_2382 normalizedInBlockPosWithOffset =
                type.usePlacementOffset() ? normalizedInBlockPos.method_23226(mop.method_17780(), 1) : normalizedInBlockPos;

        this.blockPos = mop.method_17777();
        this.bitX = normalizedInBlockPosWithOffset.method_10263();
        this.bitY = normalizedInBlockPosWithOffset.method_10264();
        this.bitZ = normalizedInBlockPosWithOffset.method_10260();

        normalize();
    }

    public BitLocation(final class_2338 pos, final int x, final int y, final int z) {
        blockPos = pos;
        bitX = x;
        bitY = y;
        bitZ = z;
        normalize();
    }

    public static BitLocation min(final BitLocation from, final BitLocation to) {
        final int bitX = Min(from.blockPos.method_10263(), to.blockPos.method_10263(), from.bitX, to.bitX);
        final int bitY = Min(from.blockPos.method_10264(), to.blockPos.method_10264(), from.bitY, to.bitY);
        final int bitZ = Min(from.blockPos.method_10260(), to.blockPos.method_10260(), from.bitZ, to.bitZ);

        return new BitLocation(
                new class_2338(
                        Math.min(from.blockPos.method_10263(), to.blockPos.method_10263()),
                        Math.min(from.blockPos.method_10264(), to.blockPos.method_10264()),
                        Math.min(from.blockPos.method_10260(), to.blockPos.method_10260())),
                bitX,
                bitY,
                bitZ);
    }

    public static BitLocation max(final BitLocation from, final BitLocation to) {
        final int bitX = Max(from.blockPos.method_10263(), to.blockPos.method_10263(), from.bitX, to.bitX);
        final int bitY = Max(from.blockPos.method_10264(), to.blockPos.method_10264(), from.bitY, to.bitY);
        final int bitZ = Max(from.blockPos.method_10260(), to.blockPos.method_10260(), from.bitZ, to.bitZ);

        return new BitLocation(
                new class_2338(
                        Math.max(from.blockPos.method_10263(), to.blockPos.method_10263()),
                        Math.max(from.blockPos.method_10264(), to.blockPos.method_10264()),
                        Math.max(from.blockPos.method_10260(), to.blockPos.method_10260())),
                bitX,
                bitY,
                bitZ);
    }

    private static int Min(final int x, final int x2, final int bitX2, final int bitX3) {
        if (x < x2) {
            return bitX2;
        }
        if (x2 == x) {
            return Math.min(bitX2, bitX3);
        }

        return bitX3;
    }

    private static int Max(final int x, final int x2, final int bitX2, final int bitX3) {
        if (x > x2) {
            return bitX2;
        }
        if (x2 == x) {
            return Math.max(bitX2, bitX3);
        }

        return bitX3;
    }

    @Override
    public class_2338 getBlockPos() {
        return blockPos;
    }

    @Override
    public int getBitX() {
        return bitX;
    }

    @Override
    public int getBitY() {
        return bitY;
    }

    @Override
    public int getBitZ() {
        return bitZ;
    }

    @Override
    public IBitLocation offSet(final class_2350 direction) {
        final int newBitX = bitX + direction.method_10148();
        final int newBitY = bitY + direction.method_10164();
        final int newBitZ = bitZ + direction.method_10165();

        return new BitLocation(blockPos, newBitX, newBitY, newBitZ);
    }

    public int snapToValid(final int x) {
        return Math.min(Math.max(0, x), 15);
    }

    private void normalize() {
        final double xOffset = Math.floor(bitX / 16d);
        final double yOffset = Math.floor(bitY / 16d);
        final double zOffset = Math.floor(bitZ / 16d);

        bitX = (bitX + 16) % 16;
        bitY = (bitY + 16) % 16;
        bitZ = (bitZ + 16) % 16;
        this.blockPos = new class_2338.class_2339(
                blockPos.method_10263() + xOffset, blockPos.method_10264() + yOffset, blockPos.method_10260() + zOffset);
    }
}
