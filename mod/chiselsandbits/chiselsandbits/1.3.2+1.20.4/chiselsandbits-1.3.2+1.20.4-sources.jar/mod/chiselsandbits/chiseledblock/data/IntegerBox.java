package mod.chiselsandbits.chiseledblock.data;

import net.minecraft.class_2350;

public final class IntegerBox {
    public int minX;
    public int minY;
    public int minZ;
    public int maxX;
    public int maxY;
    public int maxZ;

    public IntegerBox(final int x1, final int y1, final int z1, final int x2, final int y2, final int z2) {
        minX = x1;
        maxX = x2;

        minY = y1;
        maxY = y2;

        minZ = z1;
        maxZ = z2;
    }

    public void move(final class_2350 side, final int scale) {
        minX += side.method_10148() * scale;
        maxX += side.method_10148() * scale;
        minY += side.method_10164() * scale;
        maxY += side.method_10164() * scale;
        minZ += side.method_10165() * scale;
        maxZ += side.method_10165() * scale;
    }

    public boolean isBadBitPositions() {
        return minX < 0 || minY < 0 || minZ < 0 || maxX >= 16 || maxY >= 16 || maxZ >= 16;
    }
}
