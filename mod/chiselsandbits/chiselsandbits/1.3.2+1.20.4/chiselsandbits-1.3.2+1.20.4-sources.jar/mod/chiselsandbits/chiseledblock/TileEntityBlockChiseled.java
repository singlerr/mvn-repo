package mod.chiselsandbits.chiseledblock;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.BoxType;
import mod.chiselsandbits.api.ChiselsAndBitsEvents;
import mod.chiselsandbits.api.EventBlockBitPostModification;
import mod.chiselsandbits.api.EventFullBlockRestoration;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.IChiseledBlockTileEntity;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.api.VoxelStats;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateReference;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.client.model.baked.ModelDataAccess;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.client.model.data.ModelDataMap;
import mod.chiselsandbits.client.model.data.ModelProperty;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.core.api.BitAccess;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IChiseledTileContainer;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.registry.ModTileEntityTypes;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import mod.chiselsandbits.render.chiseledblock.ChiseledBlockSmartModel;
import mod.chiselsandbits.utils.SingleBlockBlockReader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1087;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_238;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TileEntityBlockChiseled extends class_2586
        implements IChiseledTileContainer, IChiseledBlockTileEntity, ModelDataAccess, LegacyBlockEntityProperties {
    public static final ModelProperty<VoxelBlobStateReference> MP_VBSR = new ModelProperty<>();
    public static final ModelProperty<Integer> MP_PBSI = new ModelProperty<>();
    public static final ModelProperty<Map<ChiselRenderType, class_1087>> MODEL_PROP = new ModelProperty<>();
    public static final ModelProperty<Boolean> MODEL_UPDATE = new ModelProperty<>();
    private static final ThreadLocal<Integer> LOCAL_LIGHT_LEVEL = new ThreadLocal<>();
    private final class_2591<?> blockEntityType;
    public IChiseledTileContainer occlusionState;
    boolean isNormalCube = false;
    int sideState = 0;
    int lightLevel = -1;
    private boolean renderUpdate = false;
    private class_2680 state;
    private VoxelBlobStateReference blobStateReference;
    private int primaryBlockStateId;
    private IModelData modelData = newModelData();
    /**
     * prevent mods that constantly ask for pick block from killing the client... ( looking at you waila )
     **/
    private ItemStackGeneratedCache pickCache = null;

    public TileEntityBlockChiseled(class_2338 pos, class_2680 state) {
        this(ModTileEntityTypes.CHISELED.get(), pos, state);
    }

    public TileEntityBlockChiseled(final class_2591<?> tileEntityTypeIn, class_2338 pos, class_2680 state) {
        super(tileEntityTypeIn == null ? ModTileEntityTypes.CHISELED.get() : tileEntityTypeIn, pos, state);
        blockEntityType = tileEntityTypeIn == null ? ModTileEntityTypes.CHISELED.get() : tileEntityTypeIn;
    }

    public static long getPositionRandom(final class_2338 pos) {
        if (pos != null && FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            return class_3532.method_15389(pos);
        }

        return 0;
    }

    public static void setLightFromBlock(final class_2680 defaultState) {
        if (defaultState == null) {
            LOCAL_LIGHT_LEVEL.remove();
        } else {
            LOCAL_LIGHT_LEVEL.set(DeprecationHelper.getLightValue(defaultState));
        }
    }

    public VoxelBlobStateReference getBlobStateReference() {
        return blobStateReference;
    }

    private void setBlobStateReference(final VoxelBlobStateReference blobStateReference) {
        if (this.blobStateReference == null || !this.blobStateReference.equals(blobStateReference)) {
            this.blobStateReference = blobStateReference;
            modelData.setData(MP_VBSR, blobStateReference);
            modelData.setData(MODEL_UPDATE, true);
        }
    }

    public int getPrimaryBlockStateId() {
        return primaryBlockStateId;
    }

    public void setPrimaryBlockStateId(final int primaryBlockStateId) {
        this.primaryBlockStateId = primaryBlockStateId;
        modelData.setData(MP_PBSI, primaryBlockStateId);
        setLightFromBlock(ModUtil.getStateById(primaryBlockStateId));
    }

    public IChiseledTileContainer getTileContainer() {
        if (occlusionState != null) {
            return occlusionState;
        }

        return this;
    }

    @Override
    public boolean isBlobOccluded(final VoxelBlob blob) {
        return false;
    }

    @Override
    public void saveData() {
        super.method_5431();
    }

    @Override
    public void sendUpdate() {
        ModUtil.sendUpdate(Objects.requireNonNull(method_10997()), field_11867);
    }

    @Nonnull
    protected class_2680 getState() {
        if (state == null) {
            state = ModBlocks.getChiseledDefaultState();
        }

        return Objects.requireNonNull(state);
    }

    public class_2680 getBlockState(final class_2248 alternative) {
        final int stateID = getPrimaryBlockStateId();

        final class_2680 state = ModUtil.getStateById(stateID);
        if (state != null) {
            return state;
        }

        return alternative.method_9564();
    }

    public void setState(final class_2680 blockState, final VoxelBlobStateReference newRef) {
        final VoxelBlobStateReference originalRef = getBlobStateReference();

        this.state = blockState;

        if (newRef != null && !newRef.equals(originalRef)) {
            final EventBlockBitPostModification bmm =
                    new EventBlockBitPostModification(Objects.requireNonNull(method_10997()), method_11016());
            ChiselsAndBitsEvents.BLOCK_BIT_POST_MODIFICATION.invoker().handle(bmm);
            setBlobStateReference(newRef);
        }
    }

    @Override
    public class_2622 method_38235() {
        final class_2487 compound = new class_2487();
        writeChiselData(compound);

        if (compound.method_10546() == 0) {
            return null;
        }

        return new class_2622(field_11867, blockEntityType, compound);
    }

    @NotNull
    @Override
    public class_2487 method_16887() {
        final class_2487 compound = new class_2487();

        compound.method_10569("x", field_11867.method_10263());
        compound.method_10569("y", field_11867.method_10264());
        compound.method_10569("z", field_11867.method_10260());

        writeChiselData(compound);

        return compound;
    }

    public boolean readChiselData(final class_2487 tag) {
        final NBTBlobConverter converter = new NBTBlobConverter(false, this);
        return converter.readChisleData(tag, VoxelBlob.VERSION_COMPACT_PALLETED);
    }

    public void writeChiselData(final class_2487 tag) {
        new NBTBlobConverter(false, this).writeChisleData(tag, false);
    }

    @Override
    protected void method_11007(class_2487 compoundTag) {
        super.method_11007(compoundTag);
        writeChiselData(compoundTag);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        final VoxelBlobStateReference current = getBlobStateReference();
        final int oldLight = lightLevel;
        final boolean changed = readChiselData(nbt);

        if (field_11863 != null && changed) {
            field_11863.method_16109(field_11867, field_11863.method_8320(field_11867), class_2246.field_10124.method_9564());

            // fixes lighting on placement when tile packet arrives.
            if (oldLight != lightLevel) {
                field_11863.method_22336().method_15513(field_11867);
            }
        }

        if (field_11863 != null) {
            if (field_11863.method_8608()) {
                UndoTracker.getInstance().onNetworkUpdate(current, getBlobStateReference());
            }
        }
    }

    @NotNull
    @Override
    public class_2487 writeTileEntityToTag(@NotNull final class_2487 tag, final boolean crossWorld) {
        method_11007(tag);
        new NBTBlobConverter(false, this).writeChisleData(tag, crossWorld);
        tag.method_10556("cw", crossWorld);
        return tag;
    }

    public void mirror(@NotNull final class_2415 mirrorIn) {
        switch (mirrorIn) {
            case field_11301:
                setBlob(getBlob().mirror(class_2351.field_11048), true);
                break;
            case field_11300:
                setBlob(getBlob().mirror(class_2351.field_11051), true);
                break;
            case field_11302:
            default:
                break;
        }
    }

    @Override
    public class_2680 mirror(class_1936 level, class_2338 pos, class_2680 blockState, class_2415 mirrorIn) {
        switch (mirrorIn) {
            case field_11301:
                setBlob(getBlob().mirror(class_2351.field_11048), true);
                break;
            case field_11300:
                setBlob(getBlob().mirror(class_2351.field_11051), true);
                break;
            case field_11302:
            default:
                break;
        }

        return blockState;
    }

    public void rotate(@NotNull final class_2470 rotationIn) {
        VoxelBlob blob = ModUtil.rotate(getBlob(), class_2351.field_11052, rotationIn);
        if (blob != null) {
            setBlob(blob, true);
        }
    }

    public void fillWith(final class_2680 blockType) {
        final int ref = ModUtil.getStateId(blockType);

        sideState = 0xff;
        lightLevel = DeprecationHelper.getLightValue(blockType);
        isNormalCube = ModUtil.isNormalCube(blockType);

        class_2680 defaultState = getState();

        // required for placing bits
        if (ref != 0) {
            setPrimaryBlockStateId(ref);
        }

        setState(
                defaultState,
                new VoxelBlobStateReference(ModUtil.getStateId(blockType), getPositionRandom(field_11867)));

        getTileContainer().saveData();
    }

    @Override
    public @Nullable Object getRenderData() {
        modelData.setData(MP_VBSR, getBlobStateReference());
        modelData.setData(MP_PBSI, getPrimaryBlockStateId());
        return modelData;
    }

    public void setModelData(IModelData modelData) {
        this.modelData = modelData;
    }

    public VoxelBlob getBlob() {
        VoxelBlob vb;
        final VoxelBlobStateReference vbs = getBlobStateReference();

        if (vbs != null) {
            vb = vbs.getVoxelBlob();
        } else {
            vb = new VoxelBlob();
        }

        return vb;
    }

    public void setBlob(final VoxelBlob vb) {
        setBlob(vb, true);
    }

    public boolean updateBlob(final NBTBlobConverter converter, final boolean triggerUpdates) {
        final int oldLV = getLightValue();
        final boolean oldNC = isNormalCube();
        final int oldSides = sideState;

        final VoxelBlobStateReference originalRef = getBlobStateReference();

        VoxelBlobStateReference voxelRef;

        sideState = converter.getSideState();
        final int b = converter.getPrimaryBlockStateID();
        lightLevel = converter.getLightValue();
        isNormalCube = converter.isNormalCube();

        try {
            voxelRef = converter.getVoxelRef(VoxelBlob.VERSION_COMPACT_PALLETED, getPositionRandom(field_11867));
        } catch (final Exception e) {
            Log.logError("Unable to read blob at " + method_11016(), e);
            voxelRef = new VoxelBlobStateReference(0, getPositionRandom(field_11867));
        }

        setPrimaryBlockStateId(b);
        setBlobStateReference(voxelRef);
        setState(getState(), voxelRef);

        if (method_10997() != null && triggerUpdates) {
            if (oldLV != getLightValue() || oldNC != isNormalCube()) {
                method_10997().method_22336().method_15513(field_11867);

                // update block state to reflect lighting characteristics
                final class_2680 state = method_10997().method_8320(field_11867);
                if (state.method_26212(new SingleBlockBlockReader(state), class_2338.field_10980) != isNormalCube
                        && state.method_26204() instanceof BlockChiseled) {
                    method_10997().method_8501(field_11867, state.method_11657(BlockChiseled.FULL_BLOCK, isNormalCube));
                }
            }

            if (oldSides != sideState) {
                Objects.requireNonNull(field_11863)
                        .method_8452(
                                field_11867,
                                field_11863.method_8320(field_11867).method_26204());
            }
        }

        return voxelRef == null || !voxelRef.equals(originalRef);
    }

    public void setBlob(final VoxelBlob vb, final boolean triggerUpdates) {
        final int olv = getLightValue();
        final boolean oldNC = isNormalCube();

        final VoxelStats common = vb.getVoxelStats();
        final float light = common.blockLight;
        final boolean nc = common.isNormalBlock;
        final int lv = Math.max(0, Math.min(15, (int) (light * 15)));

        // are most of the bits in the center solid?
        final int sideFlags = vb.getSideFlags(5, 11, 4 * 4);

        if (method_10997() == null) {
            if (common.mostCommonState == 0) {
                common.mostCommonState = getPrimaryBlockStateId();
            }

            sideState = sideFlags;
            lightLevel = lv;
            isNormalCube = nc;

            setBlobStateReference(new VoxelBlobStateReference(
                    vb.blobToBytes(VoxelBlob.VERSION_COMPACT_PALLETED), getPositionRandom(field_11867)));
            setPrimaryBlockStateId(common.mostCommonState);
            setState(getState(), getBlobStateReference());
            return;
        }

        if (common.isFullBlock) {
            setBlobStateReference(
                    new VoxelBlobStateReference(common.mostCommonState, getPositionRandom(field_11867)));
            setState(getState(), getBlobStateReference());

            final class_2680 newState = ModUtil.getStateById(common.mostCommonState);
            if (ChiselsAndBits.getConfig().getServer().canRevertToBlock(newState)) {
                EventFullBlockRestoration evt =
                        new EventFullBlockRestoration(Objects.requireNonNull(field_11863), field_11867, newState);
                ChiselsAndBitsEvents.FULL_BLOCK_RESTORATION.invoker().handle(evt);
                if (!evt.isCancelled()) {
                    field_11863.method_8652(field_11867, newState, triggerUpdates ? 3 : 0);
                }
            }
        } else if (common.mostCommonState != 0) {
            sideState = sideFlags;
            lightLevel = lv;
            isNormalCube = nc;

            setBlobStateReference(new VoxelBlobStateReference(
                    vb.blobToBytes(VoxelBlob.VERSION_COMPACT_PALLETED), getPositionRandom(field_11867)));
            setPrimaryBlockStateId(common.mostCommonState);
            setState(getState(), getBlobStateReference());

            getTileContainer().saveData();
            getTileContainer().sendUpdate();

            // since its possible for bits to occlude parts.. update every time.
            final class_2248 blk =
                    Objects.requireNonNull(field_11863).method_8320(field_11867).method_26204();
            // worldObj.notifyBlockOfStateChange( pos, blk, false );

            if (triggerUpdates) {
                field_11863.method_8452(field_11867, blk);
            }
        } else {
            setState(getState(), new VoxelBlobStateReference(0, getPositionRandom(field_11867)));
            setPrimaryBlockStateId(0);
            ModUtil.removeChiseledBlock(Objects.requireNonNull(field_11863), field_11867);
        }

        if (olv != lv || oldNC != nc) {
            Objects.requireNonNull(field_11863).method_22336().method_15513(field_11867);

            // update block state to reflect lighting characteristics
            final class_2680 state = field_11863.method_8320(field_11867);
            if (state.method_26212(new SingleBlockBlockReader(state), class_2338.field_10980) != isNormalCube
                    && state.method_26204() instanceof BlockChiseled) {
                field_11863.method_8501(field_11867, state.method_11657(BlockChiseled.FULL_BLOCK, isNormalCube));
            }
        }
    }

    public boolean shouldRenderUpdate() {
        return renderUpdate;
    }

    public void setShouldRenderUpdate(boolean renderUpdate) {
        this.renderUpdate = renderUpdate;
    }

    public class_1799 getItemStack(final class_1657 player) {
        final ItemStackGeneratedCache cache = pickCache;

        if (player != null) {
            class_2350 placingFace = ModUtil.getPlaceFace(player);
            final int rotations = ModUtil.getRotationIndex(placingFace);

            if (cache != null
                    && cache.rotations == rotations
                    && cache.ref == getBlobStateReference()
                    && cache.out != null) {
                return cache.getItemStack();
            }

            VoxelBlob vb = getBlob();

            int countDown = rotations;
            while (countDown > 0) {
                countDown--;
                placingFace = placingFace.method_10160();
                vb = vb.spin(class_2351.field_11052);
            }

            final BitAccess ba = new BitAccess(null, null, vb, VoxelBlob.NULL_BLOB);
            final class_1799 itemstack = ba.getBitsAsItem(placingFace, ItemType.CHISELED_BLOCK, false);

            pickCache = new ItemStackGeneratedCache(itemstack, getBlobStateReference(), rotations);
            return itemstack;
        } else {
            if (cache != null && cache.rotations == 0 && cache.ref == getBlobStateReference()) {
                return cache.getItemStack();
            }

            final BitAccess ba = new BitAccess(null, null, getBlob(), VoxelBlob.NULL_BLOB);
            final class_1799 itemstack = ba.getBitsAsItem(null, ItemType.CHISELED_BLOCK, false);

            pickCache = new ItemStackGeneratedCache(itemstack, getBlobStateReference(), 0);
            return itemstack;
        }
    }

    public boolean isNormalCube() {
        return isNormalCube;
    }

    public void setNormalCube(final boolean b) {
        isNormalCube = b;
    }

    public boolean isSideSolid(final class_2350 side) {
        return (sideState & 1 << side.ordinal()) != 0;
    }

    public boolean isSideOpaque(final class_2350 side) {
        if (this.method_10997() != null && this.method_10997().field_9236) {
            return isInnerSideOpaque(side);
        }

        return false;
    }

    @Environment(EnvType.CLIENT)
    public boolean isInnerSideOpaque(final class_2350 side) {
        final int sideFlags = ChiseledBlockSmartModel.getSides(this);
        return (sideFlags & 1 << side.ordinal()) != 0;
    }

    public void completeEditOperation(final VoxelBlob vb) {
        final VoxelBlobStateReference before = getBlobStateReference();
        setBlob(vb);
        final VoxelBlobStateReference after = getBlobStateReference();
        if (field_11863 != null) {
            field_11863.method_16109(field_11867, field_11863.method_8320(field_11867), class_2246.field_10124.method_9564());
        }

        UndoTracker.getInstance().add(method_10997(), method_11016(), before, after);
    }

    // TODO: Figure this out.
    public void rotateBlock() {
        final VoxelBlob occluded = new VoxelBlob();

        VoxelBlob postRotation = getBlob();
        int maxRotations = 4;
        while (--maxRotations > 0) {
            postRotation = postRotation.spin(class_2351.field_11052);

            if (occluded.canMerge(postRotation)) {
                setBlob(postRotation);
                return;
            }
        }
    }

    public boolean canMerge(final VoxelBlob voxelBlob) {
        final VoxelBlob vb = getBlob();
        final IChiseledTileContainer occ = getTileContainer();

        return vb.canMerge(voxelBlob) && !occ.isBlobOccluded(voxelBlob);
    }

    //    @Override
    //    public AABB getRenderBoundingBox()
    //    {
    //        final BlockPos p = getBlockPos();
    //        return new AABB(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1);
    //    }

    @NotNull
    @Override
    public Collection<class_238> getBoxes(@NotNull final BoxType type) {
        final VoxelBlobStateReference ref = getBlobStateReference();

        if (ref != null) {
            return ref.getBoxes(type);
        } else {
            return Collections.emptyList();
        }
    }

    public int getLightValue() {
        // first time requested, pull from local, or default to 0
        if (lightLevel < 0) {
            final Integer tmp = LOCAL_LIGHT_LEVEL.get();
            lightLevel = tmp == null ? 0 : tmp;
        }

        return lightLevel;
    }

    @NotNull
    @Override
    public IBitAccess getBitAccess() {
        VoxelBlob mask = VoxelBlob.NULL_BLOB;

        if (field_11863 != null) {
            mask = new VoxelBlob();
        }

        return new BitAccess(field_11863, field_11867, getBlob(), mask);
    }

    public IModelData newModelData() {
        return new ModelDataMap.Builder()
                .withInitial(MP_PBSI, getPrimaryBlockStateId())
                .withInitial(MP_VBSR, getBlobStateReference())
                .withInitial(MODEL_UPDATE, true)
                .withProperty(MODEL_PROP)
                .build();
    }

    private static class ItemStackGeneratedCache {
        final class_1799 out;
        final VoxelBlobStateReference ref;
        final int rotations;

        public ItemStackGeneratedCache(
                final class_1799 itemstack, final VoxelBlobStateReference blobStateReference, final int rotations2) {
            out = itemstack == null ? null : itemstack.method_7972();
            ref = blobStateReference;
            rotations = rotations2;
        }

        public class_1799 getItemStack() {
            return out == null ? null : out.method_7972();
        }
    }
}
