package mod.chiselsandbits.chiseledblock.serialization;

import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import net.minecraft.class_2540;

public class CrossWorldBlobSerializer extends BlobSerializer {

    public CrossWorldBlobSerializer(final class_2540 toInflate) {
        super(toInflate);
    }

    public CrossWorldBlobSerializer(final VoxelBlob toDeflate) {
        super(toDeflate);
    }

    @Override
    protected int readStateID(final class_2540 buffer) {
        final String name = buffer.method_19772();
        return StringStates.getStateIDFromName(name);
    }

    @Override
    protected void writeStateID(final class_2540 buffer, final int key) {
        final String sname = StringStates.getNameFromStateID(key);

        buffer.method_10814(sname);
    }

    @Override
    public int getVersion() {
        return VoxelBlob.VERSION_CROSSWORLD;
    }
}
