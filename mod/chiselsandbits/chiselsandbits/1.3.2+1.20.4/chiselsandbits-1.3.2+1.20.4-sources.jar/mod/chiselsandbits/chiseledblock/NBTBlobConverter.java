package mod.chiselsandbits.chiseledblock;

import java.io.IOException;
import mod.chiselsandbits.api.VoxelStats;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateReference;
import mod.chiselsandbits.chiseledblock.serialization.StringStates;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.registry.ModBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2519;
import net.minecraft.class_2680;

public class NBTBlobConverter {

    public static final String NBT_SIDE_FLAGS = "s";
    public static final String NBT_NORMALCUBE_FLAG = "nc";
    public static final String NBT_LIGHTVALUE = "lv";

    public static final String NBT_PRIMARY_STATE = "b";
    public static final String NBT_LEGACY_VOXEL = "v";
    public static final String NBT_VERSIONED_VOXEL = "X";
    private final boolean triggerUpdates;
    TileEntityBlockChiseled tile;
    private int sideState;
    private int lightValue;
    private boolean isNormalCube;
    private int primaryBlockState;
    private VoxelBlobStateReference voxelBlobRef;
    private int format = -1;

    public NBTBlobConverter() {
        triggerUpdates = false;
    }

    public NBTBlobConverter(final boolean triggerBlockUpdates, final TileEntityBlockChiseled tile) {
        this.tile = tile;

        triggerUpdates = triggerBlockUpdates;
        sideState = tile.sideState;
        lightValue = tile.getLightValue();
        isNormalCube = tile.isNormalCube;
        primaryBlockState = ModUtil.getStateId(tile.getBlockState(class_2246.field_10445));
        voxelBlobRef = tile.getBlobStateReference();
        format = voxelBlobRef == null ? -1 : voxelBlobRef.getFormat();
    }

    public int getSideState() {
        return sideState;
    }

    public int getLightValue() {
        return lightValue;
    }

    public boolean isNormalCube() {
        return isNormalCube;
    }

    public int getPrimaryBlockStateID() {
        return primaryBlockState;
    }

    public class_2680 getPrimaryBlockState() {
        return ModUtil.getStateById(primaryBlockState);
    }

    public VoxelBlobStateReference getVoxelRef(final int version, final long weight) throws Exception {
        final VoxelBlobStateReference voxelRef = getRef();

        if (format == version) {
            return new VoxelBlobStateReference(voxelRef.getByteArray(), weight);
        }

        return new VoxelBlobStateReference(voxelRef.getVoxelBlobCatchable().blobToBytes(version), weight);
    }

    public void fillWith(final class_2680 state) {
        voxelBlobRef = new VoxelBlobStateReference(ModUtil.getStateId(state), 0);
        updateFromBlob();
    }

    public final void writeChisleData(final class_2487 compound, final boolean crossWorld) {
        final VoxelBlobStateReference voxelRef = getRef();

        if (primaryBlockState == 0) {
            return;
        }

        final int newFormat = crossWorld ? VoxelBlob.VERSION_CROSSWORLD : VoxelBlob.VERSION_COMPACT_PALLETED;
        final byte[] voxelBytes = newFormat == format
                ? voxelRef.getByteArray()
                : voxelRef.getVoxelBlob().blobToBytes(newFormat);

        compound.method_10569(NBT_LIGHTVALUE, lightValue);

        if (crossWorld) {
            compound.method_10582(NBT_PRIMARY_STATE, StringStates.getNameFromStateID(primaryBlockState));
        } else {
            compound.method_10569(NBT_PRIMARY_STATE, primaryBlockState);
        }

        compound.method_10569(NBT_SIDE_FLAGS, sideState);
        compound.method_10556(NBT_NORMALCUBE_FLAG, isNormalCube);
        compound.method_10570(NBT_VERSIONED_VOXEL, voxelBytes);
    }

    public final boolean readChisleData(final class_2487 compound, final int preferedFormat) {
        if (compound == null) {
            voxelBlobRef = new VoxelBlobStateReference(0, 0);
            format = voxelBlobRef.getFormat();

            if (tile != null) {
                return tile.updateBlob(this, triggerUpdates);
            }

            return false;
        }

        sideState = compound.method_10550(NBT_SIDE_FLAGS);

        if (compound.method_10580(NBT_PRIMARY_STATE) instanceof class_2519) {
            primaryBlockState = StringStates.getStateIDFromName(compound.method_10558(NBT_PRIMARY_STATE));
        }
        {
            primaryBlockState = compound.method_10550(NBT_PRIMARY_STATE);
        }

        lightValue = compound.method_10550(NBT_LIGHTVALUE);
        isNormalCube = compound.method_10577(NBT_NORMALCUBE_FLAG);
        byte[] v = compound.method_10547(NBT_VERSIONED_VOXEL);

        if (v.length == 0) {
            final byte[] vx = compound.method_10547(NBT_LEGACY_VOXEL);
            if (vx.length > 0) {
                final VoxelBlob bx = new VoxelBlob();

                try {
                    bx.fromLegacyByteArray(vx);
                } catch (final IOException e) {
                }

                v = bx.blobToBytes(VoxelBlob.VERSION_COMPACT_PALLETED);
                format = VoxelBlob.VERSION_COMPACT_PALLETED;
            }
        }

        if (primaryBlockState == 0) {
            // if load fails default to cobble stone...
            primaryBlockState = ModUtil.getStateId(class_2246.field_10445.method_9564());
        }

        voxelBlobRef = new VoxelBlobStateReference(v, 0);
        format = voxelBlobRef.getFormat();

        boolean formatChanged = false;

        if (preferedFormat != format && preferedFormat != VoxelBlob.VERSION_ANY) {
            formatChanged = true;
            v = voxelBlobRef.getVoxelBlob().blobToBytes(preferedFormat);
            voxelBlobRef = new VoxelBlobStateReference(v, 0);
            format = voxelBlobRef.getFormat();
        }

        if (tile != null) {
            if (formatChanged) {
                // this only works on already loaded tiles, so i'm not sure
                // there is much point in it.
                tile.method_5431();
            }

            return tile.updateBlob(this, triggerUpdates);
        }

        return true;
    }

    public void updateFromBlob() {
        final VoxelBlob vb = getRef().getVoxelBlob();

        final VoxelStats common = vb.getVoxelStats();
        final float floatLight = common.blockLight;

        isNormalCube = common.isNormalBlock;
        lightValue = Math.max(0, Math.min(15, (int) (floatLight * 15)));
        sideState = vb.getSideFlags(5, 11, 4 * 4);
        primaryBlockState = common.mostCommonState;
    }

    public class_1799 getItemStack(final boolean crossWorld) {
        final class_2248 blk = ModBlocks.getChiseledBlock();

        if (blk != null) {
            final class_1799 is = new class_1799(blk);
            final class_2487 compound = ModUtil.getSubCompound(is, ModUtil.NBT_BLOCKENTITYTAG, true);
            writeChisleData(compound, crossWorld);

            if (compound.method_10546() > 0) {
                return is;
            }
        }

        return null;
    }

    private VoxelBlobStateReference getRef() {
        if (voxelBlobRef == null) {
            voxelBlobRef = new VoxelBlobStateReference(0, 0);
        }

        return voxelBlobRef;
    }

    public VoxelBlob getBlob() {
        return getRef().getVoxelBlob();
    }

    public void setBlob(final VoxelBlob vb) {
        voxelBlobRef = new VoxelBlobStateReference(vb, 0);
        format = voxelBlobRef.getFormat();
        updateFromBlob();
    }
}
