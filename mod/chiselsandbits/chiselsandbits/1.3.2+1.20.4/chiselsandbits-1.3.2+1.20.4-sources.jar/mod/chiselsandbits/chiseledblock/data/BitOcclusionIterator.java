package mod.chiselsandbits.chiseledblock.data;

import java.util.List;
import net.minecraft.class_238;

public class BitOcclusionIterator extends BitCollisionIterator {

    final List<class_238> o;
    private final double epsilon = 0;
    private float physicalStartX = 0.0f;
    private boolean lastSetting = false;

    public BitOcclusionIterator(final List<class_238> out) {
        o = out;
    }

    @Override
    protected void yPlus() {
        addCurrentBox(One16thf);
        super.yPlus();
    }

    @Override
    protected void zPlus() {
        addCurrentBox(One16thf);
        super.zPlus();
    }

    @Override
    protected void done() {
        addCurrentBox(One16thf);
    }

    protected void addCurrentBox(final double addition) {
        if (lastSetting) {
            addBox(addition);
            lastSetting = false;
        }
    }

    private void addBox(final double addition) {
        final double xFullMinusEpsilon = 1.0 - epsilon;
        final class_238 newBox = new class_238(
                physicalStartX < epsilon ? physicalStartX : physicalStartX + epsilon,
                y == 0 ? physicalY : physicalY + epsilon,
                z == 0 ? physicalZ : physicalZ + epsilon,
                physicalX + addition > xFullMinusEpsilon ? physicalX + addition : physicalX + addition - epsilon,
                y == 15 ? physicalYp1 : physicalYp1 - epsilon,
                z == 15 ? physicalZp1 : physicalZp1 - epsilon);

        if (!o.isEmpty()) {
            int offset = o.size() - 1;
            class_238 lastBox = o.get(offset);

            if (isBelow(newBox, lastBox)) {
                class_238 combined = lastBox.method_991(newBox);
                o.remove(offset);

                if (!o.isEmpty()) {
                    offset = o.size() - 1;
                    lastBox = o.get(offset);
                    if (!o.isEmpty() && isNextTo(combined, lastBox)) {
                        combined = lastBox.method_991(combined);
                        o.remove(offset);
                    }
                }

                o.add(combined);
                return;
            }
        }

        o.add(newBox);
    }

    private boolean isNextTo(final class_238 newBox, final class_238 lastBox) {
        final boolean sameX = newBox.field_1323 == lastBox.field_1323 && newBox.field_1320 == lastBox.field_1320;
        final boolean sameY = newBox.field_1322 == lastBox.field_1322 && newBox.field_1325 == lastBox.field_1325;
        final double touchingZ = newBox.field_1321 - lastBox.field_1324;
        final double epsilonGap = epsilon * 2.1;
        return sameX && sameY && touchingZ < epsilonGap;
    }

    private boolean isBelow(final class_238 newBox, final class_238 lastBox) {
        final boolean sameX = newBox.field_1323 == lastBox.field_1323 && newBox.field_1320 == lastBox.field_1320;
        final boolean sameZ = newBox.field_1321 == lastBox.field_1321 && newBox.field_1324 == lastBox.field_1324;
        final double touchingY = newBox.field_1322 - lastBox.field_1325;
        return sameX && sameZ && touchingY < 0.001;
    }

    public void add() {
        if (!lastSetting) {
            physicalStartX = physicalX;
            lastSetting = true;
        }
    }

    public void drop() {
        addCurrentBox(0);
    }
}
