package mod.chiselsandbits.chiseledblock.serialization;

import java.util.List;
import java.util.Map;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.utils.PaletteUtils;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2361;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_2814;
import net.minecraft.class_2816;
import net.minecraft.class_2835;
import net.minecraft.class_2837;

public class PalettedBlobSerializer extends BlobSerializer implements class_2835<class_2680> {
    private final class_2361<class_2680> registry = class_2248.field_10651;
    private final class_2837<class_2680> registryPalette = new class_2816<>(class_2248.field_10651);
    private class_2837<class_2680> palette = new class_2816<>(class_2248.field_10651);
    private int bits = 0;

    public PalettedBlobSerializer(final VoxelBlob toDeflate) {
        super(toDeflate);
        this.setBits(4);

        // Setup the palette ids.
        final Map<Integer, Integer> entries = toDeflate.getBlockSums();
        for (final Map.Entry<Integer, Integer> o : entries.entrySet()) {
            this.palette.method_12291(ModUtil.getStateById(o.getKey()));
        }
    }

    public PalettedBlobSerializer(final class_2540 toInflate) {
        super();
        this.setBits(4);

        // Setup the palette ids.
        this.setBits(toInflate.method_10816());
        PaletteUtils.read(this.palette, toInflate);
    }

    private void setBits(int bitsIn) {
        setBits(bitsIn, false);
    }

    private void setBits(int bitsIn, boolean forceBits) {
        if (bitsIn != this.bits) {
            this.bitsPerInt = bitsIn;
            this.bitsPerIntMinus1 = bitsIn - 1;

            this.bits = bitsIn;
            //            if (this.bits <= 8) {
            //                this.bits = 4;
            //                this.palette = new LinearPalette<>(this.registry, this.bits, this,
            // NbtUtils::readBlockState);
            //            } else if (this.bits < 17) {
            //                this.palette = new HashMapPalette<>(this.registry, this.bits, this,
            // NbtUtils::readBlockState, NbtUtils::writeBlockState);
            //            } else {
            //                this.palette = this.registryPalette;
            //                this.bits = Mth.ceillog2(this.registry.size());
            //                if (forceBits)
            //                    this.bits = bitsIn;
            //            }
            this.palette = new class_2814<>(this.registry, this.bits, this);
            this.palette.method_12291(class_2246.field_10124.method_9564());
        }
    }

    @Override
    public void write(final class_2540 to) {
        to.method_10804(this.bits);
        this.palette.method_12287(to);
    }

    @Override
    protected int readStateID(final class_2540 buffer) {
        // Not needed because of different palette system.
        return 0;
    }

    @Override
    protected void writeStateID(final class_2540 buffer, final int key) {
        // Noop
    }

    @Override
    protected int getIndex(final int stateID) {
        return this.palette.method_12291(ModUtil.getStateById(stateID));
    }

    @Override
    protected int getStateID(final int indexID) {
        return ModUtil.getStateId(this.palette.method_12288(indexID));
    }

    @Override
    public int getVersion() {
        return VoxelBlob.VERSION_COMPACT_PALLETED;
    }

    @Override
    public int onResize(final int newBitSize, final class_2680 violatingBlockState) {
        final class_2837<class_2680> currentPalette = this.palette;
        this.setBits(newBitSize);

        final List<class_2680> ids = PaletteUtils.getOrderedListInPalette(currentPalette);
        ids.forEach(this.palette::method_12291);

        return this.palette.method_12291(violatingBlockState);
    }
}
