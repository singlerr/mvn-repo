package mod.chiselsandbits.chiseledblock.iterators;

import mod.chiselsandbits.chiseledblock.data.IntegerBox;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import net.minecraft.class_2350;
import net.minecraft.class_238;

public interface ChiselIterator {

    IntegerBox getVoxelBox(VoxelBlob blobAt, boolean b);

    class_238 getBoundingBox(VoxelBlob nULL_BLOB, boolean b);

    boolean hasNext();

    class_2350 side();

    int x();

    int y();

    int z();
}
