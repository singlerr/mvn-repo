package mod.chiselsandbits.chiseledblock.serialization;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Optional;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.ModUtil;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_7923;

public class StringStates {

    public static int getStateIDFromName(final String name) {
        final String[] parts = name.split("[?&]");

        parts[0] = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);

        final class_2248 blk = class_7923.field_41175.method_10223(new class_2960(parts[0]));

        if (blk == null || blk == class_2246.field_10124) {
            return 0;
        }

        class_2680 state = blk.method_9564();

        if (state == null) {
            return 0;
        }

        // rebuild state...
        for (int x = 1; x < parts.length; ++x) {
            try {
                if (parts[x].length() > 0) {
                    final String[] nameval = parts[x].split("[=]");
                    if (nameval.length == 2) {
                        nameval[0] = URLDecoder.decode(nameval[0], StandardCharsets.UTF_8);
                        nameval[1] = URLDecoder.decode(nameval[1], StandardCharsets.UTF_8);

                        state = withState(state, blk, nameval);
                    }
                }
            } catch (final Exception err) {
                Log.logError("Failed to reload Property from store data : " + name, err);
            }
        }

        return ModUtil.getStateId(state);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static class_2680 withState(final class_2680 state, final class_2248 blk, final String[] nameval) {
        final class_2769<?> prop = blk.method_9595().method_11663(nameval[0]);
        if (prop == null) {
            Log.info(nameval[0] + " is not a valid property for " + class_7923.field_41175.method_10221(blk));
            return state;
        }

        return setPropValue(state, prop, nameval[1]);
    }

    public static <T extends Comparable<T>> class_2680 setPropValue(
            class_2680 blockState, class_2769<T> property, String value) {
        final Optional<T> pv = property.method_11900(value);
        if (pv.isPresent()) {
            return blockState.method_11657(property, pv.get());
        } else {
            Log.info(value + " is not a valid value of " + property.method_11899() + " for "
                    + class_7923.field_41175.method_10221(blockState.method_26204()));
            return blockState;
        }
    }

    public static String getNameFromStateID(final int key) {
        final class_2680 state = ModUtil.getStateById(key);
        final class_2248 blk = state.method_26204();

        String sname = "air?";

        final StringBuilder stateName = new StringBuilder(URLEncoder.encode(
                Objects.requireNonNull(class_7923.field_41175.method_10221(blk)).toString(), StandardCharsets.UTF_8));
        stateName.append('?');

        boolean first = true;
        for (final class_2769<?> p : state.method_26204().method_9595().method_11659()) {
            if (!first) {
                stateName.append('&');
            }

            first = false;

            final Comparable<?> propVal = state.method_11654(p);

            String saveAs;
            if (propVal instanceof class_3542) {
                saveAs = ((class_3542) propVal).method_15434();
            } else {
                saveAs = propVal.toString();
            }

            stateName.append(URLEncoder.encode(p.method_11899(), StandardCharsets.UTF_8));
            stateName.append('=');
            stateName.append(URLEncoder.encode(saveAs, StandardCharsets.UTF_8));
        }

        sname = stateName.toString();

        return sname;
    }
}
