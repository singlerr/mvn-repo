package mod.chiselsandbits.events;

import mod.chiselsandbits.items.ItemMagnifyingGlass;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;

public class ClientTickHandler {

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(ClientTickHandler::onTickPlayerTick);
    }

    @Environment(EnvType.CLIENT)
    private static void onTickPlayerTick(class_310 event) {
        if (class_310.method_1551().field_1724 != null) {
            if (class_310.method_1551().field_1724.method_6047().method_7909() instanceof ItemMagnifyingGlass
                    || class_310.method_1551().field_1724.method_6079().method_7909() instanceof ItemMagnifyingGlass) {
                if (class_310.method_1551().field_1705 != null) {
                    class_310.method_1551().field_1705.field_2040 = 40;
                }
            }
        }
    }
}
