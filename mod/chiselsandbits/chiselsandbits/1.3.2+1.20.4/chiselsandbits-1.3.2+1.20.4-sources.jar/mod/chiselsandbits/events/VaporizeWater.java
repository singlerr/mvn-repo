package mod.chiselsandbits.events;

import mod.chiselsandbits.api.ChiselsAndBitsEvents;
import mod.chiselsandbits.api.EventFullBlockRestoration;
import net.minecraft.class_2246;
import net.minecraft.class_2398;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class VaporizeWater {

    public static void register() {
        ChiselsAndBitsEvents.FULL_BLOCK_RESTORATION.register(VaporizeWater::handle);
    }

    private static void handle(final EventFullBlockRestoration e) {
        if (e.getState().method_26204() == class_2246.field_10382
                && e.getWorld().method_8597().comp_644()) {
            double i = e.getPos().method_10263();
            double j = e.getPos().method_10264();
            double k = e.getPos().method_10260();
            e.getWorld()
                    .method_8486(
                            i,
                            j,
                            k,
                            class_3417.field_15102,
                            class_3419.field_15245,
                            0.5F,
                            2.6F
                                    + (e.getWorld().field_9229.method_43057()
                                                    - e.getWorld().field_9229.method_43057())
                                            * 0.8F,
                            true);

            for (int l = 0; l < 8; ++l) {
                e.getWorld()
                        .method_8406(
                                class_2398.field_11237,
                                i + Math.random(),
                                j + Math.random(),
                                k + Math.random(),
                                0.0D,
                                0.0D,
                                0.0D);
            }

            e.getWorld().method_8501(e.getPos(), class_2246.field_10124.method_9564());
            e.setCancelled(true);
        }
    }
}
