package mod.chiselsandbits.events;

import java.util.WeakHashMap;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

/**
 * Disable breaking blocks when using a chisel / bit, some items break too fast
 * for the other code to prevent which is where this comes in.
 * <p>
 * This manages survival chisel actions, creative some how skips this and calls
 * onBlockStartBreak on its own, but when in creative this is called on the
 * server... which still needs to be canceled or it will break the block.
 * <p>
 * The whole things, is very strange.
 */
public class EventPlayerInteract {

    private static final WeakHashMap<class_1657, Boolean> serverSuppressEvent = new WeakHashMap<class_1657, Boolean>();

    public static void register() {
        AttackBlockCallback.EVENT.register(EventPlayerInteract::interaction);
        UseBlockCallback.EVENT.register(EventPlayerInteract::interaction);
    }

    public static void setPlayerSuppressionState(final class_1657 player, final boolean state) {
        if (state) {
            serverSuppressEvent.put(player, state);
        } else {
            serverSuppressEvent.remove(player);
        }
    }

    private static class_1269 interaction(
            class_1657 player, class_1937 world, class_1268 hand, class_2338 pos, class_2350 direction) {
        final class_1799 is = player.method_5998(hand);
        final boolean validEvent = pos != null && world != null;
        if ((is.method_7909() instanceof ItemChisel || is.method_7909() instanceof ItemChiseledBit) && validEvent) {
            final class_2680 state = world.method_8320(pos);
            if (BlockBitInfo.canChisel(state)) {
                if (world.field_9236) {
                    // this is called when the player is survival -
                    // client side.
                    is.method_7909().method_7885(state, world, pos, player);
                    //                    is.getItem().onBlockStartBreak(is, event.getPos(), event.getPlayer());
                }

                // cancel interactions vs chiseable blocks, creative is
                // magic.
                return class_1269.field_5814;
            }
        }

        return testInteractionSupression(world, player);
    }

    private static class_1269 interaction(
            class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {

        return testInteractionSupression(player, world, hand, hitResult);
    }

    private static class_1269 testInteractionSupression(
            class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {
        // client is dragging...
        if (world.field_9236) {
            if (ClientSide.instance.getStartPos() != null) {
                return class_1269.field_5814;
            }
        }
        class_1799 itemEntity = player.method_5998(hand);
        // server is supressed.
        if (!world.field_9236 && itemEntity != null) {
            if (serverSuppressEvent.containsKey(player)) {
                return class_1269.field_5814;
            }
        }
        return class_1269.field_5811;
    }

    private static class_1269 testInteractionSupression(class_1937 level, class_1657 player) {
        // client is dragging...
        if (level.field_9236) {
            if (ClientSide.instance.getStartPos() != null) {
                return class_1269.field_5814;
            }
        }

        // server is supressed.
        if (!level.field_9236) {
            if (serverSuppressEvent.containsKey(player)) {
                return class_1269.field_5814;
            }
        }
        return class_1269.field_5811;
    }
}
