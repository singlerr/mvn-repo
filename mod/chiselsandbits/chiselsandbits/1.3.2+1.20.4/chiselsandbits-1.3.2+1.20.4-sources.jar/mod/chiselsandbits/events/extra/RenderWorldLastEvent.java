package mod.chiselsandbits.events.extra;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_4587;

public interface RenderWorldLastEvent {

    Event<RenderWorldLast> EVENT =
            EventFactory.createArrayBacked(RenderWorldLast.class, listeners -> ((stack, partialTicks) -> {
                for (RenderWorldLast listener : listeners) {
                    listener.handle(stack, partialTicks);
                }
            }));

    interface RenderWorldLast {
        void handle(class_4587 stack, float partialTicks);
    }
}
