package mod.chiselsandbits.events;

import java.util.List;
import mod.chiselsandbits.events.extra.EntityItemPickupEvent;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class EntityItemPickupEventHandler {

    public static void register() {
        EntityItemPickupEvent.EVENT.register(EntityItemPickupEventHandler::pickupItems);
    }

    private static boolean pickupItems(final class_1542 entityItem, final class_1657 player) {
        boolean modified = false;
        if (entityItem != null) {
            final class_1799 is = entityItem.method_6983();
            if (is != null && is.method_7909() instanceof ItemChiseledBit) {
                final int originalSize = ModUtil.getStackSize(is);
                final class_1263 inv = player.field_7514;
                final List<ItemBitBag.BagPos> bags = ItemBitBag.getBags(inv);

                // has the stack?
                final boolean seen = ModUtil.containsAtLeastOneOf(inv, is);

                if (seen) {
                    for (final ItemBitBag.BagPos i : bags) {
                        if (entityItem.method_5805()) {
                            modified = updateEntity(
                                            player,
                                            entityItem,
                                            i.inv.insertItem(ModUtil.nonNull(entityItem.method_6983())),
                                            originalSize)
                                    || modified;
                        }
                    }
                } else {
                    if (ModUtil.getStackSize(is) > is.method_7914() && entityItem.method_5805()) {
                        final class_1799 singleStack = is.method_7972();
                        ModUtil.setStackSize(singleStack, singleStack.method_7914());

                        if (!player.field_7514.method_7394(singleStack)) {
                            ModUtil.adjustStackSize(is, -(singleStack.method_7914() - ModUtil.getStackSize(is)));
                        }

                        modified = updateEntity(player, entityItem, is, originalSize) || modified;
                    } else {
                        return false;
                    }

                    for (final ItemBitBag.BagPos i : bags) {

                        if (entityItem.method_5805()) {
                            modified = updateEntity(
                                            player,
                                            entityItem,
                                            i.inv.insertItem(ModUtil.nonNull(entityItem.method_6983())),
                                            originalSize)
                                    || modified;
                        }
                    }
                }
            }

            ItemBitBag.cleanupInventory(player, is);
        }

        return modified;
    }

    private static boolean updateEntity(
            final class_1657 player, final class_1542 ei, class_1799 is, final int originalSize) {
        if (is == null) {
            ei.method_5650(class_1297.class_5529.field_26999);
            return true;
        } else {
            final int changed = ModUtil.getStackSize(is) - ModUtil.getStackSize(ei.method_6983());
            ei.method_6979(is);
            return changed != 0;
        }
    }
}
