package mod.chiselsandbits.events.extra;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1542;
import net.minecraft.class_1657;

public interface EntityItemPickupEvent {

    Event<EntityItemPickup> EVENT =
            EventFactory.createArrayBacked(EntityItemPickup.class, listeners -> ((itemEntity, player) -> {
                boolean result = false;
                for (EntityItemPickup listener : listeners) {
                    result |= listener.handle(itemEntity, player);
                }
                return result;
            }));

    interface EntityItemPickup {
        boolean handle(class_1542 itemEntity, class_1657 player);
    }
}
