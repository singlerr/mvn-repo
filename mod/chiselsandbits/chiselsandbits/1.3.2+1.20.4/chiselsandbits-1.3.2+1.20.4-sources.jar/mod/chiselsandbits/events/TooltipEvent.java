package mod.chiselsandbits.events;

import java.util.List;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.items.ItemMagnifyingGlass;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class TooltipEvent {

    public static void register() {
        ItemTooltipCallback.EVENT.register(TooltipEvent::onItemTooltip);
    }

    private static void onItemTooltip(class_1799 stack, class_1836 context, List<class_2561> lines) {
        if (class_310.method_1551().field_1724 != null
                && ChiselsAndBits.getConfig().getCommon().enableHelp.get()) {
            if (class_310.method_1551().field_1724.method_6047().method_7909() instanceof ItemMagnifyingGlass
                    || class_310.method_1551().field_1724.method_6079().method_7909() instanceof ItemMagnifyingGlass) {
                if (stack.method_7909() instanceof class_1747 blockItem) {
                    final class_2248 block = blockItem.method_7711();
                    final class_2680 blockState = block.method_9564();
                    final BlockBitInfo.SupportsAnalysisResult result = BlockBitInfo.doSupportAnalysis(blockState);

                    lines.add(class_2561.method_43470(
                            result.isSupported()
                                    ? class_124.field_1060
                                            + result.getSupportedReason().getLocal()
                                            + class_124.field_1070
                                    : class_124.field_1061
                                            + result.getUnsupportedReason().getLocal()
                                            + class_124.field_1070));
                }
            }
        }
    }
}
