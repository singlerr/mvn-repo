package mod.chiselsandbits.core.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import mod.chiselsandbits.api.APIExceptions.CannotBeChiseled;
import mod.chiselsandbits.api.APIExceptions.InvalidBitItem;
import mod.chiselsandbits.api.BlockProvider;
import mod.chiselsandbits.api.IBitAccess;
import mod.chiselsandbits.api.IBitBag;
import mod.chiselsandbits.api.IBitBrush;
import mod.chiselsandbits.api.IBitLocation;
import mod.chiselsandbits.api.IChiselAndBitsAPI;
import mod.chiselsandbits.api.ItemStackHandler;
import mod.chiselsandbits.api.ItemType;
import mod.chiselsandbits.api.ModKeyBinding;
import mod.chiselsandbits.api.ParameterType;
import mod.chiselsandbits.api.ParameterType.DoubleParam;
import mod.chiselsandbits.api.ParameterType.FloatParam;
import mod.chiselsandbits.api.ParameterType.IntegerParam;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.ItemBlockChiseled;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.client.RenderHelper;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.BitInventoryFeeder;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.items.ItemMirrorPrint;
import mod.chiselsandbits.items.ItemNegativePrint;
import mod.chiselsandbits.items.ItemPositivePrint;
import mod.chiselsandbits.items.ItemWrench;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.modes.PositivePatternMode;
import mod.chiselsandbits.modes.TapeMeasureModes;
import mod.chiselsandbits.registry.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraftforge.items.CapabilityItemHandler;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.NotNull;

public class ChiselAndBitsAPI implements IChiselAndBitsAPI {

    private final Map<class_2248, ItemStackHandler> itemStackHandlers = new ConcurrentHashMap<>();
    private final List<BlockProvider> stateProviders = new ArrayList<>();

    public Map<class_2248, ItemStackHandler> getItemStackHandlers() {
        return itemStackHandlers;
    }

    @Override
    public void registerBlockProvider(BlockProvider provider) {
        Validate.notNull(provider, "BlockProvider cannot be null");
        this.stateProviders.add(provider);
    }

    public List<BlockProvider> getStateProviders() {
        return stateProviders;
    }

    @Override
    public void registerItemStackHandler(class_2248 block, @NotNull ItemStackHandler provider) {
        itemStackHandlers.put(block, provider);
    }

    @Override
    public boolean canBeChiseled(final class_1937 world, final class_2338 pos) {
        if (world == null || pos == null) {
            return false;
        }

        final class_2680 state = world.method_8320(pos);
        return state.method_26204() == class_2246.field_10124
                || BlockBitInfo.canChisel(state)
                || ModUtil.getChiseledTileEntity(world, pos, false) != null;
    }

    @Override
    public boolean isBlockChiseled(final class_1937 world, final class_2338 pos) {
        if (world == null || pos == null) {
            return false;
        }

        return ModUtil.getChiseledTileEntity(world, pos, false) != null;
    }

    @Override
    public IBitAccess getBitAccess(final class_1937 world, final class_2338 pos) throws CannotBeChiseled {
        if (world == null || pos == null) {
            throw new CannotBeChiseled();
        }

        final class_2680 state = world.method_8320(pos);
        if (BlockBitInfo.isSupported(state) && !(state.method_26204() instanceof BlockChiseled)) {
            final VoxelBlob blob = new VoxelBlob();
            blob.fill(ModUtil.getStateId(state));
            return new BitAccess(world, pos, blob, VoxelBlob.NULL_BLOB);
        }

        if (world.method_22347(pos)) {
            final VoxelBlob blob = new VoxelBlob();
            return new BitAccess(world, pos, blob, VoxelBlob.NULL_BLOB);
        }

        final TileEntityBlockChiseled te = ModUtil.getChiseledTileEntity(world, pos, true);
        if (te != null) {
            final VoxelBlob mask = new VoxelBlob();
            return new BitAccess(world, pos, te.getBlob(), mask);
        }

        throw new CannotBeChiseled();
    }

    @Override
    public IBitBrush createBrush(final class_1799 stack) throws InvalidBitItem {
        if (ModUtil.isEmpty(stack)) {
            return new BitBrush(0);
        }

        if (getItemType(stack) == ItemType.CHISELED_BIT) {
            final int stateID = ItemChiseledBit.getStackState(stack);
            final class_2680 state = ModUtil.getStateById(stateID);

            if (state != null && BlockBitInfo.canChisel(state)) {
                return new BitBrush(stateID);
            }
        }

        throw new InvalidBitItem();
    }

    @Override
    public IBitLocation getBitPos(
            final double hitX,
            final double hitY,
            final double hitZ,
            final class_2350 side,
            final class_2338 pos,
            final boolean placement) {
        final class_3965 mop = new class_3965(new class_243(hitX, hitY, hitZ), side, pos, false);
        return new BitLocation(mop, placement ? BitOperation.PLACE : BitOperation.CHISEL);
    }

    @Override
    public ItemType getItemType(final class_1799 stack) {
        if (stack.method_7909() instanceof ItemChiseledBit) {
            return ItemType.CHISELED_BIT;
        }

        if (stack.method_7909() instanceof ItemBitBag) {
            return ItemType.BIT_BAG;
        }

        if (stack.method_7909() instanceof ItemChisel) {
            return ItemType.CHISEL;
        }

        if (stack.method_7909() instanceof ItemBlockChiseled) {
            return ItemType.CHISELED_BLOCK;
        }

        if (stack.method_7909() instanceof ItemMirrorPrint) {
            return ItemType.MIRROR_DESIGN;
        }

        if (stack.method_7909() instanceof ItemPositivePrint) {
            return ItemType.POSITIVE_DESIGN;
        }

        if (stack.method_7909() instanceof ItemNegativePrint) {
            return ItemType.NEGATIVE_DESIGN;
        }

        if (stack.method_7909() instanceof ItemWrench) {
            return ItemType.WRENCH;
        }

        return null;
    }

    @Override
    public IBitAccess createBitItem(final class_1799 stack) {
        if (ModUtil.isEmpty(stack)) {
            return new BitAccess(null, null, new VoxelBlob(), VoxelBlob.NULL_BLOB);
        }

        final ItemType type = getItemType(stack);
        if (type != null && type.isBitAccess) {
            final VoxelBlob blob = ModUtil.getBlobFromStack(stack, null);
            return new BitAccess(null, null, blob, VoxelBlob.NULL_BLOB);
        }

        if (stack.method_7909() instanceof class_1747) {
            final class_2680 state = DeprecationHelper.getStateFromItem(stack);

            if (BlockBitInfo.canChisel(state)) {
                final VoxelBlob blob = new VoxelBlob();
                blob.fill(ModUtil.getStateId(state));
                return new BitAccess(null, null, blob, VoxelBlob.NULL_BLOB);
            }
        }

        return null;
    }

    @Override
    public IBitBrush createBrushFromState(final class_2680 state) throws InvalidBitItem {
        if (state == null || state.method_26204() == class_2246.field_10124) {
            return new BitBrush(0);
        }

        if (!BlockBitInfo.canChisel(state)) {
            throw new InvalidBitItem();
        }

        return new BitBrush(ModUtil.getStateId(state));
    }

    @Override
    public class_1799 getBitItem(final class_2680 state) throws InvalidBitItem {
        if (!BlockBitInfo.canChisel(state)) {
            throw new InvalidBitItem();
        }

        return ItemChiseledBit.createStack(ModUtil.getStateId(state), 1, true);
    }

    @Override
    public void giveBitToPlayer(final class_1657 player, final class_1799 stack, class_243 spawnPos) {
        if (ModUtil.isEmpty(stack)) {
            return;
        }

        if (spawnPos == null) {
            spawnPos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        }

        final class_1542 ei = new class_1542(player.method_5770(), spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350, stack);

        if (stack.method_7909() == ModItems.ITEM_BLOCK_BIT.get()) {
            if (player.method_5770().field_9236) {
                return;
            }

            BitInventoryFeeder feeder = new BitInventoryFeeder(player, player.method_5770());
            feeder.addItem(ei);
        } else if (!player.field_7514.method_7394(stack)) {
            ei.method_6979(stack);
            player.method_5770().method_8649(ei);
        }
    }

    @Override
    public IBitBag getBitbag(final class_1799 stack) {
        if (!ModUtil.isEmpty(stack)) {
            final Object o = stack.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, class_2350.field_11036);
            if (o instanceof IBitBag) {
                return (IBitBag) o;
            }
        }

        return null;
    }

    @Override
    public void beginUndoGroup(final class_1657 player) {
        UndoTracker.getInstance().beginGroup(player);
    }

    @Override
    public void endUndoGroup(final class_1657 player) {
        UndoTracker.getInstance().endGroup(player);
    }

    @Override
    @Environment(EnvType.CLIENT)
    public class_304 getKeyBinding(ModKeyBinding modKeyBinding) {
        switch (modKeyBinding) {
            case SINGLE:
                return (class_304) ChiselMode.SINGLE.binding;
            case SNAP2:
                return (class_304) ChiselMode.SNAP2.binding;
            case SNAP4:
                return (class_304) ChiselMode.SNAP4.binding;
            case SNAP8:
                return (class_304) ChiselMode.SNAP8.binding;
            case LINE:
                return (class_304) ChiselMode.LINE.binding;
            case PLANE:
                return (class_304) ChiselMode.PLANE.binding;
            case CONNECTED_PLANE:
                return (class_304) ChiselMode.CONNECTED_PLANE.binding;
            case CUBE_SMALL:
                return (class_304) ChiselMode.CUBE_SMALL.binding;
            case CUBE_MEDIUM:
                return (class_304) ChiselMode.CUBE_MEDIUM.binding;
            case CUBE_LARGE:
                return (class_304) ChiselMode.CUBE_LARGE.binding;
            case SAME_MATERIAL:
                return (class_304) ChiselMode.SAME_MATERIAL.binding;
            case DRAWN_REGION:
                return (class_304) ChiselMode.DRAWN_REGION.binding;
            case CONNECTED_MATERIAL:
                return (class_304) ChiselMode.CONNECTED_MATERIAL.binding;
            case REPLACE:
                return (class_304) PositivePatternMode.REPLACE.binding;
            case ADDITIVE:
                return (class_304) PositivePatternMode.ADDITIVE.binding;
            case PLACEMENT:
                return (class_304) PositivePatternMode.PLACEMENT.binding;
            case IMPOSE:
                return (class_304) PositivePatternMode.IMPOSE.binding;
            case BIT:
                return (class_304) TapeMeasureModes.BIT.binding;
            case BLOCK:
                return (class_304) TapeMeasureModes.BLOCK.binding;
            case DISTANCE:
                return (class_304) TapeMeasureModes.DISTANCE.binding;
            default:
                return ClientSide.instance.getKeyBinding(modKeyBinding);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public Object getParameter(ParameterType which) {
        switch (which.getType()) {
            case BOOLEAN:
                switch ((ParameterType.BooleanParam) which) {
                    case ENABLE_DAMAGE_TOOLS:
                        return ChiselsAndBits.getConfig()
                                .getServer()
                                .damageTools
                                .get();
                    case ENABLE_BIT_LIGHT_SOURCE:
                        return ChiselsAndBits.getConfig()
                                .getServer()
                                .enableBitLightSource
                                .get();
                }
                break;

            case DOUBLE:
                switch ((DoubleParam) which) {
                    case BIT_MAX_DRAWN_REGION_SIZE:
                        return ChiselsAndBits.getConfig()
                                .getClient()
                                .maxDrawnRegionSize
                                .get();
                }
                break;

            case FLOAT:
                switch ((FloatParam) which) {
                    case BLOCK_FULL_LIGHT_PERCENTAGE:
                        return ChiselsAndBits.getConfig()
                                .getServer()
                                .bitLightPercentage
                                .get();
                }
                break;

            case INTEGER:
                switch ((IntegerParam) which) {
                    case BIT_BAG_MAX_STACK_SIZE:
                        return ChiselsAndBits.getConfig()
                                .getServer()
                                .bagStackSize
                                .get();
                }
                break;
        }

        return null;
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void renderModel(
            final class_4587 stack,
            final class_1087 model,
            final class_1937 world,
            final class_2338 pos,
            final int alpha,
            final int combinedLight,
            final int combinedOverlay) {
        RenderHelper.renderModel(stack, model, world, pos, alpha << 24, combinedLight, combinedOverlay);
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void renderGhostModel(
            final class_4587 stack,
            final class_1087 model,
            final class_1937 world,
            final class_2338 pos,
            final boolean isUnplaceable,
            final int combinedLight,
            final int combinedOverlay) {
        RenderHelper.renderGhostModel(stack, model, world, pos, isUnplaceable, combinedLight, combinedOverlay);
    }
}
