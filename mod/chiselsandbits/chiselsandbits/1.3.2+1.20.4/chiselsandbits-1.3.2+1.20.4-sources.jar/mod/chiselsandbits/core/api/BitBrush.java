package mod.chiselsandbits.core.api;

import javax.annotation.Nullable;
import mod.chiselsandbits.api.IBitBrush;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import net.minecraft.class_1799;
import net.minecraft.class_2680;

public class BitBrush implements IBitBrush {

    protected final int stateID;

    public BitBrush(final int blockStateID) {
        stateID = blockStateID;
    }

    @Override
    public class_1799 getItemStack(final int count) {
        if (stateID == 0) {
            return ModUtil.getEmptyStack();
        }

        return ItemChiseledBit.createStack(stateID, count, true);
    }

    @Override
    public boolean isAir() {
        return stateID == 0;
    }

    @Override
    public @Nullable class_2680 getState() {
        if (stateID == 0) {
            return null;
        }

        return ModUtil.getStateById(stateID);
    }

    @Override
    public int getStateID() {
        return stateID;
    }
}
