package mod.chiselsandbits.core.textures;

import mod.chiselsandbits.utils.Constants;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4075;
import org.jetbrains.annotations.NotNull;

public class IconSpriteUploader extends class_4075 {
    public static final class_2960 TEXTURE_MAP_NAME =
            new class_2960(Constants.MOD_ID, "textures/atlases/icons.png");

    public IconSpriteUploader() {
        super(
                class_310.method_1551().method_1531(),
                TEXTURE_MAP_NAME,
                new class_2960(Constants.MOD_ID, "icons"));
    }

    /**
     * Overridden to make it public
     */
    @Override
    public @NotNull class_1058 method_18667(@NotNull class_2960 location) {
        return super.method_18667(location);
    }
}
