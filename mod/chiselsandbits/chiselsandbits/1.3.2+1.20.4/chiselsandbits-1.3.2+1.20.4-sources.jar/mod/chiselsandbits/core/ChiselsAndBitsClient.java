package mod.chiselsandbits.core;

import java.awt.image.BufferedImage;
import java.io.IOException;
import mod.chiselsandbits.bitbag.BagGui;
import mod.chiselsandbits.client.gui.SpriteIconPositioning;
import mod.chiselsandbits.core.textures.IconSpriteUploader;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.modes.IToolMode;
import mod.chiselsandbits.modes.PositivePatternMode;
import mod.chiselsandbits.modes.TapeMeasureModes;
import mod.chiselsandbits.printer.ChiselPrinterScreen;
import mod.chiselsandbits.registry.ModContainerTypes;
import mod.chiselsandbits.utils.TextureUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1059;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3304;
import net.minecraft.class_3929;

public class ChiselsAndBitsClient {

    private static IconSpriteUploader spriteUploader;

    @Environment(EnvType.CLIENT)
    public static void onClientInit() {

        ClientSide.instance.preInit();
        ClientSide.instance.init();
        ClientSide.instance.postInit();
        class_3929.method_17542(ModContainerTypes.BAG_CONTAINER.get(), BagGui::new);
        class_3929.method_17542(ModContainerTypes.CHISEL_STATION_CONTAINER.get(), ChiselPrinterScreen::new);
    }

    //    @Environment(EnvType.CLIENT)
    //    public static void onModelRegistry(Map<ResourceLocation, IGeometryLoader<?>> loaders) {
    //        loaders.put(new ResourceLocation(Constants.MOD_ID, "chiseled_block"),
    // ChiseledBlockModelLoader.getInstance());
    //    }

    @Environment(EnvType.CLIENT)
    public static void registerIconTextures() {
        spriteUploader = new IconSpriteUploader();
        if (class_310.method_1551().method_1478() instanceof class_3304 resourceManager) {
            resourceManager.method_14477(spriteUploader);
        }
    }

    @Environment(EnvType.CLIENT)
    public static void retrieveRegisteredIconSprites(class_1059 map) {
        if (!map.method_24106().equals(IconSpriteUploader.TEXTURE_MAP_NAME)) {
            return;
        }
        ClientSide.swapIcon = spriteUploader.method_18667(new class_2960("chiselsandbits", "swap"));
        ClientSide.placeIcon = spriteUploader.method_18667(new class_2960("chiselsandbits", "place"));
        ClientSide.undoIcon = spriteUploader.method_18667(new class_2960("chiselsandbits", "undo"));
        ClientSide.redoIcon = spriteUploader.method_18667(new class_2960("chiselsandbits", "redo"));
        ClientSide.trashIcon = spriteUploader.method_18667(new class_2960("chiselsandbits", "trash"));
        ClientSide.sortIcon = spriteUploader.method_18667(new class_2960("chiselsandbits", "sort"));
        ClientSide.roll_x = spriteUploader.method_18667(new class_2960("chiselsandbits", "roll_x"));
        ClientSide.roll_z = spriteUploader.method_18667(new class_2960("chiselsandbits", "roll_z"));
        ClientSide.white = spriteUploader.method_18667(new class_2960("chiselsandbits", "white"));

        for (final ChiselMode mode : ChiselMode.values()) {
            loadIcon(spriteUploader, mode);
        }

        for (final PositivePatternMode mode : PositivePatternMode.values()) {
            loadIcon(spriteUploader, mode);
        }

        for (final TapeMeasureModes mode : TapeMeasureModes.values()) {
            loadIcon(spriteUploader, mode);
        }
    }

    @Environment(EnvType.CLIENT)
    private static void loadIcon(final IconSpriteUploader spriteUploader, final IToolMode mode) {
        final SpriteIconPositioning sip = new SpriteIconPositioning();

        final class_2960 sprite =
                new class_2960("chiselsandbits", mode.name().toLowerCase());
        final class_2960 png = new class_2960(
                "chiselsandbits", "textures/icons/" + mode.name().toLowerCase() + ".png");

        sip.sprite = spriteUploader.method_18667(sprite);

        try {
            final class_3298 iresource = class_310.method_1551()
                    .method_1478()
                    .method_14486(png)
                    .get();
            final BufferedImage bi = TextureUtils.readBufferedImage(iresource.method_14482());

            int bottom = 0;
            int right = 0;
            sip.left = bi.getWidth();
            sip.top = bi.getHeight();

            for (int x = 0; x < bi.getWidth(); x++) {
                for (int y = 0; y < bi.getHeight(); y++) {
                    final int color = bi.getRGB(x, y);
                    final int a = color >> 24 & 0xff;
                    if (a > 0) {
                        sip.left = Math.min(sip.left, x);
                        right = Math.max(right, x);

                        sip.top = Math.min(sip.top, y);
                        bottom = Math.max(bottom, y);
                    }
                }
            }

            sip.height = bottom - sip.top + 1;
            sip.width = right - sip.left + 1;

            sip.left /= bi.getWidth();
            sip.width /= bi.getWidth();
            sip.top /= bi.getHeight();
            sip.height /= bi.getHeight();
        } catch (final IOException e) {
            sip.height = 1;
            sip.width = 1;
            sip.left = 0;
            sip.top = 0;
        }

        ClientSide.instance.setIconForMode(mode, sip);
    }
}
