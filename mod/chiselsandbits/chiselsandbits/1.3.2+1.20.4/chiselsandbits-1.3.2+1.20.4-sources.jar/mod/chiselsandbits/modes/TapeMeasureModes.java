package mod.chiselsandbits.modes;

import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.LocalStrings;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2519;

public enum TapeMeasureModes implements IToolMode {
    BIT(LocalStrings.TapeMeasureBit),
    BLOCK(LocalStrings.TapeMeasureBlock),
    DISTANCE(LocalStrings.TapeMeasureDistance);

    public final LocalStrings string;
    public boolean isDisabled = false;

    public Object binding;

    TapeMeasureModes(final LocalStrings str) {
        string = str;
    }

    public static TapeMeasureModes getMode(final class_1799 stack) {
        if (stack != null) {
            try {
                final class_2487 nbt = stack.method_7969();
                if (nbt != null && nbt.method_10545("mode")) {
                    return valueOf(nbt.method_10558("mode"));
                }
            } catch (final IllegalArgumentException iae) {
                // nope!
            } catch (final Exception e) {
                Log.logError("Unable to determine mode.", e);
            }
        }

        return TapeMeasureModes.BIT;
    }

    public static TapeMeasureModes castMode(final IToolMode chiselMode) {
        if (chiselMode instanceof TapeMeasureModes) {
            return (TapeMeasureModes) chiselMode;
        }

        return TapeMeasureModes.BIT;
    }

    @Override
    public void setMode(final class_1799 stack) {
        if (stack != null) {
            stack.method_7959("mode", class_2519.method_23256(name()));
        }
    }

    @Override
    public LocalStrings getName() {
        return string;
    }

    @Override
    public boolean isDisabled() {
        return isDisabled;
    }
}
