package mod.chiselsandbits.modes;

import mod.chiselsandbits.helpers.LocalStrings;
import net.minecraft.class_1799;

public interface IToolMode {

    void setMode(class_1799 ei);

    LocalStrings getName();

    String name();

    boolean isDisabled();

    int ordinal();
}
