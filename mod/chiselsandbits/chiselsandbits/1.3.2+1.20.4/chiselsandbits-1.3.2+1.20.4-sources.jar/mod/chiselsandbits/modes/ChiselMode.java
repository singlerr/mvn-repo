package mod.chiselsandbits.modes;

import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.LocalStrings;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2519;

public enum ChiselMode implements IToolMode {
    SINGLE(LocalStrings.ChiselModeSingle),
    SNAP2(LocalStrings.ChiselModeSnap2),
    SNAP4(LocalStrings.ChiselModeSnap4),
    SNAP8(LocalStrings.ChiselModeSnap8),
    LINE(LocalStrings.ChiselModeLine),
    PLANE(LocalStrings.ChiselModePlane),
    CONNECTED_PLANE(LocalStrings.ChiselModeConnectedPlane),
    CUBE_SMALL(LocalStrings.ChiselModeCubeSmall),
    CUBE_MEDIUM(LocalStrings.ChiselModeCubeMedium),
    CUBE_LARGE(LocalStrings.ChiselModeCubeLarge),
    SAME_MATERIAL(LocalStrings.ChiselModeSameMaterial),
    DRAWN_REGION(LocalStrings.ChiselModeDrawnRegion),
    CONNECTED_MATERIAL(LocalStrings.ChiselModeConnectedMaterial);

    public final LocalStrings string;

    public boolean isDisabled = false;

    public Object binding;

    ChiselMode(final LocalStrings str) {
        string = str;
    }

    public static ChiselMode getMode(final class_1799 stack) {
        if (stack != null) {
            try {
                final class_2487 nbt = stack.method_7969();
                if (nbt != null && nbt.method_10545("mode")) {
                    return valueOf(nbt.method_10558("mode"));
                }
            } catch (final IllegalArgumentException iae) {
                // nope!
            } catch (final Exception e) {
                Log.logError("Unable to determine mode.", e);
            }
        }

        return SINGLE;
    }

    public static ChiselMode castMode(final IToolMode chiselMode) {
        if (chiselMode instanceof ChiselMode) {
            return (ChiselMode) chiselMode;
        }

        return ChiselMode.SINGLE;
    }

    @Override
    public void setMode(final class_1799 stack) {
        if (stack != null) {
            stack.method_7959("mode", class_2519.method_23256(name()));
        }
    }

    @Override
    public LocalStrings getName() {
        return string;
    }

    @Override
    public boolean isDisabled() {
        return isDisabled;
    }
}
