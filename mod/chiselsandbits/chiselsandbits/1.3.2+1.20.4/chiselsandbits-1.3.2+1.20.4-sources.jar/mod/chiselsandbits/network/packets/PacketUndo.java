package mod.chiselsandbits.network.packets;

import java.util.ArrayList;
import java.util.List;
import mod.chiselsandbits.api.APIExceptions.CannotBeChiseled;
import mod.chiselsandbits.bitbag.BagInventory;
import mod.chiselsandbits.chiseledblock.data.BitIterator;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateReference;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.api.BitAccess;
import mod.chiselsandbits.helpers.ActingPlayer;
import mod.chiselsandbits.helpers.BitInventoryFeeder;
import mod.chiselsandbits.helpers.ContinousChisels;
import mod.chiselsandbits.helpers.IContinuousInventory;
import mod.chiselsandbits.helpers.IItemInInventory;
import mod.chiselsandbits.helpers.InventoryBackup;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketUndo extends ModPacket {

    public static final PacketType<PacketUndo> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_undo"), PacketUndo::new);

    private class_2338 pos;
    private VoxelBlobStateReference before;
    private VoxelBlobStateReference after;

    public PacketUndo(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketUndo(final class_2338 pos, final VoxelBlobStateReference before, final VoxelBlobStateReference after) {
        this.pos = pos;
        this.before = before;
        this.after = after;
    }

    @Override
    public void server(final class_3222 player) {
        performAction(ActingPlayer.actingAs(player, class_1268.field_5808), true);
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_10807(pos);

        final byte[] bef = before.getByteArray();
        buffer.method_53002(bef.length);
        buffer.method_52983(bef);

        final byte[] aft = after.getByteArray();
        buffer.method_53002(aft.length);
        buffer.method_52983(aft);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        pos = buffer.method_10811();

        final int lena = buffer.readInt();
        final byte[] ta = new byte[lena];
        buffer.method_52979(ta);

        final int lenb = buffer.readInt();
        final byte[] tb = new byte[lenb];
        buffer.method_52979(tb);

        before = new VoxelBlobStateReference(ta, 0);
        after = new VoxelBlobStateReference(tb, 0);
    }

    public boolean performAction(final ActingPlayer player, final boolean spawnItemsAndCommitWorldChanges) {
        if (inRange(player, pos)) {
            return apply(player, spawnItemsAndCommitWorldChanges);
        }

        return false;
    }

    private boolean apply(final ActingPlayer player, final boolean spawnItemsAndCommitWorldChanges) {
        try {
            final class_2350 side = class_2350.field_11036;

            final class_1937 world = player.getWorld();
            final BitAccess ba = (BitAccess) ChiselsAndBits.getApi().getBitAccess(world, pos);

            final VoxelBlob bBefore = before.getVoxelBlob();
            final VoxelBlob bAfter = after.getVoxelBlob();

            final VoxelBlob target = ba.getNativeBlob();

            if (target.equals(bBefore)) {
                // if something horrible goes wrong in a single block change we
                // can roll it back, but it shouldn't happen since its already
                // been approved as possible.
                final InventoryBackup backup = new InventoryBackup(player.getInventory());

                boolean successful = true;

                final IContinuousInventory selected = new ContinousChisels(player, pos, side);
                class_1799 spawnedItem = null;

                final List<BagInventory> bags = ModUtil.getBags(player);
                final List<class_1542> spawnlist = new ArrayList<class_1542>();

                final BitIterator bi = new BitIterator();
                while (bi.hasNext()) {
                    final int inBefore = bi.getNext(bBefore);
                    final int inAfter = bi.getNext(bAfter);

                    if (inBefore != inAfter) {
                        if (inAfter == 0) {
                            if (selected.isValid()) {
                                spawnedItem = ItemChisel.chiselBlock(
                                        selected,
                                        player,
                                        target,
                                        world,
                                        pos,
                                        side,
                                        bi.x,
                                        bi.y,
                                        bi.z,
                                        spawnedItem,
                                        spawnlist);
                            } else {
                                successful = false;
                                break;
                            }
                        } else if (inAfter != 0) {
                            if (inBefore != 0) {
                                if (selected.isValid()) {
                                    spawnedItem = ItemChisel.chiselBlock(
                                            selected,
                                            player,
                                            target,
                                            world,
                                            pos,
                                            side,
                                            bi.x,
                                            bi.y,
                                            bi.z,
                                            spawnedItem,
                                            spawnlist);
                                } else {
                                    successful = false;
                                    break;
                                }
                            }

                            final IItemInInventory bit = ModUtil.findBit(player, pos, inAfter);
                            if (ModUtil.consumeBagBit(bags, inAfter, 1) == 1) {
                                bi.setNext(target, inAfter);
                            } else if (bit.isValid()) {
                                if (!player.isCreative()) {
                                    if (!bit.consume()) {
                                        successful = false;
                                        break;
                                    }
                                }

                                bi.setNext(target, inAfter);
                            } else {
                                successful = false;
                                break;
                            }
                        }
                    }
                }

                if (successful) {
                    if (spawnItemsAndCommitWorldChanges) {
                        ba.commitChanges(true);
                        BitInventoryFeeder feeder = new BitInventoryFeeder(player.getPlayer(), player.getWorld());
                        for (final class_1542 ei : spawnlist) {
                            feeder.addItem(ei);
                            ItemBitBag.cleanupInventory(player.getPlayer(), ei.method_6983());
                        }
                    }

                    return true;
                } else {
                    backup.rollback();
                    UndoTracker.getInstance().addError(player, "mod.chiselsandbits.result.missing_bits");
                    return false;
                }
            }
        } catch (final CannotBeChiseled e) {
            // error message below.
        }

        UndoTracker.getInstance().addError(player, "mod.chiselsandbits.result.has_changed");
        return false;
    }

    private boolean inRange(final ActingPlayer player, final class_2338 pos) {
        if (player.isReal()) {
            return true;
        }

        double reach = 6;
        if (player.isCreative()) {
            reach = 32;
        }

        if (player.getPlayer().method_5649(pos.method_10263(), pos.method_10264(), pos.method_10260()) < reach * reach) {
            return true;
        }

        UndoTracker.getInstance().addError(player, "mod.chiselsandbits.result.out_of_range");
        return false;
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
