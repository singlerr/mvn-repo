package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.bitbag.BagContainer;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketBagGui extends ModPacket {

    public static final PacketType<PacketBagGui> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_bag_gui"), PacketBagGui::new);

    private int slotNumber = -1;
    private int mouseButton = -1;
    private boolean duplicateButton = false;
    private boolean holdingShift = false;

    public PacketBagGui(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketBagGui(
            final int slotNumber, final int mouseButton, final boolean duplicateButton, final boolean holdingShift) {
        this.slotNumber = slotNumber;
        this.mouseButton = mouseButton;
        this.duplicateButton = duplicateButton;
        this.holdingShift = holdingShift;
    }

    @Override
    public void server(final class_3222 player) {
        doAction(player);
    }

    public void doAction(final class_1657 player) {
        final class_1703 c = player.field_7512;
        if (c instanceof BagContainer bc) {
            bc.handleCustomSlotAction(slotNumber, mouseButton, duplicateButton, holdingShift);
        }
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_53002(slotNumber);
        buffer.method_53002(mouseButton);
        buffer.method_52964(duplicateButton);
        buffer.method_52964(holdingShift);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        slotNumber = buffer.readInt();
        mouseButton = buffer.readInt();
        duplicateButton = buffer.readBoolean();
        holdingShift = buffer.readBoolean();
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
