package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.events.EventPlayerInteract;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketSuppressInteraction extends ModPacket {

    public static final PacketType<PacketSuppressInteraction> PACKET_TYPE = PacketType.create(
            new class_2960(Constants.MOD_ID, "packet_suppress_interaction"), PacketSuppressInteraction::new);

    private boolean newSetting = false;

    public PacketSuppressInteraction(final class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketSuppressInteraction(final boolean newSetting) {
        this.newSetting = newSetting;
    }

    @Override
    public void server(final class_3222 player) {
        EventPlayerInteract.setPlayerSuppressionState(player, newSetting);
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_52964(newSetting);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        newSetting = buffer.readBoolean();
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
