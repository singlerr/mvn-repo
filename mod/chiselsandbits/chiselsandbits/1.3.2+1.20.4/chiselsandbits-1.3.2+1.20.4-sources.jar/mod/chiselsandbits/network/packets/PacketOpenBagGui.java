package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.bitbag.BagContainer;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_747;

public class PacketOpenBagGui extends ModPacket {

    public static final PacketType<PacketOpenBagGui> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_open_bag_gui"), PacketOpenBagGui::new);

    public PacketOpenBagGui(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketOpenBagGui() {}

    @Override
    public void server(final class_3222 player) {
        player.method_17355(new class_747(
                (id, playerInventory, playerEntity) -> new BagContainer(id, playerInventory),
                class_2561.method_43470("Bitbag")));
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        // no data...
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        // no data..
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
