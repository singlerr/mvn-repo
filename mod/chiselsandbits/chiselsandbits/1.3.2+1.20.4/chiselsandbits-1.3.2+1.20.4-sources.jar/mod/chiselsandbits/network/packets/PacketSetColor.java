package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.IChiselModeItem;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2519;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketSetColor extends ModPacket {

    public static final PacketType<PacketSetColor> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_set_color"), PacketSetColor::new);

    private class_1767 newColor = class_1767.field_7952;
    private ChiselToolType type = ChiselToolType.TAPEMEASURE;
    private boolean chatNotification = false;

    public PacketSetColor(final class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketSetColor(final class_1767 newColor, final ChiselToolType type, final boolean chatNotification) {
        this.newColor = newColor;
        this.type = type;
        this.chatNotification = chatNotification;
    }

    @Override
    public void server(final class_3222 player) {
        final class_1799 ei = player.method_6047();
        if (ei != null && ei.method_7909() instanceof IChiselModeItem) {
            final class_1767 originalMode = getColor(ei);
            setColor(ei, newColor);

            if (originalMode != newColor && chatNotification) {
                player.method_43496(class_2561.method_43471("chiselsandbits.color." + newColor.method_7792()));
            }
        }
    }

    private void setColor(final class_1799 ei, final class_1767 newColor2) {
        if (ei != null) {
            ei.method_7959("color", class_2519.method_23256(newColor2.name()));
        }
    }

    private class_1767 getColor(final class_1799 ei) {
        try {
            if (ei != null && ei.method_7985()) {
                return class_1767.valueOf(ModUtil.getTagCompound(ei).method_10558("color"));
            }
        } catch (final IllegalArgumentException e) {
            // nope!
        }

        return class_1767.field_7952;
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_52964(chatNotification);
        buffer.method_10817(type);
        buffer.method_10817(newColor);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        chatNotification = buffer.readBoolean();
        type = buffer.method_10818(ChiselToolType.class);
        newColor = buffer.method_10818(class_1767.class);
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
