package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class PacketAccurateSneakPlace extends ModPacket {

    public static final PacketType<PacketAccurateSneakPlace> PACKET_TYPE = PacketType.create(
            new class_2960(Constants.MOD_ID, "packet_accurate_sneak_place"), PacketAccurateSneakPlace::new);
    private class_1799 stack;
    private class_2338 pos;
    private class_1268 hand;
    private class_2350 side;
    private double hitX, hitY, hitZ;
    private boolean offgrid;

    public PacketAccurateSneakPlace(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketAccurateSneakPlace(
            final class_1799 stack,
            final class_2338 pos,
            final class_1268 hand,
            final class_2350 side,
            final double hitX,
            final double hitY,
            final double hitZ,
            final boolean offgrid) {
        this.stack = stack;
        this.pos = pos;
        this.hand = hand;
        this.side = side;
        this.hitX = hitX;
        this.hitY = hitY;
        this.hitZ = hitZ;
        this.offgrid = offgrid;
    }

    @Override
    public void server(final class_3222 playerEntity) {
        if (stack != null && stack.method_7909() instanceof IItemBlockAccurate) {
            class_1799 inHand = playerEntity.method_5998(hand);
            if (class_1799.method_31577(stack, inHand)) {
                if (playerEntity.method_7337()) {
                    inHand = stack;
                }

                final IItemBlockAccurate ibc = (IItemBlockAccurate) stack.method_7909();
                final class_1838 context = new class_1838(
                        playerEntity, hand, new class_3965(new class_243(hitX, hitY, hitZ), side, pos, false));
                ibc.tryPlace(new class_1750(context), offgrid);

                if (!playerEntity.method_7337() && ModUtil.getStackSize(inHand) <= 0) {
                    playerEntity.method_6122(hand, ModUtil.getEmptyStack());
                }
            }
        }
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_10793(stack);
        buffer.method_10807(pos);
        buffer.method_10817(side);
        buffer.method_10817(hand);
        buffer.method_52940(hitX);
        buffer.method_52940(hitY);
        buffer.method_52940(hitZ);
        buffer.method_52964(offgrid);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        stack = buffer.method_10819();
        pos = buffer.method_10811();
        side = buffer.method_10818(class_2350.class);
        hand = buffer.method_10818(class_1268.class);
        hitX = buffer.readDouble();
        hitY = buffer.readDouble();
        hitZ = buffer.readDouble();
        offgrid = buffer.readBoolean();
    }

    public class_1799 getStack() {
        return stack;
    }

    public void setStack(final class_1799 stack) {
        this.stack = stack;
    }

    public class_2338 getPos() {
        return pos;
    }

    public void setPos(final class_2338 pos) {
        this.pos = pos;
    }

    public class_1268 getHand() {
        return hand;
    }

    public void setHand(final class_1268 hand) {
        this.hand = hand;
    }

    public class_2350 getSide() {
        return side;
    }

    public void setSide(final class_2350 side) {
        this.side = side;
    }

    public double getHitX() {
        return hitX;
    }

    public void setHitX(final double hitX) {
        this.hitX = hitX;
    }

    public double getHitY() {
        return hitY;
    }

    public void setHitY(final double hitY) {
        this.hitY = hitY;
    }

    public double getHitZ() {
        return hitZ;
    }

    public void setHitZ(final double hitZ) {
        this.hitZ = hitZ;
    }

    public boolean isOffgrid() {
        return offgrid;
    }

    public void setOffgrid(final boolean offgrid) {
        this.offgrid = offgrid;
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }

    public interface IItemBlockAccurate {

        class_1269 tryPlace(class_1838 context, boolean offGrid);
    }
}
