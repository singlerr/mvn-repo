package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.bitbag.BagContainer;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketClearBagGui extends ModPacket {

    public static final PacketType<PacketClearBagGui> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_clear_bag_gui"), PacketClearBagGui::new);

    private class_1799 stack = null;

    public PacketClearBagGui(final class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketClearBagGui(final class_1799 inHandItem) {
        stack = inHandItem;
    }

    @Override
    public void server(final class_3222 player) {
        if (player.field_7512 instanceof BagContainer) {
            ((BagContainer) player.field_7512).clear(stack);
        }
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_10793(stack);
        // no data...
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        stack = buffer.method_10819();
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
