package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.bitbag.BagContainer;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class PacketBagGuiStack extends ModPacket {

    public static final PacketType<PacketBagGuiStack> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_bag_gui_stack"), PacketBagGuiStack::new);

    private int index = -1;
    private class_1799 is;

    public PacketBagGuiStack(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketBagGuiStack(final int index, final class_1799 is) {
        this.index = index;
        this.is = is;
    }

    @Override
    public void client() {
        final class_1703 cc = ClientSide.instance.getPlayer().field_7512;
        if (cc instanceof BagContainer) {
            ((BagContainer) cc).customSlots.get(index).method_7673(is);
        }
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_53002(index);

        if (is == null) {
            buffer.method_53002(0);
        } else {
            buffer.method_53002(ModUtil.getStackSize(is));
            buffer.method_53002(ItemChiseledBit.getStackState(is));
        }
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        index = buffer.readInt();

        final int size = buffer.readInt();

        if (size <= 0) {
            is = null;
        } else {
            is = ItemChiseledBit.createStack(buffer.readInt(), size, false);
        }
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
