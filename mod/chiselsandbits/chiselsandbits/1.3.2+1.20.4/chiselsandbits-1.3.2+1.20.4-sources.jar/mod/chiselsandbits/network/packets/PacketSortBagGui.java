package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.bitbag.BagContainer;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketSortBagGui extends ModPacket {

    public static final PacketType<PacketSortBagGui> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_sort_bag_gui"), PacketSortBagGui::new);

    public PacketSortBagGui(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketSortBagGui() {}

    @Override
    public void server(final class_3222 player) {
        if (player.field_7512 instanceof BagContainer) {
            ((BagContainer) player.field_7512).sort();
        }
    }

    @Override
    public void getPayload(class_2540 buffer) {}

    @Override
    public void readPayload(class_2540 buffer) {}

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
