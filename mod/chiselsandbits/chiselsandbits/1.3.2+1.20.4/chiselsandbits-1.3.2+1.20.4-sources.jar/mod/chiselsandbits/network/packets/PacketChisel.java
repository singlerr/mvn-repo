package mod.chiselsandbits.network.packets;

import java.util.ArrayList;
import java.util.List;
import mod.chiselsandbits.chiseledblock.BlockChiseled;
import mod.chiselsandbits.chiseledblock.BlockChiseled.ReplaceWithChiseledValue;
import mod.chiselsandbits.chiseledblock.TileEntityBlockChiseled;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.iterators.ChiselIterator;
import mod.chiselsandbits.chiseledblock.iterators.ChiselTypeIterator;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.helpers.ActingPlayer;
import mod.chiselsandbits.helpers.BitInventoryFeeder;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.ContinousBits;
import mod.chiselsandbits.helpers.ContinousChisels;
import mod.chiselsandbits.helpers.IContinuousInventory;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.helpers.VoxelRegionSrc;
import mod.chiselsandbits.items.ItemBitBag;
import mod.chiselsandbits.items.ItemChisel;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class PacketChisel extends ModPacket {

    public static final PacketType<PacketChisel> PACKET_TYPE =
            PacketType.create(new class_2960(Constants.MOD_ID, "packet_chisel"), PacketChisel::new);

    BitLocation from;
    BitLocation to;

    BitOperation place;
    class_2350 side;
    ChiselMode mode;
    class_1268 hand;

    public PacketChisel(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketChisel(
            final BitOperation place,
            final BitLocation from,
            final BitLocation to,
            final class_2350 side,
            final ChiselMode mode,
            final class_1268 hand) {
        this.place = place;
        this.from = BitLocation.min(from, to);
        this.to = BitLocation.max(from, to);
        this.side = side;
        this.mode = mode;
        this.hand = hand;
    }

    public PacketChisel(
            final BitOperation place,
            final BitLocation location,
            final class_2350 side,
            final ChiselMode mode,
            final class_1268 hand) {
        this.place = place;
        from = to = location;
        this.side = side;
        this.mode = mode;
        this.hand = hand;
    }

    @Override
    public void server(final class_3222 playerEntity) {
        doAction(playerEntity);
    }

    public int doAction(final class_1657 who) {
        final class_1937 world = who.method_5770();
        final ActingPlayer player = ActingPlayer.actingAs(who, hand);

        final int minX = Math.min(from.blockPos.method_10263(), to.blockPos.method_10263());
        final int maxX = Math.max(from.blockPos.method_10263(), to.blockPos.method_10263());
        final int minY = Math.min(from.blockPos.method_10264(), to.blockPos.method_10264());
        final int maxY = Math.max(from.blockPos.method_10264(), to.blockPos.method_10264());
        final int minZ = Math.min(from.blockPos.method_10260(), to.blockPos.method_10260());
        final int maxZ = Math.max(from.blockPos.method_10260(), to.blockPos.method_10260());

        int returnVal = 0;

        boolean update = false;
        class_1799 extracted = null;
        class_1799 bitPlaced = null;

        final List<class_1542> spawnlist = new ArrayList<class_1542>();

        UndoTracker.getInstance().beginGroup(who);

        try {
            for (int xOff = minX; xOff <= maxX; ++xOff) {
                for (int yOff = minY; yOff <= maxY; ++yOff) {
                    for (int zOff = minZ; zOff <= maxZ; ++zOff) {
                        final class_2338 pos = new class_2338(xOff, yOff, zOff);

                        final int placeStateID =
                                place.usesBits() ? ItemChiseledBit.getStackState(who.method_5998(hand)) : 0;
                        final IContinuousInventory chisels = new ContinousChisels(player, pos, side);
                        final IContinuousInventory bits = new ContinousBits(player, pos, placeStateID);

                        class_2680 blkstate = world.method_8320(pos);
                        class_2248 blkObj = blkstate.method_26204();

                        if (place.usesChisels()) {
                            if (!chisels.isValid()
                                    || blkObj == null
                                    || blkstate == null
                                    || !ItemChisel.canMine(chisels, blkstate, who, world, pos)) {
                                continue;
                            }
                        }

                        if (place.usesBits()) {
                            if (!bits.isValid() || blkObj == null || blkstate == null) {
                                continue;
                            }
                        }

                        if (world instanceof class_3218
                                && world.method_8503() != null
                                && world.method_8503()
                                        .method_3785((class_3218) world, pos, player.getPlayer())) {
                            continue;
                        }

                        if (!world.method_8505(player.getPlayer(), pos)) {
                            continue;
                        }

                        if (world.method_8320(pos)
                                        .method_26166(new class_1750(
                                                who,
                                                hand,
                                                class_1799.field_8037,
                                                new class_3965(class_243.field_1353, class_2350.field_11043, pos, false)))
                                && place.usesBits()) {
                            world.method_8501(pos, class_2246.field_10124.method_9564());
                        }

                        ReplaceWithChiseledValue rv = null;
                        if ((rv = BlockChiseled.replaceWithChiseled(world, pos, blkstate, placeStateID, true))
                                .success) {
                            blkstate = world.method_8320(pos);
                            blkObj = blkstate.method_26204();
                        }

                        final class_2586 te =
                                rv.te != null ? rv.te : ModUtil.getChiseledTileEntity(world, pos, place.usesBits());
                        if (te instanceof TileEntityBlockChiseled tec) {

                            final VoxelBlob mask = new VoxelBlob();

                            // adjust voxel state...
                            final VoxelBlob vb = tec.getBlob();

                            final ChiselIterator i = getIterator(new VoxelRegionSrc(world, pos, 1), pos, place);
                            while (i.hasNext()) {
                                if (place.usesChisels() && chisels.isValid()) {
                                    if (!place.usesBits() || vb.get(i.x(), i.y(), i.z()) != placeStateID) {
                                        extracted = ItemChisel.chiselBlock(
                                                chisels, player, vb, world, pos, i.side(), i.x(), i.y(), i.z(),
                                                extracted, spawnlist);
                                    }
                                }

                                if (place.usesBits() && bits.isValid()) {
                                    if (mask.get(i.x(), i.y(), i.z()) == 0) {
                                        bitPlaced = bits.getItem(0).getStack();
                                        update = ItemChiseledBit.placeBit(bits, player, vb, i.x(), i.y(), i.z())
                                                || update;
                                    }
                                }
                            }

                            if (update) {
                                tec.completeEditOperation(vb);
                                returnVal++;
                            } else if (extracted != null) {
                                tec.completeEditOperation(vb);
                                returnVal++;
                            }
                        }
                    }
                }
            }

            BitInventoryFeeder feeder = new BitInventoryFeeder(who, world);
            for (final class_1542 ei : spawnlist) {
                feeder.addItem(ei);
                ItemBitBag.cleanupInventory(who, ei.method_6983());
            }

            if (place.usesBits()) {
                ItemBitBag.cleanupInventory(
                        who, bitPlaced != null ? bitPlaced : new class_1799(ModItems.ITEM_BLOCK_BIT.get(), 1));
            }

        } finally {
            UndoTracker.getInstance().endGroup(who);
        }

        return returnVal;
    }

    private ChiselIterator getIterator(final VoxelRegionSrc vb, final class_2338 pos, final BitOperation place) {
        if (mode == ChiselMode.DRAWN_REGION) {
            final int bitX = pos.method_10263() == from.blockPos.method_10263() ? from.bitX : 0;
            final int bitY = pos.method_10264() == from.blockPos.method_10264() ? from.bitY : 0;
            final int bitZ = pos.method_10260() == from.blockPos.method_10260() ? from.bitZ : 0;

            final int scaleX = (pos.method_10263() == to.blockPos.method_10263() ? to.bitX : 15) - bitX + 1;
            final int scaleY = (pos.method_10264() == to.blockPos.method_10264() ? to.bitY : 15) - bitY + 1;
            final int scaleZ = (pos.method_10260() == to.blockPos.method_10260() ? to.bitZ : 15) - bitZ + 1;

            return new ChiselTypeIterator(VoxelBlob.dim, bitX, bitY, bitZ, scaleX, scaleY, scaleZ, side);
        }

        return ChiselTypeIterator.create(
                VoxelBlob.dim, from.bitX, from.bitY, from.bitZ, vb, mode, side, place.usePlacementOffset());
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        from = readBitLoc(buffer);
        to = readBitLoc(buffer);

        place = buffer.method_10818(BitOperation.class);
        side = class_2350.values()[buffer.readInt()];
        mode = ChiselMode.values()[buffer.readInt()];
        hand = class_1268.values()[buffer.readInt()];
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        writeBitLoc(from, buffer);
        writeBitLoc(to, buffer);

        buffer.method_10817(place);
        buffer.method_53002(side.ordinal());
        buffer.method_53002(mode.ordinal());
        buffer.method_53002(hand.ordinal());
    }

    private BitLocation readBitLoc(final class_2540 buffer) {
        return new BitLocation(buffer.method_10811(), buffer.readByte(), buffer.readByte(), buffer.readByte());
    }

    private void writeBitLoc(final BitLocation from2, final class_2540 buffer) {
        buffer.method_10807(from2.blockPos);
        buffer.method_52997(from2.bitX);
        buffer.method_52997(from2.bitY);
        buffer.method_52997(from2.bitZ);
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
