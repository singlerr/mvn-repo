package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.interfaces.IVoxelBlobItem;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketRotateVoxelBlob extends ModPacket {

    public static final PacketType<PacketRotateVoxelBlob> PACKET_TYPE = PacketType.create(
            new class_2960(Constants.MOD_ID, "packet_rotate_voxel_blob"), PacketRotateVoxelBlob::new);

    private class_2350.class_2351 axis;
    private class_2470 rotation;

    public PacketRotateVoxelBlob(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketRotateVoxelBlob(final class_2350.class_2351 axis, final class_2470 rotation) {
        this.axis = axis;
        this.rotation = rotation;
    }

    @Override
    public void server(final class_3222 player) {
        final class_1799 is = player.method_6047();
        if (is != null && is.method_7909() instanceof IVoxelBlobItem) {
            ((IVoxelBlobItem) is.method_7909()).rotate(is, axis, rotation);
        }
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_10817(axis);
        buffer.method_10817(rotation);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        axis = buffer.method_10818(class_2350.class_2351.class);
        rotation = buffer.method_10818(class_2470.class);
    }

    public class_2350.class_2351 getAxis() {
        return axis;
    }

    public void setAxis(final class_2350.class_2351 axis) {
        this.axis = axis;
    }

    public class_2470 getRotation() {
        return rotation;
    }

    public void setRotation(final class_2470 rotation) {
        this.rotation = rotation;
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }
}
