package mod.chiselsandbits.network.packets;

import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.interfaces.IChiselModeItem;
import mod.chiselsandbits.modes.ChiselMode;
import mod.chiselsandbits.modes.IToolMode;
import mod.chiselsandbits.modes.PositivePatternMode;
import mod.chiselsandbits.modes.TapeMeasureModes;
import mod.chiselsandbits.network.ModPacket;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class PacketSetChiselMode extends ModPacket {

    public static final PacketType<PacketSetChiselMode> PACKET_TYPE = PacketType.create(
            new class_2960(Constants.MOD_ID, "packet_set_chisel_mode"), PacketSetChiselMode::new);

    private IToolMode mode = ChiselMode.SINGLE;
    private ChiselToolType type = ChiselToolType.CHISEL;
    private boolean chatNotification = false;

    public PacketSetChiselMode(class_2540 buffer) {
        readPayload(buffer);
    }

    public PacketSetChiselMode(final IToolMode mode, final ChiselToolType type, final boolean chatNotification) {
        this.mode = mode;
        this.type = type;
        this.chatNotification = chatNotification;
    }

    @Override
    public void server(final class_3222 player) {
        final class_1799 ei = player.method_6047();
        if (ei != null && ei.method_7909() instanceof IChiselModeItem) {
            final IToolMode originalMode = type.getMode(ei);
            mode.setMode(ei);

            if (originalMode != mode && chatNotification) {
                player.method_43496(class_2561.method_43471(mode.getName().toString()));
            }
        }
    }

    @Override
    public void getPayload(final class_2540 buffer) {
        buffer.method_52964(chatNotification);
        buffer.method_10817(type);
        buffer.method_10817((Enum<?>) mode);
    }

    @Override
    public void readPayload(final class_2540 buffer) {
        chatNotification = buffer.readBoolean();
        type = buffer.method_10818(ChiselToolType.class);

        if (type == ChiselToolType.BIT || type == ChiselToolType.CHISEL) {
            mode = buffer.method_10818(ChiselMode.class);
        } else if (type == ChiselToolType.POSITIVEPATTERN) {
            mode = buffer.method_10818(PositivePatternMode.class);
        } else if (type == ChiselToolType.TAPEMEASURE) {
            mode = buffer.method_10818(TapeMeasureModes.class);
        }
    }

    public IToolMode getMode() {
        return mode;
    }

    public void setMode(final IToolMode mode) {
        this.mode = mode;
    }

    public ChiselToolType getToolType() {
        return type;
    }

    public boolean isChatNotification() {
        return chatNotification;
    }

    public void setChatNotification(final boolean chatNotification) {
        this.chatNotification = chatNotification;
    }

    @Override
    public PacketType<?> getType() {
        return PACKET_TYPE;
    }

    public void setType(final ChiselToolType type) {
        this.type = type;
    }
}
