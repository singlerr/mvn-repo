package mod.chiselsandbits.network;

import net.fabricmc.fabric.api.networking.v1.FabricPacket;
import net.minecraft.class_2540;
import net.minecraft.class_3222;

public abstract class ModPacket implements FabricPacket {

    class_3222 serverEntity = null;

    public ModPacket() {}

    public ModPacket(class_2540 buf) {
        readPayload(buf);
    }

    public void server(final class_3222 playerEntity) {
        throw new RuntimeException(getClass().getName() + " is not a server packet.");
    }

    public void client() {
        throw new RuntimeException(getClass().getName() + " is not a client packet.");
    }

    public abstract void getPayload(class_2540 buffer);

    public abstract void readPayload(class_2540 buffer);

    public void processPacket(final NetworkChannel.Context context, final Boolean onServer) {
        if (!onServer) {
            client();
        } else {
            serverEntity = context.serverPlayer();
            server(serverEntity);
        }
    }

    @Override
    public void write(class_2540 buf) {
        getPayload(buf);
    }
}
