package mod.chiselsandbits.render.helpers;

import net.minecraft.class_296;

public class ModelUVAverager extends BaseModelReader {
    private int vertCount = 0;
    private float sumU;
    private float sumV;

    public float getU() {
        return sumU / vertCount;
    }

    public float getV() {
        return sumV / vertCount;
    }

    @Override
    public void put(final int vertexIndex, final int element, final float... data) {
        final class_296 e = getVertexFormat().method_1357().get(element);
        if (e.method_1382() == class_296.class_298.field_1636 && e.method_1385() != 1) {
            sumU += data[0];
            sumV += data[1];
            ++vertCount;
        }
    }
}
