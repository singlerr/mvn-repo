package mod.chiselsandbits.render;

import java.util.List;
import mod.chiselsandbits.core.ClientSide;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;

public class NullBakedModel implements class_1087 {

    public static final NullBakedModel instance = new NullBakedModel();

    @Override
    public List<class_777> method_4707(
            @Nullable class_2680 blockState, @Nullable class_2350 direction, class_5819 randomSource) {
        return List.of();
    }

    @Override
    public boolean method_4708() {
        return false;
    }

    @Override
    public boolean method_4712() {
        return false;
    }

    @Override
    public boolean method_24304() {
        return false;
    }

    @Override
    public boolean method_4713() {
        return false;
    }

    @Override
    public class_1058 method_4711() {
        return ClientSide.instance.getMissingIcon();
    }

    @Override
    public class_809 method_4709() {
        return class_809.field_4301;
    }

    @Override
    public class_806 method_4710() {
        return class_806.field_4292;
    }
}
