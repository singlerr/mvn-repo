package mod.chiselsandbits.render.helpers;

import java.util.Arrays;
import net.minecraft.class_1058;
import net.minecraft.class_293;
import net.minecraft.class_296;

public class ModelUVReader extends BaseModelReader {

    public final float[] quadUVs = new float[] {0, 0, 0, 1, 1, 0, 1, 1};
    final float minU;
    final float maxUMinusMin;
    final float minV;
    final float maxVMinusMin;
    public int corners;
    int uCoord, vCoord;
    private float[] pos;
    private float[] uv;

    public ModelUVReader(final class_1058 texture, final int uFaceCoord, final int vFaceCoord) {
        minU = texture.method_4594();
        maxUMinusMin = texture.method_4577() - minU;

        minV = texture.method_4593();
        maxVMinusMin = texture.method_4575() - minV;

        uCoord = uFaceCoord;
        vCoord = vFaceCoord;
    }

    @Override
    public void put(final int vertexIndex, final int element, final float... data) {
        final class_293 format = getVertexFormat();
        final class_296 ele = format.method_1357().get(element);

        if (ele.method_1382() == class_296.class_298.field_1636 && ele.method_1385() == 0) {
            uv = Arrays.copyOf(data, data.length);
        } else if (ele.method_1382() == class_296.class_298.field_1633) {
            pos = Arrays.copyOf(data, data.length);
        }

        if (element == format.method_1357().size() - 1) {
            if (ModelUtil.isZero(pos[uCoord]) && ModelUtil.isZero(pos[vCoord])) {
                corners = corners | 0x1;
                quadUVs[0] = (uv[0] - minU) / maxUMinusMin;
                quadUVs[1] = (uv[1] - minV) / maxVMinusMin;
            } else if (ModelUtil.isZero(pos[uCoord]) && ModelUtil.isOne(pos[vCoord])) {
                corners = corners | 0x2;
                quadUVs[4] = (uv[0] - minU) / maxUMinusMin;
                quadUVs[5] = (uv[1] - minV) / maxVMinusMin;
            } else if (ModelUtil.isOne(pos[uCoord]) && ModelUtil.isZero(pos[vCoord])) {
                corners = corners | 0x4;
                quadUVs[2] = (uv[0] - minU) / maxUMinusMin;
                quadUVs[3] = (uv[1] - minV) / maxVMinusMin;
            } else if (ModelUtil.isOne(pos[uCoord]) && ModelUtil.isOne(pos[vCoord])) {
                corners = corners | 0x8;
                quadUVs[6] = (uv[0] - minU) / maxUMinusMin;
                quadUVs[7] = (uv[1] - minV) / maxVMinusMin;
            }
        }
    }
}
