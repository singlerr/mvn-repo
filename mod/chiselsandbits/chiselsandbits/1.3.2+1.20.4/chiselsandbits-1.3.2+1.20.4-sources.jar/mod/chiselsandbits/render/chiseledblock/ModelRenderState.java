package mod.chiselsandbits.render.chiseledblock;

import mod.chiselsandbits.helpers.IStateRef;
import net.minecraft.class_2350;

public class ModelRenderState {

    // less objects/garbage to clean up, and less memory usage.
    private IStateRef north, south, east, west, up, down;

    public ModelRenderState(final ModelRenderState sides) {
        if (sides != null) {
            north = sides.north;
            south = sides.south;
            east = sides.east;
            west = sides.west;
            up = sides.up;
            down = sides.down;
        }
    }

    public IStateRef get(final class_2350 side) {
        switch (side) {
            case field_11033:
                return down;
            case field_11034:
                return east;
            case field_11043:
                return north;
            case field_11035:
                return south;
            case field_11036:
                return up;
            case field_11039:
                return west;
            default:
        }

        return null;
    }

    public void put(final class_2350 side, final IStateRef value) {
        switch (side) {
            case field_11033:
                down = value;
                break;
            case field_11034:
                east = value;
                break;
            case field_11043:
                north = value;
                break;
            case field_11035:
                south = value;
                break;
            case field_11036:
                up = value;
                break;
            case field_11039:
                west = value;
                break;
            default:
        }
    }
}
