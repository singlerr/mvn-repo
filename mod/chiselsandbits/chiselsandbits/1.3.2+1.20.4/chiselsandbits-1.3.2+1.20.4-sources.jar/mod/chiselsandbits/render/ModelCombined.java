package mod.chiselsandbits.render;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import mod.chiselsandbits.client.model.baked.BaseBakedBlockModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ModelCombined extends BaseBakedBlockModel {

    private static final class_5819 COMBINED_RANDOM_MODEL = class_5819.method_43047();

    class_1087[] merged;

    List<class_777>[] face;
    List<class_777> generic;

    boolean isSideLit;

    Set<ChiselRenderType> renderTypes = Set.of();

    @SuppressWarnings("unchecked")
    public ModelCombined(final class_1087... args) {
        face = new ArrayList[class_2350.values().length];

        generic = new ArrayList<>();
        for (final class_2350 f : class_2350.values()) {
            face[f.ordinal()] = new ArrayList<>();
        }

        merged = args;

        for (final class_1087 m : merged) {
            generic.addAll(m.method_4707(null, null, COMBINED_RANDOM_MODEL));
            for (final class_2350 f : class_2350.values()) {
                face[f.ordinal()].addAll(m.method_4707(null, f, COMBINED_RANDOM_MODEL));
            }
        }

        isSideLit = Arrays.stream(args).anyMatch(class_1087::method_24304);
    }

    public ModelCombined(Set<ChiselRenderType> renderTypes, final class_1087... args) {
        this.renderTypes = renderTypes;
        face = new ArrayList[class_2350.values().length];

        generic = new ArrayList<>();
        for (final class_2350 f : class_2350.values()) {
            face[f.ordinal()] = new ArrayList<>();
        }

        merged = args;

        for (final class_1087 m : merged) {
            generic.addAll(m.method_4707(null, null, COMBINED_RANDOM_MODEL));
            for (final class_2350 f : class_2350.values()) {
                face[f.ordinal()].addAll(m.method_4707(null, f, COMBINED_RANDOM_MODEL));
            }
        }

        isSideLit = Arrays.stream(args).anyMatch(class_1087::method_24304);
    }

    public Set<ChiselRenderType> getRenderTypes() {
        return renderTypes;
    }

    @Override
    public class_1058 method_4711() {
        for (final class_1087 a : merged) {
            return a.method_4711();
        }

        return ClientSide.instance.getMissingIcon();
    }

    @Override
    public List<class_777> method_4707(
            @Nullable class_2680 blockState, @Nullable class_2350 side, class_5819 randomSource) {
        if (side != null) {
            return face[side.ordinal()];
        }

        return generic;
    }

    @Override
    public boolean method_24304() {
        return isSideLit;
    }

    @Override
    public List<class_777> getQuads(
            @Nullable class_2680 state,
            @Nullable class_2350 side,
            @NotNull class_5819 rand,
            @NotNull IModelData extraData,
            @NotNull ChiselRenderType renderType) {
        if (side != null) {
            return face[side.ordinal()];
        }

        return generic;
    }

    @Override
    public void updateModelData(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {}

    @Override
    public Set<ChiselRenderType> getRenderTypes(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {
        return renderTypes == null ? Set.of() : renderTypes;
    }
}
