package mod.chiselsandbits.render.bit;

import java.util.HashMap;
import java.util.Set;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.client.model.baked.BaseSmartModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.events.TickHandler;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.render.ModelCombined;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import mod.chiselsandbits.render.chiseledblock.ChiseledBlockBakedModel;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import org.jetbrains.annotations.NotNull;

public class BitItemSmartModel extends BaseSmartModel implements ICacheClearable {
    private static final HashMap<Integer, class_1087> modelCache = new HashMap<Integer, class_1087>();
    private static final HashMap<Integer, class_1087> largeModelCache = new HashMap<Integer, class_1087>();

    private static final class_2371<class_1799> alternativeStacks = class_2371.method_10211();

    private class_1087 getCachedModel(int stateID, final boolean large) {
        if (stateID == 0) {
            // We are running an empty bit, for display purposes.
            // Lets loop:
            if (alternativeStacks.isEmpty()) {
                ModItems.ITEM_BLOCK_BIT.get().fillItemCategory(alternativeStacks);
            }

            final int alternativeIndex =
                    (int) ((Math.floor(TickHandler.getClientTicks() / 20d)) % alternativeStacks.size());

            stateID = ItemChiseledBit.getStackState(alternativeStacks.get(alternativeIndex));
        }

        final HashMap<Integer, class_1087> target = large ? largeModelCache : modelCache;
        class_1087 out = target.get(stateID);

        if (out == null) {
            if (large) {
                final VoxelBlob blob = new VoxelBlob();
                blob.fill(stateID);
                ChiselRenderType[] layers = ChiselRenderType.values();
                class_1087[] models = new class_1087[layers.length];
                for (int i = 0; i < layers.length; i++) {
                    ChiselRenderType layer = layers[i];
                    models[i] = new ChiseledBlockBakedModel(stateID, layer, blob, class_290.field_1590, true);
                }
                out = new ModelCombined(models);
            } else {
                out = new BitItemBaked(stateID);
            }

            target.put(stateID, out);
        }

        return out;
    }

    public class_1087 func_239290_a_(
            final class_1087 originalModel, final class_1799 stack, final class_1937 world, final class_1309 entity) {
        return getCachedModel(ItemChiseledBit.getStackState(stack), ClientSide.instance.holdingShift());
    }

    @Override
    public class_1087 resolve(class_1087 originalModel, class_1799 stack, class_1937 world, class_1309 entity) {
        return func_239290_a_(originalModel, stack, world, entity);
    }

    @Override
    public void clearCache() {
        modelCache.clear();
        largeModelCache.clear();
    }

    @Override
    public boolean method_24304() {
        return true;
    }

    @Override
    public void updateModelData(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {}

    @Override
    public Set<ChiselRenderType> getRenderTypes(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {
        return Set.of();
    }
}
