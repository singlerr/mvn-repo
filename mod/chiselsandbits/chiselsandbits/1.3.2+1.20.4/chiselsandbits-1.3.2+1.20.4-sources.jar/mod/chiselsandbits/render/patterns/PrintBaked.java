package mod.chiselsandbits.render.patterns;

import mod.chiselsandbits.client.model.baked.BaseBakedItemModel;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.interfaces.IPatternItem;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class PrintBaked extends BaseBakedItemModel {

    final String itemName;

    public PrintBaked(final String itname, final IPatternItem item, final class_1799 stack) {
        itemName = itname;

        final class_1799 blockItem = item.getPatternedItem(stack, false);
        class_1087 model =
                class_310.method_1551().method_1480().method_4012().method_3308(blockItem);

        model = model.method_4710().method_3495(model, blockItem, null, null, 0);

        for (final class_2350 face : class_2350.values()) {
            list.addAll(model.method_4707(null, face, RANDOM));
        }

        list.addAll(model.method_4707(null, null, RANDOM));
    }

    @Override
    public boolean method_24304() {
        return false;
    }

    @Override
    public class_1058 method_4711() {
        return class_310.method_1551()
                .method_1549(class_1723.field_21668)
                .apply(new class_2960(ChiselsAndBits.MODID, "item/" + itemName));
    }
}
