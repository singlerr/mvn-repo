package mod.chiselsandbits.render;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import mod.chiselsandbits.client.model.loader.FabricBakedModelDelegate;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.registry.ModItems;
import mod.chiselsandbits.render.bit.BitItemSmartModel;
import mod.chiselsandbits.render.chiseledblock.ChiseledBlockSmartModel;
import mod.chiselsandbits.render.patterns.PrintSmartModel;
import mod.chiselsandbits.utils.Constants;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public class SmartModelManager {

    private static final SmartModelManager INSTANCE = new SmartModelManager();
    private final HashMap<class_2960, class_1087> models = new HashMap<class_2960, class_1087>();
    private final List<class_1091> res = new ArrayList<class_1091>();
    private final List<ICacheClearable> clearable = new ArrayList<ICacheClearable>();
    private boolean setup = false;

    private SmartModelManager() {}

    public static SmartModelManager getInstance() {
        return INSTANCE;
    }

    private void setup() {
        if (setup) {
            return;
        }

        setup = true;
        FabricBakedModelDelegate smartModel = new FabricBakedModelDelegate(new ChiseledBlockSmartModel());
        add(Constants.DataGenerator.CHISELED_BLOCK_MODEL, smartModel);

        ChiselsAndBits.getInstance().addClearable(smartModel);

        add(new class_2960(ChiselsAndBits.MODID, "block_bit"), new BitItemSmartModel());
        add(
                new class_2960(ChiselsAndBits.MODID, "positiveprint_written_preview"),
                new PrintSmartModel("positiveprint", ModItems.ITEM_POSITIVE_PRINT_WRITTEN.get()));
        add(
                new class_2960(ChiselsAndBits.MODID, "negativeprint_written_preview"),
                new PrintSmartModel("negativeprint", ModItems.ITEM_NEGATIVE_PRINT_WRITTEN.get()));
        add(
                new class_2960(ChiselsAndBits.MODID, "mirrorprint_written_preview"),
                new PrintSmartModel("mirrorprint", ModItems.ITEM_MIRROR_PRINT_WRITTEN.get()));
    }

    private void add(final class_2960 modelLocation, final class_1087 modelGen) {
        final class_2960 second = new class_2960(
                modelLocation.method_12836(),
                modelLocation.method_12832().substring(1 + modelLocation.method_12832().lastIndexOf('/')));

        if (modelGen instanceof ICacheClearable) {
            clearable.add((ICacheClearable) modelGen);
        }

        res.add(new class_1091(modelLocation, "normal"));
        res.add(new class_1091(second, "normal"));

        res.add(new class_1091(modelLocation, "inventory"));
        res.add(new class_1091(second, "inventory"));

        res.add(new class_1091(modelLocation, "multipart"));
        res.add(new class_1091(second, "multipart"));

        models.put(modelLocation, modelGen);
        models.put(second, modelGen);
        models.put(new class_1091(modelLocation, "normal"), modelGen);
        models.put(new class_1091(second, "normal"), modelGen);

        models.put(new class_1091(modelLocation, "inventory"), modelGen);
        models.put(new class_1091(second, "inventory"), modelGen);

        models.put(new class_1091(modelLocation, "multipart"), modelGen);
        models.put(new class_1091(second, "multipart"), modelGen);
    }

    public void textureStitchEvent(final class_1059 stitch) {
        ChiselsAndBits.getInstance().clearCache();
    }

    public void onModelBakeEvent(ModelLoadingPlugin.Context context) {
        setup();
        for (final ICacheClearable c : clearable) {
            c.clearCache();
        }

        for (final class_1091 rl : res) {
            context.modifyModelAfterBake().register(new ModelModifier.AfterBake() {
                @Override
                public @Nullable class_1087 modifyModelAfterBake(@Nullable class_1087 model, Context context) {
                    if (context.id().equals(rl)) {
                        return getModel(rl);
                    }
                    return model;
                }
            });
        }
    }

    private class_1087 getModel(final class_2960 modelLocation) {
        try {
            return models.get(modelLocation);
        } catch (final Exception e) {
            throw new RuntimeException("The Model: " + modelLocation.toString() + " was not available was requested.");
        }
    }

    private static final class Setup {}
}
