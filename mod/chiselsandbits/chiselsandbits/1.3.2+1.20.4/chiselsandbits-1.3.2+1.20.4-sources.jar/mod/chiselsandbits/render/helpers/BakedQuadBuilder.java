package mod.chiselsandbits.render.helpers;

import mod.chiselsandbits.render.chiseledblock.IFaceBuilder;
import mod.chiselsandbits.utils.LightUtil;
import mod.chiselsandbits.utils.forge.IVertexConsumer;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_777;

public final class BakedQuadBuilder implements IVertexConsumer, IFaceBuilder {
    private static final int SIZE = class_290.field_1590.method_1357().size();
    private final boolean full = false;
    private float[][][] unpackedData = new float[4][SIZE][4];
    private int tint = -1;
    private class_2350 orientation;
    private class_1058 texture;
    private boolean applyDiffuseLighting = true;
    private int vertices = 0;
    private int elements = 0;
    private class_293 vertexFormat;

    public BakedQuadBuilder(class_1058 texture) {
        this.texture = texture;
    }

    public BakedQuadBuilder(class_293 vertexFormat) {
        this.vertexFormat = vertexFormat;
    }

    @Override
    public class_293 getVertexFormat() {
        return vertexFormat;
    }

    public void setVertexFormat(class_293 vertexFormat) {
        this.vertexFormat = vertexFormat;
    }

    @Override
    public void setQuadTint(int tint) {
        this.tint = tint;
    }

    @Override
    public void setQuadOrientation(class_2350 orientation) {
        this.orientation = orientation;
    }

    @Override
    public void setTexture(class_1058 texture) {
        this.texture = texture;
    }

    @Override
    public void setApplyDiffuseLighting(boolean diffuse) {
        this.applyDiffuseLighting = diffuse;
    }

    @Override
    public void put(int vertexIndex, int element, float... data) {
        //        for (int i = 0; i < 4; i++) {
        //            if (i < data.length) {
        //                unpackedData[vertexIndex][element][i] = data[i];
        //            } else {
        //                unpackedData[vertexIndex][element][i] = 0;
        //            }
        //        }
        //        elements++;
        //        if (elements == SIZE) {
        //            elements = 0;
        //        }
        //        if (vertexIndex == 4) {
        //            full = true;
        //        }
        put(element, data);
    }

    @Override
    public void setFace(class_2350 myFace, int tintIndex) {
        setQuadOrientation(myFace);
        setQuadTint(tintIndex);
    }

    @Override
    public void put(final int element, final float... data) {
        for (int i = 0; i < 4; i++) {
            if (i < data.length) {
                unpackedData[vertices][element][i] = data[i];
            } else {
                unpackedData[vertices][element][i] = 0;
            }
        }

        elements++;

        if (elements == getVertexFormat().method_1357().size()) {
            vertices++;
            elements = 0;
        }
    }

    @Override
    public void begin() {
        unpackedData = new float[4][getVertexFormat().method_1357().size()][4];
        tint = -1;
        orientation = null;
        texture = null;
        vertices = 0;
        elements = 0;
    }

    @Override
    public class_777 create(class_1058 sprite) {
        setTexture(sprite);
        return build();
    }

    @Override
    public class_293 getFormat() {
        return vertexFormat;
    }

    public class_777 build() {
        if (texture == null) {
            throw new IllegalStateException("texture not set");
        }

        int[] packed = new int[class_290.field_1590.method_1359() * 4];
        for (int v = 0; v < 4; v++) {
            for (int e = 0; e < SIZE; e++) {
                LightUtil.pack(unpackedData[v][e], packed, class_290.field_1590, v, e);
            }
        }

        return new class_777(packed, tint, orientation, texture, applyDiffuseLighting);
    }
}
