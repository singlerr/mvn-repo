package mod.chiselsandbits.render.chiseledblock;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2350;
import net.minecraft.class_777;

public class ChiseledModelBuilder {

    private final List<class_777> up = new ArrayList<>();
    private final List<class_777> down = new ArrayList<>();
    private final List<class_777> north = new ArrayList<>();
    private final List<class_777> south = new ArrayList<>();
    private final List<class_777> east = new ArrayList<>();
    private final List<class_777> west = new ArrayList<>();
    private final List<class_777> generic = new ArrayList<>();

    public List<class_777> getList(final class_2350 side) {
        if (side != null) {
            switch (side) {
                case field_11033:
                    return down;
                case field_11034:
                    return east;
                case field_11043:
                    return north;
                case field_11035:
                    return south;
                case field_11036:
                    return up;
                case field_11039:
                    return west;
                default:
            }
        }

        return generic;
    }

    public class_777[] getSide(final class_2350 side) {
        final List<class_777> out = getList(side);

        if (out.isEmpty()) {
            return null;
        }

        return out.toArray(new class_777[out.size()]);
    }
}
