package mod.chiselsandbits.render.patterns;

import java.util.Set;
import java.util.WeakHashMap;
import mod.chiselsandbits.client.model.baked.BaseSmartModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.interfaces.IPatternItem;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;

public class PrintSmartModel extends BaseSmartModel {

    final IPatternItem item;
    final String name;
    WeakHashMap<class_1799, PrintBaked> cache = new WeakHashMap<class_1799, PrintBaked>();

    public PrintSmartModel(final String name, final IPatternItem item) {
        this.name = name;
        this.item = item;
    }

    @Override
    public class_1087 resolve(class_1087 originalModel, class_1799 stack, class_1937 world, class_1309 entity) {
        if (ClientSide.instance.holdingShift()) {
            PrintBaked npb = cache.get(stack);

            if (npb == null) {
                cache.put(stack, npb = new PrintBaked(name, item, stack));
            }

            return npb;
        }

        return class_310.method_1551()
                .method_1480()
                .method_4012()
                .method_3303()
                .method_4742(new class_1091(
                        new class_2960("chiselsandbits", name + "_written"), "inventory"));
    }

    @Override
    public boolean method_24304() {
        return false;
    }

    @Override
    public void updateModelData(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {}

    @Override
    public Set<ChiselRenderType> getRenderTypes(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {
        return Set.of(ChiselRenderType.SOLID);
    }
}
