package mod.chiselsandbits.render.helpers;

import java.util.Arrays;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_293;
import net.minecraft.class_296;

public class ModelQuadReader extends BaseModelReader {

    int minX = 16;
    int minY = 16;
    int minZ = 16;
    int maxX = 0;
    int maxY = 0;
    int maxZ = 0;

    int u;
    int v;

    int[][] pos_uv = new int[4][5];
    class_1058 sprite;
    String texture;

    class_2350 face;
    class_2350 cull;
    float[] pos;
    float[] uv;
    int index = 0;

    public ModelQuadReader(
            final String textureName, final class_1058 texture, final class_2350 face, final class_2350 cull) {
        sprite = texture;
        this.texture = textureName;
        this.face = face;
        this.cull = cull;
    }

    @Override
    public void put(final int vertexIndex, final int element, final float... data) {
        final class_293 format = getVertexFormat();
        final class_296 ele = format.method_1357().get(element);

        if (ele.method_1382() == class_296.class_298.field_1636 && ele.method_1385() != 1) {
            uv = Arrays.copyOf(data, data.length);
        } else if (ele.method_1382() == class_296.class_298.field_1633) {
            pos = Arrays.copyOf(data, data.length);
        }

        if (element == format.method_1357().size() - 1) {
            pos_uv[index][0] = Math.round(pos[0] * 16);
            pos_uv[index][1] = Math.round(pos[1] * 16);
            pos_uv[index][2] = Math.round(pos[2] * 16);
            pos_uv[index][3] = Math.round((uv[0] - sprite.method_4594()) / (sprite.method_4577() - sprite.method_4594()) * 16);
            pos_uv[index][4] = Math.round((uv[1] - sprite.method_4593()) / (sprite.method_4575() - sprite.method_4593()) * 16);

            minX = Math.min(minX, pos_uv[index][0]);
            minY = Math.min(minY, pos_uv[index][1]);
            minZ = Math.min(minZ, pos_uv[index][2]);
            maxX = Math.max(maxX, pos_uv[index][0]);
            maxY = Math.max(maxY, pos_uv[index][1]);
            maxZ = Math.max(maxZ, pos_uv[index][2]);

            index++;
        }
    }

    public String toString(class_2350 faceQuad) {
        int U1 = 0, V1 = 16, U2 = 16, V2 = 0;

        for (int idx = 0; idx < 4; idx++) {
            if (matches(minX, minY, minZ, pos_uv[idx])) {
                U1 = pos_uv[idx][3];
                V2 = pos_uv[idx][4];
            } else if (matches(maxX, maxY, maxZ, pos_uv[idx])) {
                U2 = pos_uv[idx][3];
                V1 = pos_uv[idx][4];
            }
        }

        if (faceQuad.method_10161() > 1) {
            final int tempU = U1;
            U1 = U2;
            U2 = tempU;
        } else if (faceQuad == class_2350.field_11036) {
            final int tempV = V1;
            V1 = V2;
            V2 = tempV;
        }

        if (cull == null) {
            return "{ \"from\": [" + minX
                    + ","
                    + minY
                    + ","
                    + minZ
                    + "], \"to\": ["
                    + maxX
                    + ","
                    + maxY
                    + ","
                    + maxZ
                    + "], \"faces\": { \""
                    + face.method_15434()
                    + "\":  { \"uv\": ["
                    + U1
                    + ","
                    + V1
                    + ","
                    + U2
                    + ","
                    + V2
                    + "], \"texture\": \""
                    + texture
                    + "\" } } },\n";
        } else {
            return "{ \"from\": [" + minX
                    + ","
                    + minY
                    + ","
                    + minZ
                    + "], \"to\": ["
                    + maxX
                    + ","
                    + maxY
                    + ","
                    + maxZ
                    + "], \"faces\": { \""
                    + face.method_15434()
                    + "\":  { \"uv\": ["
                    + U1
                    + ","
                    + V1
                    + ","
                    + U2
                    + ","
                    + V2
                    + "], \"texture\": \""
                    + texture
                    + "\", \"cullface\": \""
                    + cull.method_15434()
                    + "\" } } },\n";
        }
    }

    private boolean matches(final int x, final int y, final int z, final int[] v) {
        return v[0] == x && v[1] == y && v[2] == z;
    }
}
