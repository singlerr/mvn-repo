package mod.chiselsandbits.render.helpers;

import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_777;

public class ModelQuadLayer {

    public float[] uvs;
    public class_1058 sprite;
    public int light;
    public int color;
    public int tint;

    public class_777 sourceQuad;

    public class_2350 face;

    public static class ModelQuadLayerBuilder {
        public final ModelQuadLayer cache = new ModelQuadLayer();
        public final ModelLightMapReader lv;
        public ModelUVReader uvr;

        public ModelQuadLayerBuilder(final class_1058 sprite, final int uCoord, final int vCoord) {
            cache.sprite = sprite;
            lv = new ModelLightMapReader();
            uvr = new ModelUVReader(sprite, uCoord, vCoord);
        }

        public void setSourceQuad(class_777 bakedQuad) {
            cache.sourceQuad = bakedQuad;
        }

        public void setFace(class_2350 face) {
            cache.face = face;
        }

        public void setTint(int tint) {
            this.cache.tint = tint;
        }

        public ModelQuadLayer build(final int stateId, final int color, final int lightValue) {
            cache.light = Math.max(lightValue, lv.lv);
            cache.uvs = uvr.quadUVs;

            cache.color = cache.tint != -1 ? color : 0xffffffff;

            if (0x00 <= cache.tint && cache.tint <= 0xff) {
                cache.color = 0xffffffff;
                cache.tint = (stateId << 8) | cache.tint;
            } else {
                cache.tint = -1;
            }

            return cache;
        }
    }
}
