package mod.chiselsandbits.render.chiseledblock;

import java.security.InvalidParameterException;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelType;
import mod.chiselsandbits.client.culling.ICullTest;
import mod.chiselsandbits.client.culling.MCCullTest;
import net.minecraft.class_1921;

public enum ChiselRenderType {
    SOLID(class_1921.method_23577(), VoxelType.SOLID),
    SOLID_FLUID(class_1921.method_23577(), VoxelType.FLUID),
    CUTOUT(class_1921.method_23581(), null),
    CUTOUT_MIPPED(class_1921.method_23579(), null),
    TRANSLUCENT(class_1921.method_23583(), null),
    TRANSLUCENT_FLUID(class_1921.method_23583(), VoxelType.FLUID),
    TRIPWIRE(class_1921.method_29997(), null);

    public final class_1921 layer;
    public final VoxelType type;

    ChiselRenderType(final class_1921 layer, final VoxelType type) {
        this.layer = layer;
        this.type = type;
    }

    public static ChiselRenderType fromLayer(class_1921 layerInfo, final boolean isFluid) {
        if (layerInfo == null) {
            layerInfo = class_1921.method_23577();
        }

        if (ChiselRenderType.CUTOUT.layer.equals(layerInfo)) {
            return CUTOUT;
        } else if (ChiselRenderType.CUTOUT_MIPPED.layer.equals(layerInfo)) {
            return CUTOUT_MIPPED;
        } else if (ChiselRenderType.SOLID.layer.equals(layerInfo)) {
            return isFluid ? SOLID_FLUID : SOLID;
        } else if (ChiselRenderType.TRANSLUCENT.layer.equals(layerInfo)) {
            return isFluid ? TRANSLUCENT_FLUID : TRANSLUCENT;
        } else if (ChiselRenderType.TRIPWIRE.layer.equals(layerInfo)) {
            return TRIPWIRE;
        }

        throw new InvalidParameterException();
    }

    public boolean simulateFilter(final VoxelBlob vb) {
        if (vb == null) {
            return false;
        }

        if (vb.simulateFilter(layer)) {
            if (type != null) {
                return vb.simulateFilterFluids(type == VoxelType.FLUID);
            }

            return true;
        }
        return false;
    }

    public boolean filter(final VoxelBlob vb) {
        if (vb == null) {
            return false;
        }

        if (vb.simulateFilter(layer)) {
            if (type != null) {
                return vb.simulateFilterFluids(type == VoxelType.FLUID);
            }

            return true;
        }
        return false;
    }

    public ICullTest getTest() {
        return new MCCullTest();
    }
}
