package mod.chiselsandbits.render.chiseledblock;

import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_293;
import net.minecraft.class_777;

public interface IFaceBuilder {

    void setFace(class_2350 myFace, int tintIndex);

    void put(int element, float... args);

    default void put(int vertexIndex, int element, float... args) {}

    void begin();

    class_777 create(class_1058 sprite);

    class_293 getFormat();
}
