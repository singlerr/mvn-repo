package mod.chiselsandbits.render.bit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import mod.chiselsandbits.client.model.baked.BaseBakedBlockModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import mod.chiselsandbits.render.helpers.ModelQuadLayer;
import mod.chiselsandbits.render.helpers.ModelUtil;
import net.minecraft.class_1058;
import net.minecraft.class_1086;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_783;
import net.minecraft.class_787;
import net.minecraft.class_789;
import net.minecraft.class_796;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class BitItemBaked extends BaseBakedBlockModel {
    public static final float PIXELS_PER_BLOCK = 16.0f;

    private static final float BIT_BEGIN = 6.0f;
    private static final float BIT_END = 10.0f;
    private static final class_5819 RANDOM = class_5819.method_43047();
    final ArrayList<class_777> generic = new ArrayList<class_777>(6);

    public BitItemBaked(final int BlockRef) {
        final class_796 faceBakery = new class_796();

        final Vector3f to = new Vector3f(BIT_BEGIN, BIT_BEGIN, BIT_BEGIN);
        final Vector3f from = new Vector3f(BIT_END, BIT_END, BIT_END);

        final class_789 bpr = null;
        final class_1086 mr = class_1086.field_5350;

        for (final class_2350 myFace : class_2350.values()) {
            for (final class_1921 layer : class_1921.method_22720()) {

                final ModelQuadLayer[] layers = ModelUtil.getCachedFace(BlockRef, RANDOM, myFace, layer);

                if (layers == null) {
                    continue;
                }

                for (final ModelQuadLayer clayer : layers) {
                    final class_787 uv = new class_787(getFaceUvs(myFace), 0);
                    final class_783 bpf = new class_783(myFace, 0, "", uv);

                    Vector3f toB, fromB;

                    switch (myFace) {
                        case field_11036:
                            toB = new Vector3f(to.x(), from.y(), to.z());
                            fromB = new Vector3f(from.x(), from.y(), from.z());
                            break;
                        case field_11034:
                            toB = new Vector3f(from.x(), to.y(), to.z());
                            fromB = new Vector3f(from.x(), from.y(), from.z());
                            break;
                        case field_11043:
                            toB = new Vector3f(to.x(), to.y(), to.z());
                            fromB = new Vector3f(from.x(), from.y(), to.z());
                            break;
                        case field_11035:
                            toB = new Vector3f(to.x(), to.y(), from.z());
                            fromB = new Vector3f(from.x(), from.y(), from.z());
                            break;
                        case field_11033:
                            toB = new Vector3f(to.x(), to.y(), to.z());
                            fromB = new Vector3f(from.x(), to.y(), from.z());
                            break;
                        case field_11039:
                            toB = new Vector3f(to.x(), to.y(), to.z());
                            fromB = new Vector3f(to.x(), from.y(), from.z());
                            break;
                        default:
                            throw new NullPointerException();
                    }
                    generic.add(faceBakery.method_3468(
                            toB,
                            fromB,
                            bpf,
                            clayer.sprite,
                            myFace,
                            mr,
                            bpr,
                            false,
                            new class_2960(ChiselsAndBits.MODID, "bit")));
                }
            }
        }

        generic.trimToSize();
    }

    private float[] getFaceUvs(final class_2350 face) {
        float[] afloat;

        final int from_x = 7;
        final int from_y = 7;
        final int from_z = 7;

        final int to_x = 8;
        final int to_y = 8;
        final int to_z = 8;

        switch (face) {
            case field_11033:
            case field_11036:
                afloat = new float[] {from_x, from_z, to_x, to_z};
                break;
            case field_11043:
            case field_11035:
                afloat = new float[] {from_x, PIXELS_PER_BLOCK - to_y, to_x, PIXELS_PER_BLOCK - from_y};
                break;
            case field_11039:
            case field_11034:
                afloat = new float[] {from_z, PIXELS_PER_BLOCK - to_y, to_z, PIXELS_PER_BLOCK - from_y};
                break;
            default:
                throw new NullPointerException();
        }

        return afloat;
    }

    @Override
    public List<class_777> method_4707(
            @Nullable class_2680 blockState, @Nullable class_2350 direction, class_5819 randomSource) {
        if (direction != null) {
            return Collections.emptyList();
        }

        return generic;
    }

    @Override
    public boolean method_24304() {
        return true;
    }

    @Override
    public class_1058 method_4711() {
        return ClientSide.instance.getMissingIcon();
    }

    @Override
    public List<class_777> getQuads(
            @Nullable class_2680 state,
            @Nullable class_2350 side,
            @NotNull class_5819 rand,
            @NotNull IModelData extraData,
            @NotNull ChiselRenderType renderType) {
        return method_4707(state, side, rand);
    }

    @Override
    public void updateModelData(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {}

    @Override
    public Set<ChiselRenderType> getRenderTypes(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {
        return Set.of();
    }
}
