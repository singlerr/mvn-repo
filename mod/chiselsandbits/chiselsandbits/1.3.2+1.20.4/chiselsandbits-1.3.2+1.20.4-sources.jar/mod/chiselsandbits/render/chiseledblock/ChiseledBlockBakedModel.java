package mod.chiselsandbits.render.chiseledblock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob.VisibleFace;
import mod.chiselsandbits.client.culling.ICullTest;
import mod.chiselsandbits.client.model.baked.BaseBakedBlockModel;
import mod.chiselsandbits.client.model.data.IModelData;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.render.helpers.BakedQuadBuilder;
import mod.chiselsandbits.render.helpers.ModelQuadLayer;
import mod.chiselsandbits.render.helpers.ModelUtil;
import net.minecraft.class_1058;
import net.minecraft.class_1086;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_296;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_783;
import net.minecraft.class_787;
import net.minecraft.class_789;
import net.minecraft.class_796;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class ChiseledBlockBakedModel extends BaseBakedBlockModel {
    public static final float PIXELS_PER_BLOCK = 16.0f;
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static final int[][] faceVertMap = new int[6][4];
    private static final float[][][] quadMapping = new float[6][4][6];

    private static final class_2350[] X_Faces = new class_2350[] {class_2350.field_11034, class_2350.field_11039};
    private static final class_2350[] Y_Faces = new class_2350[] {class_2350.field_11036, class_2350.field_11033};
    private static final class_2350[] Z_Faces = new class_2350[] {class_2350.field_11035, class_2350.field_11043};

    // Analyze FaceBakery / makeBakedQuad and prepare static data for face gen.
    static {
        final Vector3f to = new Vector3f(0, 0, 0);
        final Vector3f from = new Vector3f(16, 16, 16);

        for (final class_2350 myFace : class_2350.values()) {
            final class_796 faceBakery = new class_796();

            final class_789 bpr = null;
            final class_1086 mr = class_1086.field_5350;

            final float[] defUVs = new float[] {0, 0, 1, 1};
            final class_787 uv = new class_787(defUVs, 0);
            final class_783 bpf = new class_783(myFace, 0, "", uv);

            final class_1058 texture = class_310.method_1551()
                    .method_1549(class_1723.field_21668)
                    .apply(new class_2960("missingno"));
            final class_777 q = faceBakery.method_3468(
                    to,
                    from,
                    bpf,
                    texture,
                    myFace,
                    mr,
                    bpr,
                    true,
                    new class_2960(ChiselsAndBits.MODID, "chiseled_block"));

            final int[] vertData = q.method_3357();

            int a = 0;
            int b = 2;

            switch (myFace) {
                case field_11043:
                case field_11035:
                    a = 0;
                    b = 1;
                    break;
                case field_11034:
                case field_11039:
                    a = 1;
                    b = 2;
                    break;
                default:
            }

            final int p = vertData.length / 4;
            for (int vertNum = 0; vertNum < 4; vertNum++) {
                final float A = Float.intBitsToFloat(vertData[vertNum * p + a]); // Current material
                final float B = Float.intBitsToFloat(vertData[vertNum * p + b]); // Neighbor material

                for (int o = 0; o < 3; o++) {
                    final float v = Float.intBitsToFloat(vertData[vertNum * p + o]);
                    final float scaler = 1.0f / 16.0f; // pos start in the 0-16
                    quadMapping[myFace.ordinal()][vertNum][o * 2] = v * scaler;
                    quadMapping[myFace.ordinal()][vertNum][o * 2 + 1] = (1.0f - v) * scaler;
                }
                if (ModelUtil.isZero(A) && ModelUtil.isZero(B)) {
                    faceVertMap[myFace.method_10146()][vertNum] = 0;
                } else if (ModelUtil.isZero(A) && ModelUtil.isOne(B)) {
                    faceVertMap[myFace.method_10146()][vertNum] = 3;
                } else if (ModelUtil.isOne(A) && ModelUtil.isZero(B)) {
                    faceVertMap[myFace.method_10146()][vertNum] = 1;
                } else {
                    faceVertMap[myFace.method_10146()][vertNum] = 2;
                }
            }
        }
    }

    private ChiselRenderType myLayer;
    private class_1058 sprite;

    // keep memory requirements low by using arrays.
    private class_777[] up;
    private class_777[] down;
    private class_777[] north;
    private class_777[] south;
    private class_777[] east;
    private class_777[] west;
    private class_777[] generic;

    private ChiseledBlockBakedModel() {}

    public ChiseledBlockBakedModel(
            final int blockReference,
            final ChiselRenderType layer,
            final VoxelBlob data,
            final class_293 format,
            boolean isItem) {
        myLayer = layer;
        final class_2680 state = ModUtil.getStateById(blockReference);

        class_1087 originalModel = null;

        if (state != null) {
            originalModel = class_310.method_1551()
                    .method_1541()
                    .method_3351()
                    .method_3335(state);
        }

        if (originalModel != null && data != null) {
            if (layer.simulateFilter(data)) {
                final ChiseledModelBuilder builder = new ChiseledModelBuilder();
                generateFaces(builder, data, RANDOM);

                // convert from builder to final storage.
                up = builder.getSide(class_2350.field_11036);
                down = builder.getSide(class_2350.field_11033);
                east = builder.getSide(class_2350.field_11034);
                west = builder.getSide(class_2350.field_11039);
                north = builder.getSide(class_2350.field_11043);
                south = builder.getSide(class_2350.field_11035);
                generic = builder.getSide(null);
            }
        }
    }

    public ChiseledBlockBakedModel(
            final int blockReference, final ChiselRenderType layer, final VoxelBlob data, final class_293 format) {
        myLayer = layer;
        final class_2680 state = ModUtil.getStateById(blockReference);

        class_1087 originalModel = null;

        if (state != null) {
            originalModel = class_310.method_1551()
                    .method_1541()
                    .method_3351()
                    .method_3335(state);
        }

        if (originalModel != null && data != null) {
            if (layer.filter(data)) {
                final ChiseledModelBuilder builder = new ChiseledModelBuilder();
                generateFaces(builder, data, RANDOM);

                // convert from builder to final storage.
                up = builder.getSide(class_2350.field_11036);
                down = builder.getSide(class_2350.field_11033);
                east = builder.getSide(class_2350.field_11034);
                west = builder.getSide(class_2350.field_11039);
                north = builder.getSide(class_2350.field_11043);
                south = builder.getSide(class_2350.field_11035);
                generic = builder.getSide(null);
            }
        }
    }

    public static ChiseledBlockBakedModel breakingParticleModel(
            final ChiselRenderType layer, final Integer blockStateID, final class_5819 random) {
        return ModelUtil.getBreakingModel(layer, blockStateID, random);
    }

    private static void offsetVec(
            final int[] result, final int toX, final int toY, final int toZ, final class_2350 f, final int d) {

        int leftX = 0;
        final int leftY = 0;
        int leftZ = 0;

        final int upX = 0;
        int upY = 0;
        int upZ = 0;

        switch (f) {
            case field_11033:
                leftX = 1;
                upZ = 1;
                break;
            case field_11034:
                leftZ = 1;
                upY = 1;
                break;
            case field_11043:
                leftX = 1;
                upY = 1;
                break;
            case field_11035:
                leftX = 1;
                upY = 1;
                break;
            case field_11036:
                leftX = 1;
                upZ = 1;
                break;
            case field_11039:
                leftZ = 1;
                upY = 1;
                break;
            default:
                break;
        }

        result[0] = (toX + leftX * d + upX * d) / 2;
        result[1] = (toY + leftY * d + upY * d) / 2;
        result[2] = (toZ + leftZ * d + upZ * d) / 2;
    }

    public static ChiseledBlockBakedModel createFromTexture(class_1058 findTexture, ChiselRenderType layer) {
        ChiseledBlockBakedModel out = new ChiseledBlockBakedModel();
        out.sprite = findTexture;
        out.myLayer = layer;
        return out;
    }

    public List<class_777> getList(final class_2350 side) {
        if (side != null) {
            switch (side) {
                case field_11033:
                    return asList(down);
                case field_11034:
                    return asList(east);
                case field_11043:
                    return asList(north);
                case field_11035:
                    return asList(south);
                case field_11036:
                    return asList(up);
                case field_11039:
                    return asList(west);
                default:
            }
        }

        return asList(generic);
    }

    private List<class_777> asList(final class_777[] array) {
        if (array == null) {
            return Collections.emptyList();
        }

        return Arrays.asList(array);
    }

    public boolean isEmpty() {
        boolean trulyEmpty = getList(null).isEmpty();

        for (final class_2350 e : class_2350.values()) {
            trulyEmpty = trulyEmpty && getList(e).isEmpty();
        }

        return trulyEmpty;
    }

    IFaceBuilder getBuilder(class_293 format) {
        return new BakedQuadBuilder(format);
    }

    private void generateFaces(final ChiseledModelBuilder builder, final VoxelBlob blob, final class_5819 weight) {
        final ArrayList<ArrayList<FaceRegion>> rset = new ArrayList<>();
        final VisibleFace visFace = new VisibleFace();

        processXFaces(blob, visFace, rset);
        processYFaces(blob, visFace, rset);
        processZFaces(blob, visFace, rset);

        // re-usable float[]'s to minimize garbage cleanup.
        final int[] to = new int[3];
        final int[] from = new int[3];
        final float[] uvs = new float[8];
        final float[] pos = new float[3];

        // single reusable face builder.
        final IFaceBuilder darkBuilder = getBuilder(class_290.field_1590);
        final IFaceBuilder litBuilder = darkBuilder;

        for (final ArrayList<FaceRegion> src : rset) {
            mergeFaces(src);

            for (final FaceRegion region : src) {
                final class_2350 myFace = region.face;
                int stateId = region.blockStateID;
                // keep integers up until the last moment... ( note I tested
                // snapping the floats after this stage, it made no
                // difference. )
                offsetVec(to, region.getMaxX(), region.getMaxY(), region.getMaxZ(), myFace, 1);
                offsetVec(from, region.getMinX(), region.getMinY(), region.getMinZ(), myFace, -1);
                final ModelQuadLayer[] mpc = ModelUtil.getCachedFace(stateId, weight, myFace, myLayer.layer);
                final float maxLightmap = 32.0f / 0xffff;
                if (mpc != null) {
                    for (final ModelQuadLayer pc : mpc) {
                        final IFaceBuilder faceBuilder = pc.light > 0 ? litBuilder : darkBuilder;
                        class_293 builderFormat = faceBuilder.getFormat();

                        faceBuilder.begin();
                        faceBuilder.setFace(myFace, pc.tint);

                        getFaceUvs(uvs, myFace, from, to, pc.uvs);
                        // build it.
                        for (int vertNum = 0; vertNum < 4; vertNum++) {
                            for (int elementIndex = 0;
                                    elementIndex < builderFormat.method_1357().size();
                                    elementIndex++) {
                                final class_296 element =
                                        builderFormat.method_1357().get(elementIndex);
                                switch (element.method_1382()) {
                                    case field_1633:
                                        getVertexPos(pos, myFace, vertNum, to, from);
                                        faceBuilder.put(vertNum, elementIndex, pos[0], pos[1], pos[2]);
                                        break;
                                    case field_1632:
                                        int cb = pc.color;
                                        final float[] colorData = new float[4];
                                        colorData[0] = ((cb >> 16) & 0xFF) / 255.0F;
                                        colorData[1] = ((cb >> 8) & 0xFF) / 255.0F;
                                        colorData[2] = (cb & 0xFF) / 255.0F;
                                        colorData[3] = ((cb >> 24) & 0xFF) / 255.0F;
                                        faceBuilder.put(vertNum, elementIndex, colorData);
                                        break;

                                    case field_1635:
                                        // this fixes a bug with Forge AO?? and
                                        // solid blocks.. I have no idea why...
                                        faceBuilder.put(
                                                vertNum,
                                                elementIndex,
                                                myFace.method_10148(),
                                                myFace.method_10164(),
                                                myFace.method_10165());
                                        break;

                                    case field_1636:
                                        if (element.method_1385() == 2) {
                                            final float v = maxLightmap * Math.max(0, Math.min(15, pc.light));
                                            faceBuilder.put(vertNum, elementIndex, v, v);
                                        } else {
                                            int uIndex = faceVertMap[myFace.method_10146()][vertNum] * 2;
                                            int vIndex = faceVertMap[myFace.method_10146()][vertNum] * 2 + 1;
                                            float u = pc.sprite.method_4580(uvs[uIndex] / 16f);
                                            float v = pc.sprite.method_4570(uvs[vIndex] / 16f);
                                            faceBuilder.put(vertNum, elementIndex, u, v);
                                        }

                                        break;
                                    default:
                                        faceBuilder.put(vertNum, elementIndex);
                                        break;
                                }
                            }
                        }

                        if (region.isEdge) {
                            builder.getList(myFace).add(faceBuilder.create(pc.sprite));
                        } else {
                            builder.getList(null).add(faceBuilder.create(pc.sprite));
                        }
                    }
                }
            }
        }
    }

    private float NotZero(float byteToFloat) {
        if (byteToFloat < 0.00001f) {
            return 1;
        }

        return byteToFloat;
    }

    private float byteToFloat(final int i) {
        return (i & 0xff) / 255.0f;
    }

    private void mergeFaces(final ArrayList<FaceRegion> src) {
        boolean restart;

        do {
            restart = false;

            final int size = src.size();
            final int sizeMinusOne = size - 1;

            restart:
            for (int x = 0; x < sizeMinusOne; ++x) {
                final FaceRegion faceA = src.get(x);

                for (int y = x + 1; y < size; ++y) {
                    final FaceRegion faceB = src.get(y);

                    if (faceA.extend(faceB)) {
                        src.set(y, src.get(sizeMinusOne));
                        src.remove(sizeMinusOne);

                        restart = true;
                        break restart;
                    }
                }
            }
        } while (restart);
    }

    private void processXFaces(
            final VoxelBlob blob, final VisibleFace visFace, final ArrayList<ArrayList<FaceRegion>> rset) {
        ArrayList<FaceRegion> regions = null;
        final ICullTest test = myLayer.getTest();

        for (final class_2350 myFace : X_Faces) {
            for (int x = 0; x < blob.detail; x++) {
                if (regions == null) {
                    regions = new ArrayList<FaceRegion>(16);
                }

                for (int z = 0; z < blob.detail; z++) {
                    FaceRegion currentFace = null;

                    for (int y = 0; y < blob.detail; y++) {
                        final FaceRegion region = getRegion(blob, myFace, x, y, z, visFace, test);

                        if (region == null) {
                            currentFace = null;
                            continue;
                        }

                        if (currentFace != null) {
                            if (currentFace.extend(region)) {
                                continue;
                            }
                        }

                        currentFace = region;
                        regions.add(region);
                    }
                }

                if (!regions.isEmpty()) {
                    rset.add(regions);
                    regions = null;
                }
            }
        }
    }

    private void processYFaces(
            final VoxelBlob blob, final VisibleFace visFace, final ArrayList<ArrayList<FaceRegion>> rset) {
        ArrayList<FaceRegion> regions = null;
        final ICullTest test = myLayer.getTest();

        for (final class_2350 myFace : Y_Faces) {
            for (int y = 0; y < blob.detail; y++) {
                if (regions == null) {
                    regions = new ArrayList<FaceRegion>(16);
                }

                for (int z = 0; z < blob.detail; z++) {
                    FaceRegion currentFace = null;

                    for (int x = 0; x < blob.detail; x++) {
                        final FaceRegion region = getRegion(blob, myFace, x, y, z, visFace, test);

                        if (region == null) {
                            currentFace = null;
                            continue;
                        }

                        if (currentFace != null) {
                            if (currentFace.extend(region)) {
                                continue;
                            }
                        }

                        currentFace = region;
                        regions.add(region);
                    }
                }

                if (!regions.isEmpty()) {
                    rset.add(regions);
                    regions = null;
                }
            }
        }
    }

    private void processZFaces(
            final VoxelBlob blob, final VisibleFace visFace, final ArrayList<ArrayList<FaceRegion>> rset) {
        ArrayList<FaceRegion> regions = null;
        final ICullTest test = myLayer.getTest();

        for (final class_2350 myFace : Z_Faces) {
            for (int z = 0; z < blob.detail; z++) {
                if (regions == null) {
                    regions = new ArrayList<FaceRegion>(16);
                }

                for (int y = 0; y < blob.detail; y++) {
                    FaceRegion currentFace = null;

                    for (int x = 0; x < blob.detail; x++) {
                        final FaceRegion region = getRegion(blob, myFace, x, y, z, visFace, test);

                        if (region == null) {
                            currentFace = null;
                            continue;
                        }

                        if (currentFace != null) {
                            if (currentFace.extend(region)) {
                                continue;
                            }
                        }

                        currentFace = region;
                        regions.add(region);
                    }
                }

                if (!regions.isEmpty()) {
                    rset.add(regions);
                    regions = null;
                }
            }
        }
    }

    private FaceRegion getRegion(
            final VoxelBlob blob,
            final class_2350 myFace,
            final int x,
            final int y,
            final int z,
            final VisibleFace visFace,
            final ICullTest test) {
        blob.visibleFace(myFace, x, y, z, visFace, test);

        if (visFace.visibleFace) {
            final class_2382 off = myFace.method_10163();

            return new FaceRegion(
                    myFace,
                    x * 2 + 1 + off.method_10263(),
                    y * 2 + 1 + off.method_10264(),
                    z * 2 + 1 + off.method_10260(),
                    visFace.state,
                    visFace.isEdge);
        }

        return null;
    }

    // generate final pos from static data.
    private void getVertexPos(
            final float[] pos, final class_2350 side, final int vertNum, final int[] to, final int[] from) {
        final float[] interpos = quadMapping[side.ordinal()][vertNum];

        pos[0] = to[0] * interpos[0] + from[0] * interpos[1];
        pos[1] = to[1] * interpos[2] + from[1] * interpos[3];
        pos[2] = to[2] * interpos[4] + from[2] * interpos[5];
    }

    private void getFaceUvs(
            final float[] uvs, final class_2350 face, final int[] from, final int[] to, final float[] quadsUV) {
        float to_u = 0;
        float to_v = 0;
        float from_u = 0;
        float from_v = 0;

        switch (face) {
            case field_11036:
                to_u = to[0] / 16.0f;
                to_v = to[2] / 16.0f;
                from_u = from[0] / 16.0f;
                from_v = from[2] / 16.0f;
                break;
            case field_11033:
                to_u = to[0] / 16.0f;
                to_v = to[2] / 16.0f;
                from_u = from[0] / 16.0f;
                from_v = from[2] / 16.0f;
                break;
            case field_11035:
                to_u = to[0] / 16.0f;
                to_v = to[1] / 16.0f;
                from_u = from[0] / 16.0f;
                from_v = from[1] / 16.0f;
                break;
            case field_11043:
                to_u = to[0] / 16.0f;
                to_v = to[1] / 16.0f;
                from_u = from[0] / 16.0f;
                from_v = from[1] / 16.0f;
                break;
            case field_11034:
                to_u = to[1] / 16.0f;
                to_v = to[2] / 16.0f;
                from_u = from[1] / 16.0f;
                from_v = from[2] / 16.0f;
                break;
            case field_11039:
                to_u = to[1] / 16.0f;
                to_v = to[2] / 16.0f;
                from_u = from[1] / 16.0f;
                from_v = from[2] / 16.0f;
                break;
            default:
        }

        uvs[0] = 16.0f * u(quadsUV, to_u, to_v); // 0
        uvs[1] = 16.0f * v(quadsUV, to_u, to_v); // 1

        uvs[2] = 16.0f * u(quadsUV, from_u, to_v); // 2
        uvs[3] = 16.0f * v(quadsUV, from_u, to_v); // 3

        uvs[4] = 16.0f * u(quadsUV, from_u, from_v); // 2
        uvs[5] = 16.0f * v(quadsUV, from_u, from_v); // 3

        uvs[6] = 16.0f * u(quadsUV, to_u, from_v); // 0
        uvs[7] = 16.0f * v(quadsUV, to_u, from_v); // 1
    }

    // Interpolate u
    float u(final float[] src, final float inU, final float inV) {
        final float inv = 1.0f - inU;
        final float u1 = src[0] * inU + inv * src[2];
        final float u2 = src[4] * inU + inv * src[6];
        return u1 * inV + (1.0f - inV) * u2;
    }

    // Interpolate v
    float v(final float[] src, final float inU, final float inV) {
        final float inv = 1.0f - inU;
        final float v1 = src[1] * inU + inv * src[3];
        final float v2 = src[5] * inU + inv * src[7];
        return v1 * inV + (1.0f - inV) * v2;
    }

    @Override
    public List<class_777> method_4707(
            @Nullable class_2680 blockState, @Nullable class_2350 direction, class_5819 randomSource) {
        return getList(direction);
    }

    @Override
    public boolean method_24304() {
        return true;
    }

    @Override
    public class_1058 method_4711() {
        return ClientSide.instance.getMissingIcon();
    }

    public int faceCount() {
        int count = getList(null).size();

        for (final class_2350 f : class_2350.values()) {
            count += getList(f).size();
        }

        return count;
    }

    @Override
    public List<class_777> getQuads(
            @Nullable class_2680 state,
            @Nullable class_2350 side,
            @NotNull class_5819 rand,
            @NotNull IModelData extraData,
            @NotNull ChiselRenderType renderType) {
        return method_4707(state, side, rand);
    }

    @Override
    public void updateModelData(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {}

    @Override
    public Set<ChiselRenderType> getRenderTypes(
            @NotNull class_1920 world,
            @NotNull class_2338 pos,
            @NotNull class_2680 state,
            @NotNull IModelData modelData) {
        return Set.of(myLayer);
    }
}
