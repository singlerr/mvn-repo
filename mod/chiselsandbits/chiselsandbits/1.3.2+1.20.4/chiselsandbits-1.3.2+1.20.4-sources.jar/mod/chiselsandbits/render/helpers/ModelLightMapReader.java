package mod.chiselsandbits.render.helpers;

import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_296;

public class ModelLightMapReader extends BaseModelReader {
    final float maxLightmap = 32.0f / 0xffff;
    public int lv = 0;
    boolean hasLightMap = false;
    private class_293 format = class_290.field_1590;

    public ModelLightMapReader() {}

    public void setVertexFormat(class_293 format) {
        hasLightMap = false;

        int eCount = format.method_1362();
        for (int x = 0; x < eCount; x++) {
            class_296 e = format.method_1357().get(x);
            if (e.method_1382() == class_296.class_298.field_1636
                    && e.method_1385() == 1
                    && e.method_1386() == class_296.class_297.field_1625) {
                hasLightMap = true;
            }
        }

        this.format = format;
    }

    @Override
    public void put(final int vertexIndex, final int element, final float... data) {
        final class_296 e = getVertexFormat().method_1357().get(element);

        if (e.method_1382() == class_296.class_298.field_1636
                && e.method_1385() == 1
                && e.method_1386() == class_296.class_297.field_1625
                && data.length >= 2
                && hasLightMap) {
            final int lvFromData_sky = (int) (data[0] / maxLightmap) & 0xf;
            final int lvFromData_block = (int) (data[1] / maxLightmap) & 0xf;

            lv = Math.max(lvFromData_sky, lv);
            lv = Math.max(lvFromData_block, lv);
        }
    }
}
