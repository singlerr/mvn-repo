package mod.chiselsandbits.render.helpers;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import mod.chiselsandbits.chiseledblock.BlockBitInfo;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.helpers.DeprecationHelper;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.interfaces.ICacheClearable;
import mod.chiselsandbits.render.chiseledblock.ChiselRenderType;
import mod.chiselsandbits.render.chiseledblock.ChiseledBlockBakedModel;
import mod.chiselsandbits.render.helpers.ModelQuadLayer.ModelQuadLayerBuilder;
import mod.chiselsandbits.utils.FluidUtil;
import mod.chiselsandbits.utils.LightUtil;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;

@SuppressWarnings("unchecked")
public class ModelUtil implements ICacheClearable {
    private static final HashMap<Pair<class_1921, class_2350>, HashMap<Integer, String>> blockToTexture =
            new HashMap<>();
    private static final HashMap<Triple<Integer, class_1921, class_2350>, ModelQuadLayer[]> cache = new HashMap<>();
    private static final HashMap<Pair<class_1921, Integer>, ChiseledBlockBakedModel> breakCache = new HashMap<>();

    @SuppressWarnings("unused")
    private static final ModelUtil instance = new ModelUtil();

    public static class_5819 MODEL_RANDOM = class_5819.method_43047();

    private ModelUtil() {
        ChiselsAndBits.getInstance().addClearable(this);
    }

    public static ModelQuadLayer[] getCachedFace(
            final int stateID, final class_5819 weight, final class_2350 face, final class_1921 layer) {
        if (layer == null) {
            return null;
        }
        final Triple<Integer, class_1921, class_2350> cacheVal = Triple.of(stateID, layer, face);

        final ModelQuadLayer[] mpc = cache.get(cacheVal);
        if (mpc != null) {
            return mpc;
        }

        return getInnerCachedFace(cacheVal, stateID, weight, face, layer);
    }

    private static ModelQuadLayer[] getInnerCachedFace(
            final Triple<Integer, class_1921, class_2350> cacheVal,
            final int stateID,
            final class_5819 weight,
            final class_2350 face,
            final class_1921 layer) {
        final class_2680 state = ModUtil.getStateById(stateID);
        final class_1087 model = ModelUtil.solveModel(
                state,
                weight,
                class_310.method_1551().method_1541().method_3351().method_3335(state),
                layer);
        final int lv = ChiselsAndBits.getConfig().getClient().useGetLightValue.get()
                ? DeprecationHelper.getLightValue(state)
                : 0;

        final class_3611 fluid = BlockBitInfo.getFluidFromBlock(state.method_26204());
        if (fluid != null) {
            for (final class_2350 xf : class_2350.values()) {
                final ModelQuadLayer[] mp = new ModelQuadLayer[1];
                mp[0] = new ModelQuadLayer();
                mp[0].color = FluidUtil.getColor(fluid);
                mp[0].light = lv;
                final float V = 0.5f;
                final float Uf = 1.0f;
                final float U = 0.5f;
                final float Vf = 1.0f;

                if (xf.method_10166() == class_2351.field_11052) {
                    mp[0].sprite = class_310.method_1551()
                            .method_1549(class_1723.field_21668)
                            .apply(FluidUtil.getStillTexture(fluid).method_45851().method_45816());
                    mp[0].uvs = new float[] {Uf, Vf, 0, Vf, Uf, 0, 0, 0};
                } else if (xf.method_10166() == class_2351.field_11048) {
                    mp[0].sprite = class_310.method_1551()
                            .method_1549(class_1723.field_21668)
                            .apply(FluidUtil.getFlowingTexture(fluid).method_45851().method_45816());
                    mp[0].uvs = new float[] {U, 0, U, V, 0, 0, 0, V};
                } else {
                    mp[0].sprite = class_310.method_1551()
                            .method_1549(class_1723.field_21668)
                            .apply(FluidUtil.getFlowingTexture(fluid).method_45851().method_45816());
                    mp[0].uvs = new float[] {U, 0, 0, 0, U, V, 0, V};
                }

                mp[0].tint = 0;

                final Triple<Integer, class_1921, class_2350> k = Triple.of(stateID, layer, xf);
                cache.put(k, mp);
            }

            return cache.get(cacheVal);
        }

        final HashMap<class_2350, ArrayList<ModelQuadLayerBuilder>> tmp = new HashMap<>();
        final int color = BlockBitInfo.getColorFor(state, 0);
        for (final class_2350 f : class_2350.values()) {
            tmp.put(f, new ArrayList<>());
        }

        if (model != null) {
            for (final class_2350 f : class_2350.values()) {
                final List<class_777> quads = ModelUtil.getModelQuads(model, layer, state, f, MODEL_RANDOM);
                processFaces(tmp, quads, state);
            }

            processFaces(tmp, ModelUtil.getModelQuads(model, layer, state, null, MODEL_RANDOM), state);
        }

        for (final class_2350 f : class_2350.values()) {
            final Triple<Integer, class_1921, class_2350> k = Triple.of(stateID, layer, f);
            final ArrayList<ModelQuadLayerBuilder> x = tmp.get(f);
            final ModelQuadLayer[] mp = new ModelQuadLayer[x.size()];

            for (int z = 0; z < x.size(); z++) {
                mp[z] = x.get(z).build(stateID, color, lv);
            }

            cache.put(k, mp);
        }

        return cache.get(cacheVal);
    }

    private static List<class_777> getModelQuads(
            final class_1087 model,
            final class_1921 renderType,
            final class_2680 state,
            final class_2350 f,
            final class_5819 rand) {
        // we have to filter model by render layer manually because it is fabric...
        // 1. check that block is fluid type and handle it in the different manner
        // 2. or else handle it in the normal manner
        class_1921 blockRenderLayer = ModUtil.isFluid(state)
                ? class_4696.method_23680(state.method_26227())
                : class_4696.method_23679(state);
        // if layer does not match with current render type, then return empty to skip
        if (blockRenderLayer != renderType) {
            return Collections.emptyList();
        }
        try {
            // try to get block model...
            return model.method_4707(state, f, rand);
        } catch (final Throwable t) {

        }

        try {
            // try to get item model?
            return model.method_4707(null, f, rand);
        } catch (final Throwable t) {

        }

        final class_1799 is = ModUtil.getItemStackFromBlockState(state);
        if (!ModUtil.isEmpty(is)) {
            final class_1087 secondModel = getOverrides(model)
                    .method_3495(model, is, class_310.method_1551().field_1687, class_310.method_1551().field_1724, 0);

            if (secondModel != null) {
                try {
                    return secondModel.method_4707(null, f, rand);
                } catch (final Throwable t) {

                }
            }
        }

        // try to not crash...
        return Collections.emptyList();
    }

    private static class_806 getOverrides(final class_1087 model) {
        if (model != null) {
            final class_806 modelOverrides = model.method_4710();
            return modelOverrides == null ? class_806.field_4292 : modelOverrides;
        }
        return class_806.field_4292;
    }

    private static void processFaces(
            final HashMap<class_2350, ArrayList<ModelQuadLayerBuilder>> tmp,
            final List<class_777> quads,
            final class_2680 state) {

        for (final class_777 q : quads) {
            final class_2350 face = q.method_3358();

            if (face == null) {
                continue;
            }

            try {
                final class_1058 sprite = findQuadTexture(q, state);
                final ArrayList<ModelQuadLayerBuilder> l = tmp.get(face);

                ModelQuadLayerBuilder b = null;
                for (final ModelQuadLayerBuilder lx : l) {
                    if (lx.cache.sprite == sprite) {
                        b = lx;
                        break;
                    }
                }

                if (b == null) {
                    // top/bottom
                    int uCoord = 0;
                    int vCoord = 2;

                    switch (face) {
                        case field_11043:
                        case field_11035:
                            uCoord = 0;
                            vCoord = 1;
                            break;
                        case field_11034:
                        case field_11039:
                            uCoord = 1;
                            vCoord = 2;
                            break;
                        default:
                    }

                    b = new ModelQuadLayerBuilder(sprite, uCoord, vCoord);
                    b.setFace(face);
                    b.setSourceQuad(q);
                    b.setTint(q.method_3359());
                    l.add(b);
                    LightUtil.put(b.uvr, q);
                }
            } catch (final Exception ignored) {

            }
        }
    }

    public static class_1058 findQuadTexture(final class_777 q, final class_2680 state)
            throws IllegalArgumentException, NullPointerException {
        if (q.method_35788() == null) {
            return class_310.method_1551()
                    .method_1549(class_1723.field_21668)
                    .apply(class_1047.method_4539());
        }
        return q.method_35788();
    }

    public static class_1087 solveModel(
            final class_2680 state, final class_5819 weight, final class_1087 originalModel, final class_1921 layer) {
        boolean hasFaces;

        try {
            hasFaces = hasFaces(originalModel, layer, state, null, weight);

            for (final class_2350 f : class_2350.values()) {
                hasFaces = hasFaces || hasFaces(originalModel, layer, state, f, weight);
            }
        } catch (final Exception e) {
            // an exception was thrown.. use the item model and hope...
            hasFaces = false;
        }

        if (!hasFaces) {
            // if the model is empty then lets grab an item and try that...
            final class_1799 is = ModUtil.getItemStackFromBlockState(state);
            if (!ModUtil.isEmpty(is)) {
                final class_1087 itemModel = class_310.method_1551()
                        .method_1480()
                        .method_4019(is, class_310.method_1551().field_1687, class_310.method_1551().field_1724, 0);

                try {
                    hasFaces = hasFaces(originalModel, layer, state, null, weight);

                    for (final class_2350 f : class_2350.values()) {
                        hasFaces = hasFaces || hasFaces(originalModel, layer, state, f, weight);
                    }
                } catch (final Exception e) {
                    // an exception was thrown.. use the item model and hope...
                    hasFaces = false;
                }

                if (hasFaces) {
                    return itemModel;
                } else {
                    return new SimpleGeneratedModel(
                            findTexture(class_2248.method_9507(state), originalModel, class_2350.field_11036, layer, weight));
                }
            }
        }

        return originalModel;
    }

    private static boolean hasFaces(
            final class_1087 model,
            final class_1921 renderType,
            final class_2680 state,
            final class_2350 f,
            final class_5819 weight) {
        final List<class_777> l = getModelQuads(model, renderType, state, f, weight);
        if (l == null || l.isEmpty()) {
            return false;
        }

        class_1058 texture = null;

        try {
            texture = findTexture(null, l, f);
        } catch (final Exception ignored) {
        }

        final ModelVertexRange mvr = new ModelVertexRange();

        for (final class_777 q : l) {
            LightUtil.put(mvr, q);
        }

        return mvr.getLargestRange() > 0 && !isMissing(texture);
    }

    private static boolean isMissing(final class_1058 texture) {
        if (texture == null) {
            return true;
        }

        return texture.method_45851().method_45816().equals(class_1047.method_4539());
    }

    public static class_1058 findTexture(
            final int BlockRef,
            final class_1087 model,
            final class_2350 myFace,
            final class_1921 layer,
            final class_5819 random) {
        // didn't work? ok lets try scanning for the texture in the
        if (blockToTexture
                .getOrDefault(Pair.of(layer, myFace), Maps.newHashMap())
                .containsKey(BlockRef)) {
            final String textureName =
                    blockToTexture.get(Pair.of(layer, myFace)).get(BlockRef);
            return class_310.method_1551()
                    .method_1549(class_1723.field_21668)
                    .apply(new class_2960(textureName));
        }

        class_1058 texture = null;
        final class_2680 state = ModUtil.getStateById(BlockRef);

        if (model != null) {
            try {
                texture = findTexture(texture, getModelQuads(model, layer, state, myFace, random), myFace);

                if (texture == null) {
                    for (final class_2350 side : class_2350.values()) {
                        texture = findTexture(texture, getModelQuads(model, layer, state, side, random), side);
                    }

                    texture = findTexture(texture, getModelQuads(model, layer, state, null, random), null);
                }
            } catch (final Exception ignored) {
            }
        }

        // who knows if that worked.. now lets try to get a texture...
        if (isMissing(texture)) {
            try {
                if (model != null) {
                    texture = model.method_4711();
                }
            } catch (final Exception ignored) {
            }
        }

        if (isMissing(texture)) {
            try {
                texture = class_310.method_1551()
                        .method_1541()
                        .method_3351()
                        .method_3339(state);
            } catch (final Exception ignored) {
            }
        }

        if (texture == null) {
            texture = class_310.method_1551()
                    .method_1549(class_1723.field_21668)
                    .apply(new class_2960("missingno"));
        }

        blockToTexture.remove(Pair.of(layer, myFace), null);
        blockToTexture.putIfAbsent(Pair.of(layer, myFace), Maps.newHashMap());
        blockToTexture
                .get(Pair.of(layer, myFace))
                .put(BlockRef, texture.method_45852().toString());
        return texture;
    }

    private static class_1058 findTexture(
            class_1058 texture, final List<class_777> faceQuads, final class_2350 myFace)
            throws IllegalArgumentException, NullPointerException {
        for (final class_777 q : faceQuads) {
            if (q.method_3358() == myFace) {
                texture = findQuadTexture(q, null);
            }
        }

        return texture;
    }

    public static boolean isOne(final float v) {
        return Math.abs(v) < 0.01;
    }

    public static boolean isZero(final float v) {
        return Math.abs(v - 1.0f) < 0.01;
    }

    public static Integer getItemStackColor(final class_1799 target, final int tint) {
        // don't send air though to MC, some mods have registered their custom
        // color handlers for it and it can crash.

        //        if (ModUtil.isEmpty(target)) return -1;
        return class_310.method_1551().field_1760.method_1704(target, tint);
    }

    public static ChiseledBlockBakedModel getBreakingModel(
            ChiselRenderType layer, Integer blockStateID, class_5819 random) {
        Pair<class_1921, Integer> key = Pair.of(layer.layer, blockStateID);
        ChiseledBlockBakedModel out = breakCache.get(key);

        if (out == null) {

            final class_2680 state = ModUtil.getStateById(blockStateID);
            final class_1087 model = ModelUtil.solveModel(
                    state,
                    random,
                    class_310.method_1551()
                            .method_1541()
                            .method_3351()
                            .method_3335(ModUtil.getStateById(blockStateID)),
                    layer.layer);

            if (model != null) {
                out = ChiseledBlockBakedModel.createFromTexture(
                        ModelUtil.findTexture(blockStateID, model, class_2350.field_11036, layer.layer, random), layer);
            } else {
                out = ChiseledBlockBakedModel.createFromTexture(null, null);
            }

            breakCache.put(key, out);
        }

        return out;
    }

    @Override
    public void clearCache() {
        blockToTexture.clear();
        cache.clear();
        breakCache.clear();
    }
}
