package mod.chiselsandbits.render.helpers;

import java.util.concurrent.ConcurrentHashMap;
import mod.chiselsandbits.render.cache.FormatInfo;
import mod.chiselsandbits.render.chiseledblock.IFaceBuilder;
import mod.chiselsandbits.utils.LightUtil;
import mod.chiselsandbits.utils.forge.IVertexConsumer;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_777;

public class BitBakedQuad extends class_777 {
    public static final ConcurrentHashMap<class_293, FormatInfo> formatData =
            new ConcurrentHashMap<class_293, FormatInfo>();

    public BitBakedQuad(
            final float[][][] unpackedData,
            final int tint,
            final class_2350 orientation,
            final class_1058 sprite) {
        super(packData(unpackedData), tint, orientation, sprite, true);
    }

    private static int[] packData(class_293 format, float[][][] unpackedData) {
        FormatInfo fi = formatData.get(format);

        if (fi == null) {
            fi = new FormatInfo(format);
            formatData.put(format, fi);
        }

        return fi.pack(unpackedData);
    }

    //    @Override
    //    public void pipe(
    //            final IVertexConsumer consumer )
    //    {
    //        final int[] eMap = LightUtil.mapFormats( consumer.getVertexFormat(), DefaultVertexFormats.BLOCK );
    //
    //        consumer.setTexture( sprite );
    //        consumer.setQuadTint( getTintIndex() );
    //        consumer.setQuadOrientation( getFace() );
    //        consumer.setApplyDiffuseLighting( true );
    //
    //        for ( int v = 0; v < 4; v++ )
    //        {
    //            for ( int e = 0; e < consumer.getVertexFormat().getElements().size(); e++ )
    //            {
    //                if ( eMap[e] != consumer.getVertexFormat().getElements().size() )
    //                {
    //                    consumer.put( e, getRawPart( v, eMap[e] ) );
    //                }
    //                else
    //                {
    //                    consumer.put( e );
    //                }
    //            }
    //        }
    //    }

    private static int[] packData(float[][][] unpackedData) {
        int[] packed = new int[class_290.field_1590.method_1359() * 4];
        for (int v = 0; v < 4; v++) {
            for (int e = 0; e < class_290.field_1590.method_1357().size(); e++) {
                LightUtil.pack(unpackedData[v][e], packed, class_290.field_1590, v, e);
            }
        }

        return packed;
    }

    private float[] getRawPart(int v, int i) {

        return formatData.get(class_290.field_1590).unpack(field_4175, v, i);
    }

    private int[] buildProcessedVertexData() {
        int[] packed = new int[class_290.field_1590.method_1359() * 4];
        for (int v = 0; v < 4; v++) {
            for (int e = 0; e < class_290.field_1590.method_1357().size(); e++) {
                LightUtil.pack(getRawPart(v, e), packed, class_290.field_1590, v, e);
            }
        }

        return packed;
    }

    public static class Builder implements IVertexConsumer, IFaceBuilder {
        private final class_293 format;
        private float[][][] unpackedData;
        private int tint = -1;
        private class_2350 orientation;
        private int vertices = 0;
        private int elements = 0;

        public Builder(class_293 format) {
            this.format = format;
        }

        @Override
        public class_293 getVertexFormat() {
            return format;
        }

        @Override
        public void setQuadTint(final int tint) {
            this.tint = tint;
        }

        @Override
        public void setQuadOrientation(final class_2350 orientation) {
            this.orientation = orientation;
        }

        @Override
        public void put(int vertexIndex, int element, float... data) {
            put(element, data);
        }

        public void put(final int element, final float... data) {
            for (int i = 0; i < 4; i++) {
                if (i < data.length) {
                    unpackedData[vertices][element][i] = data[i];
                } else {
                    unpackedData[vertices][element][i] = 0;
                }
            }

            elements++;

            if (elements == getVertexFormat().method_1357().size()) {
                vertices++;
                elements = 0;
            }
        }

        @Override
        public void begin() {
            if (format != getVertexFormat()) {
                throw new RuntimeException("Bad format, can only be CNB.");
            }

            unpackedData = new float[4][getVertexFormat().method_1357().size()][4];
            tint = -1;
            orientation = null;

            vertices = 0;
            elements = 0;
        }

        @Override
        public class_777 create(final class_1058 sprite) {
            return new BitBakedQuad(unpackedData, tint, orientation, sprite);
        }

        @Override
        public void setFace(final class_2350 myFace, final int tintIndex) {
            setQuadOrientation(myFace);
            setQuadTint(tintIndex);
        }

        @Override
        public void setApplyDiffuseLighting(final boolean diffuse) {}

        @Override
        public void setTexture(final class_1058 texture) {}

        @Override
        public class_293 getFormat() {
            return format;
        }
    }
}
