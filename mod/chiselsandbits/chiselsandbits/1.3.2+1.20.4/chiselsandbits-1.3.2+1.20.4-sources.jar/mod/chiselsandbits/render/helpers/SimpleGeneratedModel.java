package mod.chiselsandbits.render.helpers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.utils.LightUtil;
import net.minecraft.class_1058;
import net.minecraft.class_1086;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_296;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_783;
import net.minecraft.class_787;
import net.minecraft.class_789;
import net.minecraft.class_796;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class SimpleGeneratedModel implements class_1087 {

    @SuppressWarnings("unchecked")
    final List<class_777>[] face = new List[6];

    final class_1058 texture;

    public SimpleGeneratedModel(final class_1058 texture) {
        // create lists...
        face[0] = new ArrayList<class_777>();
        face[1] = new ArrayList<class_777>();
        face[2] = new ArrayList<class_777>();
        face[3] = new ArrayList<class_777>();
        face[4] = new ArrayList<class_777>();
        face[5] = new ArrayList<class_777>();

        this.texture = texture;

        final float[] afloat = new float[] {0, 0, 16, 16};
        final class_787 uv = new class_787(afloat, 0);
        final class_796 faceBakery = new class_796();

        final Vector3f to = new Vector3f(0.0f, 0.0f, 0.0f);
        final Vector3f from = new Vector3f(16.0f, 16.0f, 16.0f);

        final class_789 bpr = null;
        final class_1086 mr = class_1086.field_5350;

        for (final class_2350 side : class_2350.values()) {
            final class_783 bpf = new class_783(side, 1, "", uv);

            Vector3f toB, fromB;

            switch (side) {
                case field_11036:
                    toB = new Vector3f(to.x(), from.y(), to.z());
                    fromB = new Vector3f(from.x(), from.y(), from.z());
                    break;
                case field_11034:
                    toB = new Vector3f(from.x(), to.y(), to.z());
                    fromB = new Vector3f(from.x(), from.y(), from.z());
                    break;
                case field_11043:
                    toB = new Vector3f(to.x(), to.y(), to.z());
                    fromB = new Vector3f(from.x(), from.y(), to.z());
                    break;
                case field_11035:
                    toB = new Vector3f(to.x(), to.y(), from.z());
                    fromB = new Vector3f(from.x(), from.y(), from.z());
                    break;
                case field_11033:
                    toB = new Vector3f(to.x(), to.y(), to.z());
                    fromB = new Vector3f(from.x(), to.y(), from.z());
                    break;
                case field_11039:
                    toB = new Vector3f(to.x(), to.y(), to.z());
                    fromB = new Vector3f(to.x(), from.y(), from.z());
                    break;
                default:
                    throw new NullPointerException();
            }

            final class_777 g = faceBakery.method_3468(
                    toB,
                    fromB,
                    bpf,
                    texture,
                    side,
                    mr,
                    bpr,
                    false,
                    new class_2960(ChiselsAndBits.MODID, "simple"));
            face[side.ordinal()].add(finishFace(g, side, class_290.field_1590));
        }
    }

    private class_777 finishFace(final class_777 g, final class_2350 myFace, final class_293 format) {
        final int[] vertData = g.method_3357();
        final int wrapAt = vertData.length / 4;

        final BakedQuadBuilder b = new BakedQuadBuilder(g.method_35788());
        b.setVertexFormat(format);
        b.setQuadOrientation(myFace);
        b.setQuadTint(1);

        for (int vertNum = 0; vertNum < 4; vertNum++) {
            for (int elementIndex = 0; elementIndex < format.method_1357().size(); elementIndex++) {
                final class_296 element = format.method_1357().get(elementIndex);
                switch (element.method_1382()) {
                    case field_1633:
                        b.put(
                                vertNum,
                                elementIndex,
                                Float.intBitsToFloat(vertData[wrapAt * vertNum]),
                                Float.intBitsToFloat(vertData[1 + wrapAt * vertNum]),
                                Float.intBitsToFloat(vertData[2 + wrapAt * vertNum]));
                        break;

                    case field_1632:
                        final float light = LightUtil.diffuseLight(myFace);
                        b.put(vertNum, elementIndex, light, light, light, 1f);
                        break;

                    case field_1635:
                        b.put(vertNum, elementIndex, myFace.method_10148(), myFace.method_10164(), myFace.method_10165());
                        break;

                    case field_1636:
                        if (element.method_1385() == 1) {
                            b.put(vertNum, elementIndex, 0, 0);
                        } else {
                            final float u = Float.intBitsToFloat(vertData[4 + wrapAt * vertNum]);
                            final float v = Float.intBitsToFloat(vertData[5 + wrapAt * vertNum]);
                            b.put(vertNum, elementIndex, u, v);
                        }

                        break;

                    default:
                        b.put(vertNum, elementIndex);
                        break;
                }
            }
        }

        return b.build();
    }

    public List<class_777>[] getFace() {
        return face;
    }

    @Override
    public List<class_777> method_4707(
            @Nullable class_2680 blockState, @Nullable class_2350 side, class_5819 randomSource) {
        if (side == null) {
            return Collections.emptyList();
        }

        return face[side.ordinal()];
    }

    @Override
    public boolean method_4708() {
        return true;
    }

    @Override
    public boolean method_4712() {
        return true;
    }

    @Override
    public boolean method_24304() {
        return false;
    }

    @Override
    public class_809 method_4709() {
        return class_809.field_4301;
    }

    @Override
    public class_1058 method_4711() {
        return texture;
    }

    @Override
    public boolean method_4713() {
        return false;
    }

    @Override
    public class_806 method_4710() {
        return class_806.field_4292;
    }
}
