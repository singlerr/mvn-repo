package mod.chiselsandbits.render.helpers;

import mod.chiselsandbits.utils.forge.IVertexConsumer;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_290;
import net.minecraft.class_293;

public abstract class BaseModelReader implements IVertexConsumer {

    @Override
    public class_293 getVertexFormat() {
        return class_290.field_1590;
    }

    @Override
    public void setQuadTint(final int tint) {}

    @Override
    public void setQuadOrientation(final class_2350 orientation) {}

    @Override
    public void setApplyDiffuseLighting(final boolean diffuse) {}

    @Override
    public void setTexture(final class_1058 texture) {}
}
