package mod.chiselsandbits.extensions;

import net.minecraft.class_2338;

/***
 * Store block pos or get block pos
 * @see mod.chiselsandbits.mixin.VoxelShapeMixin
 */
public interface VoxelShapeExtension {

    class_2338 getPos();

    void setPos(class_2338 pos);
}
