package mod.chiselsandbits.chiseledblock;

import com.communi.suggestu.saecularia.caudices.core.block.IBlockWithWorldlyProperties;
import javax.annotation.Nonnull;
import mod.chiselsandbits.api.BoxType;
import mod.chiselsandbits.api.IMultiStateBlock;
import mod.chiselsandbits.chiseledblock.data.BitLocation;
import mod.chiselsandbits.chiseledblock.data.VoxelBlob;
import mod.chiselsandbits.chiseledblock.data.VoxelBlobStateReference;
import mod.chiselsandbits.chiseledblock.data.VoxelShapeCache;
import mod.chiselsandbits.client.CreativeClipboardTab;
import mod.chiselsandbits.client.UndoTracker;
import mod.chiselsandbits.core.ChiselsAndBits;
import mod.chiselsandbits.core.ClientSide;
import mod.chiselsandbits.core.Log;
import mod.chiselsandbits.helpers.BitOperation;
import mod.chiselsandbits.helpers.ChiselToolType;
import mod.chiselsandbits.helpers.ExceptionNoTileEntity;
import mod.chiselsandbits.helpers.ModUtil;
import mod.chiselsandbits.items.ItemChiseledBit;
import mod.chiselsandbits.registry.ModBlocks;
import mod.chiselsandbits.utils.SingleBlockBlockReader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_239;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2960;
import net.minecraft.class_2968;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_8235;
import org.jetbrains.annotations.Nullable;

public class BlockChiseled extends class_2248 implements class_2343, IMultiStateBlock, IBlockWithWorldlyProperties {

    public static final class_2338 ZERO = class_2338.field_10980;
    public static final class_2746 FULL_BLOCK = class_2746.method_11825("full_block");
    private static final ThreadLocal<class_2680> actingAs = new ThreadLocal<>();
    static ExceptionNoTileEntity noTileEntity = new ExceptionNoTileEntity();
    public final String name;

    public BlockChiseled(final String name, final class_4970.class_2251 properties) {
        super(properties);
        this.name = name;
        this.method_9590(this.field_10647.method_11664().method_11657(FULL_BLOCK, false));
    }

    public static @Nonnull TileEntityBlockChiseled getTileEntity(final class_2586 te) throws ExceptionNoTileEntity {
        if (te == null) {
            throw noTileEntity;
        }

        try {
            return (TileEntityBlockChiseled) te;
        } catch (final ClassCastException e) {
            throw noTileEntity;
        }
    }

    public static @Nonnull TileEntityBlockChiseled getTileEntity(
            final @Nonnull class_1922 world, final @Nonnull class_2338 pos) throws ExceptionNoTileEntity {
        final class_2586 te = ModUtil.getTileEntitySafely(world, pos);
        return getTileEntity(te);
    }

    public static boolean isFullCube(final class_2680 state) {
        return state.method_11654(FULL_BLOCK);
    }

    public static boolean replaceWithChiseled(
            final class_1937 world, final class_2338 pos, final class_2680 originalState, final boolean triggerUpdate) {
        return replaceWithChiseled(world, pos, originalState, 0, triggerUpdate).success;
    }

    public static ReplaceWithChiseledValue replaceWithChiseled(
            final @Nonnull class_1937 world,
            final @Nonnull class_2338 pos,
            final class_2680 originalState,
            final int fragmentBlockStateID,
            final boolean triggerUpdate) {
        class_2680 actingState = originalState;
        class_2248 target = originalState.method_26204();
        final boolean isAir = world.method_22347(pos)
                || actingState.method_26166(
                        new class_2968(world, pos, class_2350.field_11033, class_1799.field_8037, class_2350.field_11036));
        ReplaceWithChiseledValue rv = new ReplaceWithChiseledValue();

        if (BlockBitInfo.canChisel(actingState) || isAir) {
            BlockChiseled blk = ModBlocks.getChiseledBlock();

            int BlockID = ModUtil.getStateId(actingState);

            if (isAir) {
                actingState = ModUtil.getStateById(fragmentBlockStateID);
                target = actingState.method_26204();
                BlockID = ModUtil.getStateId(actingState);
                blk = ModBlocks.getChiseledBlock();
                // its still air tho..
                actingState = class_2246.field_10124.method_9564();
            }

            if (BlockID == 0) {
                return rv;
            }

            if (blk != null && blk != target) {
                TileEntityBlockChiseled.setLightFromBlock(actingState);
                world.method_8652(pos, blk.method_9564(), triggerUpdate ? 3 : 0);
                TileEntityBlockChiseled.setLightFromBlock(null);
                final class_2586 te = world.method_8321(pos);

                TileEntityBlockChiseled tec;
                if (!(te instanceof TileEntityBlockChiseled)) {
                    tec = (TileEntityBlockChiseled) blk.method_10123(pos, blk.method_9564());
                    world.method_8438(tec);
                } else {
                    tec = (TileEntityBlockChiseled) te;
                }

                if (tec != null) {
                    tec.fillWith(actingState);
                    tec.setPrimaryBlockStateId(BlockID);
                    tec.setState(tec.getState(), tec.getBlobStateReference());
                }

                rv.success = true;
                rv.te = tec;

                return rv;
            }
        }

        return rv;
    }

    public static void setActingAs(final class_2680 state) {
        actingAs.set(state);
    }

    @Override
    public void method_9585(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState) {
        super.method_9585(levelAccessor, blockPos, blockState);
    }

    @Override
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2680 newState = super.method_9576(level, blockPos, blockState, player);
        try {
            final TileEntityBlockChiseled tebc = getTileEntity(level, blockPos);
            if (ChiselsAndBits.getConfig()
                    .getClient()
                    .addBrokenBlocksToCreativeClipboard
                    .get()) {

                CreativeClipboardTab.getInstance().addItem(tebc.getItemStack(player));
            }
            UndoTracker.getInstance()
                    .add(level, blockPos, tebc.getBlobStateReference(), new VoxelBlobStateReference(0, 0));
        } catch (final ExceptionNoTileEntity e) {
            Log.noTileError(e);
        }
        return newState;
    }

    @Override
    public boolean shouldCheckWeakPower(
            class_2680 blockState, class_8235 signalGetter, class_2338 blockPos, class_2350 direction) {
        return isFullCube(blockState);
    }

    @Override
    public boolean shouldDisplayFluidOverlay(
            class_2680 blockState, class_1920 blockAndTintGetter, class_2338 blockPos, class_3610 fluidState) {
        return false;
    }

    @Override
    public float[] getBeaconColorMultiplier(
            class_2680 blockState, class_4538 levelReader, class_2338 blockPos, class_2338 blockPos1) {
        return new float[0];
    }

    @Override
    public class_2498 getSoundType(
            class_2680 blockState, class_4538 levelReader, class_2338 blockPos, @Nullable class_1297 entity) {
        try {
            TileEntityBlockChiseled te = getTileEntity(levelReader, blockPos);
            int p = te.getPrimaryBlockStateId();

            class_2680 s = ModUtil.getStateById(p);
            return s.method_26231();
        } catch (ExceptionNoTileEntity e) {
            return class_2498.field_11544;
        }
    }

    @Override
    public float getExplosionResistance(
            class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_1927 explosion) {
        return 5;
    }

    @Override
    public float getFriction(
            class_2680 blockState, class_4538 levelReader, class_2338 blockPos, @Nullable class_1297 entity) {
        try {
            class_2680 internalState = getTileEntity(levelReader, blockPos).getBlockState(class_2246.field_10340);

            if (internalState != null) {
                return internalState.method_26204().method_9499();
            }
        } catch (ExceptionNoTileEntity e) {
            Log.noTileError(e);
        }

        return super.method_9499();
    }

    // TODO(This fix stained glass render?)
    @Environment(EnvType.CLIENT)
    @Override
    public float method_9575(final class_2680 state, final class_1922 worldIn, final class_2338 pos) {
        return isFullCube(state) ? 0.2F : 1F;
    }

    @Override
    public boolean method_9616(final class_2680 state, final class_1750 useContext) {
        try {
            class_2338 target = useContext.method_8037();
            if (!(useContext instanceof class_2968) && !useContext.method_7717()) {
                target = target.method_10093(useContext.method_8038());
            }

            return getTileEntity(useContext.method_8045(), target).getBlob().filled() == 0;
        } catch (final ExceptionNoTileEntity e) {
            return super.method_9616(state, useContext);
        }
    }

    @Override
    public int method_9505(final class_2680 state, final class_1922 worldIn, final class_2338 pos) {
        return isFullCube(state) ? 0 : 1;
    }

    @Override
    public void method_9556(
            final class_1937 worldIn,
            final class_1657 player,
            final class_2338 pos,
            final class_2680 state,
            final class_2586 te,
            final class_1799 stack) {
        //        try {
        //            popResource(worldIn, pos, getTileEntity(te).getItemStack(player));
        //        } catch (final ExceptionNoTileEntity e) {
        //            Log.noTileError(e);
        //            super.playerDestroy(worldIn, player, pos, state, null, stack);
        //        }
    }

    @Override
    public void method_9567(
            final class_1937 worldIn,
            final class_2338 pos,
            final class_2680 state,
            @Nullable final class_1309 placer,
            final class_1799 stack) {
        try {
            if (stack == null || placer == null || !stack.method_7985()) {
                return;
            }

            final TileEntityBlockChiseled bc = getTileEntity(worldIn, pos);
            if (worldIn.field_9236) {
                bc.getState();
            }
            int rotations = ModUtil.getRotations(placer, ModUtil.getSide(stack));

            VoxelBlob blob = bc.getBlob();
            while (rotations-- > 0) {
                blob = blob.spin(class_2351.field_11052);
            }
            bc.setBlob(blob);
        } catch (final ExceptionNoTileEntity e) {
            Log.noTileError(e);
        }
    }

    @Override
    public class_1799 getCloneItemStack(
            class_2680 blockState, class_239 target, class_4538 levelReader, class_2338 blockPos, class_1657 player) {
        if (!(target instanceof class_3965)) {
            return class_1799.field_8037;
        }

        try {
            return getPickBlock((class_3965) target, blockPos, getTileEntity(levelReader, blockPos));
        } catch (final ExceptionNoTileEntity e) {
            Log.noTileError(e);
            return ModUtil.getEmptyStack();
        }
    }

    /**
     * Client side method.
     */
    private ChiselToolType getClientHeldTool() {
        return ClientSide.instance.getHeldToolType(class_1268.field_5808);
    }

    public class_1799 getPickBlock(final class_3965 target, final class_2338 pos, final TileEntityBlockChiseled te) {
        if (te.method_10997().method_8608()) {
            if (getClientHeldTool() != null) {
                final VoxelBlob vb = te.getBlob();

                final BitLocation bitLoc = new BitLocation(target, BitOperation.CHISEL);

                final int itemBlock = vb.get(bitLoc.bitX, bitLoc.bitY, bitLoc.bitZ);
                if (itemBlock == 0) {
                    return ModUtil.getEmptyStack();
                }

                return ItemChiseledBit.createStack(itemBlock, 1, false);
            }

            return te.getItemStack(ClientSide.instance.getPlayer());
        }

        return te.getItemStack(null);
    }

    @Override
    protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FULL_BLOCK);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new TileEntityBlockChiseled(blockPos, blockState);
    }

    @Override
    public class_265 method_9530(
            final class_2680 state, final class_1922 reader, final class_2338 pos, final class_3726 context) {
        try {
            final VoxelBlob blob = getTileEntity(reader, pos).getBlob();
            if (blob == null) {
                return super.method_9530(state, reader, pos, context);
            }
            return VoxelShapeCache.getInstance().get(blob, BoxType.COLLISION);
        } catch (ExceptionNoTileEntity exceptionNoTileEntity) {
            return super.method_9530(state, reader, pos, context);
        }
    }

    @Deprecated
    public class_265 method_9549(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
        try {
            final VoxelBlob blob = getTileEntity(worldIn, pos).getBlob();
            if (blob == null) {
                return super.method_9530(state, worldIn, pos, context);
            }
            return VoxelShapeCache.getInstance().get(blob, BoxType.COLLISION);
        } catch (ExceptionNoTileEntity exceptionNoTileEntity) {
            return super.method_9530(state, worldIn, pos, context);
        }
    }
    //
    //  @Deprecated
    //  public VoxelShape getVisualShape(BlockState state, BlockGetter reader, BlockPos pos,
    //                                   CollisionContext context) {
    //    try {
    //      final VoxelBlob blob = getTileEntity(reader, pos).getBlob();
    //      if (blob == null) {
    //        return Shapes.empty();
    //      }
    //
    //      return VoxelShapeCache.getInstance().get(blob, BoxType.OCCLUSION);
    //    } catch (ExceptionNoTileEntity exceptionNoTileEntity) {
    //      return Shapes.empty();
    //    }
    //  }

    public boolean method_9579(class_2680 state, class_1922 reader, class_2338 pos) {
        return true;
    }

    @Override
    public class_2680 rotate(
            final class_2680 state, final class_1936 world, final class_2338 pos, final class_2470 direction) {
        try {
            getTileEntity(world, pos).rotate(direction);
            return state;
        } catch (final ExceptionNoTileEntity e) {
            Log.noTileError(e);
            return state;
        }
    }

    public class_2680 getCommonState(final TileEntityBlockChiseled te) {
        final VoxelBlobStateReference data = te.getBlobStateReference();

        if (data != null) {
            final VoxelBlob vb = data.getVoxelBlob();
            if (vb != null) {
                return ModUtil.getStateById(vb.getVoxelStats().mostCommonState);
            }
        }

        return null;
    }

    @Override
    public int getLightEmission(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos) {
        // is this the right block?
        final class_2680 realState = blockGetter.method_8320(blockPos);
        final class_2248 realBlock = realState.method_26204();
        if (realBlock != this) {
            return 0;
        }

        // enabled?
        if (ChiselsAndBits.getConfig().getServer().enableBitLightSource.get()) {
            try {
                return getTileEntity(blockGetter, blockPos).getLightValue();
            } catch (final ExceptionNoTileEntity e) {
                Log.noTileError(e);
            }
        }

        return 0;
    }

    @Override
    public boolean canHarvestBlock(
            final class_2680 state, final class_1922 world, final class_2338 pos, final class_1657 player) {
        if (ChiselsAndBits.getConfig().getServer().enableToolHarvestLevels.get()) {
            class_2680 activeState = actingAs.get();

            if (activeState == null) {
                activeState = getPrimaryState(world, pos);
            }

            return canHarvestBlockInternal(new SingleBlockBlockReader(activeState), pos, player);
        }

        return false;
    }

    private boolean canHarvestBlockInternal(class_1922 world, class_2338 pos, class_1657 player) {
        class_2680 blockState = world.method_8320(pos);
        class_2248 var6 = blockState.method_26204();
        if (var6 instanceof IBlockWithWorldlyProperties blockWithWorldlyProperties) {
            return blockWithWorldlyProperties.canHarvestBlock(blockState, world, pos, player);
        } else {
            return player.method_7305(blockState);
        }
    }

    @Override
    public float method_9594(
            final class_2680 state, final class_1657 player, final class_1922 worldIn, final class_2338 pos) {
        if (ChiselsAndBits.getConfig().getServer().enableToolHarvestLevels.get()) {
            class_2680 actingState = actingAs.get();

            if (actingState == null) {
                actingState = getPrimaryState(worldIn, pos);
            }

            final float hardness = state.method_26214(worldIn, pos);
            if (hardness < 0.0F) {
                return 0.0F;
            }

            // since we can't call getDigSpeed on the acting state, we can just
            // do some math to try and roughly estimate it.
            float denom = player.field_7514.method_7370(actingState);
            float numer = player.field_7514.method_7370(state);

            if (!canHarvestBlockInternal(new SingleBlockBlockReader(state), ZERO, player)) {
                return player.method_7351(actingState) / hardness / 100F * (numer / denom);
            } else {
                return player.method_7351(actingState) / hardness / 30F * (numer / denom);
            }
        }

        return super.method_9594(state, player, worldIn, pos);
    }

    public class_2960 getModel() {
        return new class_2960(ChiselsAndBits.MODID, name);
    }

    @Override
    public class_2680 getPrimaryState(final class_1922 world, final class_2338 pos) {
        try {
            return getTileEntity(world, pos).getBlockState(class_2246.field_10340);
        } catch (final ExceptionNoTileEntity e) {
            Log.noTileError(e);
            return class_2246.field_10340.method_9564();
        }
    }

    @Override
    protected void method_33614(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState) {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            if (!blockState.method_26215()) {
                class_2498 soundType = blockState.method_26231();
                level.method_45446(
                        blockPos,
                        soundType.method_10595(),
                        class_3419.field_15245,
                        (soundType.method_10597() + 1.0F) / 2.0F,
                        soundType.method_10599() * 0.8F,
                        false);
            }
        }
    }

    public boolean basicHarvestBlockTest(class_1937 world, class_2338 pos, class_1657 player) {
        return canHarvestBlock(world.method_8320(pos), world, pos, player);
    }

    public static class ReplaceWithChiseledValue {
        public boolean success = false;
        public TileEntityBlockChiseled te = null;
    }
}
