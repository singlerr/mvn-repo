package net.indiespot.media.impl;

import craterstudio.math.EasyMath;
import net.indiespot.media.RenderListener;
import net.indiespot.media.VideoRenderer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;

import java.awt.*;
import java.io.IOException;
import java.nio.ByteBuffer;

import static org.lwjgl.opengl.GL11.*;


public class OpenGLVideoRenderer implements VideoRenderer {
	private final String windowTitle;

	public OpenGLVideoRenderer(String windowTitle) {
		this.windowTitle = windowTitle;
	}

	private Object syncObject;
	private int w, h;
	private int dw, dh;

	public void setSyncObject(Object syncObject) {
		this.syncObject = syncObject;
	}

	private int frameBuffer;

	public void setFrameBuffer(int frameBuffer) {
		this.frameBuffer = frameBuffer;
	}


	private RenderListener preListener;
	private RenderListener postListener;

	public void setPostListener(RenderListener postListener) {
		this.postListener = postListener;
	}

	public void setPreListener(RenderListener preListener) {
		this.preListener = preListener;
	}

	@Override
	public void init(Dimension dim) {
		this.w = dim.width;
		this.h = dim.height;

		/*
		try {
			Display.setDisplayMode(new DisplayMode(dim.width, dim.height));
			Display.setResizable(true);
			Display.setTitle(windowTitle);
			Display.create();
		} catch (LWJGLException exc) {
			throw new IllegalStateException(exc);
		}
		*/
	}

	@Override
	public boolean isVisible() {
		return !Display.isCloseRequested();
	}

	@Override
	public void setStats(String stats) {
		//Display.setTitle(windowTitle + " - OpenGL - " + stats);
	}

	float wRatio, hRatio;
	private int[] textures = null;
	private int textureIndex = 0;

	@Override
	public void render(ByteBuffer rgba) {
		if (rgba.remaining() != w * h * 4) {
			throw new IllegalStateException();
		}
		if (textures == null  || Display.wasResized()) {

			dw = Display.getWidth();
			dh = Display.getHeight();
			glMatrixMode(GL_PROJECTION);
			glEnable(GL_DEPTH_TEST);
			glLoadIdentity();
			{
				// coordinate system a la Java2D
				glScalef(2.0f, -2.0f, 1.0f);
				glTranslatef(-0.5f, -0.5f, 0);
				glScalef(1.0f / dw, 1.0f / dh, 1.0f);
			}
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
			glViewport(0, 0, dw, dh);
		}
		glClearColor(0, 0, 0, 1);

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //

		glEnable(GL_TEXTURE_2D);
		if(preListener != null)
			preListener.onRender();
		if (textures == null) {
			textures = new int[2];

			glDisable(GL_DEPTH_TEST);
			for (int i = 0; i < textures.length; i++) {
				textures[i] = glGenTextures();
				glBindTexture(GL_TEXTURE_2D, textures[i]);
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

				int wPot = EasyMath.fitInPowerOfTwo(w);
				int hPot = EasyMath.fitInPowerOfTwo(h);
				wRatio = (float) w / wPot;
				hRatio = (float) h / hPot;

				// 'tmpbuf' should be null, but some drivers are too buggy
				ByteBuffer tmpbuf = BufferUtils.createByteBuffer(wPot * hPot * 4);
				glTexImage2D(GL_TEXTURE_2D, 0/* level */, GL_RGBA, wPot, hPot, 0/* border */, GL_RGBA, GL_UNSIGNED_BYTE, tmpbuf);
			}
		}

		{
			glBindTexture(GL_TEXTURE_2D, textures[textureIndex]);
			glTexSubImage2D(GL_TEXTURE_2D, 0/* level */, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
		}

		textureIndex += 1;
		textureIndex %= textures.length;
		glBindTexture(GL_TEXTURE_2D, textures[textureIndex]);
		glColor3f(1, 1, 1);
		glClear(GL_COLOR_BUFFER_BIT);
		glBegin(GL_QUADS);
		{
			int wQuad = dw;
			int hQuad = Math.round(wQuad * ((float) h / w));

			if (hQuad > dh) {
				hQuad = dh;
				wQuad = Math.round(hQuad * ((float) w / h));
			}

			if (wQuad > dw) {
				wQuad = dw;
				hQuad = Math.round(wQuad * ((float) h / w));
			}

			int xQuad = (dw - wQuad) / 2;
			int yQuad = (dh - hQuad) / 2;
			this.renderQuad(xQuad, yQuad, wQuad, hQuad);
		}

		glEnd();
		//Display.update();
		if(postListener != null)
			postListener.onRender();
	}

	private void renderQuad(int x, int y, int w, int h) {
		glTexCoord2f(0 * wRatio, 0 * hRatio);
		glVertex2f(x + 0, y + 0);

		glTexCoord2f(1 * wRatio, 0 * hRatio);
		glVertex2f(x + w, y + 0);

		glTexCoord2f(1 * wRatio, 1 * hRatio);
		glVertex2f(x + w, y + h);

		glTexCoord2f(0 * wRatio, 1 * hRatio);
		glVertex2f(x + 0, y + h);
	}

	@Override
	public void close() throws IOException {

		for (int texture : textures) {
			glDeleteTextures(texture);
		}

		//Display.destroy();
	}
}
