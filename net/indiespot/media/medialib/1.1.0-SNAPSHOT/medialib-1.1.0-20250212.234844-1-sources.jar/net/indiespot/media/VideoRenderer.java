package net.indiespot.media;

import java.awt.Dimension;
import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;

public interface VideoRenderer extends Closeable {

	public void init(Dimension dim);

	public boolean isVisible();

	public void setStats(String stats);

	public void render(ByteBuffer rgba);

	public void close() throws IOException;
}