package net.indiespot.media.impl;

import static org.lwjgl.openal.AL10.*;

import java.io.IOException;
import java.nio.ByteBuffer;

import org.lwjgl.LWJGLException;
import org.lwjgl.openal.AL;

import net.indiespot.media.AudioRenderer;

import craterstudio.io.Streams;

public class OpenALAudioRenderer extends AudioRenderer {
	int alSource;

	public OpenALAudioRenderer() throws IOException {

		/*
		try {
			AL.create();
		} catch (LWJGLException exc) {
			exc.printStackTrace();
		}
		*/
		this.alSource = alGenSources();
		if (this.alSource == 0) {
			throw new IllegalStateException();
		}
	}

	private int lastBuffersProcessed = 0;
	private boolean isBuffering = true;
	private boolean eof = false;

	public boolean tick() {
		if (alSource == 0) {
			return false;
		}

		if (isBuffering) {
			isBuffering = false;

			System.out.println("Audio buffering...");

			// buffer 1sec of audio
			for (int i = 0; i < frameRate; i++) {
				this.enqueueNextSamples();
			}

			alSourcePlay(alSource);
		}

		int currentBuffersProcessed = alGetSourcei(alSource, AL_BUFFERS_PROCESSED);
		int toDiscard = currentBuffersProcessed - lastBuffersProcessed;
		lastBuffersProcessed = currentBuffersProcessed;

		if (toDiscard == 0) {
			return true;
		}
		if (toDiscard < 0) {
			throw new IllegalStateException();
		}

		for (int i = 0; i < toDiscard; i++) {
			int buffer = alSourceUnqueueBuffers(alSource);
			alDeleteBuffers(buffer);

			this.lastBuffersProcessed--;
			this.incAudioFrameIndex();

			this.enqueueNextSamples();
		}

		int state = alGetSourcei(alSource, AL_SOURCE_STATE);
		switch (state) {
			case AL_PLAYING:
				// ok
				break;

			case AL_STOPPED:

				if (this.lastBuffersProcessed != 0) {
					throw new IllegalStateException("should never happen");
				}
				if (this.eof) {
					Streams.safeClose(this);
					return false;
				}
				this.isBuffering = true;

				break;

			default:
				throw new IllegalStateException("unexpected state: " + state);
		}

		return true;
	}

	private void enqueueNextSamples() {

		if (this.eof) {
			return;
		}

		ByteBuffer samples = super.loadNextSamples();
		if (samples == null) {
			this.eof = true;
			return;
		}

		int buffer = alGenBuffers();
		alBufferData(buffer, AL_FORMAT_STEREO16, samples, audioStream.sampleRate);
		alSourceQueueBuffers(alSource, buffer);
	}

	public void close() throws IOException {
		if (this.alSource != 0) {
			alSourceStop(this.alSource);
			alDeleteSources(this.alSource);
			this.alSource = 0;
		}

		super.close();
	}
}