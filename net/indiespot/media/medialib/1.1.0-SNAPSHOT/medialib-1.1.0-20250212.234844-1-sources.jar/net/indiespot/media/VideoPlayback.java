package net.indiespot.media;

import craterstudio.io.Streams;
import craterstudio.util.HighLevel;
import net.indiespot.media.impl.OpenGLVideoRenderer;
import org.lwjgl.opengl.Display;

import java.awt.*;
import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;

public abstract class VideoPlayback implements Closeable {
	public final VideoStream videoStream;
	public final AudioStream audioStream;
	public final float frameRate;

	private ByteBuffer rgba;
	private RenderListener endListener;
	private long secondStarted;
	private int videoFramerate = 0;
	public VideoPlayback(float frameRate, VideoStream videoStream, AudioStream audioStream) {
		this.frameRate = frameRate;
		this.videoStream = videoStream;
		this.audioStream = audioStream;
	}
	private OpenGLVideoRenderer videoRenderer;

	public void setEndListener(RenderListener endListener) {
		this.endListener = endListener;
	}

	private void startDisplayLoop() {
		runDisplayLoop();
		/*
		new Thread(new Runnable() {
			@Override
			public void run() {
				runDisplayLoop();
			}
		}, "VideoPlayer-DisplayLoop").start();

		 */
	}

	public int getAudioFrameIndex() {
		if (this.audioRenderer == null) {
			return -1;
		}

		if (!this.audioRenderer.tick()) {
			return -2;
		}
		return this.audioRenderer.getAudioFrameIndex();
	}

	private long initFrame;
	private int videoFrameIndex;
	private long frameInterval;

	public void startVideo(VideoRenderer videoRenderer, AudioRenderer audioRenderer) {
		this.videoRenderer = (OpenGLVideoRenderer) videoRenderer;
		this.audioRenderer = audioRenderer;

		try {
			this.audioRenderer.init(this.audioStream, this.frameRate);
		} catch (IOException exc) {
			throw new IllegalStateException(exc);
		}

		this.videoStream.startReadLoop();
		this.videoStream.startDecodeLoop();
		this.startDisplayLoop();
	}
	private AudioRenderer audioRenderer;

	public void init() {
		initFrame = System.nanoTime();
		videoFrameIndex = 0;
		frameInterval = (long) (1000_000_000L / this.frameRate);
	}

	public void sync() {
		int audioFrameIndex = this.getAudioFrameIndex();

		while (videoRenderer.isVisible()) {

			boolean doWait;
			switch (audioFrameIndex) {
				case -2:
					// reached end of audio
					return;

				case -1:
					// sync video with clock
					doWait = videoFrameIndex * frameInterval > System.nanoTime() - initFrame;
					break;

				default:
					// sync video with audio
					doWait = videoFrameIndex > audioFrameIndex;
					break;
			}

			if (!doWait) {
				break;
			}

			HighLevel.sleep(1);

			if (audioFrameIndex >= 0) {
				audioFrameIndex = this.getAudioFrameIndex();
			}
		}
	}
	public void loop(){
		this.sync();

		// render
		long frameRenderTime;
		{
			long t0 = System.nanoTime();
			this.videoRenderer.render(rgba);
			long t1 = System.nanoTime();
			frameRenderTime = t1 - t0;

			this.videoStream.releaseVideoFrame(rgba);
		}

		videoFrameIndex++;
		videoFramerate++;

		// stats
		if (System.nanoTime() > secondStarted + 1000_000_000L) {
			videoRenderer.setStats(//
					+videoFramerate + "fps " + //
							"(receiving: " + (videoStream.frameReadingTime / 1000000L) + "ms, " + //
							"decoding jpeg: " + (videoStream.frameDecodingTime / 1000000L) + "ms on " + VideoStream.JPEG_DECODER_THREADS + " threads, " + //
							"rendering: " + (frameRenderTime / 1000000L) + "ms)");
			videoFramerate = 0;
			secondStarted += 1000_000_000L;
		}

		rgba = this.videoStream.takeVideoFrame();
	}
	public boolean loopEnd(){
		return videoRenderer.isVisible() && rgba != null;
	}
	public void runDisplayLoop() {

		System.out.println("Video buffering...");
		rgba = this.videoStream.takeVideoFrame();
		if (rgba == null) {
			System.out.println("no initial frame");
			return;
		}
		Dimension dim = new Dimension(this.videoStream.getWidth(), this.videoStream.getHeight());
		System.out.println("Video metadata: " + dim.width + " x " + dim.height + " @ " + this.frameRate + "Hz");

		secondStarted = System.nanoTime();
		videoFramerate = 0;

		this.init();

		videoRenderer.init(dim);
	}

	public void finalizeLoop(){
		System.out.println("Image Queue: EOF");
		try {
			this.close();
		} catch (IOException exc) {
			exc.printStackTrace();
		}
		System.out.println("Ended");
		System.out.println(Display.getTitle());
		//AL.destroy();
		if(endListener != null)
			endListener.onRender();
		HighLevel.sleep(1000L);
	}
	@Override
	public void close() throws IOException {
		Streams.safeClose(videoRenderer);
		Streams.safeClose(videoStream);
		Streams.safeClose(audioStream);
	}
}