package net.indiespot.media.impl;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import net.indiespot.media.VideoStream;


import craterstudio.data.ByteList;

public class MjpegVideoStream extends VideoStream {
	private final InputStream videoStream;

	public MjpegVideoStream(InputStream mjpegStream, int frameRate) {
		super(frameRate);

		this.videoStream = new BufferedInputStream(mjpegStream);
	}

	@Override
	protected void runReadLoop() {
		ByteList jpeg = new ByteList();

		try {
			while (true) {
				long t0 = 0, t1 = 0;
				int prev = 0;
				while (true) {
					int got = videoStream.read();
					if (got == -1) {
						if (jpeg.size() == 0) {
							this.putFrameData(null);
							return;
						}
						throw new EOFException();
					}
					jpeg.add((byte) got);

					// what are the odds?
					if (prev == 0xff && got == 0xd9) { // EOI / EndOfImage
						t1 = System.nanoTime();
						frameReadingTime = t1 - t0;

						byte[] data = jpeg.toArray();
						jpeg.clear();
						this.putFrameData(data);

						t0 = System.nanoTime();
					}

					prev = got;
				}
			}
		} catch (IOException exc) {
			// ignore
		}

		this.putFrameData(null);
		System.out.println("Byte Stream: EOF");
	}

	@Override
	public void close() throws IOException {
		videoStream.close();
		pool.shutdown();
		threadDecodeLoop.interrupt();
		threadReadLoop.interrupt();

	}
}
