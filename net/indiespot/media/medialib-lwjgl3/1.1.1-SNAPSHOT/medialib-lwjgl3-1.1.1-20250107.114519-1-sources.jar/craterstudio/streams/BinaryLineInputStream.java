/*
 * Created on 4 jun 2010
 */

package craterstudio.streams;

import craterstudio.io.Streams;
import java.io.InputStream;

public class BinaryLineInputStream extends AbstractInputStream {
    public BinaryLineInputStream(InputStream backing) {
        super(backing);
    }

    public String readLine() {
        return Streams.binaryReadLineAsString(this.backing);
    }
}
