package net.indiespot.media;

import craterstudio.data.ByteList;
import craterstudio.text.TextValues;
import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;

public abstract class AudioRenderer implements Closeable {
    protected AudioStream audioStream;
    protected float frameRate;
    private byte[] largest;
    private final int[] samplesInBuffers = new int[2];
    protected final ByteBuffer[] bufferDuo = new ByteBuffer[2];
    private final ByteList bufferIndexList = new ByteList();

    void init(AudioStream audioStream, float frameRate) throws IOException {
        this.audioStream = audioStream;
        this.frameRate = frameRate;

        if (this.audioStream.numChannels != 2) {
            throw new IllegalStateException();
        }
        if (this.audioStream.bytesPerSample != 2) {
            throw new IllegalStateException();
        }

        samplesInBuffers[0] = (int) Math.floor(this.audioStream.sampleRate / frameRate);
        samplesInBuffers[1] = (int) Math.ceil(this.audioStream.sampleRate / frameRate);
        double samplesPerSecond = this.audioStream.sampleRate / (double) frameRate;

        this.calcSyncPattern(samplesPerSecond);

        for (int i = 0; i < bufferDuo.length; i++) {
            bufferDuo[i] = ByteBuffer.allocateDirect(
                    samplesInBuffers[i] * (this.audioStream.numChannels + this.audioStream.bytesPerSample));
        }

        System.out.println("Audio metadata: " + this.audioStream.sampleRate() + "Hz, " //
                + this.audioStream.numChannels + " channels, " //
                + (this.audioStream.bytesPerSample * 8) + " bit / sample, " + this.audioStream.sampleCount
                + " samples");

        largest = new byte[Math.max(bufferDuo[0].capacity(), bufferDuo[1].capacity())];
    }

    private void calcSyncPattern(double samplesPerSecond) {
        double bestHourlyError = Integer.MAX_VALUE;
        int bestHourlyErrorIndex = -1;

        double prevErr = 1.0;
        for (int i = 0; i < 10_000; i++) {
            double currErr = (samplesPerSecond * (i + 1)) % 1.0;
            int picked = ((currErr > prevErr) ? 0 : 1);
            prevErr = currErr;

            bufferIndexList.add((byte) picked);

            double hourlyError = this.calcHourlyError();
            if (hourlyError < bestHourlyError) {
                bestHourlyError = hourlyError;
                bestHourlyErrorIndex = i;
            }
        }

        while (bufferIndexList.size() > bestHourlyErrorIndex + 1) {
            bufferIndexList.removeLast();
        }

        System.out.println("Audio hourly sync error: " + TextValues.formatNumber(calcHourlyError(), 2)
                + "sec, using pattern of " + bufferIndexList.size() + " switches");
    }

    private double calcHourlyError() {
        int totalSamples = 0;
        for (int i = 0; i < bufferIndexList.size(); i++) {
            totalSamples += samplesInBuffers[bufferIndexList.get(i)];
        }

        double desired = (audioStream.sampleRate / frameRate);
        double actual = (double) totalSamples / bufferIndexList.size();
        return (actual - desired) * 3600.0;
    }

    private int loadIndex = 0;
    private int audioFrame = 0;

    public int getAudioFrameIndex() {
        return audioFrame;
    }

    protected void incAudioFrameIndex() {
        this.audioFrame++;
    }

    public abstract boolean tick();

    public ByteBuffer loadNextSamples() {
        try {
            // switch between big and small buffer
            ByteBuffer buffer = bufferDuo[bufferIndexList.get(loadIndex++ % bufferIndexList.size())];
            audioStream.readSamples(largest, 0, buffer.capacity());

            buffer.clear();
            buffer.put(largest, 0, buffer.capacity());
            buffer.flip();

            return buffer;
        } catch (IOException exc) {
            return null;
        }
    }

    public void close() throws IOException {
        this.audioStream.close();
    }
}
