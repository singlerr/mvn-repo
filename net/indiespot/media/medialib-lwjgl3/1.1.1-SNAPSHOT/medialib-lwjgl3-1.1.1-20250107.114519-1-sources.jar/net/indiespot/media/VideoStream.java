package net.indiespot.media;

import craterstudio.func.Transformer;
import craterstudio.util.concur.LockStepExecutor;
import craterstudio.util.concur.SimpleBlockingQueue;
import de.matthiasmann.jpegdecoder.JPEGDecoder;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public abstract class VideoStream implements Closeable {

    public static final int JPEG_DECODER_THREADS =
            Math.min(4, Runtime.getRuntime().availableProcessors());

    private final SimpleBlockingQueue<byte[]> frameDataQueue;
    private final SimpleBlockingQueue<ByteBuffer> frameImageQueue;
    private final SimpleBlockingQueue<ByteBuffer> freedImageQueue;
    protected volatile long frameReadingTime;
    protected volatile long frameDecodingTime;

    protected Thread threadReadLoop;
    protected Thread threadDecodeLoop;

    protected ExecutorService pool;

    public VideoStream(int frameRate) {
        this.frameDataQueue = new SimpleBlockingQueue<>(3);
        this.frameImageQueue = new SimpleBlockingQueue<>(2 + JPEG_DECODER_THREADS);
        this.freedImageQueue = new SimpleBlockingQueue<>();
    }

    private volatile int imageWidth = -1;
    private volatile int imageHeight = -1;

    public int getWidth() {
        return imageWidth;
    }

    public int getHeight() {
        return imageHeight;
    }

    //

    protected void putFrameData(byte[] frameData) {
        this.frameDataQueue.put(frameData);
    }

    public ByteBuffer takeVideoFrame() {
        return this.frameImageQueue.take();
    }

    public void releaseVideoFrame(ByteBuffer rgba) {
        rgba.clear();
        this.freedImageQueue.put(rgba);
    }

    protected void startReadLoop() {
        threadReadLoop = new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        runReadLoop();
                    }
                },
                "VideoPlayer-ReadLoop");
        threadReadLoop.start();
    }

    protected void startDecodeLoop() {
        threadDecodeLoop = new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        runDecodeLoop();
                    }
                },
                "VideoPlayer-DecodeLoop");
        threadDecodeLoop.start();
    }

    protected abstract void runReadLoop();

    protected void runDecodeLoop() {
        pool = Executors.newFixedThreadPool(JPEG_DECODER_THREADS, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable task) {
                return new Thread(task, "VideoPlayer-DecodeLoop-Worker");
            }
        });

        LockStepExecutor<byte[], ByteBuffer> lockstepper = new LockStepExecutor<>(pool);

        Transformer<byte[], ByteBuffer> transformer = new Transformer<byte[], ByteBuffer>() {

            @Override
            public ByteBuffer transform(byte[] value) {
                try {
                    JPEGDecoder decoder = new JPEGDecoder(new ByteArrayInputStream(value));

                    if (!decoder.startDecode()) {
                        throw new IllegalStateException();
                    }

                    int rows = decoder.getNumMCURows();

                    int w = decoder.getImageWidth();
                    int h = decoder.getImageHeight();
                    int stride = w * 4;

                    imageWidth = w;
                    imageHeight = h;

                    ByteBuffer rgba = freedImageQueue.poll();
                    if (rgba == null) {
                        rgba = ByteBuffer.allocateDirect(stride * h);
                    }

                    decoder.decodeRGB(rgba, stride, rows);
                    rgba.flip();
                    return rgba;
                } catch (Exception exc) {
                    exc.printStackTrace();
                    return null;
                }
            }
        };

        boolean eof = false;

        do {
            for (int i = 0; i < JPEG_DECODER_THREADS && !eof; i++) {
                byte[] jpeg = this.frameDataQueue.take();
                if (!(eof |= (jpeg == null))) {
                    lockstepper.addInput(jpeg);
                }
            }

            List<ByteBuffer> outputs;
            {
                long t0 = System.nanoTime();
                outputs = lockstepper.lockstep(transformer);
                long t1 = System.nanoTime();
                frameDecodingTime = (t1 - t0) / JPEG_DECODER_THREADS;
            }

            for (ByteBuffer output : outputs) {
                frameImageQueue.put(output);
            }
        } while (!eof);

        frameImageQueue.put(null);
        System.out.println("Data Queue: EOF");
    }
}
