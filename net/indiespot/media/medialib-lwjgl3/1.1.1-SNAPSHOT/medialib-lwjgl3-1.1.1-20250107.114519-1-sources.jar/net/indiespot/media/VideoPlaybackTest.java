package net.indiespot.media;

import java.io.File;
import net.indiespot.media.impl.FFmpegVideoPlayback;
import net.indiespot.media.impl.OpenALAudioRenderer;
import net.indiespot.media.impl.OpenGLVideoRenderer;

class VideoPlaybackTest {
    public static void main(String[] args) throws Exception {

        File movieFile = new File(args[0]);

        VideoRenderer videoRenderer = new OpenGLVideoRenderer(movieFile.getName());
        AudioRenderer audioRenderer = new OpenALAudioRenderer();

        VideoPlayback playback = new FFmpegVideoPlayback(movieFile);
        playback.startVideo(videoRenderer, audioRenderer);
    }
}
