package net.indiespot.media.impl;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import net.indiespot.media.AudioStream;
import net.indiespot.media.VideoPlayback;
import net.indiespot.media.VideoStream;

public class FFmpegVideoPlayback extends VideoPlayback {
    public FFmpegVideoPlayback(File movieFile) throws IOException {
        super( //
                frameRate(movieFile), //
                video(movieFile), //
                audio(movieFile) //
                );
    }

    private static final ThreadLocal<Float> framerate = new ThreadLocal<>();

    private static float frameRate(File movieFile) throws IOException {
        float framerate = FFmpeg.extractFramerate(movieFile);
        FFmpegVideoPlayback.framerate.set(Float.valueOf(framerate));
        return framerate;
    }

    private static VideoStream video(File movieFile) throws IOException {
        InputStream mjpegStream = FFmpeg.extractVideoAsMJPEG(movieFile);
        return new MjpegVideoStream(mjpegStream, framerate.get().intValue());
    }

    private static AudioStream audio(File movieFile) throws IOException {
        InputStream wavStream = FFmpeg.extractAudioAsWAV(movieFile);
        try {
            return new AudioStream(new DataInputStream(new BufferedInputStream(wavStream)));
        } catch (IOException exc) {
            return null;
        }
    }
}
