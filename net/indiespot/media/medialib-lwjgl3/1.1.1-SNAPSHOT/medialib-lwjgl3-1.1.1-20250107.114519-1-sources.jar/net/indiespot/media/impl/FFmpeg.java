package net.indiespot.media.impl;

import craterstudio.io.Streams;
import craterstudio.streams.NullOutputStream;
import craterstudio.text.Text;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import net.indiespot.media.Extractor;

public class FFmpeg {
    public static String FFMPEG_PATH;
    public static boolean FFMPEG_VERBOSE = false;
    public static String JPEG_QUALITY = "1";

    static {
        String resourceName = "./bin/ffmpeg";
        resourceName += Extractor.is64bit ? "64" : "32";
        if (Extractor.isWindows) {
            resourceName += ".exe";
        }

        FFMPEG_PATH = resourceName;
    }

    public static float extractFramerate(File srcMovieFile) throws IOException {

        Process process = new ProcessBuilder()
                .command( //
                        FFMPEG_PATH, //
                        "-i",
                        srcMovieFile.getAbsolutePath() /*, //
                        "-f",
                        "null" //*/)
                .start();

        float framerate = -1;

        try {
            Streams.asynchronousTransfer(process.getInputStream(), System.out, true, false);
            InputStream stderr = process.getErrorStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(stderr));
            for (String line; (line = br.readLine()) != null; ) {
                System.out.println("ffmpeg: " + line);

                // Look for:
                // "	Stream #0:0: Video: vp6f, yuv420p, 320x240, 314 kb/s, 30 tbr, 1k tbn, 1k tbc"
                // ----------------------------------------------------------^

                if (line.trim().startsWith("Stream #") && line.contains("Video:")) {
                    line = Text.before(line, "tbr,").trim();
                    line = Text.afterLast(line, ", ").trim();

                    framerate = abbreviateNumber(line);
                }
            }

            if (framerate == -1) {
                throw new IllegalStateException("failed to find framerate of video");
            }
            return framerate;
        } finally {
            Streams.safeClose(process);
        }
    }

    private static final Map<Character, Float> unitMap = new HashMap<>();

    static {
        unitMap.put('k', 1_000.0f);
        unitMap.put('M', 1_000_000.0f);
        unitMap.put('B', 1_000_000_000.0f);
    }

    private static float abbreviateNumber(String args) {
        char lastChar = args.charAt(args.length() - 1);
        if (!unitMap.containsKey(lastChar)) return Float.parseFloat(args);

        float numeric = Float.parseFloat(args.substring(0, args.length() - 1));
        return numeric * unitMap.get(lastChar);
    }

    public static void extractVideoAsMJPEG(File srcMovieFile, File dstMjpegFile) throws IOException {
        await(new ProcessBuilder()
                .command( //
                        FFMPEG_PATH, //
                        "-y", //
                        "-i",
                        srcMovieFile.getAbsolutePath(), //
                        "-qscale",
                        JPEG_QUALITY, //
                        // "-ss", "00:05:00.00", //
                        dstMjpegFile.getAbsolutePath() //
                        ));
    }

    public static InputStream extractVideoAsMJPEG(File srcMovieFile) throws IOException {
        return streamData(new ProcessBuilder()
                .command( //
                        FFMPEG_PATH, //
                        "-i",
                        srcMovieFile.getAbsolutePath(), //
                        "-qscale",
                        JPEG_QUALITY, //
                        // "-ss", "00:05:00.00", //
                        "-f",
                        "mjpeg", //
                        "-" //
                        ));
    }

    //

    public static void extractAudioAsWAV(File srcMovieFile, File dstWavFile) throws IOException {
        await(new ProcessBuilder()
                .command( //
                        FFMPEG_PATH, //
                        "-y", //
                        "-i",
                        srcMovieFile.getAbsolutePath(), //
                        "-acodec",
                        "pcm_s16le", //
                        "-ac",
                        "2", //
                        // "-ar", "44100", //
                        // "-ss", "00:05:00.00", //
                        "-f",
                        "wav", //
                        dstWavFile.getAbsolutePath() //
                        ));
    }

    public static InputStream extractAudioAsWAV(File srcMovieFile) throws IOException {
        return streamData(new ProcessBuilder()
                .command( //
                        FFMPEG_PATH, //
                        "-i",
                        srcMovieFile.getAbsolutePath(), //
                        "-acodec",
                        "pcm_s16le", //
                        "-ac",
                        "2", //
                        // "-ar", "44100", //
                        // "-ss", "00:05:00.00", //
                        "-f",
                        "wav", //
                        "-" //
                        ));
    }

    //

    private static void await(ProcessBuilder pb) throws IOException {
        Process process = pb.start();
        Streams.asynchronousTransfer(process.getInputStream(), System.out, true, false);
        Streams.asynchronousTransfer(process.getErrorStream(), System.err, true, false);
        try {
            process.waitFor();
        } catch (InterruptedException exc) {
            throw new IllegalStateException(exc);
        }
    }

    private static InputStream streamData(ProcessBuilder pb) throws IOException {
        Process process = pb.start();
        Streams.asynchronousTransfer(
                process.getErrorStream(), FFMPEG_VERBOSE ? System.err : new NullOutputStream(), true, false);
        return process.getInputStream();
    }
}
