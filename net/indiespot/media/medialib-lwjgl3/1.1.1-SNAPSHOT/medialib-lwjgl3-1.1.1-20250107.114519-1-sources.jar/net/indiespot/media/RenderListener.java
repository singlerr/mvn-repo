package net.indiespot.media;

public interface RenderListener {
    void onRender();
}
